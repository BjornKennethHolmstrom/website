# Sweden governance series — Stage 3 working package

**12 November 2026 | Not publication-cleared.**

1. `parent/sweden-competence-trap-v1.1.en.md` and `.sv.md` — fully compiled corrective drafts of the original report. `parent/sections/` contains 28 editable Markdown section files, same 14-section structure and two languages.
2. `synthesis/01-adaptive-legitimate-governance.en.md` and `.sv.md` — independent conceptual synthesis v0.1.
3. `research/02-validation-plan.en.md` and `.sv.md` — distinct research and validation plan v0.1.
4. `audit/` — editorial decisions, two unified patches, line-level change tables and package manifest.
5. `archive/stage1-revised-unaltered.zip` and `archive/stage2-v0.1.1-unaltered.zip` — original inputs, retained byte-for-byte.

**Caution:** The original Sweden-wide causal hypothesis remains untested. Many legal claims have been source-checked selectively but not approved by Swedish specialists. No new empirical dataset was collected. Working-paper status is intentional.

The synthesis uses source links, a separate provenance statement, and explicit hypothesis/authority distinctions. For actual research, first complete the G0–G2 gates in `research/02-validation-plan.*.md`.
