# Stage 3 editorial dispositions and open gates

**Date:** 12 November 2026. **Scope:** corrective revision of Stage 1, not a silent integration of speculative Stage 2 conclusions.

## Corrected in parent v1.1

- Replaced concealed “Trojan Horse” strategy with explicit, public municipal pilot design.
- Changed the executive diagnosis, Drift Loop, consensus/Jantelagen and integration-warning claims from settled facts into candidates requiring independent tests.
- Replaced “demographic replacement” language; reframed complex population and service-demand change as a possible study topic.
- Replaced claims of mathematical proof of Swedish institutional conditions with conditional-model language; added caveats to each model summary.
- Clarified privacy-enhancing computation does not eliminate legal grounds, necessity, or disclosure/omission harms.
- Narrowed school and housing proposals: no presumed authority to link health and social-services individual records.
- Retained the Sámi-rights and municipal-jurisdiction boundary, and flagged it for expert legal review.
- Harmonized cohort size to 3–5 municipalities; pilot demonstrates feasibility, not causal national effects or subgroup results.
- Reframed policy durability and trust as outcomes with caveats, not self-justifying performance metrics.
- Added Appendix F.4 explaining the relationship to Stage 2 and Stage 3 and outstanding legal checks.

## Not established or still outstanding

- The Competence Trap and distinctively Swedish Drift Loop remain untested as general mechanisms.
- The European country-triptych remains interpretive, not comparative causal research.
- No protected administrative records or original legal case files were analyzed for the synthesis.
- Legal applicability of each proposed data flow must be checked by Swedish counsel, including health, school, social services and private providers.
- The legal consequences of consultation omissions, the scope of specific permit decisions and the practical bearing of international norms require Swedish specialist review.
- Stage 2 v0.1.1 remains a research working draft with its own unresolved release gate.
- Costs, comparative effectiveness and selection of 3–5 municipalities remain project proposals, not validated forecasts.

## Release convention

Label parent **Corrective working draft v1.1** and synthesis **Conceptual working paper v0.1**. Nothing in this package claims peer review, human legal sign-off, empirical causal validation, or implementation authority.
