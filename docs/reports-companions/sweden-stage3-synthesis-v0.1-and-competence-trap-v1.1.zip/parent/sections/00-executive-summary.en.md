# Sweden — The Competence Trap

## Executive Summary

Sweden is one of the best-governed societies on earth. By almost any international measure—trust, transparency, welfare delivery, digital infrastructure—it sits near the top. The machine hums. And precisely because it hums, something important has become difficult to see.

This report advances the **Competence Trap** as a hypothesis about institutional adaptation: *the better a system performs under known conditions, the harder it may become to recognize when those conditions have changed.* Sweden retains major governance strengths, but the report asks whether its ways of detecting, interpreting, and responding to change have kept pace with increasingly complex circumstances. The argument is a diagnostic framework to be tested, not an established general law.

The **Swedish Drift Loop** is a proposed pattern—high trust and delegation may sometimes be followed by missed or discounted signals, accumulated problems, a focusing event, and compressed correction. Selected examples illustrate the possibility but do not establish the sequence or its causes. Attention scarcity, organizational friction, political competition, capacity limits and rational responses to new information remain rivals.

The proposed underlying condition is a **feedback deficit**: uneven capacity to detect signals early, share them when lawful and appropriate, interpret conflicting evidence, and act before problems compound. The degree to which this explanation accounts for Sweden’s challenges, relative to political incentives, resources, rights conflicts, and other causes, remains an empirical question.

Three candidate mechanisms could contribute to a feedback deficit:

- **The Data Archipelago.** Sweden combines advanced digital services with fragmented responsibilities, datasets, and analytical workflows. The Public Access to Information and Secrecy Act (2009:400) and the GDPR set safeguards, but information sharing is not categorically prohibited: legal possibilities expanded in 2025, especially for crime prevention and related purposes. The question is where lawful sharing, interoperable systems, and cross-agency learning still fall short—not whether agencies are wholly unable to exchange information.

- **Consensus filtering (with Jantelagen as a metaphor).** Consensus practices may, under some conditions, discourage dissenting evidence. The proposed *Mean-Reversion Fallacy* is an additional hypothesis about how decision-makers interpret trends, not an established characteristic of Swedish institutions. Neither claim should be used to explain social outcomes without direct evidence.

- **The Municipal Capacity Trap.** Some municipalities may have less flexibility than their statutory responsibilities require, even after tax-base and cost equalisation. The size and consequences of such mismatches must be demonstrated for specific functions rather than inferred from local tax dependence alone.

These mechanisms may reinforce one another and help explain delays between signal and response. Whether they do so consistently, and which other causes matter, requires empirical testing.

The report proposes four areas for **bounded institutional experimentation**: lawful, purpose-specific information exchange and public-interest analysis; structured disagreement and accessible deliberation; locally appropriate authority matched to capacity and accountability; and independently evaluated Framtidskommuner testbeds. These are proposals, not proven prerequisites for policy success.

It proposes, but does not establish, that institutional self-protection, consensus norms and fragmented mandates can sometimes impede reform. Its transition approach is transparent voluntary experimentation, public disclosure of objectives and limitations, independent evaluation, and adoption only where evidence warrants it.

**A proposed first step** is a network of 3–5 **Framtidskommuner** (Future Municipalities): voluntary pilots combining protected cross-agency learning, structured citizen deliberation, and bounded fiscal and legal flexibility. Each pilot would require a lawful basis for any data use, meaningful participation by affected groups, independent evaluation, and a way to identify harms as well as gains. Success must be judged by public outcomes and rights protection alongside feedback velocity and policy durability.

The European dimension completes the series as an **interpretive comparison**: Germany is examined through an execution-deficit hypothesis, France through an integration-deficit hypothesis, and Sweden through a feedback-deficit hypothesis. These are contrasting analytical lenses, not validated national rankings or exclusive explanations of each country.

Sweden can test whether its strong institutions would benefit from more permeable feedback, more explicit trade-offs, and more meaningful routes from evidence to accountable action. This remains a proposal, not an established diagnosis of what Swedish success has concealed.

---
