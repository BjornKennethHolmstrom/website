# Sverige — Kompetensfällan

## Sammanfattning

Sverige är ett av de bäst styrda samhällena på jorden. Oavsett vilket internationellt mått man använder – tillit, transparens, välfärdsleverans, digital infrastruktur – ligger landet nära toppen. Maskineriet surrar. Och just för att det surrar har något viktigt blivit svårt att se.

Denna rapport för fram **kompetensfällan** som en hypotes om institutionell anpassning: *ju bättre ett system presterar under kända förhållanden, desto svårare kan det bli att upptäcka när förhållandena förändras.* Sverige har fortsatt stora styrningsmässiga styrkor, men rapporten undersöker om landets sätt att upptäcka, tolka och reagera på förändring har hållit jämna steg med alltmer komplexa förhållanden. Resonemanget är ett prövbart diagnostiskt ramverk, inte en fastslagen generell lag.

Den **svenska driftloopen** är ett föreslaget mönster: tillit och delegering kan ibland följas av sen signalhantering, ackumulerade problem, en uppmärksamhetsskapande händelse och snabb korrigering. Exemplen visar möjligheten, inte förloppets orsak. Begränsad uppmärksamhet, organisatorisk friktion, politisk konkurrens, resursbrist och rimlig anpassning till ny information är alternativ.

Den föreslagna underliggande mekanismen är ett **återkopplingsunderskott**: ojämn förmåga att upptäcka signaler tidigt, dela dem när det är lagligt och lämpligt, tolka motstridig evidens och handla innan problem växer. I vilken grad detta förklarar Sveriges utmaningar, jämfört med politiska incitament, resurser, rättighetskonflikter och andra orsaker, är en empirisk fråga.

Tre möjliga mekanismer kan bidra till återkopplingsunderskottet:

- **Dataarkipelagen.** Sverige kombinerar avancerade digitala tjänster med splittrade ansvarsförhållanden, datamängder och analysprocesser. Offentlighets- och sekretesslagen (2009:400) och GDPR ställer skyddskrav, men informationsutbyte är inte generellt förbjudet: de rättsliga möjligheterna utvidgades under 2025, särskilt för brottsförebyggande och närliggande ändamål. Frågan är var laglig delning, interoperabilitet och gemensamt lärande fortfarande brister – inte om myndigheter helt saknar möjlighet att utbyta uppgifter.

- **Konsensusfiltrering (med Jantelagen som metafor).** Konsensusnormer kan ibland missgynna avvikande evidens. Det föreslagna *medelvärdesåtergångsfelslutet* är en separat hypotes om hur trender tolkas, inte ett belagt kännetecken för svenska institutioner. Inget av antagandena bevisar en kausal förklaring av samhällsutfall.

- **Den kommunala kapacitetsfällan.** Kommuner kan ibland sakna handlingsutrymme i förhållande till sitt ansvar, även efter inkomst- och kostnadsutjämning. Omfattning och effekter måste undersökas för specifika verksamheter, inte härledas från det kommunala skattesystemet ensamt.

Dessa mekanismer kan förstärka varandra och bidra till fördröjningar mellan signal och respons. Om de gör det systematiskt, och vilka andra orsaker som spelar roll, behöver prövas empiriskt.

Rapporten föreslår fyra områden för **avgränsade institutionella försök**: lagligt och ändamålsbestämt informationsutbyte och analys i allmänintresset, strukturerad oenighet och tillgänglig deliberation, lokal befogenhet i balans med kapacitet och ansvar samt oberoende utvärderade Framtidskommuner. Detta är förslag, inte bevisade förutsättningar för politiska framgångar.

Rapporten föreslår, men visar inte, att institutionellt självskydd, konsensusnormer och fragmenterade uppdrag ibland kan hindra reformer. Övergångsstrategin bygger på öppet redovisad frivillig försöksverksamhet, offentliggjorda mål och begränsningar, oberoende utvärdering och spridning först när evidensen motiverar det.

**Ett föreslaget första steg** är ett nätverk av 3–5 **Framtidskommuner**: frivilliga piloter som förenar rättssäkert lärande över myndighetsgränser, strukturerad medborgardeliberation och avgränsad ekonomisk och juridisk flexibilitet. Varje pilot behöver rättslig grund för personuppgiftsbehandling, verkligt deltagande för berörda grupper, oberoende utvärdering och metoder för att fånga såväl skador som vinster. Framgång ska bedömas genom samhällsutfall och rättighetsskydd vid sidan av återkopplingshastighet och reformers varaktighet.

Den europeiska dimensionen fullbordar serien som en **tolkande jämförelse**: Tyskland undersöks genom en hypotes om verkställighetsunderskott, Frankrike genom en hypotes om integrationsunderskott och Sverige genom en hypotes om återkopplingsunderskott. Detta är jämförande analyslinser, inte validerade rangordningar eller uttömmande förklaringar av respektive land.

Sverige kan pröva om dess starka institutioner skulle vinna på mer mottaglig återkoppling, tydligare avvägningar och bättre vägar från evidens till ansvarsutkrävande handling. Det är ett förslag, inte en fastställd diagnos av vad svensk framgång har dolt.

---
