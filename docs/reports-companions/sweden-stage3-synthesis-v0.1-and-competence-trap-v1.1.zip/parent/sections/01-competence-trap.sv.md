## 1. Kompetensfällan

### 1.1 Den svenska driftloopen

Sverige misslyckas inte. Det driver.

Mönstret är mindre dramatiskt än den franska reform-explosion-reträtt-cykeln. Det saknar den synliga frustrationen från tysk infrastrukturparalys. Men det är inte mindre systematiskt. Ett problem samlas – tyst, i utkanten av det offentliga samtalet, i statistiken som ingen enskild myndighet har ansvar för att koppla ihop. Det är synligt för dem som tittar direkt på det, men det har ännu inte passerat tröskeln där det bredare systemet måste erkänna dess existens. I åratal, ibland decennier, ackumuleras det.

Sedan förändras något. En utlösande händelse – ett upplopp, ett valresultat, en internationell kris – tvingar fram frågan i offentligheten. Det offentliga samtalet, som artigt hade ignorerat problemet eller behandlat det som en anomali, svänger abrupt. Samma institutioner som tålmodigt hade väntat på att trenden skulle vända av sig själv tvingas nu agera med skyndsamhet. De gör det – kompetent, beslutsamt, med den svenska statens fulla kraft bakom sig. Men åtgärden är komprimerad, reaktiv och ofta snävare än problemet den adresserar. Den underliggande arkitekturen som fördröjde erkännandet förblir oförändrad. Tilliten urholkas något. Systemet stabiliseras. Och loopen börjar igen.

Den föreslagna **svenska driftloopen** är en sekvens att pröva: tillit och delegering, möjlig fördröjning av signaler, en utlösande händelse och en omfattande korrigering. Om den är vanlig, specifik för Sverige eller betingad av tidigare framgång är okänt. Varje fall kräver daterade handlingar och jämförelse med alternativa orsaker.

Den föreslagna loopen kan verka inom flera sakområden, men exemplen behöver verifieras var för sig. Bostadsbrist och segregation, integrationsdebatter, energival och Natomsvängningen 2022 har skilda politiska och materiella orsaker. Att de liknar ett gemensamt mönster är en ledtråd, inte bevis för att samma mekanism har påvisats inom alla fyra områden.

Sverige misslyckas inte slumpmässigt. Det kör en stabil loop. Loopen är symptomet på ett specifikt, diagnostiserbart underskott – ett återkopplingsunderskott – som kan adresseras när det väl har förståtts. Men att förstå det kräver att man ser förbi ytan på ett system som, enligt de flesta konventionella mått, verkar fungera utomordentligt väl.

---

### 1.2 Ytberättelsen: En maskin som fungerar

Och den fungerar. Detta måste sägas tydligt, eftersom analysen som följer lätt kan misstolkas som en kritik av den svenska modellen, och det är den inte.

Vid nästan varje internationell jämförelse presterar Sverige i toppen eller nära toppen. Tilliten till institutioner, även om den har sjunkit från historiska toppnivåer, förblir bland de högsta i världen. Korruptionen är försvinnande låg. Välfärdsstaten levererar – sjukvård, utbildning, socialt stöd, föräldraledighet, pensioner – på en nivå av omfattning och kvalitet som de flesta länder bara kan sträva efter. Den digitala infrastrukturen är i världsklass. Ekonomin är innovativ, exportorienterad och motståndskraftig. Det internationella varumärket är starkt. När globala rankningar av styrningskvalitet, livskvalitet eller sociala framsteg publiceras, återfinns Sverige tillförlitligt i toppskiktet, ofta bland de fem bästa.

Dessa resultat är verkliga. De är produkten av generationer av pragmatisk, evidensbaserad institutionell utformning – folkhemstraditionen som byggde ett av de mest jämlika och stabila samhällena i modern historia. Den svenska staten är inte en fallerande maskin. Den är en exceptionellt välunderhållen sådan. Tjänstemännen som driver den är i stort sett kompetenta och hängivna. Politikerna som styr den är, med jämförande mått, seriösa och välinriktade. Medborgarna som finansierar den genom några av världens högsta skattetryck gör det till stor del frivilligt, eftersom de tror – med rätta – att de får värde i gengäld.

Detta är ytberättelsen. Den är korrekt så långt den sträcker sig. Och just för att den är korrekt döljer den något viktigt.

---

### 1.3 Kompetensfällan, namngiven

Här är det centrala begreppet i denna rapport. Det är bedrägligt enkelt, och dess implikationer är mindre bekväma än de först verkar.

**Kompetensfällan:** *Ju bättre ett system presterar under kända förhållanden, desto svårare blir det att upptäcka när dessa förhållanden har förändrats.*

Detta behöver inte vara ett misslyckande för den svenska modellen. Det är en tänkbar risk i högpresterande system, inte en fastslagen egenskap hos alla sådana system. Framgång kan skapa tillförsikt; tillförsikt kan minska uppmärksamheten på avvikande signaler; och invanda mätetal kan missa nya förhållanden. Dessa orsakssamband måste prövas mot evidens och alternativa förklaringar.

Många institutioner som bär upp den svenska välfärdsstatsmodellen formades i ett annat socialt och ekonomiskt sammanhang: starkare industriella sysselsättningsmönster, hög organisationsgrad och långsammare teknisk förändring. Sverige har emellertid aldrig varit helt homogent eller institutionellt statiskt; befolkningen har länge omfattat samer och andra nationella minoriteter. Den analytiska frågan är vilka ärvda antaganden som lever kvar i specifika program och beslutsprocesser – inte om hela staten en gång formgavs för en enda enhetlig befolkning.

De flesta av dessa antaganden har urholkats avsevärt. Sverige är nu ett mångkulturellt samhälle med betydande befolkningsgrupper födda utomlands eller med utlandsfödda föräldrar. Industribasen har transformerats – den förblir stark, men sysselsättningens natur, fackföreningarnas roll och kopplingen mellan arbete och gemenskap har förskjutits. Geografisk rörlighet, i kombination med bostadsmarknadens dysfunktion, har koncentrerat möjligheter till urbana kärnor och lämnat peri-urbana och landsbygdskommuner med tunnare skattebaser och växande servicebehov. Den externa miljön – geopolitiskt, teknologiskt, ekologiskt – förändras snabbare än valcykeln kan bearbeta.

Statens arkitektur har emellertid inte uppgraderats i motsvarande grad. Den var aldrig utformad för att uppgradera sig själv. Den var utformad för att köras. Och den körs vackert – inom bandbredden av de förhållanden den kalibrerades för att hantera. Problemet är inte att maskinen går sönder. Det är att miljön runt den har förändrats, och maskinen saknar den sensoriska apparaturen för att upptäcka den fulla omfattningen av denna förändring.

Detta är varför Kompetensfällan är så förrädisk. Ett fallerande system genererar synlig nöd – protester, ekonomisk kontraktion, institutionell kollaps – som framtvingar anpassning. Ett framgångsrikt system genererar motsatsen: aggregerade utfall som förblir inom acceptabla gränser, internationell validering, ett rimligt argument för inkrementell förbättring snarare än strukturell reform. Framgången är inte en illusion. Men den är en partiell vy, och just det självförtroende den inger gör partiskheten svårare att uppfatta.

---

### 1.4 En kort illustration: Nato och loopen

Ett exempel tydliggör mönstret utan att kräva att läsaren navigerar politiskt laddade inrikesdebatter.

I decennier vilade Sveriges säkerhetspolitik på en stabil konsensus: militär alliansfrihet, ett starkt territoriellt försvar och en omsorgsfullt förvaltad relation till Nato som stannade kort om medlemskap. Denna konsensus upprätthölls av expertbedömningar, institutionell kultur och bred politisk enighet. Den var inte irrationell. Den hade tjänat Sverige väl genom kalla kriget och dess efterdyningar.

Säkerhetsmiljön hade förändrats under flera år: Rysslands krig i Georgien 2008, annekteringen av Krim 2014 och ökande säkerhetsoro i Östersjöområdet ingick i den svenska debatten. Sverige fördjupade också sitt praktiska Natosamarbete, bland annat genom ett fördjupat partnerskap 2014 och värdlandsstödsavtalet 2016. Detta visar såväl anpassning som kontinuitet. Om åtgärderna var tillräckliga och om andra vägval hade gett bättre resultat är omstritt.

Rysslands fullskaliga invasion av Ukraina i februari 2022 utlöste en snabb förändring av Sveriges allianspolitik. Regeringen beslutade den 16 maj 2022 att ansöka om Natomedlemskap, Sverige ansökte den 18 maj och blev medlem den 7 mars 2024. Den snabba omsvängningen är förenlig med driftloopen, men bevisar inte i sig att tidigare information hade undertryckts: en stor yttre chock kan också rationellt förändra ett lands bedömning av risker och allianser.

Illustrationen väcker därför en fråga om beslutsprocessen snarare än avgör den. Prövade institutionerna alternativa säkerhetspolitiska utvecklingar i tid, gjorde avvägningarna begripliga och möjliggjorde legitim oenighet? Eller ändrades politiken på ett rimligt sätt när förutsättningarna ändrades? En prövning av driftloopen behöver granska beslutsunderlag, offentlig debatt och alternativa förklaringar – inte härleda ett institutionellt misslyckande enbart ur omsvängningens snabbhet 2022.

---

### 1.5 Sveriges genuina fördelar

Innan vi går vidare till diagnosen är det värt att stanna upp och erkänna vad Sverige har som talar för landet. Kompetensfällan är en genuin begränsning, men resurserna som finns tillgängliga för att adressera den är lika genuina.

Sverige har en av världens högsta basnivåer av social tillit. Denna tillit är inte jämnt fördelad – den är lägre bland utlandsfödda invånare, bland unga, bland dem i prekära ekonomiska situationer – men den förblir, sammantaget, en djupgående demokratisk resurs. Tillit innebär att medborgare är villiga att finansiera ambitiösa offentliga program. Det innebär att institutioner kan agera utan att möta omedelbar delegitimisering. Det innebär att det politiska samtalet, även om det hårdnar, ännu inte har kollapsat i den tribala polarisering som paralyserar andra demokratier. Tillit är grunden på vilken en sensorisk uppgradering kan byggas – eftersom tillit möjliggör ärliga samtal om vad som inte fungerar, utan att dessa samtal utlöser ett kollaps i förtroende.

Sverige har också en stark institutionell kultur av *saklighet* – faktabaserad, rationell överläggning. Denna kultur är under press, och dess tendens att dämpa obekväma signaler är en del av diagnosen. Men det underliggande engagemanget för evidens, för pragmatisk problemlösning och för inkrementell förbättring förblir en genuin tillgång. Det är samma kultur som byggde folkhemmet från första början – inte genom ideologi, utan genom en uthållig, flergenerationsprocess av institutionell experimentation och förfining.

Den digitala infrastrukturen är i världsklass. Personnumret tillhandahåller en unik identifierare som, med lämpliga integritetsskydd, skulle kunna möjliggöra systemisk avkänning på en upplösning som de flesta länder inte kan matcha. Den kommunala strukturen, även om den är fångad i paradoxen formell subsidiaritet-funktionell centralisering, tillhandahåller ett distribuerat nätverk av styrenheter som skulle kunna bli laboratorier för adaptiv experimentation om de gavs den fiskala och legala autonomin att göra det.

Och Sveriges kulturella koppling till naturen, dess globala utblick och dess tradition av långsiktigt tänkande – *lagom*-sensibiliteten som värderar balans, tillräcklighet och intergenerationellt ansvar – tillhandahåller ett kulturellt underlag som är ovanligt redo för den typ av holistisk, föregripande styrning som 2000-talet kräver. Kompetensfällan är fortfarande en hypotes. Men Sverige, mer än de flesta länder, har resurserna att ta sig ur den – om det först kan se att det befinner sig i en.

---

### 1.6 Den verkliga frågan

Vid det här laget kan en välbekant otålighet uppstå. *Så vad bör Sverige göra? Vilka reformer behövs?*

Argumentet i denna rapport är att själva formen på dessa frågor speglar Kompetensfällan själv. De antar att problemet är en känd policymässig lucka som den existerande arkitekturen, rätt riktad, kan fylla. Men arkitekturen var inte utformad för att se de luckor som nu betyder mest. Att be den identifiera de reformer den behöver är att be en maskin att diagnostisera sin egen sensors begränsningar – samtidigt som den endast använder dessa sensorer för att göra det.

Den verkliga frågan är inte "Vad bör Sverige göra annorlunda?" Den är "Hur blir Sverige kapabelt att avkänna vad det för närvarande inte kan – och att agera på den avkänningen innan signalerna har ackumulerats till kriser?"

Resten av denna rapport ägnas åt den frågan. Den diagnosticerar återkopplingsunderskottet i dess tre strukturella mekanismer: Dataarkipelagen, den kulturella variansdämpningen och den kommunala kapacitetsfällan. Den beskriver hur ett bygge av återkopplingsinfrastruktur skulle se ut i praktiken. Den namnger det politiska immunsystem som kommer att motstå varje sådan ansträngning. Och den föreslår ett konkret första steg: ett antal *framtidskommuner* – framtidskommuner – utformade för att maximera återkopplingshastigheten och demonstrera att ett annat sätt att avkänna och reagera är möjligt.

Sverige behöver inte bli mer kompetent. Det är redan bland de mest kompetenta samhällena på jorden. Det behöver bli mer *genomsläppligt* – för de signaler dess nuvarande arkitektur filtrerar bort, för de verkligheter dess mätetal missar, och för den framtid dess framgång har gjort svårare att se. Det är inte ett misslyckande för den svenska modellen. Det är nästa kapitel i den pragmatiska tradition som byggde den.

---

---
