## 2. Återkopplingsunderskottet: En ny diagnos

### 2.1 Vad "återkopplingskapacitet" betyder

Termen "återkoppling" har en vardaglig klang. I dagligt bruk associeras den med utvärderingssamtal, kundundersökningar, det årliga samtalet mellan chef och medarbetare. Det är inte vad som avses här.

Återkopplingskapacitet, i den mening som är relevant för Sveriges nuvarande situation, är förmågan hos ett styrsystem att upptäcka oroande signaler tidigt, att dela dessa signaler över institutionella gränser utan förvrängning eller fördröjning, att erkänna deras implikationer ärligt – även när dessa implikationer utmanar den rådande konsensusen – och att agera på dem innan de förvärras till kriser.

Detta är inte en enskild förmåga. Det är en sammansättning av avkänning, överföring, tolkning och respons, fördelad över institutioner, kulturella vanor, rättsliga ramverk och kognitiva färdigheter. När återkopplingskapaciteten är hög kan ett samhälle upptäcka en bostadsmarknadsstörning, en integrationsutmaning eller en förskjutning i säkerhetsmiljön medan den fortfarande är hanterbar – och kan svara med åtgärder kalibrerade efter det framväxande problemets skala snarare än den slutliga krisens skala. När återkopplingskapaciteten är låg färdas samma signaler långsamt, om alls. De filtreras, mjukas upp och ibland aktivt dämpas. När de slutligen blir obestridliga har fönstret för kalibrerad respons stängts, och det enda återstående alternativet är den typ av komprimerad, reaktiv korrigering som den Svenska driftloopen beskriver.

Sverige saknar inte kompetens. Dess institutioner bemannas av kapabla, hängivna yrkespersoner. Dess offentliga förvaltning är jämförelsevis fri från korruption och politisk inblandning. Dess politiska kultur, även om den är alltmer ansträngd, förblir mer deliberativ och evidensbaserad än de flesta. Underskottet ligger inte i människornas kvalitet eller processernas integritet. Det ligger i arkitekturen som bestämmer vad dessa människor och processer kan se.

Rapporten undersöker tre möjliga och delvis samverkande mekanismer: fragmenterat lärande mellan organisationer, potentiell konformitetspress och obalans mellan lokalt ansvar och kapacitet. Hur vanliga de är, hur de samverkar och vilken förklaringskraft de har måste prövas empiriskt.

---

### 2.2 Dataarkipelagen: Varför Sverige inte kan se sig självt

Sveriges personnummer och administrativa register kan under lämpliga rättsliga och organisatoriska förutsättningar stödja longitudinella analyser av hög kvalitet. De skapar inte i sig något allmänt system för myndighetsövergripande personuppgiftssamkörning eller någon generell rätt att koppla samman individuppgifter. Sådan behandling kräver avgränsade ändamål, giltig rättslig grund och efterlevnad av tillämpliga sekretess- och dataskyddsregler.

I praktiken är ansvar, informationssystem, sektorsregler och analyskapacitet fortfarande fördelade mellan myndigheter och förvaltningsnivåer. Men informationsutbyte är inte generellt blockerat. Sedan den 1 april 2025 föreskriver lag (2025:170) vissa uppgiftsskyldigheter gentemot brottsbekämpande myndigheter; sedan den 1 december 2025 utvidgar en generell sekretessbrytande bestämmelse i 10 kap. 15 a § offentlighets- och sekretesslagen (2009:400) möjligheten till utbyte mellan myndigheter för angivna ändamål, bland annat brottsförebyggande arbete och felaktiga utbetalningar, med villkor och undantag. Problemet behöver därför undersökas för varje ändamål: vad får delas, vad bör delas och vad hindrar fortfarande användbar gemensam analys?

Gränserna är delvis avsiktliga: sekretess, ändamålsbegränsning och dataskydd skyddar människor mot missbruk av känsliga uppgifter. Andra hinder kan vara oförenliga system, otillräckliga resurser för samverkan, oklart ansvar eller osäkerhet om tillämpningen av nyligen ändrade regler. Ökad informationsdelning kan förbättra samordningen men också skapa oproportionerlig övervakning, profilering och avhållande effekter. Uppgiften är att identifiera den minsta lagliga och effektiva åtgärden för en påvisad informationsbrist.

Detta är **dataarkipelagen** som analytisk metafor: inte slutna öar utan broar, utan ojämnt sammankopplade myndigheter vars befogenheter, tekniska system och incitament inte automatiskt skapar gemensamt lärande. Skolfrånvaro, kommunal ekonomi och rekrytering till kriminalitet kan undersökas med olika datamängder, aggregeringsnivåer och skyddsåtgärder. Den viktiga prövningen är om tillgänglig evidens faktiskt sammanförs för legitima beslut – inte det obelagda antagandet att ingen myndighet någonsin kan se sambanden.

Detta är det djupare felet under ytan av Sveriges hyllade digitala transformation. Sverige har byggt en av världens mest avancerade **transaktionella** digitala stater. BankID tillåter medborgare att autentisera sig sömlöst över hundratals tjänster. Swish möjliggör omedelbara betalningar. Skattedeklarationen är så automatiserad att den för många medborgare inte kräver mer än en sms-bekräftelse. Detta är genuin prestation, och det är med rätta beundrat. Men transaktionell digitalisering är inte samma sak som systemisk synlighet. Staten har digitaliserat *effektivitet* – punkt-till-punkt-interaktionerna mellan medborgare och myndighet – utan att digitalisera *meningsskapande* – nod-till-nätverk-mönstren som framträder först när signaler från flera myndigheter kopplas samman.

Spänningen är ändå viktig: mycket effektiva digitala tjänster för enskilda är ingen garanti för snabbt lärande över verksamhetsgränser. Sveriges utmaning är att bedöma var befintliga rättsliga möjligheter, interoperabilitet, styrning och utvärdering räcker – och var riktade, integritetsskyddande förbättringar behövs. Dataarkipelagen är därmed en prövbar institutionshypotes, inte ett faktiskt påstående om att svenska myndighetsdata endast får användas för transaktioner.

---

### 2.3 Jantelagen som variansdämpningsalgoritm

Om Dataarkipelagen är återkopplingsunderskottets yttre arkitektur, så är den inre arkitekturen kulturell. Och kulturen har ett namn, även om det oftare åberopas i självironiska skämt än i seriös analys.

Jantelagen – härstammar från en roman från 1933 av Aksel Sandemose, där en fiktiv dansk småstad upprätthåller en oskriven social kod: *Du skall icke tro, att du är något. Du skall icke tro, att du är bättre än oss.* De tio reglerna är en karikatyr av skandinavisk småstadskonformitet, men de fångar något verkligt. Över decennier har Jantelagen blivit en förkortning för en kulturell tendens att motverka individuell exceptionalism, att värdera kollektiv konsensus över personlig ambition och att behandla synlig avvikelse från normen med tyst misstänksamhet.

Som metafor kan *Jantelagen* belysa hur anpassningstryck och ovilja mot oenighet kan begränsa institutioners uppmärksamhet. Den bör däremot inte behandlas som en uppmätt orsaksförklaring till Sveriges historiska jämlikhet, brottslighet eller sociala sammanhållning: dessa utfall beror också på politik, arbetsmarknadsinstitutioner, ekonomi och många andra faktorer. Det prövbara påståendet är om vissa beslutsmiljöer systematiskt nedvärderar välgrundade minoritets- eller avvikande signaler.

Men en variansdämpningsalgoritm som dämpar negativa avvikelser dämpar också positiva. Den dämpar entreprenören som utmanar etablerade affärsmodeller, forskaren som ifrågasätter disciplinära ortodoxier, tjänstemannen som argumenterar för att en omhuldad policy inte längre fungerar, medborgaren som insisterar på att konsensusen är fel. I en stabil miljö är denna dämpning hanterbar – kostnaden för den dämpade positiva variansen uppvägs av nyttan av den dämpade negativa variansen. I en snabbt föränderlig miljö förskjuts kalkylen. Ett system som behöver anpassa sig behöver tillgång till avvikelser – till de tidiga signalerna om att något har förändrats, till de okonventionella experiment som kan avslöja en bättre väg, till de obekväma rösterna som insisterar på att bli hörda även när konsensusen föredrar tystnad.

En möjlig fråga är om innovation i näringsliv och förvaltning möter olika incitament och institutionella hinder. Exempel på framgångsrika svenska teknikföretag visar inte någon orsakskedja till statlig anpassningsförmåga, och konsensuskulturens roll är oprövad.

Även **medelvärdesåtergångsfelslutet** är en föreslagen diagnostisk metafor, inte ett belagt antagande som omfattar hela den svenska förvaltningen. I vissa situationer kan beslutsfattare uppfatta en störning som tillfällig trots att den signalerar varaktig strukturell förändring. Att skilja dessa fall åt kräver tidsseriedata, explicita modeller och dokumentation av hur alternativa tolkningar har prövats.

Vissa störningar är övergående medan andra signalerar strukturell förändring. Tänkbart undersökningsmaterial är rekrytering till kriminella nätverk, snabbt förändrade behov av bostäder och service och klimatrelaterade risker. Faktiska tidsserier, tidigare prognoser och beslutsakter måste studeras i stället för att anta att beslutsfattare förväntade sig återgång till medelvärdet. Ingen mekanism kallad ”demografisk ersättning” påstås.

Om beslutshandlingar skulle visa en obefogad förväntan om återgång till tidigare trender vore det ett möjligt stöd för hypotesen om medelvärdesåtergångsfelslut. Det skulle inte i sig visa någon specifikt svensk kulturell orsak eller en kompetensfälla. Hypoteserna måste prövas var för sig.

Kulturförklaringar får inte ersätta evidens med antaganden om motiv. Tystnad, oliktänkande och utebliven handling kan bero på tidspress, professionella bedömningar, politiska begränsningar eller osäkerhet. Daterade beslutsunderlag, intervjuer och jämförelsefall behövs för att knyta ett förbisett larm till konsensuspress.

---

### 2.4 Den kommunala kapacitetsfällan: Ansvar utan kapacitet

Sverige beskrivs ofta som en decentraliserad stat. De 290 kommunerna och 21 regionerna åtnjuter konstitutionellt skydd under Regeringsformen, som garanterar lokalt självstyre. Kommuner tar ut sin egen inkomstskatt, sätter sina egna budgetar och ansvarar för några av de mest väsentliga offentliga tjänsterna: skolor, äldreomsorg, socialtjänst, fysisk planering och – i allt högre grad – frontlinjen för integration och allmän säkerhet.

Denna decentralisering är verklig, och den är en av den svenska modellens styrkor. Den placerar beslutanderätt nära de medborgare som påverkas av dessa beslut. Den tillåter variation i lokala prioriteringar och tillvägagångssätt. Den skapar, i princip, ett distribuerat nätverk av styrelselaboratorier som kan lära av varandras framgångar och misslyckanden.

Men decentraliseringen är ofullständig på sätt som är djupt betydelsefulla för återkopplingskapaciteten. Detta är tillståndet av **formell subsidiaritet, funktionell centralisering** – ett system som delegerar ansvar nedåt samtidigt som det behåller auktoritet och fiskal kontroll i centrum.

Den ekonomiska dimensionen är viktig men mer komplex än ett enkelt bortfall av lokal skattekraft. Kommunerna tar ut inkomstskatt, samtidigt som det kommunalekonomiska inkomst- och kostnadsutjämningssystemet uttryckligen ska kompensera för skillnader i skattekraft och strukturella servicebehov. Det undanröjer inte alla påfrestningar från demografi, nationella uppdrag, administrativ kapacitet eller tidsfördröjningar; det gör inte heller kommunernas budgetar oberoende av lokala beslut. Den empiriska frågan är vilka specifika kommuner och ansvarsområden som har obalans efter utjämning och statsbidrag.

Resultatet är att den styresnivå som är närmast de mest komplexa, snabbast föränderliga problemen – kommunerna som står på frontlinjen för integration, bostäder, brottsförebyggande och social sammanhållning – också är den nivå med den mest begränsade kapaciteten att experimentera, anpassa sig och agera. Ett nationellt policyramverk, utformat i Stockholm, sätter de breda parametrarna. Kommunen ansvarar för implementering. Men dess fiskala utrymme, dess juridiska befogenhet att avvika från nationella standarder och dess institutionella kapacitet att driva genuina experiment är alla starkt begränsade.

Detta skapar en specifik typ av återkopplingsmisslyckande. Kommunala tjänstemän är ofta de första att se framväxande problem. En skolrektor noterar förändrade mönster i närvaro och prestation. En socialarbetare ser familjedynamik som indikerar fördjupat utanförskap. En lokal polis observerar de tidiga stadierna av kriminell nätverksbildning. Dessa signaler existerar på kommunal nivå. Men kapaciteten att aggregera dem, att koppla ihop dem över silorna för utbildning, socialtjänst och allmän säkerhet, och att agera med de resurser och den experimentmyndighet som situationen kräver – den kapaciteten ligger på nationell nivå, separerad från signalerna av avstånd, tid och filtreringsmekanismerna från Dataarkipelagen och konsensuskulturen.

Signalerna färdas uppåt – långsamt, partiellt, avskalade sin lokala kontext. Responsen färdas nedåt – uniform, aggregerad, kalibrerad till det nationella medelvärdet. Kommunen som såg problemet först lämnas med konsekvenserna av en respons utformad för ett genomsnitt som inte matchar dess verklighet.

Detta är inte ett argument mot nationella standarder eller omfördelning. Det är ett argument för att den nuvarande subsidiaritetsarkitekturen är ofullständig. Om kommuner ska vara den svenska statens avkänningsorgan – och de är, i praktiken, den nivå där de flesta komplexa sociala problem först blir synliga – då behöver de den fiskala, juridiska och institutionella kapaciteten att reagera på vad de avkänner. Utan den är återkopplingsloopen bruten. Sensorerna finns på plats. Kablarna till den centrala processorn är intakta. Men processorn är för långt borta, och de lokala verkställarna har medvetet försvagats av ett system som centraliserar auktoritet samtidigt som det decentraliserar ansvar.

---

### 2.5 Hur de tre mekanismerna förstärker varandra

Dataarkipelagen, det föreslagna konsensusfiltret och den kommunala kapacitetsfällan kan samverka. Följande scenario illustrerar en möjlig förstärkande dynamik; det är inte ett dokumenterat fall eller belägg för att händelsekedjan är typisk för Sverige.

Tänk att en lokal polis ser en förändring i rekryteringen av unga till kriminella nätverk. En ansvarsfull återkopplingsprocess skulle kunna förena iakttagelsen med lämpligt aggregerade indikatorer från skola, socialtjänst och kommunal verksamhet, när detta behövs och är lagligt. Den skulle också inhämta perspektiv från berörda unga, familjer och yrkesverksamma. Målet vore att skilja ett verkligt framväxande mönster från missvisande korrelationer och utforma en proportionerlig respons som respekterar rättigheter – inte att anta att mer individdata alltid måste sammanföras.

I en svagare återkopplingsmiljö kan iakttagelser misslyckas med att nå rätt beslutsfattare, eller så kan olika aktörer tolka dem olika. Även där informationsutbyte är tillåtet kan oförenliga arbetssätt eller kapacitetsbrister fördröja handling. Andra förklaringar – oenighet om verksamma insatser, konkurrerande prioriteringar eller begränsade resurser – behöver prövas parallellt med informationsfragmentering.

Om dröjsmålen består kan ett inledningsvis hanterbart mönster bli mer skadligt innan en samordnad respons kommer till stånd. Men förloppet är villkorat: vissa svenska institutioner delar redan information, agerar tidigt och anpassar sig framgångsrikt. Både framgångar och misslyckanden behöver studeras för att avgöra om den föreslagna loopen har förklaringskraft.

Det är denna typ av misslyckande som hypotesen om återkopplingsunderskottet försöker förklara. Dess relativa betydelse jämfört med rättigheter, materiella begränsningar, omstridda mål och politiska vägval behöver prövas. Nästa avsnitt utvecklar förslag som kräver oberoende juridisk, praktisk och demokratisk utvärdering.

---

---
