## 4. The Political Immune System: Why Feedback Fails

### 4.1 The Competence Trap as Immune Response

Every political order develops reflexes that protect its existing distribution of power, its settled assumptions, and its sense of itself. In Germany, the immune system is bureaucratic inertia — the multiplication of veto points that makes decisive action difficult. In France, it is the national political spectacle — an arena that amplifies conflict and consumes reform before it can take root. In Sweden, the immune system is subtler. It is **satisfied competence**.

The reflex is not aggressive. It does not denounce or obstruct. It is the calm, reasonable, evidence-backed response of a system that has every reason to believe in its own performance: *We are already among the best in the world. Our institutions are functioning. Our metrics are strong. What exactly needs fixing?*

This is not a cynical posture. It is an honest expression of the Swedish self-understanding, and it is grounded in real achievement. The international rankings, the aggregate statistics, the daily experience of citizens who encounter a state that largely works — all of these provide genuine evidence that the machine is running well. The problem is not that this evidence is false. It is that it is partial. The very metrics that confirm the system's success are the metrics that make its blind spots invisible. The Competence Trap is not a failure of self-awareness. It is a structural property of a system that has optimised its sensors for the conditions it already knows how to handle.

A corollary of satisfied competence is that **failure must become visible and undeniable before it becomes discussable**. Until the evidence is overwhelming — until the gang violence makes international headlines, until the housing queues stretch beyond a generation, until the NATO pivot is forced by events rather than chosen by deliberation — the system defaults to the assumption that things are basically working and that deviations from the norm will correct themselves. This is not stubbornness. It is the rational inference from decades of experience in which deviations *did* correct themselves, in which the system *did* absorb shocks and return to equilibrium. The problem arises when the environment changes in ways that make that assumption obsolete, and the system's own success prevents it from noticing.

---

### 4.2 The Consensus Filter and Expert Dependence

If satisfied competence is the immune system's first line of defence, the second is a cultural filter of remarkable effectiveness: the consensus that screens out uncomfortable signals before they reach the level where they might disturb the prevailing understanding.

Swedish political culture prizes *saklighet* — fact-based, rational deliberation — and *enighet* — the achievement of broad agreement. These are genuine democratic virtues. They prevent the kind of tribal polarisation that paralyses other political systems. They create space for long-term, evidence-based policy-making. They underpin the high trust that makes the Swedish model possible. But they also create a specific vulnerability: when the consensus is wrong, or when it is right but incomplete, the mechanisms for correcting it are weak, because the culture treats deviations from the consensus as probably erroneous.

This is not a conspiracy of silence. It is a social dynamic. The civil servant who suspects that an integration programme is failing faces a high burden of proof — not because anyone has ordered them to be silent, but because the institutional culture expects them to have overwhelming evidence before challenging a policy that commands broad political and expert support. The researcher whose findings contradict the prevailing narrative faces implicit scepticism, not because the research community is dishonest, but because the prior probability assigned to outlier findings is low. The journalist who wants to report on a disturbing trend must weigh the professional cost of being seen as alarmist. None of this requires formal censorship. It operates through the ordinary mechanisms of social and professional life — the raised eyebrow, the delayed promotion, the subtle preference for work that confirms rather than disrupts.

Coupled with this is a deep **expert dependence**. The Swedish state relies heavily on agencies, expert authorities, and institutional trust. Citizens trust agencies. Politicians trust agencies. Agencies trust their own expertise. This trust is largely earned — Swedish agencies are, by global standards, competent and honest. But it creates a structural vulnerability: when expert consensus is wrong or outdated, the system has weak mechanisms for detecting that quickly. There is no institutionalised function whose job is to challenge the prevailing expert view. There are no permanent red teams within agencies tasked with arguing the opposite of the consensus. There is no standing deliberative body empowered to bring citizen experience to bear on expert judgment. The result is a system that can be honestly, diligently, and competently wrong for extended periods — not because anyone is acting in bad faith, but because the architecture assumes that expert consensus is reliable and provides no systematic way to test it.

Immigration and integration policy provide a **proposed case for investigation**, not proof of a suppressed-warning mechanism. Researchers could compile contemporaneous warnings from teachers, residents, social workers, police, elected officials and other sources—including contradictory warnings—then code whether, when and why institutions responded. Party competition, information quality and limited attention are important rival accounts. No general suppression is asserted without a dated record.

---

### 4.3 The Agency Silo as Institutional Defence

The third line of the immune system is structural: the agency silo itself functions as a defence mechanism against inconvenient signals that cut across institutional boundaries.

Swedish agencies are, by design, autonomous. They are not subject to direct ministerial control in individual cases — a constitutional protection against political interference that is one of the strengths of the Swedish model. Each agency has its own mandate, its own budget, its own professional culture, and its own interpretation of what constitutes success. This autonomy creates islands of competence and integrity. It also creates islands of information, each self-contained and self-referential, each with its own metrics that confirm its own performance.

When a signal crosses agency boundaries—for example, possible interactions among school outcomes, housing, labour markets, and criminal recruitment—no single institution necessarily owns the entire explanation or response. Different actors may already cooperate, yet coordination can still fail because of competing mandates, scarce resources, disputed diagnoses, or governance incentives. The question is where collective responsibility is clearly assigned, exercised, and evaluated.

Moreover, agencies may have institutional incentives to retain control over their data and performance measures. Those incentives should be investigated rather than assumed to explain every restriction: legitimate confidentiality, statutory mandates, technical costs, and resource scarcity may be decisive in particular cases. Recent changes to Swedish disclosure rules mean that the operational question is increasingly whether existing possibilities are applied lawfully, consistently, and productively—not simply whether the law forbids cooperation.

When a cross-agency signal does eventually become too large to ignore, the typical response is to create a new coordinating body, a new task force, a new national strategy — which often adds another layer of coordination on top of the existing silos without changing the silo structure itself. The underlying information architecture remains intact. The agencies continue to operate with their own data, their own metrics, their own cultures. The new coordinating body lacks the data access and the institutional authority to do more than write reports. The loop closes. The next cross-agency signal will follow the same path from fragmentation to crisis.

---

### 4.4 The Narrative Strategy

Given the immune system described above, the way the feedback agenda is *talked about* is not peripheral to its success. It is central. A reform proposal that announces itself as a critique of the Swedish model — that frames the Data Archipelago as a failure, Jantelagen as a pathology, the Municipal Trap as a betrayal of subsidiarity — will trigger every immune response simultaneously. It will be dismissed as alarmist, as a misunderstanding of Swedish achievements, as an import of foreign anxieties that do not apply to a society that remains, by most measures, among the most successful on earth.

The task, therefore, is to frame the agenda not as a rupture but as a **continuation** — the same pragmatic, evidence-based institutional improvement that built the *folkhemmet*, now applied to the architecture of governance itself. The argument is not that Sweden has failed. It is that Sweden succeeded so well at building institutions for a specific set of conditions that it now needs to upgrade those institutions to match the conditions that have since emerged. The Competence Trap is not an accusation. It is an observation that applies to all high-performing systems, and Sweden is simply far enough along the performance curve to encounter it first.

This framing must be paired with an honest acknowledgment of Sweden's genuine strengths. The high trust, the institutional capacity, the culture of rationality, the digital infrastructure — these are not obstacles to reform. They are the foundation on which reform can be built. Sweden does not need to become a different kind of society. It needs to give the society it already is the sensory architecture it currently lacks.

The narrative must also speak to each of the policy mindsets that coexist in the Swedish political landscape. To the social-democratic tradition that built the *folkhemmet*, it must say: *you succeeded by pragmatically adapting institutions to conditions. The conditions have changed. The pragmatic response is to adapt again.* To the liberal and green traditions that push for innovation and sustainability, it must say: *the structures that suppress uncomfortable signals are also the structures that suppress the experimentation needed for the green transition.* To the conservative and moderate traditions that value stability and prudence, it must say: *the greatest threat to stability is not change — it is the delayed recognition of change that has already occurred.*

The core message is deceptively simple: *Sweden is not broken. It is deprecating — like software that still runs but is no longer being actively maintained for the environment it is operating in. The upgrade is not a rejection of the original design. It is the continuation of the pragmatic tradition that produced it.* This is a message that can be spoken from any political platform without contradiction. And it carries the full feedback agenda inside it.

---

The political immune system is powerful, but it is not omnipotent. It can be worked with, because its foundations — trust, competence, rationality — are the very resources needed for the upgrade. The next section turns to the concrete mechanisms of that work: the transition architecture that gives the feedback agenda a chance of surviving contact with the system it intends to upgrade.

---

---
