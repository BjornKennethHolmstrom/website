## 4. Det politiska immunsystemet: Varför återkoppling misslyckas

### 4.1 Kompetensfällan som immunsvar

Varje politisk ordning utvecklar reflexer som skyddar dess existerande maktfördelning, dess etablerade antaganden och dess självbild. I Tyskland är immunsystemet byråkratisk tröghet – mångfaldigandet av vetopunkter som gör beslutsamt handlande svårt. I Frankrike är det det nationella politiska skådespelet – en arena som förstärker konflikt och konsumerar reform innan den kan slå rot. I Sverige är immunsystemet subtilare. Det är **tillfredsställd kompetens**.

Reflexen är inte aggressiv. Den fördömer inte eller obstruerar. Det är det lugna, rimliga, evidensunderstödda svaret från ett system som har all anledning att tro på sin egen prestation: *Vi är redan bland de bästa i världen. Våra institutioner fungerar. Våra mätetal är starka. Vad exakt behöver lagas?*

Detta är inte en cynisk hållning. Det är ett ärligt uttryck för den svenska självförståelsen, och det är grundat i verklig prestation. De internationella rankningarna, den aggregerade statistiken, medborgarnas dagliga erfarenhet av en stat som i stort sett fungerar – allt detta tillhandahåller genuin evidens för att maskineriet går bra. Problemet är inte att denna evidens är falsk. Det är att den är partiell. Just de mätetal som bekräftar systemets framgång är de mätetal som gör dess blinda fläckar osynliga. Kompetensfällan är inte ett misslyckande av självmedvetenhet. Det är en strukturell egenskap hos ett system som har optimerat sina sensorer för de förhållanden det redan vet hur man hanterar.

En följd av tillfredsställd kompetens är att **misslyckande måste bli synligt och obestridligt innan det blir diskuterbart**. Tills evidensen är överväldigande – tills gängvåldet skapar internationella rubriker, tills bostadsköerna sträcker sig bortom en generation, tills Natoomsvängningen framtvingas av händelser snarare än väljs genom deliberation – faller systemet tillbaka på antagandet att saker i grunden fungerar och att avvikelser från normen kommer att korrigera sig själva. Detta är inte envishet. Det är den rationella slutsatsen från decennier av erfarenhet där avvikelser *faktiskt* korrigerade sig själva, där systemet *faktiskt* absorberade chocker och återvände till jämvikt. Problemet uppstår när miljön förändras på sätt som gör det antagandet förlegat, och systemets egen framgång förhindrar det från att märka det.

---

### 4.2 Konsensusfiltret och expertberoendet

Om tillfredsställd kompetens är immunsystemets första försvarslinje, är den andra ett kulturellt filter av anmärkningsvärd effektivitet: konsensusen som sållar bort obekväma signaler innan de når den nivå där de skulle kunna störa den rådande förståelsen.

Svensk politisk kultur värdesätter *saklighet* – faktabaserad, rationell deliberation – och *enighet* – uppnåendet av bred överenskommelse. Dessa är genuina demokratiska dygder. De förhindrar den typ av tribal polarisering som paralyserar andra politiska system. De skapar utrymme för långsiktig, evidensbaserad policyutveckling. De underbygger den höga tillit som gör den svenska modellen möjlig. Men de skapar också en specifik sårbarhet: när konsensusen är fel, eller när den är rätt men ofullständig, är mekanismerna för att korrigera den svaga, eftersom kulturen behandlar avvikelser från konsensusen som sannolikt felaktiga.

Detta är ingen tystnadskonspiration. Det är en social dynamik. Den tjänsteman som misstänker att ett integrationsprogram misslyckas möter en hög bevisbörda – inte för att någon har beordrat dem att vara tysta, utan för att den institutionella kulturen förväntar sig att de har överväldigande evidens innan de utmanar en politik som åtnjuter brett politiskt och expertmässigt stöd. Den forskare vars resultat motsäger den rådande berättelsen möter implicit skepsis, inte för att forskarsamhället är ohederligt, utan för att den förhandssannolikhet som tilldelas avvikande fynd är låg. Den journalist som vill rapportera om en oroande trend måste väga den professionella kostnaden av att ses som alarmistisk. Inget av detta kräver formell censur. Det opererar genom det sociala och professionella livets vanliga mekanismer – det höjda ögonbrynet, den försenade befordran, den subtila preferensen för arbete som bekräftar snarare än stör.

Kopplat till detta är ett djupt **expertberoende**. Den svenska staten förlitar sig tungt på myndigheter, expertauktoriteter och institutionell tillit. Medborgare litar på myndigheter. Politiker litar på myndigheter. Myndigheter litar på sin egen expertis. Denna tillit är till stor del förtjänad – svenska myndigheter är, med globala mått, kompetenta och hederliga. Men det skapar en strukturell sårbarhet: när expertkonsensus är fel eller föråldrad har systemet svaga mekanismer för att upptäcka det snabbt. Det finns ingen institutionaliserad funktion vars jobb är att utmana den rådande expertsynen. Det finns inga permanenta röda team inom myndigheter med uppdrag att argumentera för motsatsen till konsensusen. Det finns inget permanent deliberativt organ bemyndigat att låta medborgarerfarenhet påverka expertbedömningar. Resultatet är ett system som kan vara ärligt, plikttroget och kompetent felaktigt under längre perioder – inte för att någon agerar i ond tro, utan för att arkitekturen antar att expertkonsensus är tillförlitlig och inte tillhandahåller något systematiskt sätt att testa den.

Invandrings- och integrationspolitiken är ett **föreslaget undersökningsfall**, inte belägg för undertryckta varningar. Forskning kan sammanställa samtida signaler från lärare, invånare, socialtjänst, polis och politiker, även motstridiga signaler, och pröva om, när och varför beslut följde. Partikonkurrens, signalernas kvalitet och begränsad uppmärksamhet är alternativa förklaringar. Ett generellt undertryckande kan inte påstås utan daterade belägg.

---

### 4.3 Myndighetssilon som institutionellt försvar

Den tredje linjen i immunsystemet är strukturell: myndighetssilon själv fungerar som en försvarsmekanism mot obekväma signaler som skär över institutionella gränser.

Svenska myndigheter är, till sin utformning, autonoma. De är inte föremål för direkt ministerstyrning i enskilda fall – ett konstitutionellt skydd mot politisk inblandning som är en av den svenska modellens styrkor. Varje myndighet har sitt eget mandat, sin egen budget, sin egen professionella kultur och sin egen tolkning av vad som utgör framgång. Denna autonomi skapar öar av kompetens och integritet. Den skapar också öar av information, var och en självinnesluten och självrefererande, var och en med sina egna mätetal som bekräftar dess egen prestation.

När en signal passerar myndighetsgränser – till exempel möjliga samband mellan skolresultat, bostäder, arbetsmarknad och rekrytering till kriminalitet – är det inte säkert att en enda institution äger hela förklaringen eller responsen. Aktörer kan redan samverka, men samordningen kan ändå brista på grund av skilda uppdrag, resursbrist, omstridda diagnoser eller styrningsincitament. Frågan är var det gemensamma ansvaret tydligt fördelas, utövas och utvärderas.

Dessutom kan myndigheter ha institutionella incitament att behålla kontrollen över sina uppgifter och prestationsmått. Dessa incitament bör undersökas i stället för att förutsättas förklara varje begränsning: legitim sekretess, författningsstyrda uppdrag, tekniska kostnader och resursbrist kan vara avgörande i enskilda fall. Nya svenska regler om uppgiftsutbyte gör att den praktiska frågan i ökande grad är om befintliga möjligheter används lagligt, konsekvent och ändamålsenligt – inte bara om lagen förbjuder samverkan.

När en tvärmyndighetssignal så småningom blir för stor för att ignorera, är den typiska responsen att skapa ett nytt samordningsorgan, en ny insatsstyrka, en ny nationell strategi – vilket ofta lägger ytterligare ett lager av samordning ovanpå de existerande silorna utan att förändra själva silostrukturen. Den underliggande informationsarkitekturen förblir intakt. Myndigheterna fortsätter att operera med sina egna data, sina egna mätetal, sina egna kulturer. Det nya samordningsorganet saknar datatillgången och den institutionella auktoriteten att göra mer än att skriva rapporter. Loopen sluts. Nästa tvärmyndighetssignal kommer att följa samma väg från fragmentering till kris.

---

### 4.4 Berättelsestrategin

Givet det immunsystem som beskrivits ovan, är sättet som återkopplingsagendan *talas om* inte perifert för dess framgång. Det är centralt. Ett reformförslag som presenterar sig självt som en kritik av den svenska modellen – som ramar in Dataarkipelagen som ett misslyckande, Jantelagen som en patologi, den Kommunala kapacitetsfällan som ett svek mot subsidiariteten – kommer att utlösa varje immunsvar samtidigt. Det kommer att avfärdas som alarmistiskt, som ett missförstånd av svenska landvinningar, som en import av utländska ängsligheter som inte gäller ett samhälle som förblir, enligt de flesta mått, bland de mest framgångsrika på jorden.

Uppgiften är därför att rama in agendan inte som ett brott utan som en **fortsättning** – samma pragmatiska, evidensbaserade institutionella förbättring som byggde folkhemmet, nu tillämpad på själva styrningens arkitektur. Argumentet är inte att Sverige har misslyckats. Det är att Sverige lyckades så väl med att bygga institutioner för en specifik uppsättning förhållanden att det nu behöver uppgradera dessa institutioner för att matcha de förhållanden som sedan dess har uppstått. Kompetensfällan är inte en anklagelse. Det är en observation som gäller alla högpresterande system, och Sverige är helt enkelt tillräckligt långt längs prestationskurvan för att stöta på den först.

Denna inramning måste paras med ett ärligt erkännande av Sveriges genuina styrkor. Den höga tilliten, den institutionella kapaciteten, rationalitetskulturen, den digitala infrastrukturen – dessa är inte hinder för reform. De är grunden på vilken reform kan byggas. Sverige behöver inte bli en annan typ av samhälle. Det behöver ge det samhälle det redan är den sensoriska arkitektur det för närvarande saknar.

Berättelsen måste också tala till vart och ett av de policymässiga tänkesätt som samexisterar i det svenska politiska landskapet. Till den socialdemokratiska tradition som byggde folkhemmet måste den säga: *ni lyckades genom att pragmatiskt anpassa institutioner till förhållanden. Förhållandena har förändrats. Det pragmatiska svaret är att anpassa igen.* Till de liberala och gröna traditioner som driver på för innovation och hållbarhet måste den säga: *strukturerna som dämpar obekväma signaler är också strukturerna som dämpar den experimentation som behövs för den gröna omställningen.* Till de konservativa och moderata traditioner som värdesätter stabilitet och försiktighet måste den säga: *det största hotet mot stabilitet är inte förändring – det är det fördröjda erkännandet av förändring som redan har inträffat.*

Kärnbudskapet är bedrägligt enkelt: *Sverige är inte trasigt. Det deprekeras – som mjukvara som fortfarande körs men som inte längre aktivt underhålls för den miljö den opererar i. Uppgraderingen är inte ett avvisande av den ursprungliga designen. Det är fortsättningen av den pragmatiska tradition som producerade den.* Detta är ett budskap som kan uttalas från vilken politisk plattform som helst utan motsägelse. Och det bär hela återkopplingsagendan inom sig.

---

Det politiska immunsystemet är kraftfullt, men det är inte allsmäktigt. Det går att arbeta med, eftersom dess grundvalar – tillit, kompetens, rationalitet – är just de resurser som behövs för uppgraderingen. Nästa sektion vänder sig till de konkreta mekanismerna för det arbetet: den övergångsarkitektur som ger återkopplingsagendan en chans att överleva kontakt med det system den avser att uppgradera.

---

---
