## 5. Working with the Grain: Transition Architecture for Sweden

### 5.1 The Principle: Start Where Trust Is High

Every transition architecture must be matched to the immune system it navigates. In Germany, the strategy is to bypass bureaucratic inertia — to build capacity beneath the threshold of political controversy, where administrative modernisation can proceed without triggering the full coordination machinery. In France, the strategy is to bypass the national political spectacle — to start in low-visibility zones where results can be demonstrated before the arena consumes them. In Sweden, the strategy is different. It is to work *with* the existing trust, not around it.

Sweden's immune system — satisfied competence, the consensus filter, the agency silo — is not a hostile adversary. It is a product of the same cultural and institutional strengths that make Sweden governable. High trust, evidence-based policy-making, professional autonomy, and a preference for consensus are not obstacles to adaptation. They are the conditions under which adaptation must occur. The task is not to defeat them but to redirect them — to use the trust to have honest conversations, to use the evidence culture to demand better sensing, to use the professional autonomy to create protected spaces for experimentation.

This principle has a practical consequence: reform in Sweden should not be framed as an emergency. It should be framed as an upgrade — the kind of continuous improvement that Swedish institutions already pride themselves on. The tone should be calm, evidence-rich, and forward-looking. The emotional register is not *we must act before it's too late* but *we have an opportunity to build on our strengths before the environment shifts further.* This is not spin. It is strategic honesty. The possibility of a Competence Trap merits investigation; Sweden can build on existing institutional strengths whether or not the hypothesis proves true. Using those strengths wisely is the point.

The architecture that follows—transparent municipal testbeds, purpose-limited data agreements, bounded experiments and evidence-conditioned scaling—should be disclosed openly to participating residents, staff and elected bodies. Its legitimacy depends on public understanding of both the modest administrative changes and any longer-term institutional ambitions.

---

### 5.2 Transparent Municipal Testbeds

The most effective vehicle for upgrading Sweden's feedback architecture is the municipality. The *kommun* is already the level where complex social problems first become visible, where services touch citizens directly, and where the gap between responsibility and capacity is most acutely felt. It is also a level of governance that Swedes trust — local government typically enjoys higher confidence than national institutions — and where experimentation can occur without immediately becoming a national political proxy war.

The pilot strategy should not have an undisclosed “wrapper” or “payload.” Municipalities, residents and participating authorities should receive the same public description of aims, expected benefits, legal constraints, data uses, possible losses and evaluation rules. Honest framing is compatible with political pragmatism and is essential to consent and accountability.

Consider a concrete example. A group of municipalities — perhaps five to seven, diverse in size, geography, and economic base — could form a **"Framtidskommuner" (Future Municipalities) Network**. The stated purpose would be straightforward: to pioneer more integrated, data-informed approaches to complex local challenges, to share learning across municipal boundaries, and to provide a testbed for administrative practices that could eventually be adopted more broadly. The language is the language of *verksamhetsutveckling* — operational development — and *evidensbaserad praktik* — evidence-based practice. It is the language that Swedish public administration already speaks.

Within these published boundaries, Framtidskommuner could test process coordination, lawful data agreements, standing citizens’ panels and defined evaluation routines. Any expansion of municipal discretion would require a specific legal route and review of affected rights, rather than a general experimental exemption.

The key is that the Framtidskommuner would be *voluntary*. No municipality would be required to participate. Those that choose to — and there are already municipalities, across the political spectrum, that are acutely aware of the gap between their responsibilities and their capacities — would be self-selected for readiness. Their participation would be a signal of local political will, which provides cover for the national government to grant the necessary exemptions and resources. The dynamics of scaling by attraction begin with the first movers.

---

### 5.3 Cross-Silo Data Covenants

The Data Archipelago can persist despite expanded legal gateways. Since the 2025 reforms, the immediate task is not necessarily another nationwide permission to share: it is to map the actual legal basis, operational practices, technical barriers, and remaining analytical needs for each use case. Where a lawful basis already exists, agencies can explore carefully scoped implementation; where it does not, a voluntary agreement alone cannot create one.

A **cross-silo data covenant** would be an operational and accountability agreement among participating organisations—not a new disclosure power. It would specify a lawful purpose, legal bases, controllers, permitted fields or aggregate outputs, minimisation, access, retention, audit, and redress. Some cases may require only joint analysis of public statistics. Where personal data are necessary, legality and proportionality must be established independently of the covenant; an illustrative school–social-services–police linkage cannot be presumed permissible.

This precision is essential, but an agreement does not make an otherwise unlawful exchange lawful. The value of the covenant lies in testing a specific, authorised collaboration, recording its benefits and harms, and exposing operational barriers that remain even when sharing is permitted.

The covenants should start with narrowly scoped, legally assessed cases where a clearly documented gap prevents useful learning. Aggregate school-to-work transitions could be a lower-risk starting point than linking sensitive data about named minors. Proposals involving schools, social services, or police must undergo a separate necessity, proportionality, and rights assessment before any information exchange; the 2025 disclosure rules do not make all such uses automatically permissible.

The national government's role is to enable, not to control. It can provide a template legal agreement, model privacy protocols, and technical assistance. It can fund an independent integrity authority to oversee the covenants and build public trust. It can celebrate successful covenants and make their methods available to other municipalities. But the covenants themselves are initiated and governed locally, by the agencies that will use them. This respects the Swedish principle of agency autonomy while building the bridges that autonomy currently lacks.

---

### 5.4 Safe-to-Fail Municipal Pilots

Sweden, like most well-functioning states, has an aversion to visible failure. The pressure to deliver consistent, high-quality outcomes across all municipalities has produced a system in which deviations from national standards are treated as risks to be managed rather than experiments to be learned from. This is understandable. Citizens in Kiruna should not receive worse healthcare than citizens in Stockholm because their municipality decided to try something unconventional. But the understandable preference for consistency has a cost: it suppresses the variation that generates learning.

A **safe-to-fail pilot** is an experiment deliberately designed to overcome this aversion. It is bounded in scope — a specific municipality, a limited timeframe, a predefined set of activities. It is explicitly framed as a learning exercise, not a permanent policy change. Its participants — municipal officials, agency staff, citizen participants — are publicly assured that mixed results are expected and that honest documentation of what did not work is as valuable as evidence of what did. And it has political cover: a national government that authorises the pilot commits to protecting it from premature judgment.

The safe-to-fail framework is particularly important for the Municipal Trap. Municipalities that have been granted fiscal or regulatory flexibility need to be able to use it without fear that a single disappointing metric will trigger intervention or public criticism. The evaluation framework matters: pilots are assessed not by whether every output target is met, but by whether they generate knowledge that improves future decision-making. A pilot that reveals an unexpected obstacle — *cross-agency data sharing is harder than anticipated because of incompatible IT systems* — is a success in learning terms, even if its programmatic outcomes are mixed. This reframing must be established from the beginning.

The legal basis for safe-to-fail pilots already exists in embryonic form. *Försöksverksamhet* — experimental activity — can be authorised by the government under existing legislation. What has been missing is the ambition to use these mechanisms at a systemic rather than incremental scale, and the political will to protect the experiments long enough for their results to become visible. A dedicated *Försöksverksamhetslag* — an Experimentation Act — would provide a standing legal framework, specifying the scope of permissible experimentation, the governance and evaluation requirements, and the conditions under which successful experiments can be scaled.

The Framtidskommuner would be the first cohort of safe-to-fail pilots under this framework. Their experiences — documented transparently, evaluated independently, shared openly — would build the evidence base for broader adoption. Some experiments will succeed. Some will fail. Some will succeed in unexpected ways and fail in expected ones. The common output is learning, and learning is the foundation of the feedback upgrade.

---

### 5.5 Scaling by Attraction

The Swedish tradition of *kommunalt självstyre* — municipal self-government — provides a cultural and institutional foundation for the final element of the transition architecture. In a system where municipalities have constitutional standing and a strong identity as independent actors, scaling by central mandate is both politically difficult and operationally counterproductive. A municipality ordered to adopt a new governance approach by Stockholm will implement it with minimal commitment and maximum compliance theatre. A municipality that chooses to adopt an approach because it has seen it work in a neighbouring *kommun* will implement it with genuine ownership.

Scaling by attraction means making successful experiments visible, accessible, and easy to replicate. The national government's role is not to command but to enable: to fund documentation and evaluation, to facilitate peer-to-peer learning networks, to provide technical assistance and seed funding for municipalities that want to adopt proven approaches, and to celebrate successes publicly. The Swedish Association of Local Authorities and Regions (*Sveriges Kommuner och Regioner*, SKR) is a natural partner — an existing institution with the relationships, the legitimacy, and the convening power to facilitate horizontal learning across municipalities.

The dynamics are slow in the beginning, then accelerating. The first few Framtidskommuner demonstrate that integrated data sensing, citizen deliberation, and experimental autonomy produce better outcomes — not just on traditional metrics, but on the feedback velocity that prevents problems from compounding. A second wave of municipalities, observing the results, voluntarily adopts elements of the model. The national government, observing the second wave, adjusts the legal and fiscal framework to make adoption easier. Over time, what began as a small experiment at the periphery becomes the norm — not because anyone mandated it, but because enough actors chose it that the old way of working became harder to justify.

This is not a fast process. It will not produce dramatic headlines or visible political victories within a single electoral cycle. But it is a durable one. The changes it produces will be embedded in institutional practice, owned by the actors who implement them, and resilient to political shifts at the national level. In a high-trust, consensus-oriented society, this is the only kind of change that sticks.

---

The transition architecture described here—transparent municipal initiatives, lawful cross-agency agreements, safe-to-fail pilots and evidence-conditioned diffusion—does not require concealed institutional ambitions. It asks public bodies to be explicit about aims, costs, possible harms and which outcomes would justify stopping.

---

---
