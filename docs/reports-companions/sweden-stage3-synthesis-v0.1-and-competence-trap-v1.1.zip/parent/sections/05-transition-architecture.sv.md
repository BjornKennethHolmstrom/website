## 5. Att arbeta med strukturen: Övergångsarkitektur för Sverige

### 5.1 Principen: Börja där tilliten är hög

Varje övergångsarkitektur måste anpassas till det immunsystem den navigerar. I Tyskland är strategin att kringgå byråkratisk tröghet – att bygga kapacitet under tröskeln för politisk kontrovers, där administrativ modernisering kan fortgå utan att utlösa hela samordningsmaskineriet. I Frankrike är strategin att kringgå det nationella politiska skådespelet – att börja i zoner med låg synlighet där resultat kan demonstreras innan arenan konsumerar dem. I Sverige är strategin annorlunda. Den är att arbeta *med* den befintliga tilliten, inte runt den.

Sveriges immunsystem – tillfredsställd kompetens, konsensusfiltret, myndighetssilon – är inte en fientlig motståndare. Det är en produkt av samma kulturella och institutionella styrkor som gör Sverige styrbart. Hög tillit, evidensbaserad policyutveckling, professionell autonomi och en preferens för konsensus är inte hinder för anpassning. De är de förhållanden under vilka anpassning måste ske. Uppgiften är inte att besegra dem utan att omdirigera dem – att använda tilliten till att ha ärliga samtal, att använda evidenskulturen till att kräva bättre avkänning, att använda den professionella autonomin till att skapa skyddade utrymmen för experimentation.

Denna princip har en praktisk konsekvens: reform i Sverige bör inte ramas in som ett nödläge. Den bör ramas in som en uppgradering – den typ av kontinuerlig förbättring som svenska institutioner redan stoltserar med. Tonen bör vara lugn, evidensrik och framåtblickande. Det känslomässiga registret är inte *vi måste agera innan det är för sent* utan *vi har en möjlighet att bygga på våra styrkor innan miljön förskjuts ytterligare.* Detta är inte spinn. Det är strategisk ärlighet. Det återstår att visa om kompetensfällan finns i Sverige. Ett försök till konstruktiv förbättring kan vara värdefullt även om den ursprungliga förklaringen visar sig felaktig.

Den följande arkitekturen – öppna kommunala testbäddar, ändamålsbundna dataöverenskommelser, avgränsade försök och evidensstyrd spridning – ska redovisas för boende, anställda och folkvalda. Legitimiteten kräver förståelse för både administrativa åtgärder och eventuella långsiktiga ambitionsförändringar.

---

### 5.2 Öppna kommunala testbäddar

Det mest effektiva fordonet för att uppgradera Sveriges återkopplingsarkitektur är kommunen. Kommunen är redan den nivå där komplexa sociala problem först blir synliga, där tjänster berör medborgare direkt, och där gapet mellan ansvar och kapacitet är mest akut känt. Det är också en styrningsnivå som svenskar litar på – lokalt självstyre åtnjuter vanligtvis högre förtroende än nationella institutioner – och där experimentation kan ske utan att omedelbart bli ett nationellt politiskt ställföreträdarkrig.

Pilotstrategin får inte ha något dolt ”omslag” eller ”innehåll”. Kommuner, boende och deltagande myndigheter ska få samma offentliga beskrivning av mål, förväntade nyttor, rättsliga begränsningar, dataanvändning, risker och utvärderingsregler. Öppen redovisning kan förenas med politisk pragmatism och behövs för legitimitet och ansvarsutkrävande.

Betrakta ett konkret exempel. En grupp kommuner – kanske fem till sju, varierade i storlek, geografi och ekonomisk bas – skulle kunna bilda ett **"Framtidskommuner"-nätverk**. Det uttalade syftet skulle vara okomplicerat: att pionjära mer integrerade, datainformerade tillvägagångssätt för komplexa lokala utmaningar, att dela lärande över kommungränser och att tillhandahålla en testbädd för administrativa praktiker som så småningom skulle kunna antas bredare. Språket är språket för *verksamhetsutveckling* och *evidensbaserad praktik*. Det är språket som svensk offentlig förvaltning redan talar.

Inom offentligt angivna ramar kan Framtidskommuner pröva processamordning, lagliga dataöverenskommelser, stående medborgarpaneler och definierade utvärderingar. Utökad kommunal befogenhet kräver en tydlig rättslig väg och granskning av berörda rättigheter, inte ett generellt försöksundantag.

Nyckeln är att Framtidskommunerna skulle vara *frivilliga*. Ingen kommun skulle tvingas att delta. De som väljer att göra det – och det finns redan kommuner, över hela det politiska spektrumet, som är akut medvetna om gapet mellan sina ansvarsområden och sin kapacitet – skulle vara självselekterade för beredskap. Deras deltagande skulle vara en signal om lokal politisk vilja, vilket ger täckning för den nationella regeringen att bevilja de nödvändiga undantagen och resurserna. Dynamiken av spridning genom attraktion börjar med de första aktörerna.

---

### 5.3 Datadelningsöverenskommelser över silogränser

Dataarkipelagen kan bestå trots utvidgade rättsliga möjligheter. Efter 2025 års reformer är den omedelbara uppgiften inte nödvändigtvis ännu ett nationellt tillstånd att dela uppgifter: den är att kartlägga rättslig grund, faktisk tillämpning, tekniska hinder och kvarstående analysbehov för varje användningsfall. När rättslig grund redan finns kan myndigheter pröva noggrant avgränsat genomförande; när den saknas kan en frivillig överenskommelse inte skapa den.

En **datadelningsöverenskommelse över silogränser** skulle vara en överenskommelse om genomförande och ansvar mellan deltagande organisationer – inte en ny befogenhet att lämna ut uppgifter. Den ska ange lagligt ändamål, rättslig grund, personuppgiftsansvar, tillåtna fält eller aggregerade resultat, uppgiftsminimering, åtkomst, lagring, granskning och möjligheter till rättelse. I vissa fall räcker gemensam analys av offentlig statistik. Där personuppgifter behövs måste laglighet och proportionalitet fastställas oberoende av överenskommelsen; samkörning av uppgifter från skola, socialtjänst och polis kan inte förutsättas vara tillåten.

Denna precision är nödvändig, men ett avtal gör inte ett annars olagligt informationsutbyte lagligt. Värdet ligger i att pröva en särskild, tillåten samverkan, dokumentera dess nytta och skador samt synliggöra praktiska hinder som finns kvar även när delning är möjlig.

Överenskommelserna bör börja med snävt avgränsade, juridiskt prövade fall där en dokumenterad informationsbrist hindrar användbart lärande. Aggregerade övergångar från skola till arbete kan vara en mindre riskfylld start än att samköra känsliga uppgifter om namngivna minderåriga. Förslag som rör skola, socialtjänst eller polis måste genomgå särskild prövning av nödvändighet, proportionalitet och rättigheter innan uppgifter delas; 2025 års regler gör inte alla sådana användningar automatiskt tillåtna.

Den nationella regeringens roll är att möjliggöra, inte att kontrollera. Den kan tillhandahålla en mall för rättslig överenskommelse, modellintegritetsprotokoll och tekniskt stöd. Den kan finansiera en oberoende integritetsmyndighet för att övervaka överenskommelserna och bygga allmänt förtroende. Den kan hylla framgångsrika överenskommelser och göra deras metoder tillgängliga för andra kommuner. Men överenskommelserna själva initieras och styrs lokalt, av de myndigheter som kommer att använda dem. Detta respekterar den svenska principen om myndighetsautonomi samtidigt som det bygger de broar som autonomin för närvarande saknar.

---

### 5.4 Säkra-att-misslyckas kommunala piloter

Sverige har, liksom de flesta välfungerande stater, en aversion mot synligt misslyckande. Trycket att leverera konsekventa, högkvalitativa resultat över alla kommuner har producerat ett system där avvikelser från nationella standarder behandlas som risker att hanteras snarare än experiment att lära från. Detta är förståeligt. Medborgare i Kiruna bör inte få sämre sjukvård än medborgare i Stockholm för att deras kommun bestämde sig för att prova något okonventionellt. Men den förståeliga preferensen för konsekvens har en kostnad: den dämpar den variation som genererar lärande.

En **säker-att-misslyckas-pilot** är ett experiment medvetet utformat för att övervinna denna aversion. Det är avgränsat i omfattning – en specifik kommun, en begränsad tidsram, en fördefinierad uppsättning aktiviteter. Det är uttryckligen inramat som en lärandeövning, inte en permanent policyförändring. Dess deltagare – kommunala tjänstemän, myndighetspersonal, medborgardeltagare – försäkras offentligt om att blandade resultat förväntas och att ärlig dokumentation av vad som inte fungerade är lika värdefullt som evidens för vad som gjorde det. Och det har politisk täckning: en nationell regering som auktoriserar piloten förbinder sig att skydda den från för tidig bedömning.

Det säkra-att-misslyckas-ramverket är särskilt viktigt för den Kommunala kapacitetsfällan. Kommuner som har beviljats fiskal eller regulatorisk flexibilitet måste kunna använda den utan rädsla för att ett enda nedslående mätetal ska utlösa intervention eller offentlig kritik. Utvärderingsramverket är avgörande: piloter bedöms inte efter om varje resultatmål uppnås, utan efter om de genererar kunskap som förbättrar framtida beslutsfattande. En pilot som avslöjar ett oväntat hinder – *datadelning mellan myndigheter är svårare än förväntat på grund av inkompatibla IT-system* – är en framgång i lärandetermer, även om dess programmatiska resultat är blandade. Denna omramning måste etableras från början.

Den rättsliga grunden för säkra-att-misslyckas-piloter existerar redan i embryonal form. Försöksverksamhet kan auktoriseras av regeringen under existerande lagstiftning. Vad som har saknats är ambitionen att använda dessa mekanismer på en systemisk snarare än inkrementell skala, och den politiska viljan att skydda experimenten tillräckligt länge för att deras resultat ska bli synliga. En särskild försöksverksamhetslag skulle tillhandahålla ett permanent rättsligt ramverk, som specificerar omfattningen av tillåten försöksverksamhet, styrnings- och utvärderingskraven, och villkoren under vilka framgångsrika experiment kan skalas upp.

Framtidskommunerna skulle vara den första kohorten av säkra-att-misslyckas-piloter under detta ramverk. Deras erfarenheter – dokumenterade transparent, utvärderade oberoende, delade öppet – skulle bygga evidensbasen för bredare antagande. Vissa experiment kommer att lyckas. Vissa kommer att misslyckas. Vissa kommer att lyckas på oväntade sätt och misslyckas på förväntade. Det gemensamma resultatet är lärande, och lärande är grunden för återkopplingsuppgraderingen.

---

### 5.5 Spridning genom attraktion

Den svenska traditionen av kommunalt självstyre tillhandahåller en kulturell och institutionell grund för det sista elementet i övergångsarkitekturen. I ett system där kommuner har konstitutionell ställning och en stark identitet som oberoende aktörer, är spridning genom centrala mandat både politiskt svårt och operationellt kontraproduktivt. En kommun som beordras att anta en ny styrningsansats av Stockholm kommer att implementera den med minimalt engagemang och maximalt complianceteater. En kommun som väljer att anta en ansats för att den har sett den fungera i en grannkommun kommer att implementera den med genuint ägarskap.

Spridning genom attraktion innebär att göra framgångsrika experiment synliga, tillgängliga och lätta att replikera. Den nationella regeringens roll är inte att befalla utan att möjliggöra: att finansiera dokumentation och utvärdering, att facilitera nätverk för kollegialt lärande, att tillhandahålla tekniskt stöd och såddfinansiering för kommuner som vill anta beprövade ansatser, och att hylla framgångar offentligt. Sveriges Kommuner och Regioner (SKR) är en naturlig partner – en befintlig institution med relationerna, legitimiteten och sammankallande kraften att facilitera horisontellt lärande över kommuner.

Dynamiken är långsam i början, sedan accelererande. De första Framtidskommunerna demonstrerar att integrerad dataavkänning, medborgardeliberation och experimentell autonomi producerar bättre resultat – inte bara på traditionella mätetal, utan på den återkopplingshastighet som förhindrar problem från att förvärras. En andra våg av kommuner, som observerar resultaten, antar frivilligt delar av modellen. Den nationella regeringen, som observerar den andra vågen, justerar det rättsliga och fiskala ramverket för att göra antagande lättare. Över tid blir vad som började som ett litet experiment i periferin normen – inte för att någon påbjöd det, utan för att tillräckligt många aktörer valde det att det gamla arbetssättet blev svårare att rättfärdiga.

Detta är inte en snabb process. Den kommer inte att producera dramatiska rubriker eller synliga politiska segrar inom en enskild valcykel. Men den är varaktig. De förändringar den producerar kommer att vara inbäddade i institutionell praktik, ägda av de aktörer som implementerar dem, och motståndskraftiga mot politiska förskjutningar på nationell nivå. I ett högtillits-, konsensusorienterat samhälle är detta den enda typ av förändring som består.

---

Den beskrivna övergångsarkitekturen – öppna kommunala initiativ, lagliga samarbeten, avgränsade försök och evidensstyrd spridning – bygger inte på dolda institutionella avsikter. Den kräver offentlighet om mål, kostnader, möjliga skador och villkor för avbrytande.

---

---
