## Appendix C: The Governance as Engineering Series Connection

### C.1 The Architectural Foundation

This report draws on a deeper body of work: the Governance as Engineering series, a set of formal analyses that model governance institutions as feedback control systems using standard mathematics from control theory, information theory, and cybernetics. The series is technical; this appendix summarises its core findings in non-technical language and shows how they underpin the feedback deficit diagnosis.

### C.2 The Five Papers in Brief

**Paper I — Governance Stability Simulator** models, under its assumptions, that centralised governance systems operate on aggregated signals that destroy spatial information. A central controller observing only the national average cannot see which municipalities are in distress and which are stable. Its interventions are simultaneously too weak for the crisis locations and too disruptive for the healthy ones. This suggests a formal analogy for the spatial blindness that the Data Archipelago produces in the Swedish context: when agencies cannot share local data, the national level sees only aggregates, and local variation becomes invisible. **Interpretation caveat:** A conclusion within a model is not an empirical result about Sweden.

**Paper II — Fractality as Stability** explores, under its assumptions, whether a single-scale controller can stabilise a system facing simultaneous fast, medium, and slow disturbances. A controller calibrated for fast crises will oscillate in response to slow trends. A controller calibrated for slow trends will be too slow for fast crises. One candidate architecture in the model is a fractal hierarchy of controllers, each matched to the timescale of its disturbance band. This suggests a formal analogy for the Mean-Reversion Fallacy critique: Sweden’s institutions are calibrated for medium-frequency electoral cycles and slow consensus-building. They lack the fast sensing and response loops that exponential or cascading challenges require. **Interpretation caveat:** A conclusion within a model is not an empirical result about Sweden.

**Paper III — The Observability-Democracy Connection** models, under its assumptions, possible limits to reliable transmission of citizen preferences through representation chains deeper than two or three layers. Noise variance exceeds surviving signal variance, and the policy layer governs a phantom signal. This suggests a formal analogy for the deliberative infrastructure proposed in Section 3: shortening the chain between citizen experience and policy response requires direct participatory mechanisms, not just improved representation. **Interpretation caveat:** A conclusion within a model is not an empirical result about Sweden.

**Paper IV — Requisite Variety and the Commons** models, under its assumptions, that governance systems with low-dimensional observation cannot stabilise high-variety resource systems. Observation dimensionality—the number of independent signal dimensions the governance system can access—is the primary determinant of commons management outcomes. This suggests a formal analogy for the cross-silo sensemaking infrastructure: connecting school data, health data, police data, and housing data increases the observation dimensionality available to municipalities, enabling them to govern the complex social systems they are responsible for. **Interpretation caveat:** A conclusion within a model is not an empirical result about Sweden.

**Paper V — The Coordination Failure Tax** models non-additive interactions among four assumed failure modes. A governance system exhibiting all four simultaneously is not four times worse than a well-designed one; it is categorically incapable of the functions it claims to perform. This suggests a formal analogy for the urgency beneath the calm tone of this report: the Competence Trap is not a single vulnerability but a compounding set of structural constraints that, left unaddressed, will progressively erode the system’s capacity to govern. **Interpretation caveat:** A conclusion within a model is not an empirical result about Sweden.

### C.3 From Engineering Analysis to Institutional Design

The Governance as Engineering papers use formal models and simulations to explore potential trade-offs in observation, representation and coordination. Results obtained under specified model assumptions are not mathematical proof that Swedish administrative institutions behave the same way. Any application requires a documented mapping from model variables to observed institutions and separate empirical validation.

This report uses the model results as **design prompts**, not as settled requirements. Candidate measures include observation delay, representational access, organizational boundaries, lawful data use and distribution of decision authority. Whether Framtidskommuner improve outcomes must be tested against alternatives, including simpler procedures and better-resourced existing services.

---

---
