## Appendix C: Kopplingen till Governance as Engineering-serien

### C.1 Den arkitektoniska grunden

Denna rapport bygger på en djupare arbetsmassa: Governance as Engineering-serien (styrning som ingenjörskonst), en uppsättning formella analyser som modellerar styrningsinstitutioner som återkopplingskontrollsystem med hjälp av standardmatematik från kontrollteori, informationsteori och cybernetik. Serien är teknisk; detta appendix sammanfattar dess kärnresultat på icke-tekniskt språk och visar hur de underbygger diagnosen av återkopplingsunderskottet.

### C.2 De fem artiklarna i korthet

**Artikel I — Governance Stability Simulator** modellerar under angivna antaganden att centraliserade styrsystem opererar på aggregerade signaler som förstör rumslig information. En central kontrollant som endast observerar det nationella genomsnittet kan inte se vilka kommuner som befinner sig i kris och vilka som är stabila. Dess interventioner är samtidigt för svaga för krisplatserna och för störande för de friska. Detta illustrerar modellens möjliga relevans för den rumsliga blindhet som Dataarkipelagen producerar i den svenska kontexten: när myndigheter inte kan dela lokala data ser den nationella nivån endast aggregerade värden, och lokal variation blir osynlig. **Tolkningsgräns:** Ett modellresultat är inte ett empiriskt fynd om svenska förhållanden.

**Artikel II — Fractality as Stability** modellerar under angivna antaganden att ingen enskalig kontrollant kan stabilisera ett system som står inför samtidiga snabba, medelsnabba och långsamma störningar. En kontrollant kalibrerad för snabba kriser kommer att oscillera som svar på långsamma trender. En kontrollant kalibrerad för långsamma trender kommer att vara för långsam för snabba kriser. En möjlig stabil arkitektur i modellen är en fraktal hierarki av kontrollanter, var och en matchad till tidsskalan för sitt störningsband. Detta illustrerar modellens möjliga relevans för kritiken av Medelvärdesåtergångsfelaktigheten: Sveriges institutioner är kalibrerade för medelfrekventa valcykler och långsamt konsensusbyggande. De saknar de snabba avkännings- och responsloopar som exponentiella eller kaskadartade utmaningar kräver. **Tolkningsgräns:** Ett modellresultat är inte ett empiriskt fynd om svenska förhållanden.

**Artikel III — The Observability-Democracy Connection** modellerar under angivna antaganden att medborgarpreferenser inte kan överföras tillförlitligt genom representationskedjor djupare än två eller tre lager. Brusvariansen överstiger den överlevande signalvariansen, och policylagret styr en fantomsignal. Detta illustrerar modellens möjliga relevans för den deliberativa infrastruktur som föreslås i Sektion 3: att förkorta kedjan mellan medborgarerfarenhet och policyrespons kräver direkta deltagandemekanismer, inte bara förbättrad representation. **Tolkningsgräns:** Ett modellresultat är inte ett empiriskt fynd om svenska förhållanden.

**Artikel IV — Requisite Variety and the Commons** modellerar under angivna antaganden att styrsystem med lågdimensionell observation inte kan stabilisera resursystem med hög varians. Observationsdimensionalitet — antalet oberoende signaldimensioner som styrsystemet kan få tillgång till — är den primära bestämningsfaktorn för allmänningsförvaltningens utfall. Detta illustrerar modellens möjliga relevans för den meningsskapande infrastrukturen över silogränser: att koppla ihop skoldata, hälsodata, polisdata och bostadsdata ökar den observationsdimensionalitet som är tillgänglig för kommunerna, vilket gör det möjligt för dem att styra de komplexa sociala system de är ansvariga för. **Tolkningsgräns:** Ett modellresultat är inte ett empiriskt fynd om svenska förhållanden.

**Artikel V — The Coordination Failure Tax** undersöker i en modell hur fyra tänkbara fellägen kan förstärka varandra på ett icke-additivt sätt. Ett styrsystem som uppvisar alla fyra samtidigt är inte fyra gånger sämre än ett väldesignat; det är kategoriskt oförmöget till de funktioner det påstår sig utföra. Detta illustrerar modellens möjliga relevans för brådskan under den lugna tonen i denna rapport: Kompetensfällan är inte en enskild sårbarhet utan en förvärrande uppsättning strukturella begränsningar som, lämnade oadresserade, progressivt kommer att urholka systemets kapacitet att styra. **Tolkningsgräns:** Ett modellresultat är inte ett empiriskt fynd om svenska förhållanden.

### C.3 Från ingenjörsanalys till institutionell design

Governance as Engineering-artiklarna använder formella modeller och simuleringar för att pröva antagna samband mellan observation, representation och samordning. Resultat under modellernas förutsättningar är inte matematiska bevis om hur svenska myndigheter faktiskt fungerar. Empirisk tillämpning kräver en prövbar koppling mellan modellvariabler och observerade institutioner.

Rapporten använder de formella resultaten som **uppslag för institutionsdesign**, inte som fastslagna krav. Framtidskommuner kan pröva effekter av minskad beslutsfördröjning, bättre representativitet, lämplig informationsanvändning och tydlig ansvarsfördelning. Nytta måste bedömas mot enklare administrativa förbättringar och resursförstärkningar, inte bara mot det nuvarande läget.

---

---
