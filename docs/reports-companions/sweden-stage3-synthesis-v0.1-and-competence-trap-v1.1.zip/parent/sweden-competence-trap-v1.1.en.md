# Sweden — The Competence Trap

## Executive Summary

Sweden is one of the best-governed societies on earth. By almost any international measure—trust, transparency, welfare delivery, digital infrastructure—it sits near the top. The machine hums. And precisely because it hums, something important has become difficult to see.

This report advances the **Competence Trap** as a hypothesis about institutional adaptation: *the better a system performs under known conditions, the harder it may become to recognize when those conditions have changed.* Sweden retains major governance strengths, but the report asks whether its ways of detecting, interpreting, and responding to change have kept pace with increasingly complex circumstances. The argument is a diagnostic framework to be tested, not an established general law.

The **Swedish Drift Loop** is a proposed pattern—high trust and delegation may sometimes be followed by missed or discounted signals, accumulated problems, a focusing event, and compressed correction. Selected examples illustrate the possibility but do not establish the sequence or its causes. Attention scarcity, organizational friction, political competition, capacity limits and rational responses to new information remain rivals.

The proposed underlying condition is a **feedback deficit**: uneven capacity to detect signals early, share them when lawful and appropriate, interpret conflicting evidence, and act before problems compound. The degree to which this explanation accounts for Sweden’s challenges, relative to political incentives, resources, rights conflicts, and other causes, remains an empirical question.

Three candidate mechanisms could contribute to a feedback deficit:

- **The Data Archipelago.** Sweden combines advanced digital services with fragmented responsibilities, datasets, and analytical workflows. The Public Access to Information and Secrecy Act (2009:400) and the GDPR set safeguards, but information sharing is not categorically prohibited: legal possibilities expanded in 2025, especially for crime prevention and related purposes. The question is where lawful sharing, interoperable systems, and cross-agency learning still fall short—not whether agencies are wholly unable to exchange information.

- **Consensus filtering (with Jantelagen as a metaphor).** Consensus practices may, under some conditions, discourage dissenting evidence. The proposed *Mean-Reversion Fallacy* is an additional hypothesis about how decision-makers interpret trends, not an established characteristic of Swedish institutions. Neither claim should be used to explain social outcomes without direct evidence.

- **The Municipal Capacity Trap.** Some municipalities may have less flexibility than their statutory responsibilities require, even after tax-base and cost equalisation. The size and consequences of such mismatches must be demonstrated for specific functions rather than inferred from local tax dependence alone.

These mechanisms may reinforce one another and help explain delays between signal and response. Whether they do so consistently, and which other causes matter, requires empirical testing.

The report proposes four areas for **bounded institutional experimentation**: lawful, purpose-specific information exchange and public-interest analysis; structured disagreement and accessible deliberation; locally appropriate authority matched to capacity and accountability; and independently evaluated Framtidskommuner testbeds. These are proposals, not proven prerequisites for policy success.

It proposes, but does not establish, that institutional self-protection, consensus norms and fragmented mandates can sometimes impede reform. Its transition approach is transparent voluntary experimentation, public disclosure of objectives and limitations, independent evaluation, and adoption only where evidence warrants it.

**A proposed first step** is a network of 3–5 **Framtidskommuner** (Future Municipalities): voluntary pilots combining protected cross-agency learning, structured citizen deliberation, and bounded fiscal and legal flexibility. Each pilot would require a lawful basis for any data use, meaningful participation by affected groups, independent evaluation, and a way to identify harms as well as gains. Success must be judged by public outcomes and rights protection alongside feedback velocity and policy durability.

The European dimension completes the series as an **interpretive comparison**: Germany is examined through an execution-deficit hypothesis, France through an integration-deficit hypothesis, and Sweden through a feedback-deficit hypothesis. These are contrasting analytical lenses, not validated national rankings or exclusive explanations of each country.

Sweden can test whether its strong institutions would benefit from more permeable feedback, more explicit trade-offs, and more meaningful routes from evidence to accountable action. This remains a proposal, not an established diagnosis of what Swedish success has concealed.

---

## 1. The Competence Trap

### 1.1 The Swedish Drift Loop

Sweden is not failing. It is drifting.

The pattern is less dramatic than the French reform-explosion-retreat cycle. It lacks the visible frustration of German infrastructure paralysis. But it is no less systematic. A problem gathers — quietly, at the edges of the public conversation, in the statistics that no single agency is responsible for connecting. It is visible to those who look directly at it, but it has not yet crossed the threshold where the wider system must acknowledge its existence. For years, sometimes decades, it accumulates.

Then something shifts. A triggering event — a riot, an election result, an international crisis — forces the issue into the open. The public conversation, which had been politely ignoring the problem or treating it as an anomaly, pivots abruptly. The same institutions that had been patiently waiting for the trend to reverse themselves are now required to act with urgency. They do so — competently, decisively, with the full force of the Swedish state behind them. But the action is compressed, reactive, and often narrower than the problem it addresses. The underlying architecture that delayed recognition remains unchanged. Trust erodes slightly. The system stabilises. And the loop begins again.

The proposed **Swedish Drift Loop** is a sequence to be tested: trust and delegation, potential delay in recognizing a signal, a focusing event, and a large corrective response. Whether this is common, distinctive to Sweden, or produced by institutional success is unknown; each episode needs dated records and rival explanations.

The proposed loop may operate across several domains, but the examples require separate verification. Housing constraints and segregation, integration disputes, energy choices, and the 2022 NATO pivot each involve different political and material causes. Their resemblance to a common pattern is suggestive, not evidence that one mechanism has been established in all four fields.

Sweden is not failing randomly. It is running a stable loop. The loop is the symptom of a specific, diagnosable deficit — a feedback deficit — that can be addressed once it is understood. But understanding it requires looking past the surface of a system that appears, by most conventional measures, to be working extraordinarily well.

---

### 1.2 The Surface Story: A Machine That Works

And it is working. This must be said clearly, because the analysis that follows can easily be misread as a critique of the Swedish model, and that is not what it is.

By almost any international comparison, Sweden performs at or near the top. Trust in institutions, while declining from historic peaks, remains among the highest in the world. Corruption is vanishingly low. The welfare state delivers — healthcare, education, social support, parental leave, pensions — at a level of comprehensiveness and quality that most nations can only aspire to. The digital infrastructure is world-class. The economy is innovative, export-oriented, and resilient. The international brand is strong. When global rankings of governance quality, quality of life, or social progress are published, Sweden appears reliably in the top tier, often in the top five.

These achievements are real. They are the product of generations of pragmatic, evidence-based institutional design — the *folkhemmet* tradition that built one of the most equitable and stable societies in modern history. The Swedish state is not a failing machine. It is an exceptionally well-maintained one. The civil servants who operate it are, by and large, competent and dedicated. The politicians who steer it are, by comparative standards, serious and well-intentioned. The citizens who fund it through some of the world's highest tax burdens do so largely willingly, because they believe — with reason — that they receive value in return.

This is the surface story. It is accurate as far as it goes. And precisely because it is accurate, it conceals something important.

---

### 1.3 The Competence Trap, Named

Here is the central concept of this report. It is deceptively simple, and its implications are less comfortable than they first appear.

**The Competence Trap:** *The better a system performs under known conditions, the harder it becomes to detect when those conditions have changed.*

This is not necessarily a failure of the Swedish model. It is a plausible risk in high-performing systems, not an established property of every such system. Success can breed confidence; confidence can reduce attention to discrepant signals; and established metrics may miss new conditions. These causal steps need to be checked against evidence and alternative explanations rather than assumed.

Many institutions central to the Swedish welfare-state settlement were shaped in a different social and economic context: stronger industrial employment patterns, high union density, and slower technological change. Yet Sweden has never been entirely homogeneous or institutionally static, and its population has long included the Sámi people and other national minorities. The useful analytical question is which inherited assumptions remain embedded in particular programmes and decision processes—not whether the entire state was designed once for a single uniform population.

Most of these assumptions have eroded significantly. Sweden is now a multicultural society with significant populations born abroad or to foreign-born parents. The industrial base has transformed — it remains strong, but the nature of employment, the role of unions, and the connection between work and community have shifted. Geographic mobility, combined with housing market dysfunction, has concentrated opportunity in urban cores and left peri-urban and rural municipalities with thinning tax bases and growing service demands. The external environment — geopolitically, technologically, ecologically — is changing faster than the electoral cycle can process.

The architecture of the state, however, has not been correspondingly upgraded. It was never designed to upgrade itself. It was designed to run. And it runs beautifully — within the bandwidth of the conditions it was calibrated to handle. The problem is not that the machine is breaking. It is that the environment around it has changed, and the machine lacks the sensory apparatus to detect the full extent of that change.

This is why the Competence Trap is so insidious. A failing system generates visible distress — protests, economic contraction, institutional collapse — that forces adaptation. A succeeding system generates the opposite: aggregate outcomes that remain within acceptable bounds, international validation, a reasonable case for incremental improvement rather than structural reform. The success is not an illusion. But it is a partial view, and the very confidence it inspires makes the partiality harder to perceive.

---

### 1.4 A Brief Illustration: NATO and the Loop

An example clarifies the pattern without requiring the reader to navigate politically charged domestic debates.

For decades, Sweden's security policy rested on a stable consensus: military non-alignment, a strong territorial defence, and a carefully managed relationship with NATO that stopped short of membership. This consensus was maintained by expert opinion, institutional culture, and broad political agreement. It was not irrational. It had served Sweden well through the Cold War and its aftermath.

The security environment had been changing for years: Russia’s war in Georgia in 2008, its annexation of Crimea in 2014, and growing security concerns in the Baltic region all entered Swedish debate. Sweden also deepened practical NATO cooperation, including its Enhanced Opportunities Partnership in 2014 and Host Nation Support Agreement in 2016. These developments show adaptation as well as continuity. Whether they were sufficient, and whether alternative choices would have produced better outcomes, is contestable.

Russia’s full-scale invasion of Ukraine in February 2022 precipitated a rapid change in Sweden’s alliance policy. The government decided to apply for NATO membership on 16 May 2022, Sweden applied on 18 May, and membership took effect on 7 March 2024. This sharp policy pivot is compatible with the Drift Loop, but is not by itself proof that earlier information was suppressed: a major external shock can also rationally change a country’s assessment of risks and alliances.

This illustration therefore raises a question about decision-making rather than settling it. Did institutions evaluate alternative security trajectories early enough, make trade-offs legible, and permit legitimate disagreement? Or did they revise policy appropriately when the facts changed? A test of the Drift Loop would examine decision records, public debate, and counterfactual explanations—not infer institutional failure solely from the speed of the 2022 pivot.

---

### 1.5 Sweden's Genuine Advantages

Before proceeding to the diagnosis, it is worth pausing to recognise what Sweden has going for it. The Competence Trap is a genuine constraint, but the resources available to address it are equally genuine.

Sweden possesses one of the world's highest baseline levels of social trust. This trust is not evenly distributed — it is lower among foreign-born residents, among the young, among those in precarious economic situations — but it remains, in aggregate, a profound democratic resource. Trust means that citizens are willing to fund ambitious public programmes. It means that institutions can act without facing immediate delegitimisation. It means that the political conversation, while hardening, has not yet collapsed into the tribal polarisation that paralyses other democracies. Trust is the foundation on which a sensory upgrade can be built — because trust allows for honest conversations about what is not working, without those conversations triggering a collapse in confidence.

Sweden also possesses a strong institutional culture of *saklighet* — fact-based, rational deliberation. This culture is under strain, and its tendency to suppress uncomfortable signals is part of the diagnosis. But the underlying commitment to evidence, to pragmatic problem-solving, and to incremental improvement remains a genuine asset. It is the same culture that built the *folkhemmet* in the first place — not through ideology, but through a sustained, multi-generational process of institutional experimentation and refinement.

The digital infrastructure is world-class. The *personnummer* provides a unique identifier that could, with appropriate privacy protections, enable systemic sensing at a resolution most nations cannot match. The municipal structure, while trapped in the formal-subsidiarity functional-centralisation paradox, provides a distributed network of governance units that could become laboratories for adaptive experimentation if given the fiscal and legal autonomy to do so.

And Sweden's cultural connection to nature, its global outlook, and its tradition of long-term thinking — the *lagom* sensibility that values balance, sufficiency, and intergenerational responsibility — provide a cultural substrate that is unusually ready for the kind of holistic, anticipatory governance that the 21st century demands. The Competence Trap remains hypothetical. But Sweden, more than most nations, has the resources to escape it — if it can first see that it is in one.

---

### 1.6 The Real Question

At this point, a familiar impatience may arise. *So what should Sweden do? What reforms are needed?*

The argument of this report is that the very form of these questions reflects the Competence Trap itself. They assume that the problem is a knowable policy gap that the existing architecture, properly directed, can fill. But the architecture was not designed to see the gaps that now matter most. Asking it to identify the reforms it needs is asking a machine to diagnose the limits of its own sensors — while using only those sensors to do so.

The real question is not "What should Sweden do differently?" It is "How does Sweden become capable of sensing what it currently cannot — and of acting on that sensing before the signals have accumulated into crises?"

The rest of this report is devoted to that question. It diagnoses the feedback deficit in its three structural mechanisms: the Data Archipelago, the cultural suppression of variance, and the municipal capacity trap. It describes what building feedback infrastructure would look like in practice. The report hypothesizes institutional responses that might impede change any such effort. And it proposes a concrete first step: a set of *framtidskommuner* — future municipalities — designed to maximise feedback velocity and demonstrate that a different way of sensing and responding is possible.

Sweden does not need to become more competent. It is already among the most competent societies on earth. It needs to become more *permeable* — to the signals its current architecture filters out, to the realities its metrics miss, and to the future its success has made harder to see. That is not a failure of the Swedish model. It is the next chapter of the pragmatic tradition that built it.

---

---

## 2. The Feedback Deficit: A New Diagnosis

### 2.1 What "Feedback Capacity" Means

The term "feedback" has a colloquial ring. In everyday use, it suggests performance reviews, customer surveys, the annual conversation between manager and employee. That is not what is meant here.

Feedback capacity, in the sense that matters for Sweden's current situation, is the ability of a governance system to detect disturbing signals early, to share those signals across institutional boundaries without distortion or delay, to acknowledge their implications honestly — even when those implications challenge the prevailing consensus — and to act on them before they compound into crises.

This is not a single capability. It is a composite of sensing, transmission, interpretation, and response, distributed across institutions, cultural habits, legal frameworks, and cognitive skills. When feedback capacity is high, a society can spot a housing market distortion, an integration challenge, or a security environment shift while it is still manageable — and can respond with measures calibrated to the scale of the emerging problem rather than the scale of the eventual crisis. When feedback capacity is low, the same signals travel slowly, if at all. They are filtered, softened, and sometimes actively suppressed. By the time they become undeniable, the window for calibrated response has closed, and the only remaining option is the kind of compressed, reactive correction the Swedish Drift Loop describes.

Sweden does not lack competence. Its institutions are staffed by capable, dedicated professionals. Its civil service is comparatively free of corruption and political interference. Its political culture, while increasingly strained, remains more deliberative and evidence-based than most. The deficit is not in the quality of the people or the integrity of the processes. It is in the architecture that determines what those people and processes can see.

The report considers three interacting candidate mechanisms: fragmented learning across organizations, potential conformity pressure, and mismatches between local responsibilities and capacity. Their prevalence, interactions and explanatory importance must be established empirically; they are not established invariant properties of Swedish governance.

---

### 2.2 The Data Archipelago: Why Sweden Cannot See Itself

Sweden’s *personnummer* system and administrative registers can support high-quality longitudinal analysis under appropriate legal and governance arrangements. They do not, by themselves, create an all-purpose cross-agency data system or a general entitlement to link individual records. Any such processing requires specified purposes, a valid legal basis, and compliance with applicable secrecy and data-protection rules.

In practice, responsibilities, information systems, sector-specific rules, and analytical capacity remain distributed across agencies and levels of government. Yet sharing is not categorically blocked. Since 1 April 2025, Act (2025:170) has imposed specified disclosure duties to law-enforcement authorities; since 1 December 2025, a general secrecy-breaking provision in Chapter 10, Section 15a of the Public Access to Information and Secrecy Act (2009:400) has broadened inter-agency disclosure for defined purposes such as preventing crime and erroneous payments, subject to conditions and exceptions. The problem must now be examined purpose by purpose: what can lawfully be shared, what should be shared, and what still prevents usable collective analysis?

The boundaries are partly deliberate: secrecy, purpose limitation, and data protection protect people against misuse of sensitive information. Other obstacles may arise from incompatible systems, under-resourced collaboration, unclear responsibility, or uncertainty about how recently changed laws apply. Greater information sharing can improve coordination, but can also create disproportionate surveillance, profiling, and chilling effects. The task is to identify the narrowest lawful and effective response to a demonstrated information gap.

This is the **Data Archipelago** as an analytical metaphor: not sealed islands without bridges, but unevenly connected agencies whose legal powers, technical systems, and incentives do not necessarily produce shared learning. School attendance, municipal finance, and criminal recruitment may be studied using different datasets, levels of aggregation, and safeguards. The important test is whether the available evidence is actually brought together for legitimate decisions—not the unsupported assumption that no agency can ever connect the dots.

This is the deeper error beneath the surface of Sweden's celebrated digital transformation. Sweden has built one of the world's most advanced **transactional** digital states. BankID allows citizens to authenticate themselves seamlessly across hundreds of services. Swish enables instant payments. Tax filing is so automated that for many citizens it requires nothing more than a text message confirmation. This is genuine achievement, and it is rightly admired. But transactional digitization is not the same as systemic visibility. The state has digitized *efficiency* — the point-to-point interactions between citizen and agency — without digitizing *sensemaking* — the node-to-network patterns that emerge only when signals from multiple agencies are connected.

The resulting tension still matters: highly efficient individual digital services do not guarantee timely cross-domain learning. Sweden’s policy challenge is to assess where existing legal gateways, interoperability, governance, and evaluation are adequate—and where targeted, privacy-preserving improvements are needed. The Data Archipelago is therefore a testable institutional hypothesis, not a factual claim that Swedish public data may be used only for transactions.

---

### 2.3 Jantelagen as a Variance-Minimization Algorithm

If the Data Archipelago is the outer architecture of the feedback deficit, the inner architecture is cultural. And the culture has a name, though it is more often invoked in self-deprecating jokes than in serious analysis.

Jantelagen — the Law of Jante — originates from a 1933 novel by Aksel Sandemose, in which a fictional Danish town enforces an unwritten social code: *You shall not believe that you are anything. You shall not believe that you are better than us.* The ten rules are a caricature of Scandinavian small-town conformity, but they capture something real. Over decades, Jantelagen has become shorthand for a cultural tendency to discourage individual exceptionalism, to value collective consensus over personal ambition, and to treat visible deviation from the norm with quiet suspicion.

As a metaphor, *Jantelagen* can illuminate how conformity and aversion to dissent might narrow an institution’s attention. It should not, however, be treated as a measured causal explanation for Sweden’s historical inequality, crime, or social cohesion: those outcomes also reflect policy, labour-market institutions, economics, and many other factors. The claim to test is whether particular decision environments systematically discount well-founded minority or dissenting signals.

But a variance-minimization algorithm that suppresses negative outliers also suppresses positive ones. It suppresses the entrepreneur who challenges established business models, the researcher who questions disciplinary orthodoxies, the civil servant who argues that a cherished policy is no longer working, the citizen who insists that the consensus is wrong. In a stable environment, this suppression is manageable — the cost of the suppressed positive variance is outweighed by the benefit of the suppressed negative variance. In a rapidly changing environment, the calculus shifts. A system that needs to adapt needs access to outliers — to the early signals that something has changed, to the unconventional experiments that might reveal a better path, to the uncomfortable voices that insist on being heard even when the consensus prefers silence.

A possible question is whether innovation capability in business and public administration faces different incentives and institutional barriers. The examples of successful Swedish technology companies do not establish a causal contrast with state adaptation, and the role of consensus culture remains untested.

The **Mean-Reversion Fallacy** is likewise a proposed diagnostic metaphor rather than a demonstrated, Sweden-wide institutional assumption. In some settings, decision-makers may assume a disturbance is temporary when it signals persistent structural change. Distinguishing these cases calls for time-series evidence, explicit models, and records of how alternative interpretations were considered.

Some disturbances are temporary while others indicate structural change. Candidate episodes include recruitment into criminal networks, rapid shifts in housing and service demand, and climate-related risks. Analysts should examine actual trends, prior forecasts and policy records rather than assume that decision-makers expected a return to the mean. No claim of a municipal “demographic replacement” mechanism is made.

If decision records showed unwarranted confidence that an anomalous trend would reverse, that might support the proposed Mean-Reversion Fallacy. Such records would not by themselves demonstrate a specifically Swedish cultural cause or a Competence Trap. The hypotheses must be tested separately.

A cultural explanation must not substitute imagined motives for evidence. Silence, dissent and non-action may reflect time pressure, professional judgment, political constraints or uncertainty. Interviews, contemporaneous records and comparison cases would be needed before attributing a missed warning to consensus pressure.

---

### 2.4 The Municipal Trap: Responsibility Without Capacity

Sweden is often described as a decentralised state. The 290 *kommuner* (municipalities) and 21 *regioner* enjoy constitutional protection under the Instrument of Government, which guarantees local self-government. Municipalities levy their own income taxes, set their own budgets, and are responsible for some of the most essential public services: schools, elderly care, social services, spatial planning, and — increasingly — the frontline of integration and public safety.

This decentralisation is real, and it is one of the strengths of the Swedish model. It places decision-making authority close to the citizens affected by those decisions. It allows for variation in local priorities and approaches. It creates, in principle, a distributed network of governance laboratories that can learn from one another's successes and failures.

But the decentralisation is incomplete in ways that matter profoundly for feedback capacity. This is the condition of **formal subsidiarity, functional centralisation** — a system that devolves responsibility downward while retaining authority and fiscal control at the centre.

The fiscal dimension is important but more complex than a simple collapse of local tax capacity. Municipalities levy income tax, while Sweden’s income- and cost-equalisation system is expressly designed to offset differences in tax bases and structural service needs. It does not erase all pressures from demographic change, national mandates, administrative capacity, or timing; nor does it make municipal budgets independent of local decisions. The empirical question is which specific municipalities and responsibilities face a mismatch, after equalisation and grants are accounted for.

The result is that the level of government closest to the most complex, fastest-changing problems — the municipalities that are on the frontline of integration, housing, crime prevention, and social cohesion — is also the level with the most constrained capacity to experiment, adapt, and respond. A national policy framework, designed in Stockholm, sets the broad parameters. The municipality is responsible for implementation. But its fiscal room, its legal authority to deviate from national standards, and its institutional capacity to run genuine experiments are all tightly bounded.

This creates a specific kind of feedback failure. Municipal officials are often the first to see emerging problems. A school principal notices changing patterns of attendance and performance. A social worker sees family dynamics that indicate deepening exclusion. A local police officer observes the early stages of criminal network formation. These signals exist at the municipal level. But the capacity to aggregate them, to connect them across the silos of education, social services, and public safety, and to respond with the resources and experimentation authority the situation requires — that capacity lies at the national level, separated from the signals by distance, time, and the filtering mechanisms of the Data Archipelago and the consensus culture.

The signals travel upward — slowly, partially, stripped of their local context. The response travels downward — uniform, aggregated, calibrated to the national mean. The municipality that saw the problem first is left with the consequences of a response designed for an average that does not match its reality.

This is not an argument against national standards or redistribution. It is an argument that the current architecture of subsidiarity is incomplete. If municipalities are to be the sensing organs of the Swedish state — and they are, in practice, the level where most complex social problems first become visible — then they need the fiscal, legal, and institutional capacity to respond to what they sense. Without that, the feedback loop is broken. The sensors are in place. The wiring to the central processor is intact. But the processor is too far away, and the local actuators have been deliberately weakened by a system that centralises authority while decentralising responsibility.

---

### 2.5 How the Three Mechanisms Reinforce Each Other

The Data Archipelago, the proposed consensus filter, and the municipal capacity trap might interact. The following scenario illustrates one possible reinforcing dynamic; it is not a documented case or evidence that this sequence is typical across Sweden.

Imagine a local officer observing a change in youth recruitment into criminal networks. A responsible feedback process could combine the officer’s observations with suitably aggregated education, social-care, and municipal indicators, where necessary and lawful. It would also seek input from affected young people, families, and professionals. The goal would be to distinguish a real emerging pattern from misleading correlations and design a proportionate, rights-respecting response—rather than assuming that more individual-level data must always be connected.

In a weaker feedback setting, observations may fail to reach the appropriate decision-makers, or different actors may interpret them differently. Even where disclosure is legally possible, incompatible practices or capacity constraints may slow action. Other explanations—lack of consensus on effective interventions, competing priorities, or limited resources—should be examined alongside information fragmentation.

If delays persist, an initially manageable pattern could become more harmful before a coordinated response occurs. But this sequence is conditional: some Swedish institutions already share information, respond early, and adapt successfully. Studying both successes and failures is necessary to establish whether the proposed loop has explanatory power.

This is the kind of failure the feedback-deficit hypothesis aims to explain. Its relative importance compared with legal rights, material constraints, contested goals, and political choice remains to be tested. The next section develops proposals that would need independent legal, practical, and democratic evaluation.

---

---


---

## 3. What Building Feedback Infrastructure Looks Like

The feedback deficit diagnosis carries a practical implication: if Sweden's core problem is not a lack of competence but an architecture that suppresses, silos, and delays the signals needed for adaptation, then the central task is not to produce another round of policy reforms. It is to build the infrastructure that makes early detection, honest acknowledgment, and rapid response possible — and then to let that infrastructure reveal what needs doing.

This section describes what that investment looks like in practice. It is organised around four categories: reconnecting the nervous system to move from transactional efficiency to systemic sensemaking, building structured disagreement into the operating culture, giving municipalities the real autonomy to match their responsibilities, and creating living testbeds where the new feedback architecture can prove itself. None of these are sectors. None belong to a single ministry. They are the enabling substrate on which Sweden's next chapter of institutional adaptation depends.

---

### 3.1 From Transactional to Sensemaking: Reconnecting the Nervous System

If the Data Archipelago hypothesis holds in particular settings, a promising investment is to improve cross-agency learning where justified—not simply to maximize data flows. The first step should be to audit existing powers, practices, and unmet needs in light of the 2025 reforms, and then choose the least intrusive approach capable of answering a specified public-interest question.

The goal is not a central surveillance database. A **federated sensemaking infrastructure** is one possible design, but technologies such as differential privacy or secure multi-party computation do not automatically establish legality, accuracy, safety, or anonymity. Each use case would require a defined controller, purpose, lawful basis, necessity and proportionality tests, security controls, and a data-protection impact assessment where required. When aggregate or non-personal data suffice, individual record linkage should not be the default.

A concrete proposal is a **National Signal Integration Framework** to document which lawful information exchanges already exist, identify unmet analytical needs, and develop carefully delimited pilot arrangements where authority is sufficient—or seek legislation where it is not. A useful starting case might assess aggregate school-to-work transitions without building individual risk scores. A public register of purposes, authorised participants, audits, retention rules, and avenues for complaint would help establish whether each arrangement creates more public value than privacy risk.

Alongside this, Sweden could test a **Societal Sensing Dashboard** using public or disclosure-safe aggregate indicators. It should show sources, update dates, uncertainty, missing populations, and relevant ecological outcomes; it should suppress or coarsen small cells to avoid identification. Such a dashboard can aid shared interpretation, but it cannot by itself establish causation, supply statutory powers, or substitute for deliberation with affected communities.

This would represent a shift from a solely transactional emphasis toward a **sensemaking state**: an administration able to study cross-domain patterns using suitable, lawful, and appropriately aggregated evidence. Understanding how neighbourhood conditions and service outcomes interact does not require displaying a named child’s school and health records on a common dashboard.

This investment would involve legal, organizational, technical, democratic, and financial choices. Even privacy-enhancing technology requires maintenance, specialist capacity, oversight, and public legitimacy. The binding constraints cannot be identified in advance without examining concrete use cases and the reforms already in force.

---

### 3.2 Structured Disagreement: Deliberative Infrastructure for Productive Conflict

If the Data Archipelago is the outer architecture of the feedback deficit, the inner architecture is the suppression of variance — the cultural and institutional filtering that screens out uncomfortable signals before they reach decision-makers. Addressing this requires more than exhortations to "speak up." It requires building institutional mechanisms that make productive conflict a structured, rewarded part of the governance process.

The first mechanism is a network of **standing citizen deliberative bodies** at municipal and regional levels. These are not one-off consultations or advisory panels that the executive can ignore. They are permanent assemblies of randomly selected citizens, given time, information, and professional facilitation, with a statutory right to a formal government response. If a citizens' assembly in a municipality recommends a different approach to housing integration, the municipal council must respond publicly, explain its reasoning, and — if it rejects the recommendation — justify the rejection in terms that the assembly can scrutinise. This is not a veto. It is an accountability mechanism that forces the system to engage seriously with signals from outside its own institutional filters.

Sweden has experimented with citizens' assemblies before — most recently a national climate assembly — but these have been ad-hoc, consultative, and peripheral to the actual decision-making process. The upgrade is to make them permanent, multi-level, and embedded in the governance architecture. A municipality with a standing deliberative body has a built-in channel for surfacing local signals that would otherwise be suppressed by the consensus culture. A region with such a body has a mechanism for processing the trade-offs — between energy development and environmental protection, between housing density and community character — that are currently resolved through expert-led processes that exclude the affected populations.

The second mechanism is institutionalised **red team functions** within public administration. A red team is a unit whose explicit role is to challenge the prevailing consensus — to argue that a cherished policy is failing, that an emerging risk is being underestimated, that a comfortable assumption is no longer valid. Sweden's agencies already contain some of this capacity; various *utredningar* (official inquiries) can serve a similar function. But the red team concept embeds it permanently, rather than commissioning it episodically, and gives it the institutional protection to speak uncomfortable truths without career damage. The Swedish tradition of *tjänstemannansvar* — the professional responsibility of civil servants — provides a cultural foundation for this approach. The red team is not disloyal. It is performing a function essential to the health of the system: testing the consensus against reality.

The third mechanism is **futures literacy embedded in education and public service training**. Futures literacy — defined by UNESCO as the ability to understand the role of the future in what we see and do — is not about prediction. It is about expanding the repertoire of plausible futures a society can imagine, and thereby expanding the range of actions it can take in the present. Finland has pioneered this approach with its Committee for the Future in Parliament and nationwide futures literacy programmes. Sweden, with its strong educational infrastructure and its cultural orientation toward long-term thinking, is well-positioned to follow. Embedding futures literacy in teacher training, civil service education, and municipal planning processes would gradually shift the operating system from reactive to anticipatory — from a system that is perpetually surprised by events to one that has rehearsed multiple possibilities and can recognise emerging patterns before they become crises.

These three mechanisms — deliberative bodies, red teams, futures literacy — share a common purpose. They are not designed to destroy consensus. They are designed to make consensus *earned* rather than assumed — the product of genuine deliberation and rigorous challenge rather than the suppression of dissent. In a high-trust society, this is a delicate cultural operation. The goal is not to import the adversarial political culture of other democracies. It is to give the existing Swedish commitment to *saklighet* — fact-based, rational deliberation — the institutional architecture it needs to function in a more complex world.

---

### 3.3 Territorial Capacity 2.0: Real Autonomy for Kommuner

The Municipal Trap — formal subsidiarity paired with functional centralisation — is the third pillar of the feedback deficit. Addressing it requires more than tinkering with the equalisation formula or adding another earmarked grant. It requires a structural shift in how authority, resources, and accountability are distributed between the centre and the periphery.

The first upgrade is **genuine fiscal autonomy**. Municipalities should have a tax base sufficient to fund their mandated responsibilities, and the equalisation system should compensate for structural differences without creating dependency. This is not a call to abolish the *kommunalekonomisk utjämning* — the principle of territorial solidarity is one of the achievements of the Swedish model. But the current system, combined with detailed national regulation of service standards, leaves municipalities with little room to set their own priorities. A municipality that wants to invest more in preventative social work and less in acute interventions should be able to make that trade-off — and be accountable to its citizens for the results.

The second upgrade is **safe-to-fail experimentation authority**. Municipalities need the legal right to test alternative approaches to integration, housing, education, and service delivery without seeking permission from Stockholm. The mechanism already exists in embryonic form: *försöksverksamhet* — experimental activity — can be authorised by the government for specific purposes. But the process is slow, narrow, and politically contingent. A general Experimentation Act — a *försöksverksamhetslag* — would give municipalities a standing right to propose and implement bounded experiments, with transparent evaluation and a clear pathway for scaling what works. The central state's role shifts from gatekeeper to enabler: setting the parameters within which experimentation is safe, providing the evaluation infrastructure, and ensuring that successful experiments are visible to other municipalities.

The third upgrade is **asymmetric capacity building**. Not all municipalities are equally positioned to take advantage of greater autonomy. Some have strong administrative capacity, dense civic networks, and a history of innovation; others are struggling with depopulation, skills shortages, and institutional fatigue. An autonomy framework that treats all municipalities identically risks widening the gap between the capable and the struggling. The solution is not to withhold autonomy from those who need it most — it is to pair autonomy with capacity-building support, so that municipalities at different starting points can build toward genuine self-governance over time. This is the principle of asymmetric devolution, applied at the sub-national level: different municipalities get different degrees of autonomy based on their demonstrated capacity to use it well, with a transparent pathway for increasing that capacity and the rights that accompany it.

The northern regions—Norrbotten and Västerbotten—illustrate both the potential and the limits of territorial coordination. Industrial investment intersects with housing, labour markets, ecosystems, and Sámi land use and rights. Coordination is not a substitute for legal entitlements or the consultation obligations applicable to the Sámi people and affected Sámi reindeer-herding communities. Any pilot in such an area would need to identify affected rights-holders, consult them through the required processes, and distinguish issues a municipality may decide from those governed by national permits or other authorities.

These three upgrades — fiscal autonomy, experimentation authority, asymmetric capacity building — are not a rejection of the Swedish model. They are its logical extension. The *folkhemmet* was built by municipalities that had genuine authority and experimented with different approaches to social welfare, housing, and public health. The centralisation of the late 20th century was a response to the complexities of a modern industrial economy. The task now is to restore the balance — to give the periphery the tools it needs to sense and respond, while maintaining the solidarity mechanisms that keep the system together.

---

### 3.4 Living Testbeds: Where Feedback Can Be Tested

Capacity does not develop in the abstract. It develops through application — through the attempt to solve real, pressing problems in real places, using the new sensing and deliberative architecture together. Sweden needs a portfolio of integrated testbeds where the feedback infrastructure can be demonstrated, refined, and made visible to the rest of the country.

These testbeds are not "sectors" to be funded. They are spatial arenas — specific territories, at the municipal or sub-regional scale — where the three upgrades described above are combined and tested simultaneously. The goal is to create visible, documented examples of what a high-feedback governance system looks like in practice, and to let that evidence do the work of persuasion.

**Energy Transition, Rights, and Territorial Coherence.** Northern industrial projects create opportunities and significant strains on housing, services, ecosystems, and Sámi reindeer-herding lands. A pilot should map cumulative environmental effects and the distribution of benefits and burdens, not merely improve coordination. It must respect consultation duties, lawful land-use decisions, and the role of Sámi rights-holders; municipal deliberation cannot replace those obligations. The municipality may coordinate services and learning, but cannot unilaterally settle contested mining, environmental, or Indigenous-rights questions.

**Housing Integration as a System Challenge.** A municipal pilot could test coordinated housing, transport and educational planning with published outcome measures and safeguards. Linking individual housing, school, employment or health records would require a separate legal basis, purpose assessment, data-minimisation analysis and governance review for every proposed use; it is not an automatic part of a Framtidskommun. Where possible, use open statistics or disclosure-safe aggregates. Any policy discretion must remain within existing law unless a lawful, rights-compatible amendment is enacted.

**School Reform as a Feedback Laboratory.** A municipal pilot could test decision processes, school-support coordination and prospective monitoring within existing competencies and national educational requirements. Longitudinal links to health or social-services data are not presumed legal or desirable; they would require their own authorization and safeguards. Designs should include baseline measures, non-participating comparisons where feasible, publication of adverse results, and no exemptions from children’s rights.

These living testbeds are not an exhaustive list. They are exemplars of a different way of thinking about public investment: not as the allocation of resources to predetermined programmes, but as the creation of spaces where a new governance architecture can be built, tested, and refined. In each case, the primary output is not a bridge, a turbine, or a school. The primary output is the *capacity to produce such things intelligently in the future* — the feedback loops, the deliberative habits, and the institutional confidence that make continuous adaptation possible.

---

What unifies these four investment domains — sensemaking infrastructure, structured disagreement, territorial autonomy, and living testbeds — is that they are all investments in the system's ability to sense and respond. They do not compete with the urgent challenges Sweden faces. They are the prerequisite for any challenge to be met without repeating the Drift Loop that has consumed so much energy and eroded so much trust.

The next section confronts the uncomfortable reality that has been lurking beneath this discussion: even the most intelligently designed feedback investments will encounter resistance from the political immune system that the current architecture sustains. Understanding that resistance — and designing around it — is the subject to which we now turn.

---

---

## 4. The Political Immune System: Why Feedback Fails

### 4.1 The Competence Trap as Immune Response

Every political order develops reflexes that protect its existing distribution of power, its settled assumptions, and its sense of itself. In Germany, the immune system is bureaucratic inertia — the multiplication of veto points that makes decisive action difficult. In France, it is the national political spectacle — an arena that amplifies conflict and consumes reform before it can take root. In Sweden, the immune system is subtler. It is **satisfied competence**.

The reflex is not aggressive. It does not denounce or obstruct. It is the calm, reasonable, evidence-backed response of a system that has every reason to believe in its own performance: *We are already among the best in the world. Our institutions are functioning. Our metrics are strong. What exactly needs fixing?*

This is not a cynical posture. It is an honest expression of the Swedish self-understanding, and it is grounded in real achievement. The international rankings, the aggregate statistics, the daily experience of citizens who encounter a state that largely works — all of these provide genuine evidence that the machine is running well. The problem is not that this evidence is false. It is that it is partial. The very metrics that confirm the system's success are the metrics that make its blind spots invisible. The Competence Trap is not a failure of self-awareness. It is a structural property of a system that has optimised its sensors for the conditions it already knows how to handle.

A corollary of satisfied competence is that **failure must become visible and undeniable before it becomes discussable**. Until the evidence is overwhelming — until the gang violence makes international headlines, until the housing queues stretch beyond a generation, until the NATO pivot is forced by events rather than chosen by deliberation — the system defaults to the assumption that things are basically working and that deviations from the norm will correct themselves. This is not stubbornness. It is the rational inference from decades of experience in which deviations *did* correct themselves, in which the system *did* absorb shocks and return to equilibrium. The problem arises when the environment changes in ways that make that assumption obsolete, and the system's own success prevents it from noticing.

---

### 4.2 The Consensus Filter and Expert Dependence

If satisfied competence is the immune system's first line of defence, the second is a cultural filter of remarkable effectiveness: the consensus that screens out uncomfortable signals before they reach the level where they might disturb the prevailing understanding.

Swedish political culture prizes *saklighet* — fact-based, rational deliberation — and *enighet* — the achievement of broad agreement. These are genuine democratic virtues. They prevent the kind of tribal polarisation that paralyses other political systems. They create space for long-term, evidence-based policy-making. They underpin the high trust that makes the Swedish model possible. But they also create a specific vulnerability: when the consensus is wrong, or when it is right but incomplete, the mechanisms for correcting it are weak, because the culture treats deviations from the consensus as probably erroneous.

This is not a conspiracy of silence. It is a social dynamic. The civil servant who suspects that an integration programme is failing faces a high burden of proof — not because anyone has ordered them to be silent, but because the institutional culture expects them to have overwhelming evidence before challenging a policy that commands broad political and expert support. The researcher whose findings contradict the prevailing narrative faces implicit scepticism, not because the research community is dishonest, but because the prior probability assigned to outlier findings is low. The journalist who wants to report on a disturbing trend must weigh the professional cost of being seen as alarmist. None of this requires formal censorship. It operates through the ordinary mechanisms of social and professional life — the raised eyebrow, the delayed promotion, the subtle preference for work that confirms rather than disrupts.

Coupled with this is a deep **expert dependence**. The Swedish state relies heavily on agencies, expert authorities, and institutional trust. Citizens trust agencies. Politicians trust agencies. Agencies trust their own expertise. This trust is largely earned — Swedish agencies are, by global standards, competent and honest. But it creates a structural vulnerability: when expert consensus is wrong or outdated, the system has weak mechanisms for detecting that quickly. There is no institutionalised function whose job is to challenge the prevailing expert view. There are no permanent red teams within agencies tasked with arguing the opposite of the consensus. There is no standing deliberative body empowered to bring citizen experience to bear on expert judgment. The result is a system that can be honestly, diligently, and competently wrong for extended periods — not because anyone is acting in bad faith, but because the architecture assumes that expert consensus is reliable and provides no systematic way to test it.

Immigration and integration policy provide a **proposed case for investigation**, not proof of a suppressed-warning mechanism. Researchers could compile contemporaneous warnings from teachers, residents, social workers, police, elected officials and other sources—including contradictory warnings—then code whether, when and why institutions responded. Party competition, information quality and limited attention are important rival accounts. No general suppression is asserted without a dated record.

---

### 4.3 The Agency Silo as Institutional Defence

The third line of the immune system is structural: the agency silo itself functions as a defence mechanism against inconvenient signals that cut across institutional boundaries.

Swedish agencies are, by design, autonomous. They are not subject to direct ministerial control in individual cases — a constitutional protection against political interference that is one of the strengths of the Swedish model. Each agency has its own mandate, its own budget, its own professional culture, and its own interpretation of what constitutes success. This autonomy creates islands of competence and integrity. It also creates islands of information, each self-contained and self-referential, each with its own metrics that confirm its own performance.

When a signal crosses agency boundaries—for example, possible interactions among school outcomes, housing, labour markets, and criminal recruitment—no single institution necessarily owns the entire explanation or response. Different actors may already cooperate, yet coordination can still fail because of competing mandates, scarce resources, disputed diagnoses, or governance incentives. The question is where collective responsibility is clearly assigned, exercised, and evaluated.

Moreover, agencies may have institutional incentives to retain control over their data and performance measures. Those incentives should be investigated rather than assumed to explain every restriction: legitimate confidentiality, statutory mandates, technical costs, and resource scarcity may be decisive in particular cases. Recent changes to Swedish disclosure rules mean that the operational question is increasingly whether existing possibilities are applied lawfully, consistently, and productively—not simply whether the law forbids cooperation.

When a cross-agency signal does eventually become too large to ignore, the typical response is to create a new coordinating body, a new task force, a new national strategy — which often adds another layer of coordination on top of the existing silos without changing the silo structure itself. The underlying information architecture remains intact. The agencies continue to operate with their own data, their own metrics, their own cultures. The new coordinating body lacks the data access and the institutional authority to do more than write reports. The loop closes. The next cross-agency signal will follow the same path from fragmentation to crisis.

---

### 4.4 The Narrative Strategy

Given the immune system described above, the way the feedback agenda is *talked about* is not peripheral to its success. It is central. A reform proposal that announces itself as a critique of the Swedish model — that frames the Data Archipelago as a failure, Jantelagen as a pathology, the Municipal Trap as a betrayal of subsidiarity — will trigger every immune response simultaneously. It will be dismissed as alarmist, as a misunderstanding of Swedish achievements, as an import of foreign anxieties that do not apply to a society that remains, by most measures, among the most successful on earth.

The task, therefore, is to frame the agenda not as a rupture but as a **continuation** — the same pragmatic, evidence-based institutional improvement that built the *folkhemmet*, now applied to the architecture of governance itself. The argument is not that Sweden has failed. It is that Sweden succeeded so well at building institutions for a specific set of conditions that it now needs to upgrade those institutions to match the conditions that have since emerged. The Competence Trap is not an accusation. It is an observation that applies to all high-performing systems, and Sweden is simply far enough along the performance curve to encounter it first.

This framing must be paired with an honest acknowledgment of Sweden's genuine strengths. The high trust, the institutional capacity, the culture of rationality, the digital infrastructure — these are not obstacles to reform. They are the foundation on which reform can be built. Sweden does not need to become a different kind of society. It needs to give the society it already is the sensory architecture it currently lacks.

The narrative must also speak to each of the policy mindsets that coexist in the Swedish political landscape. To the social-democratic tradition that built the *folkhemmet*, it must say: *you succeeded by pragmatically adapting institutions to conditions. The conditions have changed. The pragmatic response is to adapt again.* To the liberal and green traditions that push for innovation and sustainability, it must say: *the structures that suppress uncomfortable signals are also the structures that suppress the experimentation needed for the green transition.* To the conservative and moderate traditions that value stability and prudence, it must say: *the greatest threat to stability is not change — it is the delayed recognition of change that has already occurred.*

The core message is deceptively simple: *Sweden is not broken. It is deprecating — like software that still runs but is no longer being actively maintained for the environment it is operating in. The upgrade is not a rejection of the original design. It is the continuation of the pragmatic tradition that produced it.* This is a message that can be spoken from any political platform without contradiction. And it carries the full feedback agenda inside it.

---

The political immune system is powerful, but it is not omnipotent. It can be worked with, because its foundations — trust, competence, rationality — are the very resources needed for the upgrade. The next section turns to the concrete mechanisms of that work: the transition architecture that gives the feedback agenda a chance of surviving contact with the system it intends to upgrade.

---

---

## 5. Working with the Grain: Transition Architecture for Sweden

### 5.1 The Principle: Start Where Trust Is High

Every transition architecture must be matched to the immune system it navigates. In Germany, the strategy is to bypass bureaucratic inertia — to build capacity beneath the threshold of political controversy, where administrative modernisation can proceed without triggering the full coordination machinery. In France, the strategy is to bypass the national political spectacle — to start in low-visibility zones where results can be demonstrated before the arena consumes them. In Sweden, the strategy is different. It is to work *with* the existing trust, not around it.

Sweden's immune system — satisfied competence, the consensus filter, the agency silo — is not a hostile adversary. It is a product of the same cultural and institutional strengths that make Sweden governable. High trust, evidence-based policy-making, professional autonomy, and a preference for consensus are not obstacles to adaptation. They are the conditions under which adaptation must occur. The task is not to defeat them but to redirect them — to use the trust to have honest conversations, to use the evidence culture to demand better sensing, to use the professional autonomy to create protected spaces for experimentation.

This principle has a practical consequence: reform in Sweden should not be framed as an emergency. It should be framed as an upgrade — the kind of continuous improvement that Swedish institutions already pride themselves on. The tone should be calm, evidence-rich, and forward-looking. The emotional register is not *we must act before it's too late* but *we have an opportunity to build on our strengths before the environment shifts further.* This is not spin. It is strategic honesty. The possibility of a Competence Trap merits investigation; Sweden can build on existing institutional strengths whether or not the hypothesis proves true. Using those strengths wisely is the point.

The architecture that follows—transparent municipal testbeds, purpose-limited data agreements, bounded experiments and evidence-conditioned scaling—should be disclosed openly to participating residents, staff and elected bodies. Its legitimacy depends on public understanding of both the modest administrative changes and any longer-term institutional ambitions.

---

### 5.2 Transparent Municipal Testbeds

The most effective vehicle for upgrading Sweden's feedback architecture is the municipality. The *kommun* is already the level where complex social problems first become visible, where services touch citizens directly, and where the gap between responsibility and capacity is most acutely felt. It is also a level of governance that Swedes trust — local government typically enjoys higher confidence than national institutions — and where experimentation can occur without immediately becoming a national political proxy war.

The pilot strategy should not have an undisclosed “wrapper” or “payload.” Municipalities, residents and participating authorities should receive the same public description of aims, expected benefits, legal constraints, data uses, possible losses and evaluation rules. Honest framing is compatible with political pragmatism and is essential to consent and accountability.

Consider a concrete example. A group of municipalities — perhaps five to seven, diverse in size, geography, and economic base — could form a **"Framtidskommuner" (Future Municipalities) Network**. The stated purpose would be straightforward: to pioneer more integrated, data-informed approaches to complex local challenges, to share learning across municipal boundaries, and to provide a testbed for administrative practices that could eventually be adopted more broadly. The language is the language of *verksamhetsutveckling* — operational development — and *evidensbaserad praktik* — evidence-based practice. It is the language that Swedish public administration already speaks.

Within these published boundaries, Framtidskommuner could test process coordination, lawful data agreements, standing citizens’ panels and defined evaluation routines. Any expansion of municipal discretion would require a specific legal route and review of affected rights, rather than a general experimental exemption.

The key is that the Framtidskommuner would be *voluntary*. No municipality would be required to participate. Those that choose to — and there are already municipalities, across the political spectrum, that are acutely aware of the gap between their responsibilities and their capacities — would be self-selected for readiness. Their participation would be a signal of local political will, which provides cover for the national government to grant the necessary exemptions and resources. The dynamics of scaling by attraction begin with the first movers.

---

### 5.3 Cross-Silo Data Covenants

The Data Archipelago can persist despite expanded legal gateways. Since the 2025 reforms, the immediate task is not necessarily another nationwide permission to share: it is to map the actual legal basis, operational practices, technical barriers, and remaining analytical needs for each use case. Where a lawful basis already exists, agencies can explore carefully scoped implementation; where it does not, a voluntary agreement alone cannot create one.

A **cross-silo data covenant** would be an operational and accountability agreement among participating organisations—not a new disclosure power. It would specify a lawful purpose, legal bases, controllers, permitted fields or aggregate outputs, minimisation, access, retention, audit, and redress. Some cases may require only joint analysis of public statistics. Where personal data are necessary, legality and proportionality must be established independently of the covenant; an illustrative school–social-services–police linkage cannot be presumed permissible.

This precision is essential, but an agreement does not make an otherwise unlawful exchange lawful. The value of the covenant lies in testing a specific, authorised collaboration, recording its benefits and harms, and exposing operational barriers that remain even when sharing is permitted.

The covenants should start with narrowly scoped, legally assessed cases where a clearly documented gap prevents useful learning. Aggregate school-to-work transitions could be a lower-risk starting point than linking sensitive data about named minors. Proposals involving schools, social services, or police must undergo a separate necessity, proportionality, and rights assessment before any information exchange; the 2025 disclosure rules do not make all such uses automatically permissible.

The national government's role is to enable, not to control. It can provide a template legal agreement, model privacy protocols, and technical assistance. It can fund an independent integrity authority to oversee the covenants and build public trust. It can celebrate successful covenants and make their methods available to other municipalities. But the covenants themselves are initiated and governed locally, by the agencies that will use them. This respects the Swedish principle of agency autonomy while building the bridges that autonomy currently lacks.

---

### 5.4 Safe-to-Fail Municipal Pilots

Sweden, like most well-functioning states, has an aversion to visible failure. The pressure to deliver consistent, high-quality outcomes across all municipalities has produced a system in which deviations from national standards are treated as risks to be managed rather than experiments to be learned from. This is understandable. Citizens in Kiruna should not receive worse healthcare than citizens in Stockholm because their municipality decided to try something unconventional. But the understandable preference for consistency has a cost: it suppresses the variation that generates learning.

A **safe-to-fail pilot** is an experiment deliberately designed to overcome this aversion. It is bounded in scope — a specific municipality, a limited timeframe, a predefined set of activities. It is explicitly framed as a learning exercise, not a permanent policy change. Its participants — municipal officials, agency staff, citizen participants — are publicly assured that mixed results are expected and that honest documentation of what did not work is as valuable as evidence of what did. And it has political cover: a national government that authorises the pilot commits to protecting it from premature judgment.

The safe-to-fail framework is particularly important for the Municipal Trap. Municipalities that have been granted fiscal or regulatory flexibility need to be able to use it without fear that a single disappointing metric will trigger intervention or public criticism. The evaluation framework matters: pilots are assessed not by whether every output target is met, but by whether they generate knowledge that improves future decision-making. A pilot that reveals an unexpected obstacle — *cross-agency data sharing is harder than anticipated because of incompatible IT systems* — is a success in learning terms, even if its programmatic outcomes are mixed. This reframing must be established from the beginning.

The legal basis for safe-to-fail pilots already exists in embryonic form. *Försöksverksamhet* — experimental activity — can be authorised by the government under existing legislation. What has been missing is the ambition to use these mechanisms at a systemic rather than incremental scale, and the political will to protect the experiments long enough for their results to become visible. A dedicated *Försöksverksamhetslag* — an Experimentation Act — would provide a standing legal framework, specifying the scope of permissible experimentation, the governance and evaluation requirements, and the conditions under which successful experiments can be scaled.

The Framtidskommuner would be the first cohort of safe-to-fail pilots under this framework. Their experiences — documented transparently, evaluated independently, shared openly — would build the evidence base for broader adoption. Some experiments will succeed. Some will fail. Some will succeed in unexpected ways and fail in expected ones. The common output is learning, and learning is the foundation of the feedback upgrade.

---

### 5.5 Scaling by Attraction

The Swedish tradition of *kommunalt självstyre* — municipal self-government — provides a cultural and institutional foundation for the final element of the transition architecture. In a system where municipalities have constitutional standing and a strong identity as independent actors, scaling by central mandate is both politically difficult and operationally counterproductive. A municipality ordered to adopt a new governance approach by Stockholm will implement it with minimal commitment and maximum compliance theatre. A municipality that chooses to adopt an approach because it has seen it work in a neighbouring *kommun* will implement it with genuine ownership.

Scaling by attraction means making successful experiments visible, accessible, and easy to replicate. The national government's role is not to command but to enable: to fund documentation and evaluation, to facilitate peer-to-peer learning networks, to provide technical assistance and seed funding for municipalities that want to adopt proven approaches, and to celebrate successes publicly. The Swedish Association of Local Authorities and Regions (*Sveriges Kommuner och Regioner*, SKR) is a natural partner — an existing institution with the relationships, the legitimacy, and the convening power to facilitate horizontal learning across municipalities.

The dynamics are slow in the beginning, then accelerating. The first few Framtidskommuner demonstrate that integrated data sensing, citizen deliberation, and experimental autonomy produce better outcomes — not just on traditional metrics, but on the feedback velocity that prevents problems from compounding. A second wave of municipalities, observing the results, voluntarily adopts elements of the model. The national government, observing the second wave, adjusts the legal and fiscal framework to make adoption easier. Over time, what began as a small experiment at the periphery becomes the norm — not because anyone mandated it, but because enough actors chose it that the old way of working became harder to justify.

This is not a fast process. It will not produce dramatic headlines or visible political victories within a single electoral cycle. But it is a durable one. The changes it produces will be embedded in institutional practice, owned by the actors who implement them, and resilient to political shifts at the national level. In a high-trust, consensus-oriented society, this is the only kind of change that sticks.

---

The transition architecture described here—transparent municipal initiatives, lawful cross-agency agreements, safe-to-fail pilots and evidence-conditioned diffusion—does not require concealed institutional ambitions. It asks public bodies to be explicit about aims, costs, possible harms and which outcomes would justify stopping.

---

---

## 6. A Concrete First Step: Framtidskommuner

### 6.1 The Logic of the Pilot

A framework without a first step is a thought experiment. The feedback infrastructure described in this report — the sensemaking architecture, the deliberative mechanisms, the territorial rebalancing — cannot be built everywhere at once. Attempting to impose it nationally would be to commit the very error this report diagnoses: another reform designed in Stockholm, rolled out uniformly, blind to local variation, and consumed by the immune system before it has a chance to prove itself.

The wiser path is to begin with a small number of municipalities that choose to pioneer the new architecture — municipalities that already sense the gap between their responsibilities and their capacities, that have the civic infrastructure and political willingness to experiment, and that can serve as visible demonstrations of what a high-feedback governance system looks like in practice.

This section proposes the establishment of **Framtidskommuner** — Future Municipalities. The name is deliberate. It signals continuity with the pragmatic, forward-looking tradition that built the *folkhemmet*, while pointing toward the specific upgrade that municipalities need: not more resources within the existing architecture, but a different architecture that allows them to sense, connect, and respond at the speed their challenges demand.

The Framtidskommuner are not an alternative to existing municipal structures. They are an enhancement — a set of additional authorities, capacities, and accountabilities that sit alongside the regular responsibilities of a Swedish *kommun*. They are voluntary. They are time-limited, with clear evaluation milestones and a pathway for extension or scaling. And they are designed to generate the evidence that will either validate the feedback upgrade or reveal its flaws — either outcome advances the learning.

---

### 6.2 Selection Criteria

The Framtidskommuner should not be chosen by political convenience or by a competition that rewards the most polished application. The goal is to create a credible proof of concept, and credibility depends on selecting municipalities where the challenges are real, the conditions are representative, and the local capacity to engage seriously is present.

Five criteria should guide selection, administered through an open call managed by an independent foundation or research consortium, at arm's length from government:

**Problem density.** The municipality should face a meaningful cluster of interconnected challenges — for example, housing segregation combined with school inequality, or rapid demographic change combined with labour market mismatch, or industrial transition combined with social cohesion stress. The point is not to find the most distressed municipality, but to find municipalities where the interconnectedness of challenges is unmistakable and the limitations of siloed approaches are visibly costly.

**Existing civic infrastructure.** The municipality should have a baseline of functioning institutions, active civil society organisations, and some history of cross-sector collaboration — even if fragmented. The Framtidskommun is not a state-building mission from scratch. It is an upgrade to a system that already has some capacity to absorb it. A municipality with a dense network of engaged actors — strong *föreningsliv*, collaborative political culture, professional administrative capacity — would accelerate quickly.

**Political willingness.** The municipal leadership — both political and administrative — must be genuinely committed to the experiment, not merely tolerant of it. This commitment must include willingness to accept public scrutiny of mixed results, to protect the pilot through its inevitable difficult phases, and to invest staff time and political capital in the new deliberative and data-sharing arrangements. The safest sign of genuine willingness is a cross-bloc commitment, ideally spanning the traditional left-right divide.

**Scalability relevance.** The selected municipalities should collectively represent the diversity of Swedish conditions: at least one growing urban municipality, one stable mid-sized town, one rural or remote municipality facing demographic decline, and one municipality with a high proportion of foreign-born residents. If the pilots succeed only in uniquely favourable microclimates — a wealthy suburb with no integration challenges and a homogeneous, highly educated population — their lessons will be dismissed as irrelevant to the municipalities that face the hardest problems.

**Manageable scale.** The municipality should be large enough to contain meaningful systemic interactions — its own housing market, its own school system, its own social services — but small enough to be governable as a single learning entity. Most Swedish *kommuner* fall naturally within this range. The very largest — Stockholm, Göteborg, Malmö — would require sub-municipal pilot zones to be manageable; this is feasible but adds complexity for the first cohort.

A transparent selection process, with published criteria, an open call, and a publicly reasoned decision, would itself be a signal of the feedback architecture at work. It would create a constituency of municipalities that have chosen to participate rather than been conscripted — an essential foundation for scaling by attraction.

---

### 6.3 Core Design Features

Each Framtidskommun would be shaped by local conditions and priorities, but all would share a set of core design features that embody the feedback upgrade.

**Integrated governance mandate.** The pilot municipality would receive a tailored package of regulatory flexibilities and coordination authorities that allow it to treat education, housing, social services, integration, and public safety as a single integrated design space. This does not mean abolishing existing institutional boundaries or creating a new super-department. It means giving the municipal leadership — political and administrative — the authority to coordinate across silos, to pool budgets where appropriate, and to be held accountable for cross-domain outcomes rather than silo-specific outputs. The national government sets the goals; the municipality decides how to meet them, with the flexibility to deviate from national programme specifications where it can demonstrate a reasoned alternative.

**Lawful cross-silo learning infrastructure.** Each Framtidskommun would begin with a legal-and-privacy assessment of specific learning needs, using existing aggregate data where possible. Any personal-data exchange would require its own legal basis, documented necessity and proportionality, security, access controls, retention limits, and independent review; a covenant cannot grant access by itself. Public dashboards would publish only disclosure-safe aggregates, with checks for small-group identification and misleading conclusions.

**Standing citizen deliberative body.** Each Framtidskommun would establish a recurring *medborgarråd*, selected by civic lottery with stratification and deliberate outreach to people whose experiences are usually underrepresented. Participation would include accessibility support, compensation, independent facilitation, multilingual access where needed, transparent agenda-setting, and a formal public response from the elected council. Deliberation would complement—not override—representative institutions, statutory rights, or the specific consultation duties owed to rights-holders such as affected Sámi communities.

**Fiscal and experimentation autonomy.** A Framtidskommun might receive a targeted grant and specified permission to test alternative processes, subject to the legislation that actually governs each policy area. It would not have a general right to disregard national education standards, planning law, social-care duties, or privacy rules. Exemptions, if necessary, would have to be enacted or authorised through the appropriate legal route, published, time-limited, independently evaluated, and reversible.

**Adaptive learning framework.** Independent evaluators would preregister the pilot’s hypotheses and compare it with credible non-pilot cases where feasible. Measures should include feedback velocity and policy durability, but also education, health, service access, well-being, distribution of benefits and burdens, trust among underrepresented groups, privacy incidents, rights compliance, and unintended harms. More meetings or faster decisions are not successes if outcomes deteriorate or rights are infringed.

---

### 6.4 Budget, Governance, and Legal Basis

**Budget.** A preliminary planning assumption of SEK 50–100 million per municipality per year over an initial five-year period could be examined, but this is not a costed estimate. The budget must be built bottom-up from the selected pilots, existing grants, legal and technical assessments, staff capacity, participation support, and independent evaluation. Costs, opportunity costs, and the case for continued funding should be published before commitments are made.

**Governance.** The elected municipal council remains the accountable decision-maker within its competence. Any central support should be publicly authorized, with a transparent pilot-selection process and published funding criteria. An independent learning partner could evaluate the programme; its appointment, financing, conflicts, methodology and access to negative results must be disclosed. Citizen bodies advise or exercise only powers actually provided by law, and Sámi statutory consultation is not replaced by local deliberation.

**Legal basis.** Municipal self-government under the Instrument of Government and the Local Government Act provides an important starting point, not a blanket authority to depart from national law. A pilot might need targeted legislation, time-limited exemptions, or existing experimentation pathways, depending on its activities. The 2025 assignment to Statskontoret to examine municipal trials is a relevant policy route. Any dedicated **Försöksverksamhetslag för Framtidskommuner** would have to specify its scope and remain compatible with constitutional rights, sector-specific duties, EU law, and data-protection requirements. It could address:
- The scope of regulatory exemptions available to participating municipalities.
- The governance and accountability requirements for the data-sharing covenants and the citizens' assemblies.
- The evaluation framework and the role of the independent learning partner.
- The conditions under which the pilot status can be extended, modified, wound down, or scaled.

The Act would include a sunset clause: after five years, the pilots must either be renewed on the basis of demonstrated results or concluded in an orderly fashion. The temporary nature of the legal basis is politically protective. It assures sceptics that the experiment is bounded and reversible. And it creates a natural moment for the national conversation that scaling by attraction is designed to inform.

---

### 6.5 How to Measure Success

The success of the Framtidskommuner must be measured in terms that connect directly to the feedback deficit diagnosis — and that speak to the practical concerns of municipalities, citizens, and the national government.

**Feedback velocity** is a proposed process metric, measured from a clearly defined, auditable first signal to a documented and appropriate response. The comparison should account for case mix, pre-existing capacity, selection effects, and simultaneous reforms. Faster is not always better: escalation without evidence, coercive overreaction, or privacy-violating shortcuts would count against the pilot rather than for it.

**Policy durability** asks whether a reform continues to deliver documented benefits after initial funding or political enthusiasm ends. Persistence by itself is not success: a durable intervention can remain ineffective or harmful. Evaluators should track implementation fidelity, outcomes, reversibility and opportunity costs, rather than using survival time as a sufficient measure.

**Cross-silo coordination frequency** is a secondary process indicator: joint analyses and operational cooperation can be counted, but meeting volume is not a proxy for quality. Evaluators should examine whether coordination changes decisions, improves outcomes, avoids duplication, and remains proportionate to administrative costs.

**Trust and perceived procedural fairness** may be monitored with appropriate surveys. These are exploratory secondary measures, vulnerable to self-selection, small samples and simultaneous policy changes. Even observed improvements cannot automatically be attributed to the pilot; perceived safety, accessibility and non-participation also merit attention.

**Adoption by other municipalities** is a measure of transferability, not the ultimate proof of success. Replication should follow independent evidence of benefits, rights compliance, manageable cost, and suitability for different local conditions; attractive but ineffective approaches should not be scaled simply because they spread.

The evaluation would be published in accessible, visual formats — public dashboards, annual learning reports, municipal peer workshops — designed to make the pilots' experience legible and usable. Transparency is the engine of scaling by attraction. The more visible the learning, the harder it becomes for the old architecture to dismiss it.

---

The Framtidskommuner are a proposal, not a demand. An initial cohort of **3–5 volunteer municipalities** could demonstrate operational feasibility and identify harms. Self-selection and small sample size mean that the cohort cannot establish national average effects or credible intersectional subgroup effects. Expansion should follow transparent independent evaluation and a separate legality and distributional assessment.

That is how the *folkhemmet* was built: not by a single national plan imposed from above, but by municipalities experimenting, learning from one another, and gradually converging on what worked. The Framtidskommuner are an invitation to renew that tradition — not because the old model failed, but because it succeeded so well that it forgot to keep looking.

---

---

## 7. Coda: From Competence to Adaptability

### 7.1 The Wealth That Matters

Sweden is rich. Not merely in the material sense that international rankings capture, but in the deeper resources that make governance possible. It possesses one of the world's highest baseline levels of social trust. It possesses institutions that are, by global standards, competent, honest, and deeply embedded in the fabric of everyday life. It possesses a culture that values rationality, fairness, and long-term thinking. It possesses a tradition of pragmatic problem-solving that built one of the most equitable and stable societies in modern history.

These are not small things. They are the accumulated capital of generations — the *folkhemmet* that was not dreamed into existence but built, plank by plank, by municipal reformers, trade union negotiators, and civil servants who believed that good governance was a craft to be practised, not a prize to be won.

But wealth, in the sense that matters for a society's long-term flourishing, is not the stock of what has already been built. It is the capacity to build again — to sense what is emerging, to learn from what is failing, and to adapt before the window narrows. On that measure, Sweden has been drawing down its reserves — slowly, invisibly, beneath the threshold of the metrics that confirm its success.

The Competence Trap is **one candidate mechanism**: prior success may sometimes encourage excessive confidence in established ways of interpreting evidence. It has not been demonstrated for Sweden. Independent evidence could instead favour attention scarcity, routine implementation problems, political priorities or reasonable responses to changing circumstances.

---

### 7.2 The Shift

The shift this requires is subtle but profound. It is not a shift in policy, though policies will change. It is not a shift in values, though values will be tested. It is a shift in posture — from a system that is optimised to run to a system that is designed to learn.

A system optimised to run assumes that its environment is stable, its sensors are adequate, and its procedures are correct. It measures success by the consistency of its outputs and the efficiency of its processes. When disturbances arise, it treats them as temporary deviations that will revert to the mean. It filters out signals that challenge its assumptions. It protects its consensus. It performs beautifully — within the bandwidth of the conditions it was calibrated to handle.

A system designed to learn assumes that its environment is changing, its sensors are incomplete, and its procedures will need to be revised. It measures success by the speed of its sensing and the quality of its adaptation. When disturbances arise, it treats them as potentially permanent shifts that require investigation, not patience. It amplifies signals that challenge its assumptions. It structures disagreement. It performs with less elegance, perhaps, but with greater resilience — because it is constantly updating its model of the world it governs.

Sweden does not need to become less competent. It needs to become less confident that its competence is sufficient. It needs to build the sensory architecture that reveals what its current sensors miss. It needs to give its municipalities the tools to experiment, its agencies the bridges to connect, and its citizens the channels to speak. It needs to become permeable — to the signals its success has filtered out, to the realities its metrics have obscured, to the future its competence has made harder to see.

This is not a retreat from the Swedish model. It is the next chapter of the pragmatic tradition that created it. The *folkhemmet* was not built by people who assumed their institutions were adequate. It was built by people who looked honestly at their conditions, acknowledged what was not working, and designed accordingly. The conditions have changed. The pragmatism that built the *folkhemmet* now has a new task: to upgrade the architecture so that Sweden can continue to do what it has always done best — sense, learn, and build — in a world that moves faster than its current institutions can track.

---

### 7.3 The European Dimension

Sweden does not govern alone. The three reports in this series identify complementary deficits in Europe's three most capable governance systems.

Germany suffers an execution deficit. Money and projects are available, but the administrative machinery to deploy them is fragmented and slow. Permitting takes a decade. Coordination consumes the resources it was meant to deploy. The European Union's largest economy cannot translate fiscal capacity into physical outcomes at the speed its challenges demand.

France suffers an integration deficit. Decisions are made with impressive speed and intellectual clarity, but the connective tissue to translate them into durable, locally legitimate outcomes is absent. The spectacle amplifies and consumes. Reforms are announced, contested, and withdrawn — or pushed through with such visible disregard for opposition that the legitimacy wound deepens. The EU's other indispensable power cannot sustain the decisions it makes.

Sweden **may** face feedback problems in particular sectors, but this remains a hypothesis alongside competing explanations involving attention, organizational routines, political choice, law, capacity and intervention efficacy. The report does not establish a Sweden-wide causal deficit or that Sweden is uniquely less adaptive than peer countries.

Together, these three deficits define Europe's adaptive capacity gap. Europe cannot execute (Germany), cannot sustain (France), and cannot sense in time (Sweden). It struggles to *decide*, *integrate*, and *anticipate* simultaneously. The deficits are distinct, but they interact. A Germany that cannot execute slows the implementation of policies that France cannot sustain and Sweden did not detect were needed until too late. A France whose decisions unravel destabilises the frameworks that German execution and Swedish sensing depend upon. A Sweden that misreads emerging risks fails to provide the early warning that might allow German coordination and French deliberation to engage before crises mature.

The repair of any one deficit benefits the others. If Sweden upgrades its feedback architecture — if it becomes the first European nation to build a genuine sensemaking state, with the data-sharing infrastructure, the deliberative mechanisms, and the municipal capacity to detect signals before they become crises — it does not merely serve its own citizens. It provides a model for what the sensing dimension of 21st-century governance can look like. And it contributes, in a concrete and measurable way, to the adaptive capacity of the European system as a whole.

---

### 7.4 A Final Word

The Swedish model was never meant to be a museum piece. It was built by pragmatists who looked honestly at their conditions, acknowledged what was not working, and designed institutions to match the world they actually inhabited. That generation did not inherit a functioning welfare state. They built it — through municipal experiments, through iterative reform, through the patient, unglamorous work of institutional craftsmanship.

The conditions that generation faced were, in many respects, more dire than anything Sweden confronts today. Poverty was deeper. Inequality was starker. The institutional infrastructure was thinner. But they possessed something that the Competence Trap has made harder to access: the willingness to see clearly, to acknowledge what was failing, and to act.

The question facing Sweden now is not whether its institutions are still capable. They are. It is not whether its citizens still trust one another and their state. For the most part, they do. It is whether the pragmatism that built the *folkhemmet* — the same clear-eyed, evidence-based, institution-building pragmatism that turned a poor, peripheral nation into one of the most successful societies in history — still has the courage to upgrade what it built.

The money is there. The talent is there. The trust, while eroding, is still there. What has been missing is the sensory architecture that would allow all those resources to see what they are facing and to act before the window narrows. This report has described what building that architecture would look like. It has named the immune system that will resist. It has proposed a path — the Framtidskommuner — that works with the grain of Swedish institutions rather than against them.

The rest is not a matter of analysis. It is a matter of choice.

The Competence Trap is a hypothesis worth investigating, not a confirmed condition of Sweden. Testing it alongside rival accounts and protecting the legitimacy of any proposed reforms are the first tasks; developing the capability to learn from disconfirming evidence is the continuing aim.

---

### Afterword: A Note on This Report Itself

This report has argued that transformative ideas, to survive in a system governed by satisfied competence, must be framed as continuations rather than ruptures — as the next chapter of a pragmatic tradition rather than a critique of its achievements. It would be inconsistent not to apply that same logic to the report itself.

The argument presented here is, in its underlying structure, a systemic intervention. It sees the Swedish situation from a perspective that integrates the legitimate concerns of multiple political traditions while diagnosing the architectural gap that prevents any of them from being realised durably. But the report has deliberately avoided announcing itself in theoretical terms. It has spoken the language of state capacity, feedback loops, and institutional improvement — terms that the Swedish system can hear without immediate immunological rejection.

Spiral Dynamics is offered only as a heuristic vocabulary for possible policy mindsets, not a validated assignment of developmental stages to people, parties, cultures or countries. The Governance as Engineering models illustrate propositions under assumptions; they do not empirically establish the Competence Trap or prove that a specific design is superior. The companion paper *Whose Signals Count?* and the separate Stage 3 synthesis examine rival hypotheses, legal rights and institutional responsiveness.

But the report's primary purpose is not to recruit readers to a framework. It is to make one thing visible that was previously invisible: the Competence Trap at the heart of Sweden's current success, and the possibility of escaping it through the same pragmatic tradition that built the institutions now at risk. If that has been achieved, the report has done its work. What you do with that vision is, by design, up to you.

---

---

## Appendix A: Value Systems and Policy Mindsets — A Guide for the Swedish Context

### A Note on This Appendix

The main body of this report avoids specialised terminology from developmental psychology or cultural theory. It speaks the language of state capacity, feedback loops, and institutional improvement. This appendix offers a complementary lens for readers who wish to understand the deeper value-system dynamics at play in Swedish governance. It is optional, but it makes the report’s underlying logic fully transparent.

### A.1 The Basic Insight

Different groups and institutions tend to operate from different centres of gravity in how they think about governance, resources, and change. These are not personality types or party affiliations, though they correlate loosely with both. They are underlying value systems—ways of constructing what feels real, legitimate, and important.

Each value system represents a coherent response to particular life conditions. None is “better” in any absolute sense. Each has characteristic strengths that emerge under certain conditions and characteristic blind spots that emerge under others. The challenge of governance in a complex society is to integrate the legitimate concerns of multiple value systems without being captured by any single one.

The framework used here draws on Spiral Dynamics integral theory. What follows is a simplified map of the systems most relevant to contemporary Swedish governance.

### A.2 The Value Systems in the Swedish Arena

**Order and Stability (sometimes called “Blue”) — the Constitutional State.** In Sweden, this mindset expresses itself through *rättsstaten* — the rule-of-law tradition, the constitutional protection of rights, and the deep respect for due process that characterises Swedish public administration. Its strengths are procedural integrity, institutional memory, and a commitment to treating citizens equally before the law. Its blind spots include rigidity, a tendency to elevate process over outcome, and an instinct to preserve existing structures even when their function has degraded.

**Achievement and Efficiency (sometimes called “Orange”) — the Innovation Economy.** Sweden’s remarkable economic transformation from a poor agricultural nation to a high-tech export powerhouse draws on this mindset. It values competitiveness, entrepreneurship, scientific progress, and measurable results. Strengths: innovation capacity, global orientation, and a willingness to embrace technological solutions. Blind spots: externalities that fall outside market metrics, inequality that efficiency does not capture, and a tendency to treat what cannot be quantified as unimportant. The transactional digital state—world-class at point-to-point efficiency—is an expression of this mindset operating without sufficient integration from others.

**Inclusion and Care (sometimes called “Green”) — the *Folkhemmet* Ethos.** A possible value emphasis is solidarity, equal treatment and the quality of social support. These commitments can be advanced through different institutional arrangements and do not determine a single stance on migration or integration. The suggestion that inclusive aims systematically suppressed warnings remains a research hypothesis and cannot be inferred from a Spiral Dynamics label.

**Integrative and Systemic (sometimes called “Yellow”) — the Adaptive State.** This mindset prioritises functional fit, systemic awareness, and the capacity to integrate multiple perspectives without being captured by any of them. It emerges as a response to the limitations of all single-system approaches in the face of complex, interconnected challenges. Strengths: flexibility, whole-systems thinking, comfort with uncertainty and experimentation. Blind spots: can appear detached, overly intellectual, or politically unworkable to those operating from other mindsets. In Sweden, this mindset is nascent—visible in some municipal innovation work, in the design of the *försöksverksamhet* mechanisms, and in pockets of futures-oriented governance—but not yet institutionalised.

**Holistic and Planetary (sometimes called “Turquoise”) — Ecological Interdependence.** A possible orientation emphasizes long-term ecological and social interdependence. It must not be ranked as inherently more legitimate or empirically correct than other outlooks. Whether Swedish institutions express it, or would benefit from it, is not established.

### A.3 The Feedback Deficit as a Value-System Clash

The Swedish governance system is dominated by the interplay of the first three mindsets: the constitutional Blue that values procedure, the entrepreneurial Orange that drives efficiency, and the caring Green that sustains solidarity. Each has made essential contributions to the Swedish model. But the system lacks the integrative architecture that would allow them to sense collectively what none can see alone.

The Data Archipelago is an Orange transactional infrastructure that has not been upgraded to serve Green solidarity or Yellow systemic sensing. The variance-suppressing culture is a Green defence of consensus that has become a barrier to Yellow adaptation. The Municipal Trap is a Blue constitutional structure that has not been recalibrated to match the complexity that Orange economic change and Green social ambitions have produced.

The feedback infrastructure proposed in this report speaks to all three: it offers Orange measurable improvements in efficiency and innovation, Blue enhanced legal coherence and privacy protection, and Green genuine channels for citizen voice and social equity. The Framtidskommuner are spaces where the integration can be attempted—not by imposing a “higher” mindset, but by building an architecture that honours the strengths of all three while compensating for their blind spots.

---

---

## Appendix B: International Analogues and Precedents

The proposals in this report are not without precedent. The following examples illustrate existing implementations of feedback-oriented governance reforms.

### B.1 Finland: Futures Literacy and Anticipatory Governance

Finland has embedded futures thinking into government through multiple channels. The Committee for the Future in Parliament conducts foresight exercises and reviews government policy from a long-term perspective. Sitra, the Finnish Innovation Fund, has run nationwide futures literacy programmes demonstrating measurable increases in participants’ sense of agency and complexity tolerance. At the regional level, anticipatory governance zones integrate futures methods into planning. The Finnish experience demonstrates that futures literacy can be systematically cultivated and that the results are tangible. For Sweden, it offers a model for the red team and futures literacy proposals in Section 3.

### B.2 Estonia: Privacy-by-Design Data Infrastructure

Estonia’s e-governance infrastructure processes over 99% of public services online through a unified digital identity layer, but crucially, it also implements a privacy architecture that gives citizens full transparency about who has accessed their data. The X-Road data exchange layer enables cross-agency information sharing without centralising data in a single database. This is precisely the privacy-preserving sensemaking architecture that Sweden’s Data Archipelago requires. Estonia demonstrates that the technical and legal infrastructure for a sensemaking state is achievable—and that it can be built on principles that enhance rather than erode citizen trust.

### B.3 Denmark: Municipal Autonomy and Asymmetric Devolution

Denmark’s *kommuner* enjoy greater fiscal autonomy and experimentation flexibility than their Swedish counterparts, despite the structural similarities between the two Nordic models. Danish municipalities have broader authority to design service delivery models, set local priorities, and test alternative approaches. The Danish experience suggests that municipal autonomy does not undermine the universal welfare state—it can strengthen it by enabling context-sensitive adaptation. For Sweden, this is a direct precedent for the territorial capacity upgrades proposed in Section 3.

### B.4 United Kingdom: Devolution Deals and Combined Authorities

The UK’s devolution deals have created Combined Authorities with tailored powers over transport, housing, skills, and economic development in exchange for accountable governance. Greater Manchester’s health and social care devolution is a leading example of integrated public service governance at the sub-national level. While the UK context differs significantly from Sweden’s, the principle of asymmetric devolution—granting different levels of autonomy based on demonstrated capacity—is directly applicable to the Municipal Trap.

### B.5 Taiwan: Digital Democracy Infrastructure

Taiwan’s vTaiwan and Join platforms combine digital deliberation with real policy impact. vTaiwan uses structured processes of open consultation, facilitated deliberation, and consensus-seeking to develop policy proposals on contentious issues. It has produced legislation that would have been politically impossible through traditional channels. For Sweden, this demonstrates that digital tools can complement representative democracy with participatory depth—and that deliberative infrastructure can be built at scale.

### B.6 Germany and France: Cross-References in the Series

The companion reports in this series identify complementary deficits. Germany’s Adaptive Governance Pilot Regions address an execution deficit through territorial experimentation zones with integrated governance mandates. France’s Territoires d’Intégration Adaptative address an integration deficit through low-visibility high-learning zones designed to bypass the national spectacle. The Swedish Framtidskommuner complete the trilogy: they address the feedback deficit through municipalities empowered to sense, connect, and respond at the speed their challenges demand. Together, the three proposals could form the basis for a European network of learning territories.

---

---

## Appendix C: The Governance as Engineering Series Connection

### C.1 The Architectural Foundation

This report draws on a deeper body of work: the Governance as Engineering series, a set of formal analyses that model governance institutions as feedback control systems using standard mathematics from control theory, information theory, and cybernetics. The series is technical; this appendix summarises its core findings in non-technical language and shows how they underpin the feedback deficit diagnosis.

### C.2 The Five Papers in Brief

**Paper I — Governance Stability Simulator** models, under its assumptions, that centralised governance systems operate on aggregated signals that destroy spatial information. A central controller observing only the national average cannot see which municipalities are in distress and which are stable. Its interventions are simultaneously too weak for the crisis locations and too disruptive for the healthy ones. This suggests a formal analogy for the spatial blindness that the Data Archipelago produces in the Swedish context: when agencies cannot share local data, the national level sees only aggregates, and local variation becomes invisible. **Interpretation caveat:** A conclusion within a model is not an empirical result about Sweden.

**Paper II — Fractality as Stability** explores, under its assumptions, whether a single-scale controller can stabilise a system facing simultaneous fast, medium, and slow disturbances. A controller calibrated for fast crises will oscillate in response to slow trends. A controller calibrated for slow trends will be too slow for fast crises. One candidate architecture in the model is a fractal hierarchy of controllers, each matched to the timescale of its disturbance band. This suggests a formal analogy for the Mean-Reversion Fallacy critique: Sweden’s institutions are calibrated for medium-frequency electoral cycles and slow consensus-building. They lack the fast sensing and response loops that exponential or cascading challenges require. **Interpretation caveat:** A conclusion within a model is not an empirical result about Sweden.

**Paper III — The Observability-Democracy Connection** models, under its assumptions, possible limits to reliable transmission of citizen preferences through representation chains deeper than two or three layers. Noise variance exceeds surviving signal variance, and the policy layer governs a phantom signal. This suggests a formal analogy for the deliberative infrastructure proposed in Section 3: shortening the chain between citizen experience and policy response requires direct participatory mechanisms, not just improved representation. **Interpretation caveat:** A conclusion within a model is not an empirical result about Sweden.

**Paper IV — Requisite Variety and the Commons** models, under its assumptions, that governance systems with low-dimensional observation cannot stabilise high-variety resource systems. Observation dimensionality—the number of independent signal dimensions the governance system can access—is the primary determinant of commons management outcomes. This suggests a formal analogy for the cross-silo sensemaking infrastructure: connecting school data, health data, police data, and housing data increases the observation dimensionality available to municipalities, enabling them to govern the complex social systems they are responsible for. **Interpretation caveat:** A conclusion within a model is not an empirical result about Sweden.

**Paper V — The Coordination Failure Tax** models non-additive interactions among four assumed failure modes. A governance system exhibiting all four simultaneously is not four times worse than a well-designed one; it is categorically incapable of the functions it claims to perform. This suggests a formal analogy for the urgency beneath the calm tone of this report: the Competence Trap is not a single vulnerability but a compounding set of structural constraints that, left unaddressed, will progressively erode the system’s capacity to govern. **Interpretation caveat:** A conclusion within a model is not an empirical result about Sweden.

### C.3 From Engineering Analysis to Institutional Design

The Governance as Engineering papers use formal models and simulations to explore potential trade-offs in observation, representation and coordination. Results obtained under specified model assumptions are not mathematical proof that Swedish administrative institutions behave the same way. Any application requires a documented mapping from model variables to observed institutions and separate empirical validation.

This report uses the model results as **design prompts**, not as settled requirements. Candidate measures include observation delay, representational access, organizational boundaries, lawful data use and distribution of decision authority. Whether Framtidskommuner improve outcomes must be tested against alternatives, including simpler procedures and better-resourced existing services.

---

---

## Appendix D: Anticipated Objections

### D.1 “Sweden is already one of the best-governed countries in the world. Why fix what isn’t broken?”

This is the most natural response to this report, and it is precisely the Competence Trap in action. Sweden’s high rankings are real, but they measure performance against metrics that were designed for the conditions of the late 20th century. A system can be top-ranked on yesterday’s measures while being progressively less capable of handling tomorrow’s challenges. The question is not whether Sweden is well-governed by historical standards—it is. The question is whether its governance architecture is being upgraded at the pace its environment is changing. The answer, across the three mechanisms documented in this report, is no.

### D.2 “Doesn’t cross-agency data sharing threaten Sweden’s privacy traditions?”

The proposal rejects unrestricted sharing and centralized surveillance. Privacy-enhancing computation may reduce some disclosure risks, but does not remove re-identification, function creep, power asymmetries, lawful-basis requirements, or proportionality trade-offs. Every use must identify its legal authority, purpose, necessity, technical safeguards, potential harm from sharing **and not sharing**, retention rules, independent review and a route to remedy; aggregate analysis should be preferred where it suffices.

### D.3 “Isn’t this just decentralisation by another name? We tried that and it didn’t solve the problems.”

Sweden already has formal decentralisation—but it is paired with functional centralisation. Municipalities have responsibility without the fiscal or experimental autonomy to match. This report proposes not “more decentralisation” as a generic slogan, but a specific rebalancing: fiscal autonomy matched to responsibility, experimentation authority with transparent evaluation, and asymmetric capacity building so that municipalities at different starting points can build toward genuine self-governance. This is not the decentralisation Sweden has already tried; it is a qualitatively different relationship between the centre and the periphery.

### D.4 “The Swedish consensus culture is a strength, not a weakness. Why should we import adversarial politics?”

The goal is not to import adversarial politics. It is to give the existing consensus culture the architecture it needs to function in a more complex world. Structured disagreement—red teams, deliberative bodies, futures literacy—is designed to make consensus *earned* rather than *assumed*. The Swedish commitment to *saklighet* is not undermined by institutionalising the function of challenge; it is strengthened, because the consensus that emerges from genuine deliberation and rigorous testing is more robust than the consensus that emerges from the suppression of dissent.

### D.5 “Won’t the Framtidskommuner just become another pilot project that goes nowhere, like so many others?”

The risk is real. The Swedish landscape is littered with well-intentioned pilot projects that produced reports and faded away. The Framtidskommuner are designed to avoid this fate through three specific features: (1) genuine authority, not just consultative status—pilots that can actually make decisions produce different dynamics than pilots that can only advise; (2) transparent, independent evaluation that makes results visible and legible to other municipalities, creating the conditions for scaling by attraction; and (3) a dedicated legal framework—a *Försöksverksamhetslag*—that provides political cover and a pathway for extension or scaling, rather than leaving the pilots dependent on the continued enthusiasm of a particular minister or agency director.

### D.6 “This report diagnoses problems but doesn’t offer a political strategy. How do you actually get this done?”

The transition architecture in Section 5 is the political strategy. It is designed for Sweden’s specific institutional landscape: voluntary participation rather than central mandate, working with existing trust rather than against it, and framing the upgrade as a continuation of the pragmatic tradition rather than a critique of it. The Framtidskommuner require only that a handful of municipalities be willing to try something different, and that the national government be willing to grant the necessary legal and fiscal permissions. The evidence they produce—if the diagnosis is correct—will make the case for broader adoption more effectively than any political argument could.

---

---

## Appendix E: About this report and how it was made

### How it was made

This report was generated by AI language models (Claude, ChatGPT, DeepSeek) from prompts by Björn Kenneth Holmström. Several models were prompted in parallel to approach Sweden's situation, and their outputs were combined into a single text using the systems-thinking framework he had set out. He chose the topic, posed the questions and decided to publish the result, but wrote little of the text himself.

This edition received a **targeted editorial and source-checking pass (12 November 2026)** focused on the 2025 information-sharing reforms, the NATO chronology, municipal equalisation and experimentation, Sámi consultation, and privacy safeguards. That is not a comprehensive fact-check or independent validation of the report’s causal hypotheses. Numerous comparisons, cultural interpretations, projected effects, and budget assumptions remain provisional. Appendix F records sources checked and outstanding verification work.

### Perspective and limits

Neither the models nor the person who prompted them write from within Sweden's institutional core. Björn Kenneth Holmström lives in Sweden and knows Swedish society as a resident, but has no formal training or professional experience in Swedish public administration or political science. He has studied engineering physics and has worked with mathematical optimisation at TOMLAB Optimization. The framework applied here draws on complexity science, developmental psychology and governance theory.

Standing outside the institutions limits access to the granular, day-to-day texture of Swedish policy-making. A view from the periphery can sometimes raise questions that the centre has learned not to hear, but it can just as easily miss what insiders know. The report does not claim insider knowledge. It offers a lens that may or may not prove useful to those who hold institutional positions and are searching for frameworks that make sense of what they are experiencing.

Feedback, criticism, and corrections are welcome. The argument is offered in the spirit of collaborative sense-making, not definitive pronouncement.

### The Country Reports Series

This report was the third in a series of Country Reports for Systemic Change, all produced in the same way. The first examined Germany through the lens of a twin execution deficit and proposed Adaptive Governance Pilot Regions. The second examined France through the lens of an integration deficit and proposed Territoires d'Intégration Adaptative. Together, the first three reports propose a triptych on Europe's adaptive capacity gap: the inability to *decide*, *integrate*, and *sense* simultaneously. Later reports extended the series to India, the European Union, and beyond, each asking the same underlying question: *Is the real bottleneck money, decisions, or legitimacy—or is it the system's capacity to see what it is facing and adapt before the window narrows?*

---

## Appendix F: Editorial verification and open questions (12 November 2026)

This appendix documents a **targeted source check**, not a comprehensive verification or endorsement of the report’s conclusions. The report’s Competence Trap, Drift Loop, Data Archipelago, and Municipal Trap remain conceptual hypotheses. Claims of country-wide causation or comparative superiority require dedicated empirical study. The independent companion analysis proposed for later work is **not** part of this revision.

### F.1 Primary and institutional sources consulted

1. **Inter-agency sharing:** [Government of Sweden, 1 December 2025](https://www.regeringen.se/pressmeddelanden/2025/12/nu-rivs-sekretessen-mellan-alla-myndigheter-i-sverige/); [Government Bill 2024/25:180](https://www.regeringen.se/rattsliga-dokument/proposition/2025/05/prop.-202425180); [Skolverket guidance on sharing among schools, social services and police](https://www.skolverket.se/larande-och-trygghet/trygghet-vardegrund-och-arbetsmiljo/brottsforebyggande-arbete/dela-information-mellan-skola-socialtjanst-och-polis). The reform creates conditional opportunities; it does not authorise arbitrary linkage or remove all secrecy.
2. **NATO chronology and earlier cooperation:** [Government of Sweden, historical relations with NATO](https://www.government.se/government-policy/sweden-in-nato/history-of-sweden-and-nato). The rapid 2022 decision is evidence of a policy pivot, not sufficient evidence of suppressed warnings.
3. **Municipal equalisation:** [SKR, the equalisation system](https://skr.se/ekonomiochbudgetplanering/utjamningssystem.8275.html). The system is designed to offset differences in tax capacity and structural needs; specific residual mismatches must be demonstrated.
4. **Municipal trials:** [Government assignment to Statskontoret, 14 May 2025](https://www.regeringen.se/regeringsuppdrag/2025/05/uppdrag-till-statskontoret-att-analysera-och-foresla-regelforenklingar-och-forsoksverksamheter-for-okad-effektivitet-i-kommunal-verksamhet/). The proposed Framtidskommuner Act is an additional policy proposal, not existing law.
5. **Sámi consultation and rights context:** [Government Bill 2021/22:19](https://www.regeringen.se/rattsliga-dokument/proposition/2021/10/prop.-20212219); [Sametinget, mining in Sápmi (2026)](https://sametinget.se/1811). Consultation duties and rights issues are distinct from ordinary municipal coordination. This revision does not pronounce on the legality of any specific proposed project.
6. **Data-protection impact assessments:** [Swedish Authority for Privacy Protection (IMY)](https://www.imy.se/verksamhet/dataskydd/det-har-galler-enligt-gdpr/konsekvensbedomning/nar-ska-en-konsekvensbedomning-genomforas/). Technical privacy measures do not replace a lawful basis or proportionality assessment.

### F.2 Claims still requiring independent investigation

- Whether a distinctive Swedish Drift Loop can be identified in multiple domains, rather than inferred from selected examples.
- Whether *Jantelagen* and the proposed Mean-Reversion Fallacy explain measurable institutional behavior; these are metaphors until operationalised and tested.
- The comparative ranking of Swedish digital-government fragmentation and the causal contribution of each legal, technical, and organizational barrier.
- The size and distribution of municipal capacity constraints **after** tax and cost equalisation, and how constraints differ across policy fields.
- Comparisons with Germany and France, which are interpretative shorthand rather than validated country diagnoses.
- Costing, legal feasibility, baseline outcome measures, selection design, and possible adverse effects of the Framtidskommuner pilots.

### F.3 Revision principle

Correct demonstrable errors in the original report; retain its central argument while making its evidentiary limits explicit. Reserve more extensive inquiries into power, distribution, intersecting disadvantage, and decolonial critique for the separately scoped companion analysis, then revise the main architecture if that analysis warrants it.
### F.4 Relationship to the companion and Stage 3 synthesis

The separate *Whose Signals Count?* research agenda and *From Competence to Adaptive, Legitimate Governance* synthesis do not validate this report's main hypothesis. They introduce rival accounts (limited attention, selective responsiveness, organizational friction, capacity and efficacy), rights and authority boundaries, and an explicit research plan. As of 12 November 2026 no individual case-record study or comparative causal test has been performed. The 2025 inter-agency disclosure rules chiefly serve specified enforcement/control purposes, not an all-purpose mandate for statistical learning; the scheduled 1 January 2027 independent-school change must be checked again before implementation. Independent Swedish legal and methodological review remains a release requirement for operational recommendations.
