# Sverige — Kompetensfällan

## Sammanfattning

Sverige är ett av de bäst styrda samhällena på jorden. Oavsett vilket internationellt mått man använder – tillit, transparens, välfärdsleverans, digital infrastruktur – ligger landet nära toppen. Maskineriet surrar. Och just för att det surrar har något viktigt blivit svårt att se.

Denna rapport för fram **kompetensfällan** som en hypotes om institutionell anpassning: *ju bättre ett system presterar under kända förhållanden, desto svårare kan det bli att upptäcka när förhållandena förändras.* Sverige har fortsatt stora styrningsmässiga styrkor, men rapporten undersöker om landets sätt att upptäcka, tolka och reagera på förändring har hållit jämna steg med alltmer komplexa förhållanden. Resonemanget är ett prövbart diagnostiskt ramverk, inte en fastslagen generell lag.

Den **svenska driftloopen** är ett föreslaget mönster: tillit och delegering kan ibland följas av sen signalhantering, ackumulerade problem, en uppmärksamhetsskapande händelse och snabb korrigering. Exemplen visar möjligheten, inte förloppets orsak. Begränsad uppmärksamhet, organisatorisk friktion, politisk konkurrens, resursbrist och rimlig anpassning till ny information är alternativ.

Den föreslagna underliggande mekanismen är ett **återkopplingsunderskott**: ojämn förmåga att upptäcka signaler tidigt, dela dem när det är lagligt och lämpligt, tolka motstridig evidens och handla innan problem växer. I vilken grad detta förklarar Sveriges utmaningar, jämfört med politiska incitament, resurser, rättighetskonflikter och andra orsaker, är en empirisk fråga.

Tre möjliga mekanismer kan bidra till återkopplingsunderskottet:

- **Dataarkipelagen.** Sverige kombinerar avancerade digitala tjänster med splittrade ansvarsförhållanden, datamängder och analysprocesser. Offentlighets- och sekretesslagen (2009:400) och GDPR ställer skyddskrav, men informationsutbyte är inte generellt förbjudet: de rättsliga möjligheterna utvidgades under 2025, särskilt för brottsförebyggande och närliggande ändamål. Frågan är var laglig delning, interoperabilitet och gemensamt lärande fortfarande brister – inte om myndigheter helt saknar möjlighet att utbyta uppgifter.

- **Konsensusfiltrering (med Jantelagen som metafor).** Konsensusnormer kan ibland missgynna avvikande evidens. Det föreslagna *medelvärdesåtergångsfelslutet* är en separat hypotes om hur trender tolkas, inte ett belagt kännetecken för svenska institutioner. Inget av antagandena bevisar en kausal förklaring av samhällsutfall.

- **Den kommunala kapacitetsfällan.** Kommuner kan ibland sakna handlingsutrymme i förhållande till sitt ansvar, även efter inkomst- och kostnadsutjämning. Omfattning och effekter måste undersökas för specifika verksamheter, inte härledas från det kommunala skattesystemet ensamt.

Dessa mekanismer kan förstärka varandra och bidra till fördröjningar mellan signal och respons. Om de gör det systematiskt, och vilka andra orsaker som spelar roll, behöver prövas empiriskt.

Rapporten föreslår fyra områden för **avgränsade institutionella försök**: lagligt och ändamålsbestämt informationsutbyte och analys i allmänintresset, strukturerad oenighet och tillgänglig deliberation, lokal befogenhet i balans med kapacitet och ansvar samt oberoende utvärderade Framtidskommuner. Detta är förslag, inte bevisade förutsättningar för politiska framgångar.

Rapporten föreslår, men visar inte, att institutionellt självskydd, konsensusnormer och fragmenterade uppdrag ibland kan hindra reformer. Övergångsstrategin bygger på öppet redovisad frivillig försöksverksamhet, offentliggjorda mål och begränsningar, oberoende utvärdering och spridning först när evidensen motiverar det.

**Ett föreslaget första steg** är ett nätverk av 3–5 **Framtidskommuner**: frivilliga piloter som förenar rättssäkert lärande över myndighetsgränser, strukturerad medborgardeliberation och avgränsad ekonomisk och juridisk flexibilitet. Varje pilot behöver rättslig grund för personuppgiftsbehandling, verkligt deltagande för berörda grupper, oberoende utvärdering och metoder för att fånga såväl skador som vinster. Framgång ska bedömas genom samhällsutfall och rättighetsskydd vid sidan av återkopplingshastighet och reformers varaktighet.

Den europeiska dimensionen fullbordar serien som en **tolkande jämförelse**: Tyskland undersöks genom en hypotes om verkställighetsunderskott, Frankrike genom en hypotes om integrationsunderskott och Sverige genom en hypotes om återkopplingsunderskott. Detta är jämförande analyslinser, inte validerade rangordningar eller uttömmande förklaringar av respektive land.

Sverige kan pröva om dess starka institutioner skulle vinna på mer mottaglig återkoppling, tydligare avvägningar och bättre vägar från evidens till ansvarsutkrävande handling. Det är ett förslag, inte en fastställd diagnos av vad svensk framgång har dolt.

---

## 1. Kompetensfällan

### 1.1 Den svenska driftloopen

Sverige misslyckas inte. Det driver.

Mönstret är mindre dramatiskt än den franska reform-explosion-reträtt-cykeln. Det saknar den synliga frustrationen från tysk infrastrukturparalys. Men det är inte mindre systematiskt. Ett problem samlas – tyst, i utkanten av det offentliga samtalet, i statistiken som ingen enskild myndighet har ansvar för att koppla ihop. Det är synligt för dem som tittar direkt på det, men det har ännu inte passerat tröskeln där det bredare systemet måste erkänna dess existens. I åratal, ibland decennier, ackumuleras det.

Sedan förändras något. En utlösande händelse – ett upplopp, ett valresultat, en internationell kris – tvingar fram frågan i offentligheten. Det offentliga samtalet, som artigt hade ignorerat problemet eller behandlat det som en anomali, svänger abrupt. Samma institutioner som tålmodigt hade väntat på att trenden skulle vända av sig själv tvingas nu agera med skyndsamhet. De gör det – kompetent, beslutsamt, med den svenska statens fulla kraft bakom sig. Men åtgärden är komprimerad, reaktiv och ofta snävare än problemet den adresserar. Den underliggande arkitekturen som fördröjde erkännandet förblir oförändrad. Tilliten urholkas något. Systemet stabiliseras. Och loopen börjar igen.

Den föreslagna **svenska driftloopen** är en sekvens att pröva: tillit och delegering, möjlig fördröjning av signaler, en utlösande händelse och en omfattande korrigering. Om den är vanlig, specifik för Sverige eller betingad av tidigare framgång är okänt. Varje fall kräver daterade handlingar och jämförelse med alternativa orsaker.

Den föreslagna loopen kan verka inom flera sakområden, men exemplen behöver verifieras var för sig. Bostadsbrist och segregation, integrationsdebatter, energival och Natomsvängningen 2022 har skilda politiska och materiella orsaker. Att de liknar ett gemensamt mönster är en ledtråd, inte bevis för att samma mekanism har påvisats inom alla fyra områden.

Sverige misslyckas inte slumpmässigt. Det kör en stabil loop. Loopen är symptomet på ett specifikt, diagnostiserbart underskott – ett återkopplingsunderskott – som kan adresseras när det väl har förståtts. Men att förstå det kräver att man ser förbi ytan på ett system som, enligt de flesta konventionella mått, verkar fungera utomordentligt väl.

---

### 1.2 Ytberättelsen: En maskin som fungerar

Och den fungerar. Detta måste sägas tydligt, eftersom analysen som följer lätt kan misstolkas som en kritik av den svenska modellen, och det är den inte.

Vid nästan varje internationell jämförelse presterar Sverige i toppen eller nära toppen. Tilliten till institutioner, även om den har sjunkit från historiska toppnivåer, förblir bland de högsta i världen. Korruptionen är försvinnande låg. Välfärdsstaten levererar – sjukvård, utbildning, socialt stöd, föräldraledighet, pensioner – på en nivå av omfattning och kvalitet som de flesta länder bara kan sträva efter. Den digitala infrastrukturen är i världsklass. Ekonomin är innovativ, exportorienterad och motståndskraftig. Det internationella varumärket är starkt. När globala rankningar av styrningskvalitet, livskvalitet eller sociala framsteg publiceras, återfinns Sverige tillförlitligt i toppskiktet, ofta bland de fem bästa.

Dessa resultat är verkliga. De är produkten av generationer av pragmatisk, evidensbaserad institutionell utformning – folkhemstraditionen som byggde ett av de mest jämlika och stabila samhällena i modern historia. Den svenska staten är inte en fallerande maskin. Den är en exceptionellt välunderhållen sådan. Tjänstemännen som driver den är i stort sett kompetenta och hängivna. Politikerna som styr den är, med jämförande mått, seriösa och välinriktade. Medborgarna som finansierar den genom några av världens högsta skattetryck gör det till stor del frivilligt, eftersom de tror – med rätta – att de får värde i gengäld.

Detta är ytberättelsen. Den är korrekt så långt den sträcker sig. Och just för att den är korrekt döljer den något viktigt.

---

### 1.3 Kompetensfällan, namngiven

Här är det centrala begreppet i denna rapport. Det är bedrägligt enkelt, och dess implikationer är mindre bekväma än de först verkar.

**Kompetensfällan:** *Ju bättre ett system presterar under kända förhållanden, desto svårare blir det att upptäcka när dessa förhållanden har förändrats.*

Detta behöver inte vara ett misslyckande för den svenska modellen. Det är en tänkbar risk i högpresterande system, inte en fastslagen egenskap hos alla sådana system. Framgång kan skapa tillförsikt; tillförsikt kan minska uppmärksamheten på avvikande signaler; och invanda mätetal kan missa nya förhållanden. Dessa orsakssamband måste prövas mot evidens och alternativa förklaringar.

Många institutioner som bär upp den svenska välfärdsstatsmodellen formades i ett annat socialt och ekonomiskt sammanhang: starkare industriella sysselsättningsmönster, hög organisationsgrad och långsammare teknisk förändring. Sverige har emellertid aldrig varit helt homogent eller institutionellt statiskt; befolkningen har länge omfattat samer och andra nationella minoriteter. Den analytiska frågan är vilka ärvda antaganden som lever kvar i specifika program och beslutsprocesser – inte om hela staten en gång formgavs för en enda enhetlig befolkning.

De flesta av dessa antaganden har urholkats avsevärt. Sverige är nu ett mångkulturellt samhälle med betydande befolkningsgrupper födda utomlands eller med utlandsfödda föräldrar. Industribasen har transformerats – den förblir stark, men sysselsättningens natur, fackföreningarnas roll och kopplingen mellan arbete och gemenskap har förskjutits. Geografisk rörlighet, i kombination med bostadsmarknadens dysfunktion, har koncentrerat möjligheter till urbana kärnor och lämnat peri-urbana och landsbygdskommuner med tunnare skattebaser och växande servicebehov. Den externa miljön – geopolitiskt, teknologiskt, ekologiskt – förändras snabbare än valcykeln kan bearbeta.

Statens arkitektur har emellertid inte uppgraderats i motsvarande grad. Den var aldrig utformad för att uppgradera sig själv. Den var utformad för att köras. Och den körs vackert – inom bandbredden av de förhållanden den kalibrerades för att hantera. Problemet är inte att maskinen går sönder. Det är att miljön runt den har förändrats, och maskinen saknar den sensoriska apparaturen för att upptäcka den fulla omfattningen av denna förändring.

Detta är varför Kompetensfällan är så förrädisk. Ett fallerande system genererar synlig nöd – protester, ekonomisk kontraktion, institutionell kollaps – som framtvingar anpassning. Ett framgångsrikt system genererar motsatsen: aggregerade utfall som förblir inom acceptabla gränser, internationell validering, ett rimligt argument för inkrementell förbättring snarare än strukturell reform. Framgången är inte en illusion. Men den är en partiell vy, och just det självförtroende den inger gör partiskheten svårare att uppfatta.

---

### 1.4 En kort illustration: Nato och loopen

Ett exempel tydliggör mönstret utan att kräva att läsaren navigerar politiskt laddade inrikesdebatter.

I decennier vilade Sveriges säkerhetspolitik på en stabil konsensus: militär alliansfrihet, ett starkt territoriellt försvar och en omsorgsfullt förvaltad relation till Nato som stannade kort om medlemskap. Denna konsensus upprätthölls av expertbedömningar, institutionell kultur och bred politisk enighet. Den var inte irrationell. Den hade tjänat Sverige väl genom kalla kriget och dess efterdyningar.

Säkerhetsmiljön hade förändrats under flera år: Rysslands krig i Georgien 2008, annekteringen av Krim 2014 och ökande säkerhetsoro i Östersjöområdet ingick i den svenska debatten. Sverige fördjupade också sitt praktiska Natosamarbete, bland annat genom ett fördjupat partnerskap 2014 och värdlandsstödsavtalet 2016. Detta visar såväl anpassning som kontinuitet. Om åtgärderna var tillräckliga och om andra vägval hade gett bättre resultat är omstritt.

Rysslands fullskaliga invasion av Ukraina i februari 2022 utlöste en snabb förändring av Sveriges allianspolitik. Regeringen beslutade den 16 maj 2022 att ansöka om Natomedlemskap, Sverige ansökte den 18 maj och blev medlem den 7 mars 2024. Den snabba omsvängningen är förenlig med driftloopen, men bevisar inte i sig att tidigare information hade undertryckts: en stor yttre chock kan också rationellt förändra ett lands bedömning av risker och allianser.

Illustrationen väcker därför en fråga om beslutsprocessen snarare än avgör den. Prövade institutionerna alternativa säkerhetspolitiska utvecklingar i tid, gjorde avvägningarna begripliga och möjliggjorde legitim oenighet? Eller ändrades politiken på ett rimligt sätt när förutsättningarna ändrades? En prövning av driftloopen behöver granska beslutsunderlag, offentlig debatt och alternativa förklaringar – inte härleda ett institutionellt misslyckande enbart ur omsvängningens snabbhet 2022.

---

### 1.5 Sveriges genuina fördelar

Innan vi går vidare till diagnosen är det värt att stanna upp och erkänna vad Sverige har som talar för landet. Kompetensfällan är en genuin begränsning, men resurserna som finns tillgängliga för att adressera den är lika genuina.

Sverige har en av världens högsta basnivåer av social tillit. Denna tillit är inte jämnt fördelad – den är lägre bland utlandsfödda invånare, bland unga, bland dem i prekära ekonomiska situationer – men den förblir, sammantaget, en djupgående demokratisk resurs. Tillit innebär att medborgare är villiga att finansiera ambitiösa offentliga program. Det innebär att institutioner kan agera utan att möta omedelbar delegitimisering. Det innebär att det politiska samtalet, även om det hårdnar, ännu inte har kollapsat i den tribala polarisering som paralyserar andra demokratier. Tillit är grunden på vilken en sensorisk uppgradering kan byggas – eftersom tillit möjliggör ärliga samtal om vad som inte fungerar, utan att dessa samtal utlöser ett kollaps i förtroende.

Sverige har också en stark institutionell kultur av *saklighet* – faktabaserad, rationell överläggning. Denna kultur är under press, och dess tendens att dämpa obekväma signaler är en del av diagnosen. Men det underliggande engagemanget för evidens, för pragmatisk problemlösning och för inkrementell förbättring förblir en genuin tillgång. Det är samma kultur som byggde folkhemmet från första början – inte genom ideologi, utan genom en uthållig, flergenerationsprocess av institutionell experimentation och förfining.

Den digitala infrastrukturen är i världsklass. Personnumret tillhandahåller en unik identifierare som, med lämpliga integritetsskydd, skulle kunna möjliggöra systemisk avkänning på en upplösning som de flesta länder inte kan matcha. Den kommunala strukturen, även om den är fångad i paradoxen formell subsidiaritet-funktionell centralisering, tillhandahåller ett distribuerat nätverk av styrenheter som skulle kunna bli laboratorier för adaptiv experimentation om de gavs den fiskala och legala autonomin att göra det.

Och Sveriges kulturella koppling till naturen, dess globala utblick och dess tradition av långsiktigt tänkande – *lagom*-sensibiliteten som värderar balans, tillräcklighet och intergenerationellt ansvar – tillhandahåller ett kulturellt underlag som är ovanligt redo för den typ av holistisk, föregripande styrning som 2000-talet kräver. Kompetensfällan är fortfarande en hypotes. Men Sverige, mer än de flesta länder, har resurserna att ta sig ur den – om det först kan se att det befinner sig i en.

---

### 1.6 Den verkliga frågan

Vid det här laget kan en välbekant otålighet uppstå. *Så vad bör Sverige göra? Vilka reformer behövs?*

Argumentet i denna rapport är att själva formen på dessa frågor speglar Kompetensfällan själv. De antar att problemet är en känd policymässig lucka som den existerande arkitekturen, rätt riktad, kan fylla. Men arkitekturen var inte utformad för att se de luckor som nu betyder mest. Att be den identifiera de reformer den behöver är att be en maskin att diagnostisera sin egen sensors begränsningar – samtidigt som den endast använder dessa sensorer för att göra det.

Den verkliga frågan är inte "Vad bör Sverige göra annorlunda?" Den är "Hur blir Sverige kapabelt att avkänna vad det för närvarande inte kan – och att agera på den avkänningen innan signalerna har ackumulerats till kriser?"

Resten av denna rapport ägnas åt den frågan. Den diagnosticerar återkopplingsunderskottet i dess tre strukturella mekanismer: Dataarkipelagen, den kulturella variansdämpningen och den kommunala kapacitetsfällan. Den beskriver hur ett bygge av återkopplingsinfrastruktur skulle se ut i praktiken. Den namnger det politiska immunsystem som kommer att motstå varje sådan ansträngning. Och den föreslår ett konkret första steg: ett antal *framtidskommuner* – framtidskommuner – utformade för att maximera återkopplingshastigheten och demonstrera att ett annat sätt att avkänna och reagera är möjligt.

Sverige behöver inte bli mer kompetent. Det är redan bland de mest kompetenta samhällena på jorden. Det behöver bli mer *genomsläppligt* – för de signaler dess nuvarande arkitektur filtrerar bort, för de verkligheter dess mätetal missar, och för den framtid dess framgång har gjort svårare att se. Det är inte ett misslyckande för den svenska modellen. Det är nästa kapitel i den pragmatiska tradition som byggde den.

---

---

## 2. Återkopplingsunderskottet: En ny diagnos

### 2.1 Vad "återkopplingskapacitet" betyder

Termen "återkoppling" har en vardaglig klang. I dagligt bruk associeras den med utvärderingssamtal, kundundersökningar, det årliga samtalet mellan chef och medarbetare. Det är inte vad som avses här.

Återkopplingskapacitet, i den mening som är relevant för Sveriges nuvarande situation, är förmågan hos ett styrsystem att upptäcka oroande signaler tidigt, att dela dessa signaler över institutionella gränser utan förvrängning eller fördröjning, att erkänna deras implikationer ärligt – även när dessa implikationer utmanar den rådande konsensusen – och att agera på dem innan de förvärras till kriser.

Detta är inte en enskild förmåga. Det är en sammansättning av avkänning, överföring, tolkning och respons, fördelad över institutioner, kulturella vanor, rättsliga ramverk och kognitiva färdigheter. När återkopplingskapaciteten är hög kan ett samhälle upptäcka en bostadsmarknadsstörning, en integrationsutmaning eller en förskjutning i säkerhetsmiljön medan den fortfarande är hanterbar – och kan svara med åtgärder kalibrerade efter det framväxande problemets skala snarare än den slutliga krisens skala. När återkopplingskapaciteten är låg färdas samma signaler långsamt, om alls. De filtreras, mjukas upp och ibland aktivt dämpas. När de slutligen blir obestridliga har fönstret för kalibrerad respons stängts, och det enda återstående alternativet är den typ av komprimerad, reaktiv korrigering som den Svenska driftloopen beskriver.

Sverige saknar inte kompetens. Dess institutioner bemannas av kapabla, hängivna yrkespersoner. Dess offentliga förvaltning är jämförelsevis fri från korruption och politisk inblandning. Dess politiska kultur, även om den är alltmer ansträngd, förblir mer deliberativ och evidensbaserad än de flesta. Underskottet ligger inte i människornas kvalitet eller processernas integritet. Det ligger i arkitekturen som bestämmer vad dessa människor och processer kan se.

Rapporten undersöker tre möjliga och delvis samverkande mekanismer: fragmenterat lärande mellan organisationer, potentiell konformitetspress och obalans mellan lokalt ansvar och kapacitet. Hur vanliga de är, hur de samverkar och vilken förklaringskraft de har måste prövas empiriskt.

---

### 2.2 Dataarkipelagen: Varför Sverige inte kan se sig självt

Sveriges personnummer och administrativa register kan under lämpliga rättsliga och organisatoriska förutsättningar stödja longitudinella analyser av hög kvalitet. De skapar inte i sig något allmänt system för myndighetsövergripande personuppgiftssamkörning eller någon generell rätt att koppla samman individuppgifter. Sådan behandling kräver avgränsade ändamål, giltig rättslig grund och efterlevnad av tillämpliga sekretess- och dataskyddsregler.

I praktiken är ansvar, informationssystem, sektorsregler och analyskapacitet fortfarande fördelade mellan myndigheter och förvaltningsnivåer. Men informationsutbyte är inte generellt blockerat. Sedan den 1 april 2025 föreskriver lag (2025:170) vissa uppgiftsskyldigheter gentemot brottsbekämpande myndigheter; sedan den 1 december 2025 utvidgar en generell sekretessbrytande bestämmelse i 10 kap. 15 a § offentlighets- och sekretesslagen (2009:400) möjligheten till utbyte mellan myndigheter för angivna ändamål, bland annat brottsförebyggande arbete och felaktiga utbetalningar, med villkor och undantag. Problemet behöver därför undersökas för varje ändamål: vad får delas, vad bör delas och vad hindrar fortfarande användbar gemensam analys?

Gränserna är delvis avsiktliga: sekretess, ändamålsbegränsning och dataskydd skyddar människor mot missbruk av känsliga uppgifter. Andra hinder kan vara oförenliga system, otillräckliga resurser för samverkan, oklart ansvar eller osäkerhet om tillämpningen av nyligen ändrade regler. Ökad informationsdelning kan förbättra samordningen men också skapa oproportionerlig övervakning, profilering och avhållande effekter. Uppgiften är att identifiera den minsta lagliga och effektiva åtgärden för en påvisad informationsbrist.

Detta är **dataarkipelagen** som analytisk metafor: inte slutna öar utan broar, utan ojämnt sammankopplade myndigheter vars befogenheter, tekniska system och incitament inte automatiskt skapar gemensamt lärande. Skolfrånvaro, kommunal ekonomi och rekrytering till kriminalitet kan undersökas med olika datamängder, aggregeringsnivåer och skyddsåtgärder. Den viktiga prövningen är om tillgänglig evidens faktiskt sammanförs för legitima beslut – inte det obelagda antagandet att ingen myndighet någonsin kan se sambanden.

Detta är det djupare felet under ytan av Sveriges hyllade digitala transformation. Sverige har byggt en av världens mest avancerade **transaktionella** digitala stater. BankID tillåter medborgare att autentisera sig sömlöst över hundratals tjänster. Swish möjliggör omedelbara betalningar. Skattedeklarationen är så automatiserad att den för många medborgare inte kräver mer än en sms-bekräftelse. Detta är genuin prestation, och det är med rätta beundrat. Men transaktionell digitalisering är inte samma sak som systemisk synlighet. Staten har digitaliserat *effektivitet* – punkt-till-punkt-interaktionerna mellan medborgare och myndighet – utan att digitalisera *meningsskapande* – nod-till-nätverk-mönstren som framträder först när signaler från flera myndigheter kopplas samman.

Spänningen är ändå viktig: mycket effektiva digitala tjänster för enskilda är ingen garanti för snabbt lärande över verksamhetsgränser. Sveriges utmaning är att bedöma var befintliga rättsliga möjligheter, interoperabilitet, styrning och utvärdering räcker – och var riktade, integritetsskyddande förbättringar behövs. Dataarkipelagen är därmed en prövbar institutionshypotes, inte ett faktiskt påstående om att svenska myndighetsdata endast får användas för transaktioner.

---

### 2.3 Jantelagen som variansdämpningsalgoritm

Om Dataarkipelagen är återkopplingsunderskottets yttre arkitektur, så är den inre arkitekturen kulturell. Och kulturen har ett namn, även om det oftare åberopas i självironiska skämt än i seriös analys.

Jantelagen – härstammar från en roman från 1933 av Aksel Sandemose, där en fiktiv dansk småstad upprätthåller en oskriven social kod: *Du skall icke tro, att du är något. Du skall icke tro, att du är bättre än oss.* De tio reglerna är en karikatyr av skandinavisk småstadskonformitet, men de fångar något verkligt. Över decennier har Jantelagen blivit en förkortning för en kulturell tendens att motverka individuell exceptionalism, att värdera kollektiv konsensus över personlig ambition och att behandla synlig avvikelse från normen med tyst misstänksamhet.

Som metafor kan *Jantelagen* belysa hur anpassningstryck och ovilja mot oenighet kan begränsa institutioners uppmärksamhet. Den bör däremot inte behandlas som en uppmätt orsaksförklaring till Sveriges historiska jämlikhet, brottslighet eller sociala sammanhållning: dessa utfall beror också på politik, arbetsmarknadsinstitutioner, ekonomi och många andra faktorer. Det prövbara påståendet är om vissa beslutsmiljöer systematiskt nedvärderar välgrundade minoritets- eller avvikande signaler.

Men en variansdämpningsalgoritm som dämpar negativa avvikelser dämpar också positiva. Den dämpar entreprenören som utmanar etablerade affärsmodeller, forskaren som ifrågasätter disciplinära ortodoxier, tjänstemannen som argumenterar för att en omhuldad policy inte längre fungerar, medborgaren som insisterar på att konsensusen är fel. I en stabil miljö är denna dämpning hanterbar – kostnaden för den dämpade positiva variansen uppvägs av nyttan av den dämpade negativa variansen. I en snabbt föränderlig miljö förskjuts kalkylen. Ett system som behöver anpassa sig behöver tillgång till avvikelser – till de tidiga signalerna om att något har förändrats, till de okonventionella experiment som kan avslöja en bättre väg, till de obekväma rösterna som insisterar på att bli hörda även när konsensusen föredrar tystnad.

En möjlig fråga är om innovation i näringsliv och förvaltning möter olika incitament och institutionella hinder. Exempel på framgångsrika svenska teknikföretag visar inte någon orsakskedja till statlig anpassningsförmåga, och konsensuskulturens roll är oprövad.

Även **medelvärdesåtergångsfelslutet** är en föreslagen diagnostisk metafor, inte ett belagt antagande som omfattar hela den svenska förvaltningen. I vissa situationer kan beslutsfattare uppfatta en störning som tillfällig trots att den signalerar varaktig strukturell förändring. Att skilja dessa fall åt kräver tidsseriedata, explicita modeller och dokumentation av hur alternativa tolkningar har prövats.

Vissa störningar är övergående medan andra signalerar strukturell förändring. Tänkbart undersökningsmaterial är rekrytering till kriminella nätverk, snabbt förändrade behov av bostäder och service och klimatrelaterade risker. Faktiska tidsserier, tidigare prognoser och beslutsakter måste studeras i stället för att anta att beslutsfattare förväntade sig återgång till medelvärdet. Ingen mekanism kallad ”demografisk ersättning” påstås.

Om beslutshandlingar skulle visa en obefogad förväntan om återgång till tidigare trender vore det ett möjligt stöd för hypotesen om medelvärdesåtergångsfelslut. Det skulle inte i sig visa någon specifikt svensk kulturell orsak eller en kompetensfälla. Hypoteserna måste prövas var för sig.

Kulturförklaringar får inte ersätta evidens med antaganden om motiv. Tystnad, oliktänkande och utebliven handling kan bero på tidspress, professionella bedömningar, politiska begränsningar eller osäkerhet. Daterade beslutsunderlag, intervjuer och jämförelsefall behövs för att knyta ett förbisett larm till konsensuspress.

---

### 2.4 Den kommunala kapacitetsfällan: Ansvar utan kapacitet

Sverige beskrivs ofta som en decentraliserad stat. De 290 kommunerna och 21 regionerna åtnjuter konstitutionellt skydd under Regeringsformen, som garanterar lokalt självstyre. Kommuner tar ut sin egen inkomstskatt, sätter sina egna budgetar och ansvarar för några av de mest väsentliga offentliga tjänsterna: skolor, äldreomsorg, socialtjänst, fysisk planering och – i allt högre grad – frontlinjen för integration och allmän säkerhet.

Denna decentralisering är verklig, och den är en av den svenska modellens styrkor. Den placerar beslutanderätt nära de medborgare som påverkas av dessa beslut. Den tillåter variation i lokala prioriteringar och tillvägagångssätt. Den skapar, i princip, ett distribuerat nätverk av styrelselaboratorier som kan lära av varandras framgångar och misslyckanden.

Men decentraliseringen är ofullständig på sätt som är djupt betydelsefulla för återkopplingskapaciteten. Detta är tillståndet av **formell subsidiaritet, funktionell centralisering** – ett system som delegerar ansvar nedåt samtidigt som det behåller auktoritet och fiskal kontroll i centrum.

Den ekonomiska dimensionen är viktig men mer komplex än ett enkelt bortfall av lokal skattekraft. Kommunerna tar ut inkomstskatt, samtidigt som det kommunalekonomiska inkomst- och kostnadsutjämningssystemet uttryckligen ska kompensera för skillnader i skattekraft och strukturella servicebehov. Det undanröjer inte alla påfrestningar från demografi, nationella uppdrag, administrativ kapacitet eller tidsfördröjningar; det gör inte heller kommunernas budgetar oberoende av lokala beslut. Den empiriska frågan är vilka specifika kommuner och ansvarsområden som har obalans efter utjämning och statsbidrag.

Resultatet är att den styresnivå som är närmast de mest komplexa, snabbast föränderliga problemen – kommunerna som står på frontlinjen för integration, bostäder, brottsförebyggande och social sammanhållning – också är den nivå med den mest begränsade kapaciteten att experimentera, anpassa sig och agera. Ett nationellt policyramverk, utformat i Stockholm, sätter de breda parametrarna. Kommunen ansvarar för implementering. Men dess fiskala utrymme, dess juridiska befogenhet att avvika från nationella standarder och dess institutionella kapacitet att driva genuina experiment är alla starkt begränsade.

Detta skapar en specifik typ av återkopplingsmisslyckande. Kommunala tjänstemän är ofta de första att se framväxande problem. En skolrektor noterar förändrade mönster i närvaro och prestation. En socialarbetare ser familjedynamik som indikerar fördjupat utanförskap. En lokal polis observerar de tidiga stadierna av kriminell nätverksbildning. Dessa signaler existerar på kommunal nivå. Men kapaciteten att aggregera dem, att koppla ihop dem över silorna för utbildning, socialtjänst och allmän säkerhet, och att agera med de resurser och den experimentmyndighet som situationen kräver – den kapaciteten ligger på nationell nivå, separerad från signalerna av avstånd, tid och filtreringsmekanismerna från Dataarkipelagen och konsensuskulturen.

Signalerna färdas uppåt – långsamt, partiellt, avskalade sin lokala kontext. Responsen färdas nedåt – uniform, aggregerad, kalibrerad till det nationella medelvärdet. Kommunen som såg problemet först lämnas med konsekvenserna av en respons utformad för ett genomsnitt som inte matchar dess verklighet.

Detta är inte ett argument mot nationella standarder eller omfördelning. Det är ett argument för att den nuvarande subsidiaritetsarkitekturen är ofullständig. Om kommuner ska vara den svenska statens avkänningsorgan – och de är, i praktiken, den nivå där de flesta komplexa sociala problem först blir synliga – då behöver de den fiskala, juridiska och institutionella kapaciteten att reagera på vad de avkänner. Utan den är återkopplingsloopen bruten. Sensorerna finns på plats. Kablarna till den centrala processorn är intakta. Men processorn är för långt borta, och de lokala verkställarna har medvetet försvagats av ett system som centraliserar auktoritet samtidigt som det decentraliserar ansvar.

---

### 2.5 Hur de tre mekanismerna förstärker varandra

Dataarkipelagen, det föreslagna konsensusfiltret och den kommunala kapacitetsfällan kan samverka. Följande scenario illustrerar en möjlig förstärkande dynamik; det är inte ett dokumenterat fall eller belägg för att händelsekedjan är typisk för Sverige.

Tänk att en lokal polis ser en förändring i rekryteringen av unga till kriminella nätverk. En ansvarsfull återkopplingsprocess skulle kunna förena iakttagelsen med lämpligt aggregerade indikatorer från skola, socialtjänst och kommunal verksamhet, när detta behövs och är lagligt. Den skulle också inhämta perspektiv från berörda unga, familjer och yrkesverksamma. Målet vore att skilja ett verkligt framväxande mönster från missvisande korrelationer och utforma en proportionerlig respons som respekterar rättigheter – inte att anta att mer individdata alltid måste sammanföras.

I en svagare återkopplingsmiljö kan iakttagelser misslyckas med att nå rätt beslutsfattare, eller så kan olika aktörer tolka dem olika. Även där informationsutbyte är tillåtet kan oförenliga arbetssätt eller kapacitetsbrister fördröja handling. Andra förklaringar – oenighet om verksamma insatser, konkurrerande prioriteringar eller begränsade resurser – behöver prövas parallellt med informationsfragmentering.

Om dröjsmålen består kan ett inledningsvis hanterbart mönster bli mer skadligt innan en samordnad respons kommer till stånd. Men förloppet är villkorat: vissa svenska institutioner delar redan information, agerar tidigt och anpassar sig framgångsrikt. Både framgångar och misslyckanden behöver studeras för att avgöra om den föreslagna loopen har förklaringskraft.

Det är denna typ av misslyckande som hypotesen om återkopplingsunderskottet försöker förklara. Dess relativa betydelse jämfört med rättigheter, materiella begränsningar, omstridda mål och politiska vägval behöver prövas. Nästa avsnitt utvecklar förslag som kräver oberoende juridisk, praktisk och demokratisk utvärdering.

---

---

## 3. Hur ett bygge av återkopplingsinfrastruktur ser ut

Diagnosen av återkopplingsunderskottet bär på en praktisk implikation: om Sveriges centrala problem inte är brist på kompetens utan en arkitektur som dämpar, siloindelar och fördröjer de signaler som behövs för anpassning, då är den centrala uppgiften inte att producera ännu en omgång policyreformer. Den är att bygga den infrastruktur som gör tidig upptäckt, ärligt erkännande och snabb respons möjlig – och sedan låta den infrastrukturen avslöja vad som behöver göras.

Denna sektion beskriver hur den investeringen ser ut i praktiken. Den är organiserad kring fyra kategorier: återkoppling av nervsystemet för att röra sig från transaktionell effektivitet till systemiskt meningsskapande, inbyggnad av strukturerad oenighet i operationskulturen, beviljande av verklig autonomi till kommunerna i förhållande till deras ansvar, och skapandet av levande testbäddar där den nya återkopplingsarkitekturen kan bevisa sig själv. Inget av dessa är sektorer. Inget tillhör ett enskilt departement. De är det möjliggörande underlag på vilket Sveriges nästa kapitel av institutionell anpassning beror.

---

### 3.1 Från transaktionell till meningsskapande: Återkoppling av nervsystemet

Om hypotesen om dataarkipelagen håller i vissa sammanhang kan en lovande investering vara att förbättra motiverat lärande över myndighetsgränser – inte att maximera dataflödena. Första steget bör vara att granska befintliga befogenheter, arbetssätt och ouppfyllda behov mot bakgrund av 2025 års reformer, och därefter välja det minst ingripande sätt som kan besvara en avgränsad fråga av allmänt intresse.

Målet är inte en central övervakningsdatabas. En **federerad infrastruktur för gemensam analys** är en möjlig utformning, men tekniker som differentiell integritet och säker flerpartsberäkning ger inte automatiskt laglighet, korrekthet, säkerhet eller anonymitet. Varje användningsfall kräver fastställt personuppgiftsansvar, ändamål, rättslig grund, prövning av nödvändighet och proportionalitet, säkerhetsåtgärder och konsekvensbedömning avseende dataskydd när sådan krävs. När aggregerade eller icke-personliga uppgifter räcker bör samkörning på individnivå inte vara förstahandsvalet.

Ett konkret förslag är ett **nationellt ramverk för signalintegration** som kartlägger vilka lagliga informationsutbyten som redan finns, identifierar ouppfyllda analysbehov och utvecklar strikt avgränsade pilotupplägg där rättslig behörighet finns – eller föreslår lagstiftning där den saknas. Ett första fall kan undersöka aggregerade övergångar från skola till arbete utan att skapa individuella riskpoäng. Ett offentligt register över ändamål, behöriga aktörer, granskningar, gallringsregler och klagomöjligheter kan visa om varje upplägg ger större samhällsnytta än integritetsrisk.

Vid sidan av detta skulle Sverige kunna pröva en **samhällelig lägesbild** med offentliga eller säkert aggregerade indikatorer. Den bör visa källor, uppdateringsdatum, osäkerhet, saknade grupper och relevanta ekologiska utfall samt undertrycka eller slå samman små celler för att undvika identifiering. En sådan översikt kan stödja gemensam tolkning men kan inte i sig fastställa kausalitet, ge rättsliga befogenheter eller ersätta samtal med berörda grupper.

Detta skulle vara en förskjutning från enbart transaktionell betoning mot en **meningsskapande stat**: en förvaltning som kan undersöka mönster mellan sakområden med lämplig, laglig och tillräckligt aggregerad evidens. Att förstå hur bostadsområdens villkor och serviceutfall samspelar kräver inte att namngivna barns skol- och hälsouppgifter visas i en gemensam lägesbild.

Investeringen kräver juridiska, organisatoriska, tekniska, demokratiska och ekonomiska avvägningar. Även integritetsfrämjande teknik behöver underhåll, specialistkompetens, tillsyn och allmän legitimitet. Vilka begränsningar som är avgörande kan inte fastslås i förväg utan att granska konkreta användningsfall och redan genomförda reformer.

---

### 3.2 Strukturerad oenighet: Deliberativ infrastruktur för produktiv konflikt

Om Dataarkipelagen är återkopplingsunderskottets yttre arkitektur, är den inre arkitekturen variansdämpningen – den kulturella och institutionella filtrering som sållar bort obekväma signaler innan de når beslutsfattare. Att adressera detta kräver mer än uppmaningar att "säga ifrån". Det kräver att man bygger institutionella mekanismer som gör produktiv konflikt till en strukturerad, belönad del av styrningsprocessen.

Den första mekanismen är ett nätverk av **permanenta medborgardeliberativa organ** på kommunal och regional nivå. Dessa är inte engångskonsultationer eller rådgivande paneler som den verkställande makten kan ignorera. De är permanenta församlingar av slumpmässigt utvalda medborgare, givna tid, information och professionell facilitering, med en lagstadgad rätt till ett formellt myndighetssvar. Om en medborgarpanel i en kommun rekommenderar ett annat tillvägagångssätt för bostadsintegration, måste kommunfullmäktige svara offentligt, förklara sitt resonemang och – om det avvisar rekommendationen – motivera avvisandet i termer som panelen kan granska. Detta är inte ett veto. Det är en ansvarsmekanism som tvingar systemet att seriöst engagera sig med signaler från utanför sina egna institutionella filter.

Sverige har experimenterat med medborgarpaneler tidigare – senast en nationell klimatpanel – men dessa har varit ad-hoc, konsultativa och perifera i förhållande till den faktiska beslutsprocessen. Uppgraderingen är att göra dem permanenta, flernivå och inbäddade i styrningsarkitekturen. En kommun med ett permanent deliberativt organ har en inbyggd kanal för att lyfta fram lokala signaler som annars skulle dämpas av konsensuskulturen. En region med ett sådant organ har en mekanism för att bearbeta avvägningarna – mellan energiutveckling och miljöskydd, mellan bostadstäthet och samhällskaraktär – som för närvarande löses genom expertledda processer som exkluderar de berörda befolkningarna.

Den andra mekanismen är institutionaliserade **röda team-funktioner** inom offentlig förvaltning. Ett rött team är en enhet vars uttryckliga roll är att utmana den rådande konsensusen – att argumentera för att en omhuldad policy misslyckas, att en framväxande risk underskattas, att ett bekvämt antagande inte längre är giltigt. Sveriges myndigheter innehåller redan en del av denna kapacitet; olika utredningar kan tjäna en liknande funktion. Men röda team-konceptet bäddar in det permanent, snarare än att beställa det episodiskt, och ger det det institutionella skyddet att uttala obekväma sanningar utan karriärskada. Den svenska traditionen av tjänstemannansvar tillhandahåller en kulturell grund för detta tillvägagångssätt. Det röda teamet är inte illojalt. Det utför en funktion som är väsentlig för systemets hälsa: att testa konsensusen mot verkligheten.

Den tredje mekanismen är **framtidskompetens inbäddad i utbildning och offentlig tjänsteutbildning**. Framtidskompetens – definierat av UNESCO som förmågan att förstå framtidens roll i vad vi ser och gör – handlar inte om förutsägelse. Det handlar om att utvidga repertoaren av plausibla framtider ett samhälle kan föreställa sig, och därigenom utvidga omfånget av handlingar det kan vidta i nuet. Finland har banat väg för detta tillvägagångssätt med sitt Framtidsutskott i riksdagen och rikstäckande program för framtidskompetens. Sverige, med sin starka utbildningsinfrastruktur och sin kulturella orientering mot långsiktigt tänkande, är väl positionerat att följa efter. Att bädda in framtidskompetens i lärarutbildning, statstjänstemannautbildning och kommunala planeringsprocesser skulle gradvis förskjuta operativsystemet från reaktivt till föregripande – från ett system som ständigt överraskas av händelser till ett som har repeterat multipla möjligheter och kan känna igen framväxande mönster innan de blir kriser.

Dessa tre mekanismer – deliberativa organ, röda team, framtidskompetens – delar ett gemensamt syfte. De är inte utformade för att förstöra konsensus. De är utformade för att göra konsensus *förtjänad* snarare än antagen – produkten av genuin deliberation och rigorös utmaning snarare än undertryckande av oliktänkande. I ett högtillitssamhälle är detta en känslig kulturell operation. Målet är inte att importera den adversativa politiska kulturen från andra demokratier. Det är att ge det befintliga svenska engagemanget för saklighet – faktabaserad, rationell deliberation – den institutionella arkitektur det behöver för att fungera i en mer komplex värld.

---

### 3.3 Territoriell kapacitet 2.0: Verklig autonomi för kommuner

Den kommunala kapacitetsfällan – formell subsidiaritet parad med funktionell centralisering – är den tredje pelaren i återkopplingsunderskottet. Att adressera den kräver mer än att pilla med utjämningsformeln eller lägga till ytterligare ett öronmärkt bidrag. Det kräver en strukturell förskjutning i hur auktoritet, resurser och ansvarsskyldighet fördelas mellan centrum och periferi.

Den första uppgraderingen är **genuin fiskal autonomi**. Kommuner bör ha en skattebas tillräcklig för att finansiera sina ålagda ansvarsområden, och utjämningssystemet bör kompensera för strukturella skillnader utan att skapa beroende. Detta är inte en uppmaning att avskaffa det kommunalekonomiska utjämningssystemet – principen om territoriell solidaritet är en av den svenska modellens landvinningar. Men det nuvarande systemet, kombinerat med detaljerad nationell reglering av servicestandarder, lämnar kommuner med litet utrymme att sätta sina egna prioriteringar. En kommun som vill investera mer i förebyggande socialt arbete och mindre i akuta interventioner bör kunna göra den avvägningen – och vara ansvarig inför sina medborgare för resultaten.

Den andra uppgraderingen är **experimentmyndighet med rätt att misslyckas säkert**. Kommuner behöver den juridiska rätten att testa alternativa tillvägagångssätt för integration, bostäder, utbildning och tjänsteleverans utan att be om tillstånd från Stockholm. Mekanismen existerar redan i embryonal form: försöksverksamhet kan auktoriseras av regeringen för specifika syften. Men processen är långsam, snäv och politiskt betingad. En generell försöksverksamhetslag skulle ge kommuner en stående rätt att föreslå och implementera avgränsade experiment, med transparent utvärdering och en tydlig väg för att skala upp det som fungerar. Den centrala statens roll skiftar från grindvakt till möjliggörare: att sätta parametrarna inom vilka experimentation är säker, tillhandahålla utvärderingsinfrastrukturen och säkerställa att framgångsrika experiment är synliga för andra kommuner.

Den tredje uppgraderingen är **asymmetrisk kapacitetsuppbyggnad**. Alla kommuner är inte lika positionerade för att dra nytta av större autonomi. Vissa har stark administrativ kapacitet, täta civilsamhällesnätverk och en historia av innovation; andra kämpar med avbefolkning, kompetensbrist och institutionell utmattning. Ett autonomiramverk som behandlar alla kommuner identiskt riskerar att vidga gapet mellan de kapabla och de kämpande. Lösningen är inte att undanhålla autonomi från dem som behöver den mest – det är att para autonomi med kapacitetsuppbyggnadsstöd, så att kommuner vid olika startpunkter kan bygga mot genuint självstyre över tid. Detta är principen om asymmetrisk delegering, tillämpad på subnationell nivå: olika kommuner får olika grader av autonomi baserat på deras demonstrerade kapacitet att använda den väl, med en transparent väg för att öka den kapaciteten och de rättigheter som åtföljer den.

De nordliga regionerna – Norrbotten och Västerbotten – illustrerar både möjligheter och gränser för territoriell samordning. Industriinvesteringar berör bostäder, arbetsmarknader, ekosystem samt samisk markanvändning och samiska rättigheter. Samordning ersätter inte rättigheter eller de konsultationsskyldigheter som gäller i förhållande till det samiska folket och berörda samebyar. En pilot i ett sådant område måste identifiera berörda rättighetshavare, konsultera dem enligt gällande ordning och skilja mellan frågor som kommunen får besluta om och sådana som styrs av nationella tillstånd eller andra myndigheter.

Dessa tre uppgraderingar – fiskal autonomi, experimentmyndighet, asymmetrisk kapacitetsuppbyggnad – är inte ett avvisande av den svenska modellen. De är dess logiska förlängning. Folkhemmet byggdes av kommuner som hade genuin auktoritet och experimenterade med olika tillvägagångssätt för social välfärd, bostäder och folkhälsa. Centraliseringen under det sena 1900-talet var ett svar på den moderna industriella ekonomins komplexiteter. Uppgiften nu är att återställa balansen – att ge periferin de verktyg den behöver för att avkänna och agera, samtidigt som man upprätthåller de solidaritetsmekanismer som håller systemet samman.

---

### 3.4 Levande testbäddar: Där återkoppling kan prövas

Kapacitet utvecklas inte i det abstrakta. Den utvecklas genom tillämpning – genom försöket att lösa verkliga, pressande problem på verkliga platser, med den nya avkännings- och deliberativa arkitekturen tillsammans. Sverige behöver en portfölj av integrerade testbäddar där återkopplingsinfrastrukturen kan demonstreras, förfinas och göras synlig för resten av landet.

Dessa testbäddar är inte "sektorer" som ska finansieras. De är rumsliga arenor – specifika territorier, på kommunal eller subregional skala – där de tre uppgraderingar som beskrivs ovan kombineras och testas samtidigt. Målet är att skapa synliga, dokumenterade exempel på hur ett högåterkopplande styrsystem ser ut i praktiken, och att låta den evidensen göra övertalningsarbetet.

**Energiomställning, rättigheter och territoriell sammanhållning.** Industriprojekt i norr innebär möjligheter men också stora påfrestningar för bostäder, service, ekosystem och samiska renbetesmarker. En pilot bör kartlägga kumulativa miljöeffekter samt fördelningen av nytta och bördor, inte bara förbättra samordningen. Den måste respektera konsultationsskyldigheter, lagliga markanvändningsbeslut och samiska rättighetshavares ställning; kommunal deliberation kan inte ersätta dessa skyldigheter. Kommunen kan samordna service och lärande men inte ensidigt avgöra tvister om gruvor, miljö eller urfolksrättigheter.

**Bostadsintegration som systemutmaning.** En kommunal pilot kan pröva samordnad planering för bostäder, transporter och utbildning med öppna utfallsmått och skyddsmekanismer. Samkörning av individdata från bostäder, skola, arbetsmarknad eller vård kräver separat rättslig grund, ändamålsprövning och uppgiftsminimering för varje användning; den ingår inte automatiskt i en Framtidskommun. Använd i första hand öppen eller säkert aggregerad statistik. Försöken får inte gå utanför gällande befogenheter utan en giltig rättslig förändring som respekterar rättigheter.

**Skolreform som ett återkopplingslaboratorium.** Ett kommunalt försök kan pröva rutiner för skolan och elevstöd inom befintlig lagstiftning och nationella utbildningskrav. Ingen automatisk rätt att samköra skol-, vård- eller socialtjänstuppgifter följer av försöket: varje användning kräver separat prövning av ändamål, lagstöd, nödvändighet, skydd och barns rättigheter. Följ utfall mot en baslinje och publicera också negativa resultat.

Dessa levande testbäddar är inte en uttömmande lista. De är exempel på ett annorlunda sätt att tänka kring offentlig investering: inte som allokeringen av resurser till förutbestämda program, utan som skapandet av utrymmen där en ny styrningsarkitektur kan byggas, testas och förfinas. I varje fall är det primära resultatet inte en bro, en turbin eller en skola. Det primära resultatet är *kapaciteten att producera sådana saker intelligent i framtiden* – de återkopplingsloopar, de deliberativa vanor och det institutionella självförtroende som gör kontinuerlig anpassning möjlig.

---

Vad som förenar dessa fyra investeringsdomäner – meningsskapande infrastruktur, strukturerad oenighet, territoriell autonomi och levande testbäddar – är att de alla är investeringar i systemets förmåga att avkänna och agera. De konkurrerar inte med de akuta utmaningar Sverige står inför. De är förutsättningen för att någon utmaning ska kunna mötas utan att upprepa den Driftloop som har konsumerat så mycket energi och urholkat så mycket tillit.

Nästa sektion konfronterar den obekväma verklighet som har legat och lurat under denna diskussion: även de mest intelligent utformade återkopplingsinvesteringarna kommer att möta motstånd från det politiska immunsystem som den nuvarande arkitekturen upprätthåller. Att förstå det motståndet – och att utforma runt det – är det ämne vi nu vänder oss till.

---

---

## 4. Det politiska immunsystemet: Varför återkoppling misslyckas

### 4.1 Kompetensfällan som immunsvar

Varje politisk ordning utvecklar reflexer som skyddar dess existerande maktfördelning, dess etablerade antaganden och dess självbild. I Tyskland är immunsystemet byråkratisk tröghet – mångfaldigandet av vetopunkter som gör beslutsamt handlande svårt. I Frankrike är det det nationella politiska skådespelet – en arena som förstärker konflikt och konsumerar reform innan den kan slå rot. I Sverige är immunsystemet subtilare. Det är **tillfredsställd kompetens**.

Reflexen är inte aggressiv. Den fördömer inte eller obstruerar. Det är det lugna, rimliga, evidensunderstödda svaret från ett system som har all anledning att tro på sin egen prestation: *Vi är redan bland de bästa i världen. Våra institutioner fungerar. Våra mätetal är starka. Vad exakt behöver lagas?*

Detta är inte en cynisk hållning. Det är ett ärligt uttryck för den svenska självförståelsen, och det är grundat i verklig prestation. De internationella rankningarna, den aggregerade statistiken, medborgarnas dagliga erfarenhet av en stat som i stort sett fungerar – allt detta tillhandahåller genuin evidens för att maskineriet går bra. Problemet är inte att denna evidens är falsk. Det är att den är partiell. Just de mätetal som bekräftar systemets framgång är de mätetal som gör dess blinda fläckar osynliga. Kompetensfällan är inte ett misslyckande av självmedvetenhet. Det är en strukturell egenskap hos ett system som har optimerat sina sensorer för de förhållanden det redan vet hur man hanterar.

En följd av tillfredsställd kompetens är att **misslyckande måste bli synligt och obestridligt innan det blir diskuterbart**. Tills evidensen är överväldigande – tills gängvåldet skapar internationella rubriker, tills bostadsköerna sträcker sig bortom en generation, tills Natoomsvängningen framtvingas av händelser snarare än väljs genom deliberation – faller systemet tillbaka på antagandet att saker i grunden fungerar och att avvikelser från normen kommer att korrigera sig själva. Detta är inte envishet. Det är den rationella slutsatsen från decennier av erfarenhet där avvikelser *faktiskt* korrigerade sig själva, där systemet *faktiskt* absorberade chocker och återvände till jämvikt. Problemet uppstår när miljön förändras på sätt som gör det antagandet förlegat, och systemets egen framgång förhindrar det från att märka det.

---

### 4.2 Konsensusfiltret och expertberoendet

Om tillfredsställd kompetens är immunsystemets första försvarslinje, är den andra ett kulturellt filter av anmärkningsvärd effektivitet: konsensusen som sållar bort obekväma signaler innan de når den nivå där de skulle kunna störa den rådande förståelsen.

Svensk politisk kultur värdesätter *saklighet* – faktabaserad, rationell deliberation – och *enighet* – uppnåendet av bred överenskommelse. Dessa är genuina demokratiska dygder. De förhindrar den typ av tribal polarisering som paralyserar andra politiska system. De skapar utrymme för långsiktig, evidensbaserad policyutveckling. De underbygger den höga tillit som gör den svenska modellen möjlig. Men de skapar också en specifik sårbarhet: när konsensusen är fel, eller när den är rätt men ofullständig, är mekanismerna för att korrigera den svaga, eftersom kulturen behandlar avvikelser från konsensusen som sannolikt felaktiga.

Detta är ingen tystnadskonspiration. Det är en social dynamik. Den tjänsteman som misstänker att ett integrationsprogram misslyckas möter en hög bevisbörda – inte för att någon har beordrat dem att vara tysta, utan för att den institutionella kulturen förväntar sig att de har överväldigande evidens innan de utmanar en politik som åtnjuter brett politiskt och expertmässigt stöd. Den forskare vars resultat motsäger den rådande berättelsen möter implicit skepsis, inte för att forskarsamhället är ohederligt, utan för att den förhandssannolikhet som tilldelas avvikande fynd är låg. Den journalist som vill rapportera om en oroande trend måste väga den professionella kostnaden av att ses som alarmistisk. Inget av detta kräver formell censur. Det opererar genom det sociala och professionella livets vanliga mekanismer – det höjda ögonbrynet, den försenade befordran, den subtila preferensen för arbete som bekräftar snarare än stör.

Kopplat till detta är ett djupt **expertberoende**. Den svenska staten förlitar sig tungt på myndigheter, expertauktoriteter och institutionell tillit. Medborgare litar på myndigheter. Politiker litar på myndigheter. Myndigheter litar på sin egen expertis. Denna tillit är till stor del förtjänad – svenska myndigheter är, med globala mått, kompetenta och hederliga. Men det skapar en strukturell sårbarhet: när expertkonsensus är fel eller föråldrad har systemet svaga mekanismer för att upptäcka det snabbt. Det finns ingen institutionaliserad funktion vars jobb är att utmana den rådande expertsynen. Det finns inga permanenta röda team inom myndigheter med uppdrag att argumentera för motsatsen till konsensusen. Det finns inget permanent deliberativt organ bemyndigat att låta medborgarerfarenhet påverka expertbedömningar. Resultatet är ett system som kan vara ärligt, plikttroget och kompetent felaktigt under längre perioder – inte för att någon agerar i ond tro, utan för att arkitekturen antar att expertkonsensus är tillförlitlig och inte tillhandahåller något systematiskt sätt att testa den.

Invandrings- och integrationspolitiken är ett **föreslaget undersökningsfall**, inte belägg för undertryckta varningar. Forskning kan sammanställa samtida signaler från lärare, invånare, socialtjänst, polis och politiker, även motstridiga signaler, och pröva om, när och varför beslut följde. Partikonkurrens, signalernas kvalitet och begränsad uppmärksamhet är alternativa förklaringar. Ett generellt undertryckande kan inte påstås utan daterade belägg.

---

### 4.3 Myndighetssilon som institutionellt försvar

Den tredje linjen i immunsystemet är strukturell: myndighetssilon själv fungerar som en försvarsmekanism mot obekväma signaler som skär över institutionella gränser.

Svenska myndigheter är, till sin utformning, autonoma. De är inte föremål för direkt ministerstyrning i enskilda fall – ett konstitutionellt skydd mot politisk inblandning som är en av den svenska modellens styrkor. Varje myndighet har sitt eget mandat, sin egen budget, sin egen professionella kultur och sin egen tolkning av vad som utgör framgång. Denna autonomi skapar öar av kompetens och integritet. Den skapar också öar av information, var och en självinnesluten och självrefererande, var och en med sina egna mätetal som bekräftar dess egen prestation.

När en signal passerar myndighetsgränser – till exempel möjliga samband mellan skolresultat, bostäder, arbetsmarknad och rekrytering till kriminalitet – är det inte säkert att en enda institution äger hela förklaringen eller responsen. Aktörer kan redan samverka, men samordningen kan ändå brista på grund av skilda uppdrag, resursbrist, omstridda diagnoser eller styrningsincitament. Frågan är var det gemensamma ansvaret tydligt fördelas, utövas och utvärderas.

Dessutom kan myndigheter ha institutionella incitament att behålla kontrollen över sina uppgifter och prestationsmått. Dessa incitament bör undersökas i stället för att förutsättas förklara varje begränsning: legitim sekretess, författningsstyrda uppdrag, tekniska kostnader och resursbrist kan vara avgörande i enskilda fall. Nya svenska regler om uppgiftsutbyte gör att den praktiska frågan i ökande grad är om befintliga möjligheter används lagligt, konsekvent och ändamålsenligt – inte bara om lagen förbjuder samverkan.

När en tvärmyndighetssignal så småningom blir för stor för att ignorera, är den typiska responsen att skapa ett nytt samordningsorgan, en ny insatsstyrka, en ny nationell strategi – vilket ofta lägger ytterligare ett lager av samordning ovanpå de existerande silorna utan att förändra själva silostrukturen. Den underliggande informationsarkitekturen förblir intakt. Myndigheterna fortsätter att operera med sina egna data, sina egna mätetal, sina egna kulturer. Det nya samordningsorganet saknar datatillgången och den institutionella auktoriteten att göra mer än att skriva rapporter. Loopen sluts. Nästa tvärmyndighetssignal kommer att följa samma väg från fragmentering till kris.

---

### 4.4 Berättelsestrategin

Givet det immunsystem som beskrivits ovan, är sättet som återkopplingsagendan *talas om* inte perifert för dess framgång. Det är centralt. Ett reformförslag som presenterar sig självt som en kritik av den svenska modellen – som ramar in Dataarkipelagen som ett misslyckande, Jantelagen som en patologi, den Kommunala kapacitetsfällan som ett svek mot subsidiariteten – kommer att utlösa varje immunsvar samtidigt. Det kommer att avfärdas som alarmistiskt, som ett missförstånd av svenska landvinningar, som en import av utländska ängsligheter som inte gäller ett samhälle som förblir, enligt de flesta mått, bland de mest framgångsrika på jorden.

Uppgiften är därför att rama in agendan inte som ett brott utan som en **fortsättning** – samma pragmatiska, evidensbaserade institutionella förbättring som byggde folkhemmet, nu tillämpad på själva styrningens arkitektur. Argumentet är inte att Sverige har misslyckats. Det är att Sverige lyckades så väl med att bygga institutioner för en specifik uppsättning förhållanden att det nu behöver uppgradera dessa institutioner för att matcha de förhållanden som sedan dess har uppstått. Kompetensfällan är inte en anklagelse. Det är en observation som gäller alla högpresterande system, och Sverige är helt enkelt tillräckligt långt längs prestationskurvan för att stöta på den först.

Denna inramning måste paras med ett ärligt erkännande av Sveriges genuina styrkor. Den höga tilliten, den institutionella kapaciteten, rationalitetskulturen, den digitala infrastrukturen – dessa är inte hinder för reform. De är grunden på vilken reform kan byggas. Sverige behöver inte bli en annan typ av samhälle. Det behöver ge det samhälle det redan är den sensoriska arkitektur det för närvarande saknar.

Berättelsen måste också tala till vart och ett av de policymässiga tänkesätt som samexisterar i det svenska politiska landskapet. Till den socialdemokratiska tradition som byggde folkhemmet måste den säga: *ni lyckades genom att pragmatiskt anpassa institutioner till förhållanden. Förhållandena har förändrats. Det pragmatiska svaret är att anpassa igen.* Till de liberala och gröna traditioner som driver på för innovation och hållbarhet måste den säga: *strukturerna som dämpar obekväma signaler är också strukturerna som dämpar den experimentation som behövs för den gröna omställningen.* Till de konservativa och moderata traditioner som värdesätter stabilitet och försiktighet måste den säga: *det största hotet mot stabilitet är inte förändring – det är det fördröjda erkännandet av förändring som redan har inträffat.*

Kärnbudskapet är bedrägligt enkelt: *Sverige är inte trasigt. Det deprekeras – som mjukvara som fortfarande körs men som inte längre aktivt underhålls för den miljö den opererar i. Uppgraderingen är inte ett avvisande av den ursprungliga designen. Det är fortsättningen av den pragmatiska tradition som producerade den.* Detta är ett budskap som kan uttalas från vilken politisk plattform som helst utan motsägelse. Och det bär hela återkopplingsagendan inom sig.

---

Det politiska immunsystemet är kraftfullt, men det är inte allsmäktigt. Det går att arbeta med, eftersom dess grundvalar – tillit, kompetens, rationalitet – är just de resurser som behövs för uppgraderingen. Nästa sektion vänder sig till de konkreta mekanismerna för det arbetet: den övergångsarkitektur som ger återkopplingsagendan en chans att överleva kontakt med det system den avser att uppgradera.

---

---

## 5. Att arbeta med strukturen: Övergångsarkitektur för Sverige

### 5.1 Principen: Börja där tilliten är hög

Varje övergångsarkitektur måste anpassas till det immunsystem den navigerar. I Tyskland är strategin att kringgå byråkratisk tröghet – att bygga kapacitet under tröskeln för politisk kontrovers, där administrativ modernisering kan fortgå utan att utlösa hela samordningsmaskineriet. I Frankrike är strategin att kringgå det nationella politiska skådespelet – att börja i zoner med låg synlighet där resultat kan demonstreras innan arenan konsumerar dem. I Sverige är strategin annorlunda. Den är att arbeta *med* den befintliga tilliten, inte runt den.

Sveriges immunsystem – tillfredsställd kompetens, konsensusfiltret, myndighetssilon – är inte en fientlig motståndare. Det är en produkt av samma kulturella och institutionella styrkor som gör Sverige styrbart. Hög tillit, evidensbaserad policyutveckling, professionell autonomi och en preferens för konsensus är inte hinder för anpassning. De är de förhållanden under vilka anpassning måste ske. Uppgiften är inte att besegra dem utan att omdirigera dem – att använda tilliten till att ha ärliga samtal, att använda evidenskulturen till att kräva bättre avkänning, att använda den professionella autonomin till att skapa skyddade utrymmen för experimentation.

Denna princip har en praktisk konsekvens: reform i Sverige bör inte ramas in som ett nödläge. Den bör ramas in som en uppgradering – den typ av kontinuerlig förbättring som svenska institutioner redan stoltserar med. Tonen bör vara lugn, evidensrik och framåtblickande. Det känslomässiga registret är inte *vi måste agera innan det är för sent* utan *vi har en möjlighet att bygga på våra styrkor innan miljön förskjuts ytterligare.* Detta är inte spinn. Det är strategisk ärlighet. Det återstår att visa om kompetensfällan finns i Sverige. Ett försök till konstruktiv förbättring kan vara värdefullt även om den ursprungliga förklaringen visar sig felaktig.

Den följande arkitekturen – öppna kommunala testbäddar, ändamålsbundna dataöverenskommelser, avgränsade försök och evidensstyrd spridning – ska redovisas för boende, anställda och folkvalda. Legitimiteten kräver förståelse för både administrativa åtgärder och eventuella långsiktiga ambitionsförändringar.

---

### 5.2 Öppna kommunala testbäddar

Det mest effektiva fordonet för att uppgradera Sveriges återkopplingsarkitektur är kommunen. Kommunen är redan den nivå där komplexa sociala problem först blir synliga, där tjänster berör medborgare direkt, och där gapet mellan ansvar och kapacitet är mest akut känt. Det är också en styrningsnivå som svenskar litar på – lokalt självstyre åtnjuter vanligtvis högre förtroende än nationella institutioner – och där experimentation kan ske utan att omedelbart bli ett nationellt politiskt ställföreträdarkrig.

Pilotstrategin får inte ha något dolt ”omslag” eller ”innehåll”. Kommuner, boende och deltagande myndigheter ska få samma offentliga beskrivning av mål, förväntade nyttor, rättsliga begränsningar, dataanvändning, risker och utvärderingsregler. Öppen redovisning kan förenas med politisk pragmatism och behövs för legitimitet och ansvarsutkrävande.

Betrakta ett konkret exempel. En grupp kommuner – kanske fem till sju, varierade i storlek, geografi och ekonomisk bas – skulle kunna bilda ett **"Framtidskommuner"-nätverk**. Det uttalade syftet skulle vara okomplicerat: att pionjära mer integrerade, datainformerade tillvägagångssätt för komplexa lokala utmaningar, att dela lärande över kommungränser och att tillhandahålla en testbädd för administrativa praktiker som så småningom skulle kunna antas bredare. Språket är språket för *verksamhetsutveckling* och *evidensbaserad praktik*. Det är språket som svensk offentlig förvaltning redan talar.

Inom offentligt angivna ramar kan Framtidskommuner pröva processamordning, lagliga dataöverenskommelser, stående medborgarpaneler och definierade utvärderingar. Utökad kommunal befogenhet kräver en tydlig rättslig väg och granskning av berörda rättigheter, inte ett generellt försöksundantag.

Nyckeln är att Framtidskommunerna skulle vara *frivilliga*. Ingen kommun skulle tvingas att delta. De som väljer att göra det – och det finns redan kommuner, över hela det politiska spektrumet, som är akut medvetna om gapet mellan sina ansvarsområden och sin kapacitet – skulle vara självselekterade för beredskap. Deras deltagande skulle vara en signal om lokal politisk vilja, vilket ger täckning för den nationella regeringen att bevilja de nödvändiga undantagen och resurserna. Dynamiken av spridning genom attraktion börjar med de första aktörerna.

---

### 5.3 Datadelningsöverenskommelser över silogränser

Dataarkipelagen kan bestå trots utvidgade rättsliga möjligheter. Efter 2025 års reformer är den omedelbara uppgiften inte nödvändigtvis ännu ett nationellt tillstånd att dela uppgifter: den är att kartlägga rättslig grund, faktisk tillämpning, tekniska hinder och kvarstående analysbehov för varje användningsfall. När rättslig grund redan finns kan myndigheter pröva noggrant avgränsat genomförande; när den saknas kan en frivillig överenskommelse inte skapa den.

En **datadelningsöverenskommelse över silogränser** skulle vara en överenskommelse om genomförande och ansvar mellan deltagande organisationer – inte en ny befogenhet att lämna ut uppgifter. Den ska ange lagligt ändamål, rättslig grund, personuppgiftsansvar, tillåtna fält eller aggregerade resultat, uppgiftsminimering, åtkomst, lagring, granskning och möjligheter till rättelse. I vissa fall räcker gemensam analys av offentlig statistik. Där personuppgifter behövs måste laglighet och proportionalitet fastställas oberoende av överenskommelsen; samkörning av uppgifter från skola, socialtjänst och polis kan inte förutsättas vara tillåten.

Denna precision är nödvändig, men ett avtal gör inte ett annars olagligt informationsutbyte lagligt. Värdet ligger i att pröva en särskild, tillåten samverkan, dokumentera dess nytta och skador samt synliggöra praktiska hinder som finns kvar även när delning är möjlig.

Överenskommelserna bör börja med snävt avgränsade, juridiskt prövade fall där en dokumenterad informationsbrist hindrar användbart lärande. Aggregerade övergångar från skola till arbete kan vara en mindre riskfylld start än att samköra känsliga uppgifter om namngivna minderåriga. Förslag som rör skola, socialtjänst eller polis måste genomgå särskild prövning av nödvändighet, proportionalitet och rättigheter innan uppgifter delas; 2025 års regler gör inte alla sådana användningar automatiskt tillåtna.

Den nationella regeringens roll är att möjliggöra, inte att kontrollera. Den kan tillhandahålla en mall för rättslig överenskommelse, modellintegritetsprotokoll och tekniskt stöd. Den kan finansiera en oberoende integritetsmyndighet för att övervaka överenskommelserna och bygga allmänt förtroende. Den kan hylla framgångsrika överenskommelser och göra deras metoder tillgängliga för andra kommuner. Men överenskommelserna själva initieras och styrs lokalt, av de myndigheter som kommer att använda dem. Detta respekterar den svenska principen om myndighetsautonomi samtidigt som det bygger de broar som autonomin för närvarande saknar.

---

### 5.4 Säkra-att-misslyckas kommunala piloter

Sverige har, liksom de flesta välfungerande stater, en aversion mot synligt misslyckande. Trycket att leverera konsekventa, högkvalitativa resultat över alla kommuner har producerat ett system där avvikelser från nationella standarder behandlas som risker att hanteras snarare än experiment att lära från. Detta är förståeligt. Medborgare i Kiruna bör inte få sämre sjukvård än medborgare i Stockholm för att deras kommun bestämde sig för att prova något okonventionellt. Men den förståeliga preferensen för konsekvens har en kostnad: den dämpar den variation som genererar lärande.

En **säker-att-misslyckas-pilot** är ett experiment medvetet utformat för att övervinna denna aversion. Det är avgränsat i omfattning – en specifik kommun, en begränsad tidsram, en fördefinierad uppsättning aktiviteter. Det är uttryckligen inramat som en lärandeövning, inte en permanent policyförändring. Dess deltagare – kommunala tjänstemän, myndighetspersonal, medborgardeltagare – försäkras offentligt om att blandade resultat förväntas och att ärlig dokumentation av vad som inte fungerade är lika värdefullt som evidens för vad som gjorde det. Och det har politisk täckning: en nationell regering som auktoriserar piloten förbinder sig att skydda den från för tidig bedömning.

Det säkra-att-misslyckas-ramverket är särskilt viktigt för den Kommunala kapacitetsfällan. Kommuner som har beviljats fiskal eller regulatorisk flexibilitet måste kunna använda den utan rädsla för att ett enda nedslående mätetal ska utlösa intervention eller offentlig kritik. Utvärderingsramverket är avgörande: piloter bedöms inte efter om varje resultatmål uppnås, utan efter om de genererar kunskap som förbättrar framtida beslutsfattande. En pilot som avslöjar ett oväntat hinder – *datadelning mellan myndigheter är svårare än förväntat på grund av inkompatibla IT-system* – är en framgång i lärandetermer, även om dess programmatiska resultat är blandade. Denna omramning måste etableras från början.

Den rättsliga grunden för säkra-att-misslyckas-piloter existerar redan i embryonal form. Försöksverksamhet kan auktoriseras av regeringen under existerande lagstiftning. Vad som har saknats är ambitionen att använda dessa mekanismer på en systemisk snarare än inkrementell skala, och den politiska viljan att skydda experimenten tillräckligt länge för att deras resultat ska bli synliga. En särskild försöksverksamhetslag skulle tillhandahålla ett permanent rättsligt ramverk, som specificerar omfattningen av tillåten försöksverksamhet, styrnings- och utvärderingskraven, och villkoren under vilka framgångsrika experiment kan skalas upp.

Framtidskommunerna skulle vara den första kohorten av säkra-att-misslyckas-piloter under detta ramverk. Deras erfarenheter – dokumenterade transparent, utvärderade oberoende, delade öppet – skulle bygga evidensbasen för bredare antagande. Vissa experiment kommer att lyckas. Vissa kommer att misslyckas. Vissa kommer att lyckas på oväntade sätt och misslyckas på förväntade. Det gemensamma resultatet är lärande, och lärande är grunden för återkopplingsuppgraderingen.

---

### 5.5 Spridning genom attraktion

Den svenska traditionen av kommunalt självstyre tillhandahåller en kulturell och institutionell grund för det sista elementet i övergångsarkitekturen. I ett system där kommuner har konstitutionell ställning och en stark identitet som oberoende aktörer, är spridning genom centrala mandat både politiskt svårt och operationellt kontraproduktivt. En kommun som beordras att anta en ny styrningsansats av Stockholm kommer att implementera den med minimalt engagemang och maximalt complianceteater. En kommun som väljer att anta en ansats för att den har sett den fungera i en grannkommun kommer att implementera den med genuint ägarskap.

Spridning genom attraktion innebär att göra framgångsrika experiment synliga, tillgängliga och lätta att replikera. Den nationella regeringens roll är inte att befalla utan att möjliggöra: att finansiera dokumentation och utvärdering, att facilitera nätverk för kollegialt lärande, att tillhandahålla tekniskt stöd och såddfinansiering för kommuner som vill anta beprövade ansatser, och att hylla framgångar offentligt. Sveriges Kommuner och Regioner (SKR) är en naturlig partner – en befintlig institution med relationerna, legitimiteten och sammankallande kraften att facilitera horisontellt lärande över kommuner.

Dynamiken är långsam i början, sedan accelererande. De första Framtidskommunerna demonstrerar att integrerad dataavkänning, medborgardeliberation och experimentell autonomi producerar bättre resultat – inte bara på traditionella mätetal, utan på den återkopplingshastighet som förhindrar problem från att förvärras. En andra våg av kommuner, som observerar resultaten, antar frivilligt delar av modellen. Den nationella regeringen, som observerar den andra vågen, justerar det rättsliga och fiskala ramverket för att göra antagande lättare. Över tid blir vad som började som ett litet experiment i periferin normen – inte för att någon påbjöd det, utan för att tillräckligt många aktörer valde det att det gamla arbetssättet blev svårare att rättfärdiga.

Detta är inte en snabb process. Den kommer inte att producera dramatiska rubriker eller synliga politiska segrar inom en enskild valcykel. Men den är varaktig. De förändringar den producerar kommer att vara inbäddade i institutionell praktik, ägda av de aktörer som implementerar dem, och motståndskraftiga mot politiska förskjutningar på nationell nivå. I ett högtillits-, konsensusorienterat samhälle är detta den enda typ av förändring som består.

---

Den beskrivna övergångsarkitekturen – öppna kommunala initiativ, lagliga samarbeten, avgränsade försök och evidensstyrd spridning – bygger inte på dolda institutionella avsikter. Den kräver offentlighet om mål, kostnader, möjliga skador och villkor för avbrytande.

---

---

## 6. Ett konkret första steg: Framtidskommuner

### 6.1 Pilotens logik

Ett ramverk utan ett första steg är ett tankeexperiment. Den återkopplingsinfrastruktur som beskrivs i denna rapport – den meningsskapande arkitekturen, de deliberativa mekanismerna, den territoriella ombalanseringen – kan inte byggas överallt samtidigt. Att försöka införa den nationellt vore att begå just det misstag denna rapport diagnosticerar: ännu en reform utformad i Stockholm, utrullad enhetligt, blind för lokal variation och konsumerad av immunsystemet innan den har en chans att bevisa sig själv.

Den klokare vägen är att börja med ett litet antal kommuner som väljer att pionjära den nya arkitekturen – kommuner som redan avkänner gapet mellan sina ansvarsområden och sin kapacitet, som har den medborgerliga infrastrukturen och den politiska villigheten att experimentera, och som kan tjäna som synliga demonstrationer av hur ett högåterkopplande styrsystem ser ut i praktiken.

Denna sektion föreslår etableringen av **Framtidskommuner**. Namnet är medvetet. Det signalerar kontinuitet med den pragmatiska, framåtblickande tradition som byggde folkhemmet, samtidigt som det pekar mot den specifika uppgradering som kommuner behöver: inte mer resurser inom den befintliga arkitekturen, utan en annorlunda arkitektur som tillåter dem att avkänna, koppla ihop och agera i den hastighet deras utmaningar kräver.

Framtidskommunerna är inte ett alternativ till befintliga kommunala strukturer. De är en förstärkning – en uppsättning ytterligare befogenheter, kapaciteter och ansvarsskyldigheter som ligger vid sidan av en svensk kommuns ordinarie ansvarsområden. De är frivilliga. De är tidsbegränsade, med tydliga utvärderingsmilstolpar och en väg för förlängning eller uppskalning. Och de är utformade för att generera den evidens som antingen kommer att validera återkopplingsuppgraderingen eller avslöja dess brister – båda utfallen för lärandet framåt.

---

### 6.2 Urvalskriterier

Framtidskommunerna bör inte väljas av politisk bekvämlighet eller genom en tävling som belönar den mest polerade ansökan. Målet är att skapa ett trovärdigt konceptbevis, och trovärdighet beror på att man väljer kommuner där utmaningarna är verkliga, förhållandena är representativa och den lokala kapaciteten att engagera sig seriöst är närvarande.

Fem kriterier bör vägleda urvalet, administrerat genom en öppen utlysning som hanteras av en oberoende stiftelse eller ett forskningskonsortium, på armlängds avstånd från regeringen:

**Problemdensitet.** Kommunen bör stå inför en meningsfull klunga av sammanlänkade utmaningar – till exempel bostadssegregation kombinerat med skolo jämlikhet, eller snabb demografisk förändring kombinerat med missmatchning på arbetsmarknaden, eller industriell omställning kombinerat med stress på den sociala sammanhållningen. Poängen är inte att hitta den mest utsatta kommunen, utan att hitta kommuner där utmaningarnas sammanlänkning är omisskännlig och begränsningarna i siloansatser är synbart kostsamma.

**Befintlig medborgerlig infrastruktur.** Kommunen bör ha en basnivå av fungerande institutioner, aktiva civilsamhällesorganisationer och viss historia av samarbete över sektorsgränser – även om det är fragmenterat. Framtidskommunen är inte ett statsbyggnadsuppdrag från grunden. Det är en uppgradering till ett system som redan har viss kapacitet att absorbera den. En kommun med ett tätt nätverk av engagerade aktörer – starkt föreningsliv, samarbetsinriktad politisk kultur, professionell administrativ kapacitet – skulle accelerera snabbt.

**Politisk villighet.** Kommunledningen – både politisk och administrativ – måste vara genuint engagerad i experimentet, inte bara tolerant inför det. Detta engagemang måste inkludera villighet att acceptera offentlig granskning av blandade resultat, att skydda piloten genom dess oundvikliga svåra faser, och att investera personaltid och politiskt kapital i de nya deliberativa arrangemangen och datadelningsarrangemangen. Det säkraste tecknet på genuin villighet är ett blocköverskridande åtagande, som helst spänner över den traditionella vänster-höger-skalan.

**Skalningsrelevans.** De utvalda kommunerna bör kollektivt representera mångfalden av svenska förhållanden: minst en växande urban kommun, en stabil mellanstor stad, en landsbygds- eller glesbygdskommun som står inför demografisk tillbakagång, och en kommun med hög andel utlandsfödda invånare. Om piloterna endast lyckas i unikt gynnsamma mikroklimat – en välbärgad förort utan integrationsutmaningar och med en homogen, högutbildad befolkning – kommer deras lärdomar att avfärdas som irrelevanta för de kommuner som står inför de svåraste problemen.

**Hanterbar skala.** Kommunen bör vara tillräckligt stor för att innehålla meningsfulla systemiska interaktioner – sin egen bostadsmarknad, sitt eget skolsystem, sin egen socialtjänst – men tillräckligt liten för att vara styrbar som en enda lärande enhet. De flesta svenska kommuner faller naturligt inom detta spann. De allra största – Stockholm, Göteborg, Malmö – skulle kräva subkommunala pilotzoner för att vara hanterbara; detta är genomförbart men tillför komplexitet för den första kohorten.

En transparent urvalsprocess, med publicerade kriterier, en öppen utlysning och ett offentligt motiverat beslut, skulle själv vara en signal om återkopplingsarkitekturen i arbete. Det skulle skapa en valkrets av kommuner som har valt att delta snarare än blivit inkallade – en väsentlig grund för spridning genom attraktion.

---

### 6.3 Grundläggande designegenskaper

Varje Framtidskommun skulle formas av lokala förhållanden och prioriteringar, men alla skulle dela en uppsättning grundläggande designegenskaper som förkroppsligar återkopplingsuppgraderingen.

**Integrerat styrningsmandat.** Pilotkommunen skulle erhålla ett skräddarsytt paket av regulatoriska flexibiliteter och samordningsbefogenheter som tillåter den att behandla utbildning, bostäder, socialtjänst, integration och allmän säkerhet som ett enda integrerat designutrymme. Detta innebär inte att avskaffa befintliga institutionella gränser eller att skapa en ny superförvaltning. Det innebär att ge kommunledningen – politisk och administrativ – befogenheten att samordna över silor, att slå samman budgetar där det är lämpligt, och att hållas ansvarig för tvärdomäna utfall snarare än silospecifika prestationer. Den nationella regeringen sätter målen; kommunen beslutar hur de ska uppnås, med flexibiliteten att avvika från nationella programspecifikationer där den kan demonstrera ett motiverat alternativ.

**Rättssäker infrastruktur för lärande över silogränser.** Varje Framtidskommun skulle börja med att juridiskt och integritetsmässigt pröva konkreta lärandebehov och använda befintliga aggregerade data där det går. Varje utbyte av personuppgifter kräver egen rättslig grund, dokumenterad nödvändighet och proportionalitet, säkerhet, åtkomstkontroller, gallringsfrister och oberoende granskning; en överenskommelse ger inte i sig tillgång. Offentliga översikter skulle endast visa aggregerade uppgifter som tål publicering, med kontroller av röjanderisker för små grupper och vilseledande slutsatser.

**Permanent medborgardeliberativt organ.** Varje Framtidskommun skulle inrätta ett återkommande *medborgarråd*, med lottning, stratifiering och aktivt arbete för att nå personer vars erfarenheter ofta är underrepresenterade. Deltagande behöver stöd för tillgänglighet, ersättning, oberoende processledning, flerspråkighet där så behövs, transparent dagordningssättning och ett formellt offentligt svar från kommunfullmäktige. Deliberationen ska komplettera – inte åsidosätta – representativa institutioner, lagstadgade rättigheter eller särskilda konsultationsskyldigheter gentemot rättighetshavare som berörda samiska grupper.

**Ekonomiskt handlingsutrymme och försöksbefogenheter.** En Framtidskommun skulle kunna få ett riktat bidrag och en avgränsad möjlighet att pröva alternativa processer, inom den lagstiftning som gäller för varje sakområde. Den skulle inte ha någon generell rätt att åsidosätta nationella skolkrav, planlagstiftning, socialtjänstens skyldigheter eller dataskydd. Eventuella undantag måste beslutas genom behörig rättslig ordning, publiceras, tidsbegränsas, utvärderas oberoende och kunna återkallas.

**Adaptivt läranderamverk.** Oberoende utvärderare skulle förregistrera pilotens hypoteser och där det är möjligt jämföra med trovärdiga icke-pilotkommuner. Måtten bör omfatta återkopplingshastighet och reformers varaktighet, men också utbildning, hälsa, tillgång till service, välbefinnande, fördelning av nytta och bördor, tillit bland underrepresenterade grupper, integritetsincidenter, rättighetsefterlevnad och oavsiktliga skador. Fler möten eller snabbare beslut är inte framgång om utfallen försämras eller rättigheter kränks.

---

### 6.4 Budget, styrning och rättslig grund

**Budget.** Ett preliminärt planeringsantagande om 50–100 miljoner kronor per kommun och år under en första femårsperiod kan undersökas, men detta är ingen kostnadsberäkning. Budgeten måste byggas nedifrån utifrån de valda piloterna, befintliga bidrag, juridiska och tekniska bedömningar, personalkapacitet, deltagandestöd och oberoende utvärdering. Kostnader, alternativkostnader och skäl för fortsatt finansiering bör publiceras före bindande beslut.

**Styrning.** Kommunfullmäktige är fortsatt ansvarig beslutsfattare inom sin kompetens. Eventuellt statligt stöd ska ha öppna beslutsgrunder, publicerade urvalskriterier och finansieringsvillkor. En oberoende utvärderare kan anlitas, men uppdrag, finansiering, intressekonflikter, metoder och tillgång till negativa resultat måste redovisas. Medborgarorgan får bara den befogenhet som lagen faktiskt medger och ersätter inte lagstadgad samisk konsultation.

**Rättslig grund.** Kommunalt självstyre enligt regeringsformen och kommunallagen är en viktig utgångspunkt, inte ett generellt tillstånd att frångå nationell lag. En pilot kan behöva riktad lagstiftning, tidsbegränsade undantag eller befintliga försöksvägar, beroende på innehåll. Statskontorets uppdrag från 2025 att analysera kommunala försöksverksamheter är en relevant policyväg. En särskild **försöksverksamhetslag för Framtidskommuner** måste avgränsa sitt tillämpningsområde och vara förenlig med grundläggande rättigheter, sektorslagstiftning, EU-rätt och dataskyddskrav. Den skulle kunna reglera:
- Omfattningen av regulatoriska undantag tillgängliga för deltagande kommuner.
- Styrnings- och ansvarsskyldighetskraven för datadelningsöverenskommelserna och medborgarpanelerna.
- Utvärderingsramverket och den oberoende lärandepartnerns roll.
- Villkoren under vilka pilotstatusen kan förlängas, modifieras, avvecklas eller skalas upp.

Lagen skulle innehålla en solnedgångsklausul: efter fem år måste piloterna antingen förnyas på grundval av demonstrerade resultat eller avslutas på ett ordnat sätt. Den tillfälliga naturen hos den rättsliga grunden är politiskt skyddande. Den försäkrar skeptiker om att experimentet är avgränsat och reversibelt. Och den skapar ett naturligt tillfälle för det nationella samtal som spridning genom attraktion är utformad för att informera.

---

### 6.5 Hur man mäter framgång

Framgången för Framtidskommunerna måste mätas i termer som kopplar direkt till diagnosen av återkopplingsunderskottet – och som talar till kommunernas, medborgarnas och den nationella regeringens praktiska angelägenheter.

**Återkopplingshastighet** är ett föreslaget processmått, mätt från en tydligt definierad och granskningsbar första signal till en dokumenterad och lämplig respons. Jämförelser bör ta hänsyn till fallmix, befintlig kapacitet, urvalseffekter och samtidiga reformer. Snabbare är inte alltid bättre: eskalering utan evidens, oproportionerliga tvångsåtgärder eller genvägar som kränker integriteten ska räknas emot piloten, inte till dess fördel.

**Reformers varaktighet** undersöker om en åtgärd fortsätter att ge dokumenterad nytta efter initial finansiering eller uppmärksamhet. Varaktighet är inte i sig framgång: även en bestående åtgärd kan vara ineffektiv eller skadlig. Genomförande, nytta, skada, alternativkostnader och avvecklingsbarhet måste följas.

**Samordningsfrekvens över silogränser** är ett sekundärt processmått: gemensamma analyser och operativ samverkan kan räknas, men mötesvolym är inget mått på kvalitet. Utvärderare bör undersöka om samordningen förändrar beslut, förbättrar utfall, undviker dubbelarbete och står i proportion till administrativa kostnader.

**Tillit och upplevd proceduriell rättvisa** kan följas med anpassade enkäter. Detta är explorativa sekundära mått som påverkas av självselektion, små urval och samtidiga reformer. Förbättringar får inte automatiskt tillskrivas piloten; även upplevd trygghet, tillgänglighet och uteblivet deltagande bör beaktas.

**Användning i andra kommuner** är ett mått på överförbarhet, inte det yttersta beviset på framgång. Spridning bör följa oberoende evidens om nytta, rättighetsefterlevnad, rimliga kostnader och lämplighet för olika lokala förhållanden; tilltalande men ineffektiva arbetssätt bör inte skalas upp bara för att de sprids.

Utvärderingen skulle publiceras i tillgängliga, visuella format – offentliga dashboards, årliga läranderapporter, kommunala kollegiala workshops – utformade för att göra piloternas erfarenhet läsbar och användbar. Transparens är motorn i spridning genom attraktion. Ju mer synligt lärandet är, desto svårare blir det för den gamla arkitekturen att avfärda det.

---

Framtidskommunerna är ett förslag, inte ett krav. En första grupp med **3–5 frivilliga kommuner** kan pröva genomförbarhet och identifiera skador. Självselektion och litet urval gör det omöjligt att belägga nationella genomsnittseffekter eller tillförlitliga intersektionella delgruppseffekter. Utvidgning kräver oberoende prövning av effekter, rättslighet och fördelningskonsekvenser.

Det är så folkhemmet byggdes: inte genom en enda nationell plan påtvingad uppifrån, utan genom att kommuner experimenterade, lärde av varandra och gradvis konvergerade mot vad som fungerade. Framtidskommunerna är en inbjudan att förnya den traditionen – inte för att den gamla modellen misslyckades, utan för att den lyckades så väl att den glömde att fortsätta titta.

---

---

## 7. Avslutning: Från kompetens till anpassningsförmåga

### 7.1 Den rikedom som betyder något

Sverige är rikt. Inte bara i den materiella bemärkelse som internationella rankningar fångar, utan i de djupare resurser som gör styrning möjlig. Landet har en av världens högsta basnivåer av social tillit. Det har institutioner som, med globala mått, är kompetenta, hederliga och djupt inbäddade i vardagslivets väv. Det har en kultur som värdesätter rationalitet, rättvisa och långsiktigt tänkande. Det har en tradition av pragmatisk problemlösning som byggde ett av de mest jämlika och stabila samhällena i modern historia.

Dessa är inte små saker. De är det ackumulerade kapitalet från generationer – folkhemmet som inte drömdes till existens utan byggdes, planka för planka, av kommunala reformatorer, fackliga förhandlare och tjänstemän som trodde att god styrning var ett hantverk att utöva, inte ett pris att vinna.

Men rikedom, i den mening som betyder något för ett samhälles långsiktiga blomstring, är inte lagret av vad som redan har byggts. Det är kapaciteten att bygga igen – att avkänna vad som är på väg att uppstå, att lära av vad som misslyckas och att anpassa sig innan fönstret smalnar. Med det måttet har Sverige tärt på sina reserver – långsamt, osynligt, under tröskeln för de mätetal som bekräftar dess framgång.

Kompetensfällan är **en möjlig mekanism**: tidigare framgång kan ibland ge för stor tilltro till etablerade sätt att tolka evidens. Den har inte påvisats för Sverige. Oberoende belägg skulle i stället kunna stödja uppmärksamhetsbrist, genomförandeproblem, politiska prioriteringar eller rimliga svar på förändrade förhållanden.

---

### 7.2 Förskjutningen

Den förskjutning detta kräver är subtil men djupgående. Det är inte en förskjutning i policy, även om policys kommer att förändras. Det är inte en förskjutning i värderingar, även om värderingar kommer att testas. Det är en förskjutning i hållning – från ett system som är optimerat för att köras till ett system som är utformat för att lära.

Ett system optimerat för att köras antar att dess miljö är stabil, dess sensorer är adekvata och dess procedurer är korrekta. Det mäter framgång genom konsekvensen i sina utfall och effektiviteten i sina processer. När störningar uppstår behandlar det dem som tillfälliga avvikelser som kommer att återgå till medelvärdet. Det filtrerar bort signaler som utmanar dess antaganden. Det skyddar sin konsensus. Det presterar vackert – inom bandbredden av de förhållanden det kalibrerades för att hantera.

Ett system utformat för att lära antar att dess miljö förändras, dess sensorer är ofullständiga och dess procedurer kommer att behöva revideras. Det mäter framgång genom hastigheten i sin avkänning och kvaliteten i sin anpassning. När störningar uppstår behandlar det dem som potentiellt permanenta förskjutningar som kräver undersökning, inte tålamod. Det förstärker signaler som utmanar dess antaganden. Det strukturerar oenighet. Det presterar med mindre elegans, kanske, men med större motståndskraft – eftersom det ständigt uppdaterar sin modell av den värld det styr.

Sverige behöver inte bli mindre kompetent. Det behöver bli mindre övertygat om att dess kompetens är tillräcklig. Det behöver bygga den sensoriska arkitektur som avslöjar vad dess nuvarande sensorer missar. Det behöver ge sina kommuner verktygen att experimentera, sina myndigheter broarna att koppla ihop sig och sina medborgare kanalerna att tala. Det behöver bli genomsläppligt – för de signaler dess framgång har filtrerat bort, för de verkligheter dess mätetal har dolt, för den framtid dess kompetens har gjort svårare att se.

Detta är inte en reträtt från den svenska modellen. Det är nästa kapitel i den pragmatiska tradition som skapade den. Folkhemmet byggdes inte av människor som antog att deras institutioner var adekvata. Det byggdes av människor som såg ärligt på sina förhållanden, erkände vad som inte fungerade och utformade därefter. Förhållandena har förändrats. Den pragmatism som byggde folkhemmet har nu en ny uppgift: att uppgradera arkitekturen så att Sverige kan fortsätta att göra vad det alltid har gjort bäst – avkänna, lära och bygga – i en värld som rör sig snabbare än dess nuvarande institutioner kan spåra.

---

### 7.3 Den europeiska dimensionen

Sverige styr inte ensamt. De tre rapporterna i denna serie identifierar kompletterande underskott i Europas tre mest kapabla styrsystem.

Tyskland lider av ett exekveringsunderskott. Pengar och projekt finns tillgängliga, men det administrativa maskineriet för att driftsätta dem är fragmenterat och långsamt. Tillståndsprövning tar ett decennium. Samordning konsumerar de resurser den var avsedd att driftsätta. Europeiska unionens största ekonomi kan inte omvandla fiskal kapacitet till fysiska resultat i den hastighet dess utmaningar kräver.

Frankrike lider av ett integrationsunderskott. Beslut fattas med imponerande hastighet och intellektuell klarhet, men den förbindande vävnaden för att översätta dem till varaktiga, lokalt legitima utfall saknas. Skådespelet förstärker och konsumerar. Reformer tillkännages, bestrids och dras tillbaka – eller drivs igenom med ett så synligt förakt för opposition att legitimitets-skadan fördjupas. EU:s andra oumbärliga makt kan inte upprätthålla de beslut den fattar.

Sverige **kan** ha återkopplingsproblem inom vissa verksamheter, men hypotesen konkurrerar med förklaringar som uppmärksamhetsbrist, organisatoriska rutiner, politiska vägval, juridik, kapacitet och åtgärders effektivitet. Rapporten belägger inte ett landsomfattande kausalt underskott eller att Sverige har sämre anpassningsförmåga än jämförbara länder.

Tillsammans definierar dessa tre underskott Europas adaptiva kapacitetsgap. Europa kan inte exekvera (Tyskland), kan inte upprätthålla (Frankrike) och kan inte avkänna i tid (Sverige). Det kämpar med att *besluta*, *integrera* och *föregripa* samtidigt. Underskotten är distinkta, men de interagerar. Ett Tyskland som inte kan exekvera saktar ned implementeringen av policys som Frankrike inte kan upprätthålla och som Sverige inte upptäckte behövdes förrän för sent. Ett Frankrike vars beslut upplöses destabiliserar de ramverk som tysk exekvering och svensk avkänning är beroende av. Ett Sverige som felläser framväxande risker misslyckas med att tillhandahålla den tidiga varning som skulle kunna tillåta tysk samordning och fransk deliberation att engagera sig innan kriser mognar.

Reparationen av ett enda underskott gynnar de andra. Om Sverige uppgraderar sin återkopplingsarkitektur – om det blir den första europeiska nationen att bygga en genuin meningsskapande stat, med datadelningsinfrastrukturen, de deliberativa mekanismerna och den kommunala kapaciteten att upptäcka signaler innan de blir kriser – tjänar det inte bara sina egna medborgare. Det tillhandahåller en modell för hur avkänningsdimensionen av 2000-talets styrning kan se ut. Och det bidrar, på ett konkret och mätbart sätt, till det europeiska systemets adaptiva kapacitet som helhet.

---

### 7.4 Ett sista ord

Den svenska modellen var aldrig tänkt som ett museiföremål. Den byggdes av pragmatiker som såg ärligt på sina förhållanden, erkände vad som inte fungerade och utformade institutioner för att matcha den värld de faktiskt bebodde. Den generationen ärvde inte en fungerande välfärdsstat. De byggde den – genom kommunala experiment, genom iterativ reform, genom det tålmodiga, oglamorösa arbetet av institutionellt hantverk.

De förhållanden den generationen mötte var, i många avseenden, mer dystra än något Sverige konfronterar idag. Fattigdomen var djupare. Ojämlikheten var skarpare. Den institutionella infrastrukturen var tunnare. Men de hade något som Kompetensfällan har gjort svårare att komma åt: viljan att se klart, att erkänna vad som misslyckades och att agera.

Frågan som Sverige nu står inför är inte om dess institutioner fortfarande är kapabla. Det är de. Det är inte om dess medborgare fortfarande litar på varandra och sin stat. För det mesta gör de det. Det är om den pragmatism som byggde folkhemmet – samma klarsynta, evidensbaserade, institutionsbyggande pragmatism som förvandlade en fattig, perifer nation till ett av de mest framgångsrika samhällena i historien – fortfarande har modet att uppgradera vad den byggde.

Pengarna finns där. Talangen finns där. Tilliten, även om den urholkas, finns fortfarande där. Vad som har saknats är den sensoriska arkitektur som skulle tillåta alla dessa resurser att se vad de står inför och att agera innan fönstret smalnar. Denna rapport har beskrivit hur ett bygge av den arkitekturen skulle se ut. Den har namngett det immunsystem som kommer att göra motstånd. Den har föreslagit en väg – Framtidskommunerna – som arbetar med den svenska institutionella strukturen snarare än mot den.

Resten är inte en fråga om analys. Det är en fråga om val.

Sverige behöver inte bli mer kompetent. Det är redan bland de mest kompetenta samhällena på jorden. Det behöver bli mer *genomsläppligt* – för de signaler dess framgång har filtrerat bort, för de verkligheter dess mätetal har missat, för den framtid dess kompetens har gjort svårare att se. Kompetensfällan är en oprövad hypotes, inte ett bekräftat svenskt tillstånd. Det första steget är att se den. Det andra är att bygga den infrastruktur som gör seende kontinuerligt, delat och handlingsbart. Det tredje är att lita på – som folkhemmets byggare litade på – att ärligt, evidensbaserat institutionellt hantverk fortfarande är det mest kraftfulla verktyg ett samhälle har.

---

### Efterord: En not om denna rapport själv

Denna rapport har argumenterat för att transformativa idéer, för att överleva i ett system styrt av tillfredsställd kompetens, måste ramas in som fortsättningar snarare än brott – som nästa kapitel i en pragmatisk tradition snarare än en kritik av dess landvinningar. Det vore inkonsekvent att inte tillämpa samma logik på själva rapporten.

Argumentet som presenteras här är, i sin underliggande struktur, en systemisk intervention. Det ser den svenska situationen från ett perspektiv som integrerar de legitima angelägenheterna från multipla politiska traditioner samtidigt som det diagnosticerar det arkitektoniska gap som förhindrar någon av dem från att förverkligas varaktigt. Men rapporten har medvetet undvikit att presentera sig i teoretiska termer. Den har talat språket för statskapacitet, återkopplingsloopar och institutionell förbättring – termer som det svenska systemet kan höra utan omedelbart immunologiskt avvisande.

Spiral Dynamics är en möjlig heuristik för värdeorienteringar, inte en validerad stadieklassificering av människor, partier, kulturer eller länder. Governance as Engineering-modellerna visar möjligheter under givna antaganden; de bevisar varken Kompetensfällan eller en specifik institutions överlägsenhet. Följerapporten *Vems signaler räknas?* och etapp 3-syntesen granskar alternativa hypoteser, rättigheter och institutionell respons.

Men rapportens primära syfte är inte att rekrytera läsare till ett ramverk. Det är att göra en sak synlig som tidigare var osynlig: Kompetensfällan i hjärtat av Sveriges nuvarande framgång, och möjligheten att undkomma den genom samma pragmatiska tradition som byggde de institutioner som nu är i riskzonen. Om det har uppnåtts har rapporten gjort sitt arbete. Vad du gör med den visionen är, genom design, upp till dig.

---

---

## Appendix A: Värdesystem och policymässiga tänkesätt — En guide för den svenska kontexten

### En not om detta appendix

Huvuddelen av denna rapport undviker specialiserad terminologi från utvecklingspsykologi eller kulturteori. Den talar språket för statskapacitet, återkopplingsloopar och institutionell förbättring. Detta appendix erbjuder en kompletterande lins för läsare som önskar förstå den djupare värdesystemsdynamiken som är verksam i svensk styrning. Det är valfritt, men det gör rapportens underliggande logik fullt transparent.

### A.1 Grundinsikten

Olika grupper och institutioner tenderar att operera från olika tyngdpunkter i hur de tänker kring styrning, resurser och förändring. Dessa är inte personlighetstyper eller partitillhörigheter, även om de korrelerar löst med båda. De är underliggande värdesystem — sätt att konstruera vad som känns verkligt, legitimt och viktigt.

Varje värdesystem representerar ett sammanhängande svar på särskilda livsvillkor. Inget är "bättre" i någon absolut mening. Varje har karakteristiska styrkor som framträder under vissa förhållanden och karakteristiska blinda fläckar som framträder under andra. Utmaningen för styrning i ett komplext samhälle är att integrera de legitima angelägenheterna från multipla värdesystem utan att fångas av något enskilt.

Det ramverk som används här bygger på Spiral Dynamics integralteori. Vad som följer är en förenklad karta över de system som är mest relevanta för samtida svensk styrning.

### A.2 Värdesystemen på den svenska arenan

**Ordning och stabilitet (ibland kallat "Blått") — Den konstitutionella staten.** I Sverige uttrycker sig detta tänkesätt genom *rättsstaten* — rättsstatstraditionen, det konstitutionella skyddet av rättigheter och den djupa respekt för rättssäkerhet som kännetecknar svensk offentlig förvaltning. Dess styrkor är processuell integritet, institutionellt minne och ett åtagande att behandla medborgare lika inför lagen. Dess blinda fläckar inkluderar rigiditet, en tendens att upphöja process över utfall och en instinkt att bevara befintliga strukturer även när deras funktion har försämrats.

**Prestation och effektivitet (ibland kallat "Orange") — Innovationsekonomin.** Sveriges anmärkningsvärda ekonomiska omvandling från en fattig jordbruksnation till ett högteknologiskt exportkraftverk bygger på detta tänkesätt. Det värdesätter konkurrenskraft, entreprenörskap, vetenskapliga framsteg och mätbara resultat. Styrkor: innovationskapacitet, global orientering och en villighet att omfamna teknologiska lösningar. Blinda fläckar: externaliteter som faller utanför marknadsmätetal, ojämlikhet som effektivitet inte fångar, och en tendens att behandla det som inte kan kvantifieras som oviktigt. Den transaktionella digitala staten — i världsklass på punkt-till-punkt-effektivitet — är ett uttryck för detta tänkesätt som opererar utan tillräcklig integration från andra.

**Inkludering och omsorg (ibland kallat ”Grönt”) — Folkhemmets etos.** En möjlig värdebetoning är solidaritet, likabehandling och kvalitet i socialt stöd. Sådana mål kan främjas genom olika institutioner och avgör inte en enda ståndpunkt i integrationsfrågor. Antagandet att inkluderande ambitioner systematiskt tystade varningar är en forskningshypotes och följer inte av en färgetikett.

**Integrativt och systemiskt (ibland kallat "Gult") — Den adaptiva staten.** Detta tänkesätt prioriterar funktionell passform, systemisk medvetenhet och kapaciteten att integrera multipla perspektiv utan att fångas av något av dem. Det framträder som ett svar på begränsningarna hos alla enskilda systemansatser inför komplexa, sammanlänkade utmaningar. Styrkor: flexibilitet, helhetssystemtänkande, bekvämlighet med osäkerhet och experimentation. Blinda fläckar: kan framstå som distanserad, överdrivet intellektuell eller politiskt ogenomförbar för dem som opererar från andra tänkesätt. I Sverige är detta tänkesätt spirande — synligt i visst kommunalt innovationsarbete, i utformningen av försöksverksamhetsmekanismerna och i fickor av framtidsorienterad styrning — men ännu inte institutionaliserat.

**Holistiskt och planetärt (ibland kallat ”Turkost”) — Ekologiskt ömsesidigt beroende.** En möjlig orientering betonar långsiktiga ekologiska och sociala samband. Den ska inte rangordnas som principiellt mer legitim eller empiriskt korrekt än andra synsätt. Om svenska institutioner uttrycker detta, eller skulle vinna på det, är inte visat.

### A.3 Återkopplingsunderskottet som en värdesystemskonflikt

Det svenska styrsystemet domineras av samspelet mellan de tre första tänkesätten: det konstitutionella Blå som värdesätter procedur, det entreprenöriella Orange som driver effektivitet och det omsorgsfulla Gröna som upprätthåller solidaritet. Varje har gjort väsentliga bidrag till den svenska modellen. Men systemet saknar den integrativa arkitektur som skulle tillåta dem att avkänna kollektivt vad ingen kan se ensam.

Dataarkipelagen är en Orange transaktionell infrastruktur som inte har uppgraderats för att tjäna Grön solidaritet eller Gul systemisk avkänning. Den variansdämpande kulturen är ett Grönt försvar av konsensus som har blivit ett hinder för Gul anpassning. Den kommunala kapacitetsfällan är en Blå konstitutionell struktur som inte har omkalibrerats för att matcha den komplexitet som Orange ekonomisk förändring och Gröna sociala ambitioner har producerat.

Den återkopplingsinfrastruktur som föreslås i denna rapport talar till alla tre: den erbjuder Orange mätbara förbättringar i effektivitet och innovation, Blå förstärkt rättslig koherens och integritetsskydd, och Gröna genuina kanaler för medborgarröst och social rättvisa. Framtidskommunerna är utrymmen där integrationen kan försökas — inte genom att påtvinga ett "högre" tänkesätt, utan genom att bygga en arkitektur som hedrar styrkorna hos alla tre samtidigt som den kompenserar för deras blinda fläckar.

---

---

## Appendix B: Internationella analogier och prejudikat

Förslagen i denna rapport är inte utan prejudikat. Följande exempel illustrerar befintliga implementationer av återkopplingsorienterade styrningsreformer.

### B.1 Finland: Framtidskompetens och föregripande styrning

Finland har bäddat in framtidstänkande i regeringsarbetet genom flera kanaler. Framtidsutskottet i riksdagen genomför framsynsövningar och granskar regeringens politik från ett långsiktigt perspektiv. Sitra, den finländska innovationsfonden, har drivit rikstäckande program för framtidskompetens som visar mätbara ökningar i deltagarnas känsla av handlingsförmåga och komplexitetstolerans. På regional nivå integrerar föregripande styrningszoner framtidsmetoder i planering. Den finländska erfarenheten demonstrerar att framtidskompetens kan odlas systematiskt och att resultaten är påtagliga. För Sverige erbjuder det en modell för förslagen om röda team och framtidskompetens i Sektion 3.

### B.2 Estland: Integritets-by-design datainfrastruktur

Estlands e-förvaltningsinfrastruktur behandlar över 99 % av offentliga tjänster online genom ett enhetligt digitalt identitetslager, men avgörande är att den också implementerar en integritetsarkitektur som ger medborgare full transparens om vem som har haft tillgång till deras data. Datautbyteslagret X-Road möjliggör informationsdelning mellan myndigheter utan att centralisera data i en enda databas. Detta är precis den integritetsbevarande meningsskapande arkitektur som Sveriges Dataarkipelag kräver. Estland demonstrerar att den tekniska och rättsliga infrastrukturen för en meningsskapande stat är uppnåelig — och att den kan byggas på principer som förstärker snarare än urholkar medborgarnas tillit.

### B.3 Danmark: Kommunal autonomi och asymmetrisk delegering

Danmarks kommuner åtnjuter större fiskal autonomi och experimentflexibilitet än sina svenska motsvarigheter, trots de strukturella likheterna mellan de två nordiska modellerna. Danska kommuner har bredare befogenhet att utforma tjänsteleveransmodeller, sätta lokala prioriteringar och testa alternativa tillvägagångssätt. Den danska erfarenheten antyder att kommunal autonomi inte undergräver den universella välfärdsstaten — den kan stärka den genom att möjliggöra kontextkänslig anpassning. För Sverige är detta ett direkt prejudikat för de territoriella kapacitetsuppgraderingar som föreslås i Sektion 3.

### B.4 Storbritannien: Delegeringsöverenskommelser och kombinerade myndigheter

Storbritanniens delegeringsöverenskommelser har skapat kombinerade myndigheter med skräddarsydda befogenheter över transport, bostäder, kompetensförsörjning och ekonomisk utveckling i utbyte mot ansvarsskyldig styrning. Greater Manchesters delegering av hälso- och sjukvård och social omsorg är ett ledande exempel på integrerad offentlig tjänstestyrning på subnationell nivå. Även om den brittiska kontexten skiljer sig avsevärt från Sveriges, är principen om asymmetrisk delegering — att bevilja olika nivåer av autonomi baserat på demonstrerad kapacitet — direkt tillämplig på den Kommunala kapacitetsfällan.

### B.5 Taiwan: Digital demokratiinfrastruktur

Taiwans vTaiwan- och Join-plattformar kombinerar digital deliberation med verklig politisk påverkan. vTaiwan använder strukturerade processer av öppen konsultation, faciliterad deliberation och konsensussökande för att utveckla policyförslag i kontroversiella frågor. Det har producerat lagstiftning som skulle ha varit politiskt omöjlig genom traditionella kanaler. För Sverige demonstrerar detta att digitala verktyg kan komplettera representativ demokrati med deltagandedjup — och att deliberativ infrastruktur kan byggas i skala.

### B.6 Tyskland och Frankrike: Korsreferenser i serien

De kompletterande rapporterna i denna serie identifierar kompletterande underskott. Tysklands adaptiva styrningspilotregioner adresserar ett exekveringsunderskott genom territoriella experimentzoner med integrerade styrningsmandat. Frankrikes Territoires d'Intégration Adaptative adresserar ett integrationsunderskott genom zoner med låg synlighet och högt lärande utformade för att kringgå det nationella skådespelet. De svenska Framtidskommunerna fullbordar trilogin: de adresserar återkopplingsunderskottet genom kommuner bemyndigade att avkänna, koppla ihop och agera i den hastighet deras utmaningar kräver. Tillsammans skulle de tre förslagen kunna utgöra grunden för ett europeiskt nätverk av lärande territorier.

---

---

## Appendix C: Kopplingen till Governance as Engineering-serien

### C.1 Den arkitektoniska grunden

Denna rapport bygger på en djupare arbetsmassa: Governance as Engineering-serien (styrning som ingenjörskonst), en uppsättning formella analyser som modellerar styrningsinstitutioner som återkopplingskontrollsystem med hjälp av standardmatematik från kontrollteori, informationsteori och cybernetik. Serien är teknisk; detta appendix sammanfattar dess kärnresultat på icke-tekniskt språk och visar hur de underbygger diagnosen av återkopplingsunderskottet.

### C.2 De fem artiklarna i korthet

**Artikel I — Governance Stability Simulator** modellerar under angivna antaganden att centraliserade styrsystem opererar på aggregerade signaler som förstör rumslig information. En central kontrollant som endast observerar det nationella genomsnittet kan inte se vilka kommuner som befinner sig i kris och vilka som är stabila. Dess interventioner är samtidigt för svaga för krisplatserna och för störande för de friska. Detta illustrerar modellens möjliga relevans för den rumsliga blindhet som Dataarkipelagen producerar i den svenska kontexten: när myndigheter inte kan dela lokala data ser den nationella nivån endast aggregerade värden, och lokal variation blir osynlig. **Tolkningsgräns:** Ett modellresultat är inte ett empiriskt fynd om svenska förhållanden.

**Artikel II — Fractality as Stability** modellerar under angivna antaganden att ingen enskalig kontrollant kan stabilisera ett system som står inför samtidiga snabba, medelsnabba och långsamma störningar. En kontrollant kalibrerad för snabba kriser kommer att oscillera som svar på långsamma trender. En kontrollant kalibrerad för långsamma trender kommer att vara för långsam för snabba kriser. En möjlig stabil arkitektur i modellen är en fraktal hierarki av kontrollanter, var och en matchad till tidsskalan för sitt störningsband. Detta illustrerar modellens möjliga relevans för kritiken av Medelvärdesåtergångsfelaktigheten: Sveriges institutioner är kalibrerade för medelfrekventa valcykler och långsamt konsensusbyggande. De saknar de snabba avkännings- och responsloopar som exponentiella eller kaskadartade utmaningar kräver. **Tolkningsgräns:** Ett modellresultat är inte ett empiriskt fynd om svenska förhållanden.

**Artikel III — The Observability-Democracy Connection** modellerar under angivna antaganden att medborgarpreferenser inte kan överföras tillförlitligt genom representationskedjor djupare än två eller tre lager. Brusvariansen överstiger den överlevande signalvariansen, och policylagret styr en fantomsignal. Detta illustrerar modellens möjliga relevans för den deliberativa infrastruktur som föreslås i Sektion 3: att förkorta kedjan mellan medborgarerfarenhet och policyrespons kräver direkta deltagandemekanismer, inte bara förbättrad representation. **Tolkningsgräns:** Ett modellresultat är inte ett empiriskt fynd om svenska förhållanden.

**Artikel IV — Requisite Variety and the Commons** modellerar under angivna antaganden att styrsystem med lågdimensionell observation inte kan stabilisera resursystem med hög varians. Observationsdimensionalitet — antalet oberoende signaldimensioner som styrsystemet kan få tillgång till — är den primära bestämningsfaktorn för allmänningsförvaltningens utfall. Detta illustrerar modellens möjliga relevans för den meningsskapande infrastrukturen över silogränser: att koppla ihop skoldata, hälsodata, polisdata och bostadsdata ökar den observationsdimensionalitet som är tillgänglig för kommunerna, vilket gör det möjligt för dem att styra de komplexa sociala system de är ansvariga för. **Tolkningsgräns:** Ett modellresultat är inte ett empiriskt fynd om svenska förhållanden.

**Artikel V — The Coordination Failure Tax** undersöker i en modell hur fyra tänkbara fellägen kan förstärka varandra på ett icke-additivt sätt. Ett styrsystem som uppvisar alla fyra samtidigt är inte fyra gånger sämre än ett väldesignat; det är kategoriskt oförmöget till de funktioner det påstår sig utföra. Detta illustrerar modellens möjliga relevans för brådskan under den lugna tonen i denna rapport: Kompetensfällan är inte en enskild sårbarhet utan en förvärrande uppsättning strukturella begränsningar som, lämnade oadresserade, progressivt kommer att urholka systemets kapacitet att styra. **Tolkningsgräns:** Ett modellresultat är inte ett empiriskt fynd om svenska förhållanden.

### C.3 Från ingenjörsanalys till institutionell design

Governance as Engineering-artiklarna använder formella modeller och simuleringar för att pröva antagna samband mellan observation, representation och samordning. Resultat under modellernas förutsättningar är inte matematiska bevis om hur svenska myndigheter faktiskt fungerar. Empirisk tillämpning kräver en prövbar koppling mellan modellvariabler och observerade institutioner.

Rapporten använder de formella resultaten som **uppslag för institutionsdesign**, inte som fastslagna krav. Framtidskommuner kan pröva effekter av minskad beslutsfördröjning, bättre representativitet, lämplig informationsanvändning och tydlig ansvarsfördelning. Nytta måste bedömas mot enklare administrativa förbättringar och resursförstärkningar, inte bara mot det nuvarande läget.

---

---

## Appendix D: Förväntade invändningar

### D.1 "Sverige är redan ett av de bäst styrda länderna i världen. Varför laga något som inte är trasigt?"

Detta är den mest naturliga reaktionen på denna rapport, och det är precis Kompetensfällan i aktion. Sveriges höga rankningar är verkliga, men de mäter prestation mot mätetal som utformades för det sena 1900-talets förhållanden. Ett system kan vara topprankat på gårdagens mått samtidigt som det är progressivt mindre kapabelt att hantera morgondagens utmaningar. Frågan är inte om Sverige är välstyrt med historiska mått — det är det. Frågan är om dess styrningsarkitektur uppgraderas i den takt dess miljö förändras. Svaret, över de tre mekanismer som dokumenteras i denna rapport, är nej.

### D.2 "Hotar inte datadelning mellan myndigheter Sveriges integritetstraditioner?"

Förslaget avvisar obegränsat informationsutbyte och centraliserad övervakning. Integritetsfrämjande beräkning kan minska vissa risker men undanröjer inte risken för återidentifiering, ändamålsglidning, maktobalans eller kraven på rättslig grund och proportionalitet. Varje användning måste redovisa lagstöd, ändamål, nödvändighet, tekniska skydd, möjliga skador av **både delning och utebliven delning**, lagringstid, oberoende granskning och rättsmedel. Aggregat bör föredras när de räcker.

### D.3 "Är inte detta bara decentralisering under ett annat namn? Vi provade det och det löste inte problemen."

Sverige har redan formell decentralisering — men den är parad med funktionell centralisering. Kommuner har ansvar utan den fiskala eller experimentmässiga autonomi som matchar det. Denna rapport föreslår inte "mer decentralisering" som en generisk slogan, utan en specifik ombalansering: fiskal autonomi matchad till ansvar, experimentmyndighet med transparent utvärdering, och asymmetrisk kapacitetsuppbyggnad så att kommuner vid olika startpunkter kan bygga mot genuint självstyre. Detta är inte den decentralisering Sverige redan har provat; det är en kvalitativt annorlunda relation mellan centrum och periferi.

### D.4 "Den svenska konsensuskulturen är en styrka, inte en svaghet. Varför skulle vi importera adversativ politik?"

Målet är inte att importera adversativ politik. Det är att ge den befintliga konsensuskulturen den arkitektur den behöver för att fungera i en mer komplex värld. Strukturerad oenighet — röda team, deliberativa organ, framtidskompetens — är utformad för att göra konsensus *förtjänad* snarare än *antagen*. Det svenska engagemanget för saklighet undergrävs inte av att institutionalisera funktionen av utmaning; det stärks, eftersom den konsensus som framträder ur genuin deliberation och rigorös prövning är mer robust än den konsensus som framträder ur undertryckande av oliktänkande.

### D.5 "Kommer inte Framtidskommunerna bara att bli ännu ett pilotprojekt som inte leder någonvart, som så många andra?"

Risken är verklig. Det svenska landskapet är översållat med välmenande pilotprojekt som producerade rapporter och tynade bort. Framtidskommunerna är utformade för att undvika detta öde genom tre specifika egenskaper: (1) genuin befogenhet, inte bara konsultativ status — piloter som faktiskt kan fatta beslut producerar annan dynamik än piloter som bara kan ge råd; (2) transparent, oberoende utvärdering som gör resultat synliga och läsbara för andra kommuner, vilket skapar förutsättningarna för spridning genom attraktion; och (3) ett särskilt rättsligt ramverk — en Försöksverksamhetslag — som tillhandahåller politisk täckning och en väg för förlängning eller uppskalning, snarare än att lämna piloterna beroende av en viss ministers eller myndighetschefs fortsatta entusiasm.

### D.6 "Denna rapport diagnosticerar problem men erbjuder ingen politisk strategi. Hur får man egentligen detta gjort?"

Övergångsarkitekturen i Sektion 5 är den politiska strategin. Den är utformad för Sveriges specifika institutionella landskap: frivilligt deltagande snarare än centrala mandat, att arbeta med befintlig tillit snarare än mot den, och att rama in uppgraderingen som en fortsättning av den pragmatiska traditionen snarare än en kritik av den. Framtidskommunerna kräver endast att en handfull kommuner är villiga att prova något annorlunda, och att den nationella regeringen är villig att bevilja de nödvändiga rättsliga och fiskala tillstånden. Den evidens de producerar — om diagnosen är korrekt — kommer att göra argumentet för bredare antagande mer effektivt än något politiskt argument skulle kunna.

---

---

## Bilaga E: Om rapporten och hur den togs fram

### Hur rapporten togs fram

Denna rapport har genererats av AI-språkmodeller (Claude, ChatGPT, DeepSeek) utifrån instruktioner från Björn Kenneth Holmström. Flera modeller instruerades parallellt att närma sig Sveriges situation, och deras svar fogades samman till en text med hjälp av det systemtänkande-ramverk som han hade formulerat. Han valde ämnet, ställde frågorna och beslutade att publicera resultatet, men har skrivit lite av texten själv.

Denna utgåva genomgick en **riktad redaktionell granskning och källkontroll (12 november 2026)** med fokus på 2025 års reformer av informationsutbyte, Natokronologin, kommunal utjämning och försöksverksamhet, samisk konsultation samt integritetsskydd. Detta är inte en heltäckande faktagranskning eller en oberoende prövning av rapportens orsakshypoteser. Många jämförelser, kulturella tolkningar, förväntade effekter och budgetantaganden är fortsatt preliminära. Bilaga F redovisar kontrollerade källor och kvarstående verifieringsarbete.

### Perspektiv och begränsningar

Varken modellerna eller den som instruerade dem skriver inifrån Sveriges institutionella kärna. Björn Kenneth Holmström bor i Sverige och känner det svenska samhället som invånare, men har ingen formell utbildning eller yrkeserfarenhet inom svensk offentlig förvaltning eller statsvetenskap. Han har läst teknisk fysik och har arbetat med matematisk optimering på TOMLAB Optimization. Ramverket som tillämpas här bygger på komplexitetsvetenskap, utvecklingspsykologi och styrningsteori.

Att stå utanför institutionerna begränsar tillgången till den granulära, vardagliga väven i svenskt policyarbete. Ett perspektiv från periferin kan ibland väcka frågor som centrum har lärt sig att inte höra, men det kan lika gärna missa det som de insatta vet. Rapporten gör inte anspråk på insiderkunskap. Den erbjuder en lins som kanske, eller kanske inte, kan vara till nytta för dem som innehar institutionella positioner och söker efter ramverk som gör begripligt vad de upplever.

Återkoppling, kritik och rättelser välkomnas. Argumentet erbjuds i en anda av gemensamt meningsskapande, inte som ett slutgiltigt uttalande.

### Landrapportserien

Denna rapport var den tredje i serien Landrapporter för systemisk förändring, som alla har tagits fram på samma sätt. Den första undersökte Tyskland genom linsen av ett dubbelt verkställighetsunderskott och föreslog adaptiva pilotregioner för styrning. Den andra undersökte Frankrike genom linsen av ett integrationsunderskott och föreslog Territoires d'Intégration Adaptative. Tillsammans föreslår de tre första rapporterna en triptyk över Europas gap i adaptiv förmåga: oförmågan att *besluta*, *integrera* och *uppfatta* samtidigt. Senare rapporter har utvidgat serien till Indien, Europeiska unionen och vidare, och var och en ställer samma underliggande fråga: *Är den verkliga flaskhalsen pengar, beslut eller legitimitet – eller är det systemets förmåga att se vad det står inför och anpassa sig innan fönstret stängs?*

---

---

## Bilaga F: Redaktionell källkontroll och öppna frågor (12 november 2026)

Denna bilaga dokumenterar en **riktad källkontroll**, inte en fullständig verifiering eller ett godkännande av rapportens slutsatser. Kompetensfällan, driftloopen, dataarkipelagen och den kommunala kapacitetsfällan är fortfarande begreppsliga hypoteser. Påståenden om allmängiltig kausalitet eller jämförande överlägsenhet kräver särskilda empiriska undersökningar. Den planerade fristående följeanalysen ingår **inte** i denna revision.

### F.1 Granskade primära och institutionella källor

1. **Informationsutbyte:** [Regeringen, 1 december 2025](https://www.regeringen.se/pressmeddelanden/2025/12/nu-rivs-sekretessen-mellan-alla-myndigheter-i-sverige/); [prop. 2024/25:180](https://www.regeringen.se/rattsliga-dokument/proposition/2025/05/prop.-202425180); [Skolverkets vägledning om informationsdelning mellan skola, socialtjänst och polis](https://www.skolverket.se/larande-och-trygghet/trygghet-vardegrund-och-arbetsmiljo/brottsforebyggande-arbete/dela-information-mellan-skola-socialtjanst-och-polis). Reformen ger villkorade möjligheter, inte rätt till godtycklig samkörning, och avskaffar inte all sekretess.
2. **Natokronologi och tidigare samarbete:** [Regeringen, Sveriges och Natos historia](https://www.regeringen.se/regeringens-politik/sverige-i-nato/sveriges-och-natos-historia/). Den snabba omsvängningen 2022 visar en förändring av politiken men bevisar inte att varningar undertryckts.
3. **Kommunal utjämning:** [SKR, utjämningssystemet](https://skr.se/ekonomiochbudgetplanering/utjamningssystem.8275.html). Systemet syftar till att kompensera för skillnader i skattekraft och strukturella behov; konkreta kvarstående obalanser måste visas.
4. **Kommunala försök:** [Regeringens uppdrag till Statskontoret, 14 maj 2025](https://www.regeringen.se/regeringsuppdrag/2025/05/uppdrag-till-statskontoret-att-analysera-och-foresla-regelforenklingar-och-forsoksverksamheter-for-okad-effektivitet-i-kommunal-verksamhet/). Den föreslagna lagen om Framtidskommuner är ett ytterligare policyförslag, inte gällande rätt.
5. **Samisk konsultation och rättigheter:** [prop. 2021/22:19](https://www.regeringen.se/rattsliga-dokument/proposition/2021/10/prop.-20212219); [Sametinget, Gruvor i Sápmi (2026)](https://sametinget.se/1811). Konsultationsskyldigheter och rättighetsfrågor är skilda från vanlig kommunal samordning. Denna revision avgör inte lagligheten i något enskilt projekt.
6. **Konsekvensbedömning av dataskydd:** [Integritetsskyddsmyndigheten (IMY)](https://www.imy.se/verksamhet/dataskydd/det-har-galler-enligt-gdpr/konsekvensbedomning/nar-ska-en-konsekvensbedomning-genomforas/). Tekniska skyddsåtgärder ersätter inte rättslig grund eller proportionalitetsprövning.

### F.2 Påståenden som fortsatt kräver oberoende undersökning

- Om en särskild svensk driftloop kan identifieras inom flera sakområden, i stället för att härledas ur utvalda exempel.
- Om *Jantelagen* och det föreslagna medelvärdesåtergångsfelslutet förklarar mätbart institutionellt beteende; tills vidare är de metaforer.
- Sveriges jämförande placering vad gäller fragmentering av digital förvaltning och den kausala betydelsen av rättsliga, tekniska och organisatoriska hinder.
- Omfattningen och fördelningen av kommunala kapacitetsbegränsningar **efter** inkomst- och kostnadsutjämning samt skillnader mellan sakområden.
- Jämförelserna med Tyskland och Frankrike, som är tolkande sammanfattningar snarare än validerade landsdiagnoser.
- Kostnader, rättslig genomförbarhet, baslinjer för utfall, urvalsdesign och möjliga negativa effekter av Framtidskommuner.

### F.3 Revisionsprincip

Rätta påvisbara fel i originalrapporten och bevara huvudargumentet med tydligare evidensgränser. Låt mer omfattande undersökningar av makt, fördelning, samverkande ojämlikheter och dekolonial kritik ingå i en separat följeanalys. Revidera därefter huvudarkitekturen om resultaten motiverar det.
### F.4 Förhållande till följerapporten och etapp 3-syntesen

Den separata forskningsagendan *Vems signaler räknas?* och syntesen *Från kompetens till adaptiv och legitim samhällsstyrning* bekräftar inte huvudrapportens hypotes. De tillför alternativ som begränsad uppmärksamhet, selektiv respons, organisatorisk friktion, kapacitet och åtgärdseffekt samt rättighetsgränser och en forskningsplan. Per den 12 november 2026 har ingen kausal jämförande studie eller analys av enskilda personakter utförts. Sekretessbrytande regler från 2025 gäller särskilda kontrolländamål, inte en allmän rätt till statistisk samkörning; ändringen för fristående skolor som planeras till den 1 januari 2027 måste kontrolleras på nytt före tillämpning. Svensk juridisk och metodologisk sakkunskap krävs innan förslagen kan användas operativt.
