# Validation plan — Swedish governance responsiveness

**Companion protocol to Stage 3 synthesis | v0.1 | 12 November 2026**

**Status:** Feasibility and research-design plan, not a preregistered study. No approvals, agreements, participant recruitment or data access have been obtained. Legal and ethical review is required before access to protected case material. Numerical sample sizes below are *not* commitments and must be calculated using pilot record counts, variance and a prespecified minimum detectable effect.

## 1. Three separate research questions

**Track A — Service-pathway mechanism study.** Within a specified municipal service, do information quality, workload, operational routines and report-source category predict processing time, decision and subsequent documented outcomes?

**Track B — Rights and decisions documentary audit.** For a defined sample of Swedish land-use decisions affecting Sámi interests, which decision-maker had authority, what consultation law applied, how was Sámi participation documented, and what reasons and changes appear in the record?

**Track C — Macro comparative theory test.** Across sufficiently many policy domains, institutions or jurisdictions, does higher prior performance predict *later* recognition of independently identifiable changes, after comparison with attention, organizational friction, shocks and political competition?

These tracks must remain distinct. Track A cannot establish the Competence Trap. Track B is a legal/process audit, not a verdict on all land use or a quantitative measure of domination. Track C is a separate, potentially long-term research programme, not something three to five voluntary pilot municipalities can settle.

## 2. Track A: reports of concern (*orosanmälningar*)

### Proposed unit and design

A retrospective cohort of **individual reports of concern** received by municipal social services during a fixed, predeclared 24-month window. Consider 2–4 consenting municipalities with meaningfully different size or staffing profiles, but do not assume they represent Sweden. The unit is the report, nested within a child and municipality; repeats must be tracked without publishing identifiers. The selection frame includes all reports in the chosen period, not only headline failures. Where legally feasible, sample a blind-rated subset for text-based severity and completeness coding.

**Before extraction:** register sites, time window, inclusion/exclusion criteria, analytic plan, data dictionary, outcomes, attrition policy, missing-data handling, disclosure controls and stop conditions. Retrospective registration is transparency about planned analysis, *not* advance registration of data collection or a guarantee against hindsight selection. Researchers must explicitly document which cases and public controversies were already known.

### Essential variables

| Element | Minimum operationalization | Key limitation |
|---|---|---|
| Receipt | Dated recorded report, pseudonymous child identifier | Never-reported concerns are absent |
| Source | Fixed categories (school, police, health, family, self, other), assigned before outcome coding | Profession and report content may be correlated |
| Severity | Two independent, blinded ratings of the original report using fixed rubric | The report may omit meaningful context |
| Completeness | Separate blinded score of actionable information | Not equivalent to truth or accuracy |
| Attention load | Weekly open cases per staff member, vacancies, non-routine shocks | Workload may be endogenous to policies |
| Capacity | Staff availability, lawful remit, known resource constraints at receipt | Budget ultimately reflects political decisions |
| Response | Protection assessment, first decision, days to decision, service actually delivered | A decision not to open a case may be correct |
| Follow-up | Subsequent reports in 12 months; service continuity where lawful | A new report is not proof of previous failure |
| Harm/safeguards | Improper disclosure, unjustified intervention, failure to protect, appeal or review | Omission harms require carefully chosen proxies |

### Hypotheses for a *future* preregistration

- **A1 (operational quality):** At comparable blind-rated severity, more complete incoming information predicts shorter time to a properly justified decision. *Rival:* severe cases may be processed quickly regardless of completeness.
- **A2 (limited attention):** Within municipality, unanticipated workload or staffing shocks predict longer time to decision across source categories. *Rival:* shocks coincide with changes in severity or practice.
- **A3 (selective response):** At similar severity, completeness, workload and history, source categories differ in investigation probability or timing. This is a **screen for residual differences**, not direct evidence of social power; unobserved information and legally relevant criteria may remain.
- **A4 (response effectiveness):** Follow-up burden differs after responses, conditional on observable baseline risks. Analysis remains descriptive unless credible treatment assignment or a design addressing confounding is found.
- **A5 (negative-space selection):** Some concerns are never reported because prospective reporters expect no useful response. Survey school and police staff and, if ethics permits, other groups, using neutral questions about *reported and unreported* concerns. Survey self-selection must be acknowledged.

### Feasibility and safeguards

Obtain a university or qualified research partner, municipal agreement, GDPR assessment, secrecy review and ethics approval where legally necessary. Establish safe analysis arrangements, no export of direct identifiers, minimum cell sizes, a retention/deletion plan, and publication independent of municipality-specific approval of findings. Secure consent where legally required; do not assume that consent alone legitimizes processing of protected child data. If data or workload time series cannot be accessed, **stop or publish an explicitly descriptive feasibility study**; do not fabricate measures.

Pre-specify intercoder reliability and adjudication; compare raters before they see decision or outcome data. Include positive and routine cases as well as failures. Use methods accounting for multiple reports per child and for sites; have a statistician calculate sample requirements after aggregate feasibility counts. Do not advertise a statistically identified source effect before diagnostics of residual confounding and missingness.

## 3. Track B: Sámi consultation / land-use decision audit

### Decision-type-first sampling

Create a sample frame by **decision type and deciding body**: municipal or regional planning decisions, state authorities' decisions, permit bodies and courts where relevant. The first code is **whether and why Act (2022:66) applies to this particular decision**, including exceptions and the role of a request under section 6. Identify other potentially applicable consultation obligations separately. Distinguish legally relevant Sámi collective rights-holders, other Sámi representatives and interested individuals without assuming they are interchangeable.

For a defined interval, extract public decisions, invitations, requests, consultation dates and records, revised alternatives, reasons, cumulative-impact assessment and review or appeal details. Code changes following consultation but avoid equating lack of change with unlawful consultation. The audit may describe how the process operated; **only qualified lawyers should reach project-specific legality conclusions**.

### Key legal source categories

- Statutory consultation Act 2022:66 and amendments, §§1–7, 11–12;
- Planning guidance and decision-type application;
- Girjas (T 853-18): actual holding concerning small-game hunting/fishing licensing rights, not blanket mining consent;
- CERD 2020 individual-communication opinion and 2025 review observations, distinguished from domestic judgments;
- SOU 2026:58 recommendations (including FPIC and cumulative impacts), which are not enacted law;
- Relevant case-specific laws and judicial remedies, to be checked by counsel.

## 4. Track C: Competence Trap at policy level

A conceptual claim cannot be established by repeatedly pointing to dramatic policy reversals. Define **prior performance** independently from the later anomaly, date the emergence of the anomaly from independent evidence, then measure recognition lag and policy response. Compare units with different performance histories and similar exposure; account for political competition, attention demands, exogenous shocks, institutional turnover and resource levels. Register comparison cases selected without knowledge of their eventual outcome, including timely adjustment and no-change examples.

A possible starting point is a **feasibility corpus**, not a causal study: a dated register of warnings, institutional recognition and decisions across several policy domains, with explicit source and missing-record flags. The project should **stop claiming cross-country identification** until equivalent source availability and a plausible comparison design exist. Qualitative process tracing can evaluate explanations within a case but should not be described as a quantitative test of the national hypothesis.

## 5. Study design and decision gates

| Gate | Required artifact | Pass condition | If failed |
|---|---|---|---|
| G0 — source integrity | Verified source register and access notes | All central legal claims trace to primary text or are marked unresolved | Revise or withdraw claim |
| G1 — legality/ethics | Written assessment, partner, approvals if required | Data may be processed lawfully and proportionately | No protected-data extraction |
| G2 — feasibility | Counts, fields, missingness, site selection | Enough cases and relevant variables for an interpretable test | Narrow or convert to descriptive study |
| G3 — registration | Dated protocol and frozen codebook | Hypotheses, outcomes and exclusions fixed before analytical extraction | Label analyses exploratory |
| G4 — coder reliability | Blinded duplicate scores and agreement record | Prespecified adequate agreement; conflicts adjudicated | Revise rubric without peeking or stop |
| G5 — analysis | Reproducible scripts, deviations ledger, uncertainty | Results distinguish at least the specified operational accounts | Report non-identification |
| G6 — rights and harm | Review of disclosure and omission harms | Lawful practice, no unacceptable ongoing risk | Pause, remediate, terminate where necessary |
| G7 — dissemination | Final methods/results/limitations | Publish results including zero and negative findings | No positive effectiveness claim |

**Publication is not dependent on positive findings.** A documented infeasibility result can still be useful.

## 6. Avoiding overreach in interpretation

- A shorter processing delay is not necessarily a better outcome.
- A difference by sender is not automatically discrimination or domination.
- Equal measured outcomes do not prove equal access to reporting.
- An investigation that begins does not guarantee an effective intervention.
- A consultation that changes nothing is not automatically unlawful, nor necessarily adequate.
- One institution's refusal to release data can be a lawful protection, not institutional obstruction.
- No small volunteer pilot validates a Swedish national diagnosis.

## 7. Immediate next artifacts

**Before recruiting or collecting:** (i) a Swedish-law question list for legal counsel; (ii) a one-page feasibility request to potential municipal/university partners that requests only *aggregate field availability*, not case files; (iii) a draft codebook with sensitive fields withheld until approval; (iv) a public dated protocol template for Track A; and (v) a sample-frame memorandum for Track B. Track C should remain a scoped exploratory corpus until sufficient comparable records are located.

## Sources and provenance

Read alongside the Stage 3 synthesis source register and the Stage 2 v0.1.1 evidence ledger. The designs build on Claude's Round 2 proposal but revise its assumptions into gates, explicitly treating access, deadlines and legal interpretation as unverified until qualified review. This plan is AI-assisted research design; it has not been independently approved or executed.
