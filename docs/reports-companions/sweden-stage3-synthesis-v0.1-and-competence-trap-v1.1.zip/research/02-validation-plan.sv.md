# Valideringsplan — lyhördhet i svensk samhällsstyrning

**Forskningsplan till etapp 3-syntesen | v0.1 | 12 november 2026**

**Status:** Genomförbarhets- och metodplan, inte en förregistrerad studie. Inga tillstånd, samverkansavtal, deltagare eller skyddade personuppgifter finns tillgängliga för projektet. Juridisk prövning och etikprövning där den krävs måste ske före tillgång till skyddat material. Urvalsstorlekar bestäms först genom en förhandsberäkning utifrån tillgängligt antal ärenden och planerad minsta påvisbara skillnad.

## 1. Tre skilda forskningsfrågor

**Spår A – Kommunal ärendekedja.** Hur samvarierar informationens kvalitet, arbetsbelastning, organisatoriska rutiner och anmälarkategori med handläggningstid, beslut och senare dokumenterade utfall i en viss verksamhet?

**Spår B – Dokumentgranskning av rättigheter och beslut.** För ett avgränsat urval av markanvändningsbeslut som berör samiska intressen: vem hade beslutskompetens, vilken konsultationslagstiftning gällde, hur dokumenterades samiskt deltagande, och vilka ändringar och motiveringar finns?

**Spår C – Jämförande prövning av kompetensfällan.** För tillräckligt många policyområden eller institutioner: förutsäger högre tidigare resultat en *senare* upptäckt av oberoende identifierbar förändring, med hänsyn till uppmärksamhet, friktion, yttre chocker och politisk konkurrens?

Spåren ska hållas isär. A kan inte bekräfta en nationell kompetensfälla. B är en dokument- och processgranskning, inte ett rättsligt avgörande om alla markärenden. C är ett separat forskningsprogram som inte kan avgöras av tre till fem självselekterade kommuner.

## 2. Spår A: orosanmälningar till socialtjänsten

### Design och enhet

En retrospektiv kohort av **enskilda orosanmälningar** mottagna under en i förväg bestämd sammanhängande tvåårsperiod. Undersök möjligheten att delta för 2–4 kommuner av olika storlek och med olika bemanningsvillkor, utan att behandla dem som representativa för Sverige. Enheten är anmälan, nästlad inom barn och kommun; återkommande anmälningar måste hanteras utan publicerade identiteter. Om juridiken medger det bedömer två oberoende kodare ett slumpmässigt urval av originaltexter utan att se efterföljande beslut.

**Före datauttag:** registrera plats, tidsfönster, urval, exklusioner, analysplan, variabler, utfall, bortfallshantering, sekretesskydd och stoppvillkor. Registrering av retrospektiva data visar en förhandsplan för *analysen*; den innebär inte att händelserna var prospektivt registrerade eller att uppmärksammade misslyckanden varit okända. Dokumentera vilka fall som redan var offentligt kända.

### Datavariabler

| Del | Föreslagen operationalisering | Viktig begränsning |
|---|---|---|
| Mottagande | Daterad orosanmälan, pseudonymiserad identifierare | Orapporterade signaler saknas |
| Avsändare | Fördefinierad kategori: skola, polis, vård, familj, egen, annan | Avsändare och informationskvalitet hänger samman |
| Allvar | Två blindade, oberoende bedömningar av ursprungstexten | All relevant bakgrund finns inte i texten |
| Fullständighet | Separat kodning av handlingsbar information | Inte detsamma som sanning |
| Uppmärksamhetsbelastning | Veckovis ärendebelastning och vakansgrad, externa störningar | Belastning kan själv påverkas av politik |
| Kapacitet | Bemanning, mandat och kända resursbegränsningar | Resurser beror ytterst på tidigare val |
| Respons | Skyddsbedömning, första beslut, antal dagar, faktiskt genomförd insats | Ett avstående kan vara rätt beslut |
| Uppföljning | Ny anmälan inom 12 månader, möjlig servicekontinuitet | Ny anmälan bevisar inte tidigare fel |
| Skador | Felaktigt utlämnande, omotiverad insats, uteblivet skydd, omprövning | Underlåtenhetsskada kräver försiktig proxy |

### Hypoteser för eventuell framtida förregistrering

- **A1 – Informationskvalitet:** Vid jämförbar blindbedömd allvarlighetsgrad hänger mer fullständig information samman med kortare tid till välgrundat beslut.
- **A2 – Uppmärksamhet:** Oväntade och orelaterade belastnings- eller bemanningschocker förlänger tiden till beslut i flera avsändarkategorier inom samma kommun.
- **A3 – Selektiv respons:** Vid jämförbart allvar, fullständighet, belastning och historik varierar utredningsbeslut eller tid mellan avsändare. Kvarstående skillnader är **inte** i sig bevis för makt eller diskriminering.
- **A4 – Åtgärdseffekt:** Jämför senare dokumenterade händelser efter olika beslut, men redovisa observationerna beskrivande tills ett tillförlitligt kausalt upplägg finns.
- **A5 – Signalbortfall:** Fråga personal och eventuellt andra aktörer neutralt om oro som aldrig anmäldes och varför. Erkänn att även enkätsvaren påverkas av urval.

### Rättssäkerhet och genomförbarhet

Sök universitet eller behörig forskningspart, kommunala avtal, bedömning av dataskydd och sekretess samt etikprövning där det krävs. Ha säkra analysmiljöer, inga direkta identifierare i utdrag, gränser för små celler, gallringsplan och oberoende rätt att publicera negativa resultat. Anta inte att samtycke ensamt löser sekretess eller annan rättslig grund. Om akter eller veckovis belastning inte går att få fram: **avbryt den tänkta kausala undersökningen eller publicera endast en tydligt beskrivande genomförbarhetsstudie**.

Kodaröverensstämmelse, hantering av oenighet och ett bedömningsschema ska fastställas innan kodarna ser utfallen. Studera också rutinärenden och fungerande insatser. Statistiken måste hantera flera anmälningar per barn och skillnader mellan kommuner. En statistiker ska avgöra om materialet är tillräckligt stort; utlovade effekter utan sådan prövning är inte acceptabla.

## 3. Spår B: samisk konsultation och markbeslut

### Börja med beslutstypen

Definiera urvalet efter **beslutsfattare och beslutstyp**: kommunal/regional planering, statliga beslut, tillståndsmyndigheter och eventuellt domstolsprocesser. Den första kodningen är **om och varför lag (2022:66) är tillämplig på detta ärende**, inklusive undantag och betydelsen av begäran enligt 6 §. Andra lagars samråds- och konsultationsskyldigheter noteras separat. Kollektiva samiska rättighetsbärare får inte sammanblandas med andra representanter eller individer.

Inhämta offentliga beslut, kallelser, begäranden, protokoll, datum, ändrade alternativ, skäl, konsekvensbedömningar inklusive kumulativa effekter och möjliga rättsmedel för en fördefinierad period. Koda förändringar efter konsultation men behandla inte utebliven ändring som automatiskt olaglig. Granskningen får beskriva processer; **rättslig bedömning av enskilda ärenden kräver kvalificerad jurist**.

Juridiskt underlag omfattar konsultationslagen §§1–7 och 11–12, planeringsregler, Girjasdomens *faktiska* upplåtelserätt, CERD:s yttrande från 2020 och slutsatser från 2025 samt SOU 2026:58:s reformuppmaningar. Skilj gällande lag, civilrättslig dom, traktatorgans icke-bindande bedömning, offentliga utredningsförslag och eventuella rättsmedel. Att Sverige inte ratificerat ILO 169 betyder inte att den saknar möjlig rättslig relevans för domstolars resonemang.

## 4. Spår C: kompetensfällan på policynivå

Hypotesen får inte beläggas genom att välja ut spektakulära omsvängningar. Mät **tidigare resultat** separat från den senare störningen, datera störningens uppkomst oberoende och undersök tid till upptäckt och respons. Jämför enheter med olika resultat före störningen, men likartad exponering. Ta hänsyn till partipolitik, trängsel på dagordningen, yttre chocker, omsättning i organisationer och resurser. Inkludera tidiga lyckade anpassningar och fall utan omsvängning.

En rimlig första produkt är ett **förstudiearkiv**, inte ett kausalt resultat: daterade larm, dokumenterat erkännande och faktiska beslut i flera sektorer, med källor och bortfallsflaggor. Påstå inte jämförande nationell identifiering förrän jämförbara data och en trovärdig metod finns. Processpårning kan hjälpa i enskilda fall men ska inte säljas som kvantitativt test av en nationell teori.

## 5. Grindar och stoppregler

| Grind | Krävt underlag | Villkor för att gå vidare | Om villkoret inte nås |
|---|---|---|---|
| G0 Källor | Spårbart källregister | Centrala juridiska påståenden verifierade eller markerade öppna | Rätta eller dra tillbaka |
| G1 Juridik/etik | Skriftlig prövning, partner, nödvändiga tillstånd | Behandlingen får ske lagligt och proportionerligt | Inget skyddat datauttag |
| G2 Genomförbarhet | Antal, variabler, bortfall, urval | Materialet kan svara på de specificerade frågorna | Avgränsa eller gör beskrivande studie |
| G3 Registrering | Daterat protokoll och låst kodbok | Hypoteser och analyser fixerade före analytiskt uttag | Märk analyser explorativa |
| G4 Kodning | Blindad dubbelkodning | I förväg bestämd tillräcklig överensstämmelse | Revidera utan utfallsinsyn eller avbryt |
| G5 Analys | Reproducerbar kod, avvikelselogg | Osäkerhet redovisas och åtminstone vissa förklaringar kan skiljas | Rapportera icke-identifiering |
| G6 Skador | Bedömning av utlämnande och underlåtenhet | Inga oacceptabla pågående risker | Pausa, rätta, avsluta |
| G7 Publicering | Metod, resultat, begränsningar | Även nollresultat och negativa fynd publiceras | Inga positiva effektpåståenden |

**Ett negativt resultat får publiceras.** Genomförbarhetsproblem är också kunskap om de redovisas ärligt.

## 6. Tolkningsregler

Kortare handläggningstid är inte automatiskt bättre utfall. Skillnader efter avsändare är inte automatiskt diskriminering. Lika registrerade utfall bevisar inte lika möjlighet att anmäla. Ett inlett ärende garanterar ingen verksam insats. Utebliven förändring efter konsultation är varken automatiskt olaglig eller nödvändigtvis legitim. Att vägra dela uppgifter kan vara korrekt sekretesskydd. En handfull frivilliga piloter bekräftar inte någon landsomfattande diagnos.

## 7. Första konkreta forskningsprodukter

Före rekrytering eller datainsamling: (1) juridisk frågelista för svensk sakkunnig, (2) kort förfrågan till tänkbara universitet och kommuner om *aggregerad tillgång på fält*, inte personakter, (3) preliminär kodbok utan känsligt material före godkännande, (4) protokollmall för spår A och (5) urvalsmemo för spår B. Spår C förblir en explorativ kartläggning tills jämförbara handlingar finns.

## Källor och tillkomst

Läs tillsammans med källregistret till syntesen och evidensliggaren i etapp 2 v0.1.1. Uppläggen bygger delvis på Claudes förslag i granskningens andra omgång men gör juridik, etik, dataåtkomst och metodval till uttryckliga grindar. Planen är AI-assisterad forskningsdesign; den har inte godkänts eller genomförts av en forskningshuvudman.
