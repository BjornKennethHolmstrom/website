# From Competence to Adaptive, Legitimate Governance

## A synthesis of *The Competence Trap* and *Whose Signals Count?*

**Sweden country-report series | Stage 3 synthesis | Working paper v0.1 | 12 November 2026**

**Status.** Conceptual and institutional-design synthesis; **not** an empirical validation of a Sweden-wide causal mechanism, a legal opinion, or an evaluated policy intervention. It integrates the two earlier reports and the two adversarial audits without replacing either. Specific interpretations and proposed reforms are distinguished from what the documentary sources establish.

## Executive summary

Sweden combines considerable institutional capabilities with unresolved governance challenges. The original report proposed a **Competence Trap**: success under familiar conditions could make some institutions slow to recognize changes that challenge established routines. Its companion asked **whose signals count**: whether information reaches decision-makers is not the same as whether they allocate attention, possess lawful authority, take effective action, or accept affected people as legitimate participants in defining the problem.

Two adversarial audits exposed a critical limitation: neither paper demonstrates a general Swedish Competence Trap or selective responsiveness by social power. A competing account—**disproportionate attention** in crowded policy agendas—might also explain delay followed by abrupt adjustment. The records examined do not distinguish those macro-level explanations. The contribution of the present synthesis is therefore a **conditional architecture for asking better questions, designing accountable experiments, and learning from negative results**, not a declaration that one explanation won.

The synthesis proposes seven connected functions of adaptive governance: **sensing; interpretation; attention and prioritization; authority and legitimacy; response and implementation; outcomes and harm; and learning and correction**. Failure at one function can masquerade as failure at another. Legal rights and obligations constrain action across the entire sequence; they are not signals to be optimized away. A pilot is justified only when a specified problem, an available lawful intervention, and a credible evaluation plan have been identified.

## 1. What the three investigations actually establish

### 1.1 Original report: a potentially important but unproven mechanism

*The Competence Trap* identifies candidate features of institutional adaptation: organizationally fragmented information, possible consensus filtering, and mismatches between municipal responsibility and capacity. Its Drift Loop is an intelligible **hypothesis** about delayed recognition and compressed correction, not a measured time series. The NATO decision is compatible with several explanations, including a rational response to a large external shock; it cannot independently demonstrate decades of institutional suppression. *Jantelagen*, “mean-reversion fallacy,” and the European three-country comparison should be used as exploratory metaphors or competing hypotheses rather than factual generalizations.

### 1.2 Companion: a change of analytical question

*Whose Signals Count?* asks whether information is heard, whether an issue reaches the agenda, whether a decision-maker can act, whose interests influence a choice, and whether the response respects rights. These questions are valuable even without a uniquely critical-theoretical statistical method. Their application must be **symmetric**: sources of neglected evidence could include frontline professionals, officials, residents, minorities, majorities, organized groups, and individuals who bear the costs of proposed interventions. No category should be treated as inherently authoritative or strategic.

### 1.3 Adversarial reviews: a narrower defensible claim

The two reviews established an important corrective to both papers: no verified Swedish evidence in the review discriminated between the three general explanations—success-induced blindness, selective political influence, and disproportionate attention. Case-level records can test information quality, processing delays, capacity constraints and some differences in response. They cannot, on their own, test the national Competence Trap. The reviews also identified concrete statutory distinctions relevant to pilot design. Review findings themselves remain fallible and require source and specialist checks.

## 2. An integrated seven-function model

**This is a normative-analytical model, not a demonstrated causal chain.** Functions may operate simultaneously, loop backward, and be distributed among several institutions.

| Function | Diagnostic question | Observable or documentary trace | Principal failure modes |
|---|---|---|---|
| 1. **Sensing** | What event or need is detected? What is never reported? | Original warnings, service reports, incident logs, missing-data audits | Missing data; chilling effects; unsuitable categories; excessive collection |
| 2. **Interpretation** | How are signals classified, compared and challenged? | Dated assessments, disagreement records, analytic assumptions | Misclassification; hindsight bias; ignored disconfirmation; spurious inference |
| 3. **Attention and prioritization** | When does the issue enter a decision agenda? | Meeting agendas, workload and staffing series, media or event timeline | Agenda crowding; unequal access; focusing-event dependence |
| 4. **Authority and legitimacy** | Who may lawfully decide, and who has standing? | Statutes, mandates, consultation records, appeals | Power without accountability; consultation substituted for rights; unjustified veto points |
| 5. **Response and implementation** | What was decided, delivered and resourced? | Decision date, budget, actual service delivered | Inadequate capacity; mandate gaps; implementation failure; disproportionate reaction |
| 6. **Outcomes and harm** | Did it help, and who gained or lost? | Predefined outcomes, distributional indicators, privacy and omission harms | Ineffective action; unequal burdens; wrongful disclosure; missed protection |
| 7. **Learning and correction** | Does disconfirming evidence change the rules or priorities? | Revised decisions, published evaluation, cessation criteria | Reputation protection; irreversibility; selective reporting; persistence of harmful programmes |

**The distinction matters.** A child-protection report can reach the right office (sensing), be recognized as serious (interpretation), be dealt with within required time (attention), and still result in an ineffective intervention (outcomes). Calling all of this a “feedback deficit” hides the mechanisms that policy should address. Conversely, refusing an intervention can be wise restraint, not a failure to respond.

Rights, privacy, due process, appropriate democratic control and remedies apply *across* functions. They are constraints and questions of legitimacy; their existence is not evidence of an information failure.

## 3. Rival causal explanations and their distinct predictions

| Candidate account | Distinctive prediction | Potential contrary evidence | Identifiability in one Swedish pathway |
|---|---|---|---|
| **Competence Trap** | At otherwise comparable exposure, formerly high-performing units systematically recognize anomalous change later than weaker performers | Equal or earlier recognition among higher performers, with independent anomaly dates | **No**: needs many units, prior-performance measures and exogenous or independently dated anomalies |
| **Limited attention** | Comparable files face longer delays during unrelated workload and staffing shocks | Delays unrelated to workload after accounting for severity and reporting quality | **Partial**: weekly within-unit workload variation |
| **Selective responsiveness** | At comparable severity, report quality and load, response differs by source or cost-bearer | Comparable responses across groups in adequately powered and well-measured settings | **Partial**: source effects may still reflect unmeasured quality or need |
| **Operational friction** | Delay varies with turnover, rule uncertainty, handoffs and procedural changes | Timely and consistent handoffs despite identified friction | **Yes, for documented steps** |
| **Authority / capacity** | Missing mandate or resources blocks delivery even when the signal is recognized | Adequate powers and resources yet no action | **Partial**: upstream resource choices are political |
| **Intervention inefficacy** | Timely response fails to improve predefined outcomes | Sustained improvement relative to a credible comparator | **Descriptive** without stronger identification |
| **Legitimate disagreement / restraint** | Decision-makers acknowledge a signal but reasonably decline a proposed action for documented reasons | No coherent reasoning, inconsistent treatment of similar cases | **Procedural**; substantive legitimacy can remain contested |

Attention scarcity and political influence can be **nested without being indistinguishable**: workload explains the capacity available for action, while source access or influence may affect which cases receive that capacity. The latter claim needs a comparison conditional on severity, documented information quality and load. A simple correlation is not enough. Likewise, institutional success may condition attention practices; proving that requires a separate comparative design rather than an interpretive example.

## 4. What Swedish records justify saying today

### Information sharing: an incomplete gateway, not a general prohibition

The **Act (2025:170)**, effective 1 April 2025, creates specified duties to disclose information to law-enforcement authorities. **Chapter 10, section 15a of the Public Access to Information and Secrecy Act (2009:400)**, effective 1 December 2025, permits certain disclosures for five control purposes involving crime, benefits, taxes and regulatory noncompliance, with a balancing test and statutory exclusions. These provisions are not general authorization for linking housing, school, health and social-services records for research or municipal dashboards. Independent-school public-access changes are scheduled for 1 January 2027 and extend relevant disclosure rules for their defined purposes; publication-stage confirmation and legal assessment remain necessary. [Sources S01–S04.]

A 2024 National Audit Office investigation found variation in the quality, content and frequency of information exchanged in measures relating to children suspected of serious crimes. The audit points to actual operational shortcomings, not proof of a universal legal blackout or the Competence Trap. [S05.]

### Sámi rights: the scope of decisions is essential

The **Act (2022:66) on consultation in matters concerning the Sámi people**, in its amended form, requires consultation in specified matters of particular significance. Its scope and exceptions vary by decision type; section 6 can make a matter significant following a request from a Sámi representative, while planning obligations cover specified adoption and amendment decisions. Consultation is not automatically a veto or an unrestricted FPIC right. The **Girjas** judgment (T 853-18) recognized the Girjas Sámi village's exclusive right against the state to grant small-game hunting and fishing in the litigated area based on immemorial prescription; it is not a general judgment on mining consent. CERD findings and observations, and the Sámi Truth Commission's 2026 recommendations, raise further rights issues but require careful distinction between domestic statutory obligations, civil-law holdings, treaty-body assessments and reform proposals. [S06–S10.]

A northern municipal pilot may coordinate services and exercise its own planning powers. It must **not** be presented as able to decide mining concessions or environmental permits outside its jurisdiction, waive applicable consultation duties, or substitute a citizens' panel for a collective rights-holder. This is a legal-and-design boundary, not a finding that a particular proposed project is unlawful. A Swedish public-law/Sámi-law review is needed before publication-ready legal application.

### Inequality and what is measured

Statistics Sweden reports an income-based Gini coefficient of **0.314 for 2024** versus **0.310 for 2023**; without capital income, the measure remained **0.246 across 2022–2024**. These describe income distribution, not household wealth concentration or the state's responsiveness to particular warnings. Sweden's government announced in September 2025 an expansion of household-debt statistics while explicitly declining expanded asset data, stating that such data could underpin a wealth tax. That **documented choice** is suitable for competing interpretations about measurement priorities; it does not alone establish improper influence or a privacy rationale stated by government. [S11–S12.]

## 5. A governance architecture worth testing, not imposing

The seven functions suggest design requirements rather than a predetermined reform package:

1. **Define the problem before proposing infrastructure.** Identify a documented failure, the relevant decision-maker and whether the constraint is information, attention, capacity, authority, efficacy, or rights-related. If a simpler measure is likely to solve it, compare that first.
2. **Use the least intrusive sufficient information.** Document purpose, necessity, legal basis, statistical alternatives, security, access, retention, oversight and remedies. Record harm from both disclosure and failure to share where warranted.
3. **Publish the attention rules.** Explain triage criteria, time limits, reasoned non-action, routes for appeal or review, and who can submit counter-evidence. Include protection against media-driven priority distortion without excluding emergencies.
4. **Make authority and participation explicit.** Elected bodies retain statutory powers. Citizens' assemblies need clear agendas, balanced recruitment and published responses. Rights-holder consultation is not interchangeable with random citizen representation.
5. **Track decisions and actual delivery.** Publish a small, feasible set of metrics: timely lawful triage, effective service delivery, costs, rights violations, omission harms and corrections. “More data,” more meetings and higher speed are not success by themselves.
6. **Permit correction and termination.** Preregister evaluation questions prospectively where possible; publish negative results; state who can pause unlawful or unsafe practices and who decides whether an experiment continues.

These measures address accountability and learning, but they create administrative cost and may delay action. More review and consultation is not always better. Each added safeguard must have a specified protective function, reasonable timetable and review of opportunity cost. **Minimal Sufficient Coordination** is a design principle here, not an empirically established optimum.

## 6. Framtidskommuner: a narrower pilot claim

A first cohort of **3–5 voluntary municipalities** could investigate operational feasibility, implementation barriers, public acceptance, data protections and unintended effects. It **cannot** credibly identify Sweden-wide causal effects, the general Competence Trap, or fine-grained intersectional disparities solely from a few self-selected sites. Central funding for a small core evaluation is preferable to an elaborate unfunded dashboard that advantages high-capacity applicants. Record sites that decline, why they decline and what their selection implies.

For northern municipalities, limit experiments to their lawful service and planning remit; map permitting responsibility outside the municipal pilot. For schools and social services, establish specific data permissions rather than advertising a generalized cross-sector nervous system. For citizens' panels, use independent evaluation of **process design, deliberative experience, and pathways to impact**, consistent with OECD guidance. [S13.]

Do not conceal a transformative “payload” within administrative reforms. State the project's larger ambition openly. Transparency is a governance constraint, not an obstacle to be engineered around.

## 7. Boundaries of the critical and developmental lenses

Critical theory can motivate questions about unequal agenda access, measurement choices, and concentrated interests. Intersectionality can identify interaction effects and experiences omitted by existing administrative categories. Decolonial and Indigenous-rights work can foreground historical constraints, collective rights-holders and cumulative impacts that a permit-by-permit or individual-based analysis misses. Their usefulness must appear as **specified hypotheses, measurement choices or explicit normative boundaries**, not as confirmation that power caused an observed delay.

Systems thinking and critical realism help frame rival causal mechanisms and interacting processes. Ecological economics adds material and cumulative constraints where relevant. Reflexive analysis requires publication of who designed the inquiry and what motivated it. Spiral Dynamics, if used, remains optional interpretive vocabulary—not an evidence-based ranking of people or countries. Neither “higher-stage” language nor legal jargon can replace observed decision pathways.

## 8. Conclusions and explicit limits

The original and companion analyses can be integrated at the level of **questions and design principles** without pretending that their macro-diagnoses have been proven. The most defensible conclusion is modest: good governance depends on more than detecting information. It also depends on interpretation, bounded attention, legitimate authority, implementation, outcomes, correction and rights. That is a conceptual proposition, not a finding that Sweden has failed at any particular stage.

The next empirical step should be narrow: a prospective protocol for a retrospective cohort of *orosanmälningar* (reports of concern) to municipal social services, subject to legality, ethics approval and access; and a separate document audit of Sámi consultation by decision type. These can test some mechanisms and describe others, but cannot settle the country-level Competence Trap. Any national causal claim would require a different design and independent scrutiny.

**A mature synthesis leaves open the possibility that the original hypothesis is wrong.** Its value lies in organizing honest comparison and helping institutions learn without sacrificing the people they serve.

## Source register (institutional and primary sources checked or identified)

- **S01** — [Act (2025:170), Swedish Riksdag](https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/lag-2025170-om-skyldighet-att-lamna-uppgifter_sfs-2025-170/), disclosure duties to law-enforcement authorities.
- **S02** — [SFS 2025:934](https://svenskforfattningssamling.se/sites/default/files/sfs/2025-10/SFS2025-934.pdf), Chapter 10, section 15a of OSL, effect 1 December 2025; source is a PDF and needs legal line-by-line review before operational implementation.
- **S03** — [Skolverket, independent providers and public access](https://www.skolverket.se/styrning-och-ansvar/en-skola-i-forandring/offentlighetsprincipen-infors-hos-enskilda-huvudman), scheduled 1 January 2027.
- **S04** — [Government assignment to Skolverket, 21 May 2026](https://www.regeringen.se/regeringsuppdrag/2026/05/uppdrag-till-statens-skolverk-om-stod-i-tillampningen-av-nya-regler-om-informationsutbyte/).
- **S05** — [Riksrevisionen, RiR 2024:9](https://www.riksrevisionen.se/granskningar/granskningsrapporter/2024/otillrackliga-insatser-nar-barn-misstanks-for-grova-brott.html).
- **S06** — [Act (2022:66) on consultation](https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/lag-202266-om-konsultation-i-fragor-som-ror_sfs-2022-66/), as amended; statutory scope and exclusions.
- **S07** — [Boverket, consultation in planning](https://www.boverket.se/sv/PBL-kunskapsbanken/detaljplan/detaljplaneprocessen/samiska-fragor/).
- **S08** — [Supreme Court, Girjas T 853-18](https://www.domstol.se/hogsta-domstolen/avgoranden2/2020/47294/).
- **S09** — [CERD concluding observations (2025)](https://regeringen.se/contentassets/ddc2b527534e42d59218ba632d0df760/cerd-concluding-observations-on-the-combined-twenty-fourth-and-twenty-fifth-periodic-reports-of-sweden.pdf). Treaty-body observations, not a domestic court ruling.
- **S10** — [SOU 2026:58, *Markerna berättar och minns*](https://www.riksdagen.se/sv/dokument-och-lagar/dokument/statens-offentliga-utredningar/markerna-berattar-och-minns_heb358/html/). Inquiry recommendations, not enacted law.
- **S11** — [Statistics Sweden, incomes and taxes 2024](https://www.scb.se/en/finding-statistics/statistics-by-subject-area/household-finances/household-income-assets-and-debts/income-and-tax-statistics/pong/statistical-news/income-and-taxes-2024/).
- **S12** — [Government release, household debt statistics, 26 September 2025](https://www.regeringen.se/pressmeddelanden/2025/09/scb-ska-oka-tillgangen-till-statistik-om-hushallens-skulder/).
- **S13** — [OECD, *Evaluation Guidelines for Representative Deliberative Processes* (2021)](https://www.oecd.org/en/publications/evaluation-guidelines-for-representative-deliberative-processes_10ccbfcb-en.html).

## Provenance and review needs

Prepared with AI drafting and source-assisted editorial checking, using Stage 1 revised bilingual reports, Stage 2 v0.1.1 reports and two independent AI adversarial audits. Source checks are selective, not comprehensive and not an assurance of legal correctness. The analyses and manuscript should receive human review in Swedish public/administrative law, Sámi law, social-services research ethics, causal inference, and bilingual terminology. No individual case files, interviews or administrative datasets were examined for this synthesis. The author and reviewers should document any later substantive changes and keep earlier versions accessible.
