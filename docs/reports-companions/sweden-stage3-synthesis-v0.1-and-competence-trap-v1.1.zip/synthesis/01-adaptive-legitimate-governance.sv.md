# Från kompetens till adaptiv och legitim samhällsstyrning

## En syntes av *Kompetensfällan* och *Vems signaler räknas?*

**Sveriges landrapportserie | Etapp 3: syntes | Arbetsrapport v0.1 | 12 november 2026**

**Status.** Begreppslig syntes och förslag till institutionsdesign – **inte** en empiriskt bekräftad svensk orsaksförklaring, ett rättsutlåtande eller en utvärderad reform. Texten förenar två tidigare rapporter och två adversariella granskningar utan att ersätta dem. Dokumenterade sakförhållanden skiljs från tolkningar, hypoteser och normativa förslag.

## Sammanfattning

Sverige förenar betydande institutionell kapacitet med olösta styrningsproblem. Huvudrapporten föreslog en **kompetensfälla**: framgång under välkända förhållanden skulle kunna göra vissa institutioner långsamma att uppmärksamma förändringar som utmanar etablerade rutiner. Följerapporten frågade **vems signaler som räknas**: att information når en beslutsfattare är inte detsamma som att frågan får uppmärksamhet, att befogenhet finns, att en verksam insats genomförs eller att berörda människor ges legitim del i problemformuleringen.

Två adversariella granskningar blottlade en avgörande begränsning: ingendera rapporten belägger någon allmän svensk kompetensfälla eller selektiv respons efter samhällelig maktposition. En konkurrerande förklaring – **ojämnt fördelad uppmärksamhet** under trängsel på den politiska dagordningen – kan också förklara dröjsmål följda av plötslig omställning. Det granskade materialet skiljer inte dessa landsövergripande förklaringar åt. Syntesens bidrag är därför ett **villkorat ramverk för bättre frågor, ansvarsfulla försök och lärande av negativa resultat**, inte en utsaga om vilken teori som vann.

Syntesen föreslår sju sammanlänkade styrningsfunktioner: **upptäckt; tolkning; uppmärksamhet och prioritering; befogenhet och legitimitet; beslut och genomförande; utfall och skada; samt lärande och korrigering**. Ett fel i en funktion kan felaktigt beskrivas som ett fel i en annan. Rättigheter och rättsliga skyldigheter begränsar åtgärder genom hela kedjan; de är inte signaler som kan optimeras bort. Ett pilotförsök bör endast initieras när problemet, den lagliga åtgärden och den trovärdiga utvärderingsmetoden kan specificeras.

## 1. Vad de tre undersökningarna faktiskt visar

### 1.1 Huvudrapporten: en intressant men oprövad mekanism

*Kompetensfällan* identifierar möjliga svårigheter vid institutionell omställning: fragmenterat lärande mellan organisationer, tänkbar konsensusfiltrering och obalans mellan kommuners ansvar och kapacitet. Driftloopen är en begriplig **hypotes** om sen problemupptäckt och koncentrerad korrigering, inte en uppmätt tidsserie. Natosvängningen passar flera förklaringar, även ett rationellt svar på en omfattande extern chock, och bevisar inte att varningssignaler undertryckts under årtionden. *Jantelagen*, ”medelvärdesåtergångsfelslutet” och trelandskontrasten i Europa bör användas som metaforer eller prövbara hypoteser – inte som belagda generaliseringar.

### 1.2 Följerapporten: en förändrad fråga

*Vems signaler räknas?* undersöker om information når fram, om en fråga förs upp på dagordningen, om befogenhet finns, vems intressen som påverkar beslut och om insatser respekterar rättigheter. Frågorna kan vara värdefulla även utan en unik kritisk-teoretisk statistisk metod. Tillämpningen måste vara **symmetrisk**: förbisedda uppgifter kan komma från frontpersonal, tjänstemän, invånare, minoriteter, majoriteter, organisationer och dem som drabbas av föreslagna insatser. Ingen kategori är automatiskt mer sanningsenlig eller mer strategisk.

### 1.3 Granskningarna: en snävare hållbar slutsats

De två granskningarna rättade ett problem i båda rapporterna: ingen svensk evidens som faktiskt kontrollerades kunde skilja mellan de tre generella förklaringarna – framgångsskapad blindhet, selektivt politiskt inflytande och ojämn uppmärksamhet. Aktbaserade studier kan pröva informationskvalitet, handläggningsfördröjningar, kapacitetsbegränsningar och vissa skillnader i respons. De kan inte ensamma testa en nationell kompetensfälla. Granskningarna identifierade också rättsliga skillnader som påverkar försöksverksamhetens utformning. Även AI-granskarnas egna slutsatser måste kunna rättas mot källor och sakkunskap.

## 2. En integrerad modell med sju funktioner

**Detta är en begreppslig och normativ modell, inte en påvisad kausalkedja.** Funktionerna kan verka samtidigt, gå tillbaka till tidigare led och ligga hos olika aktörer.

| Funktion | Diagnostisk fråga | Möjlig observation | Möjliga fel |
|---|---|---|---|
| 1. **Upptäckt** | Vilket behov uppmärksammas? Vilka uppgifter rapporteras aldrig? | Ursprungliga varningar, orosanmälningar, incidentloggar, analys av saknade uppgifter | Databrist; tystnadseffekter; fel kategorier; överinsamling |
| 2. **Tolkning** | Hur klassificeras och ifrågasätts uppgifter? | Daterade bedömningar, dokumenterad oenighet, analysantaganden | Felklassificering; efterklokhet; bortvald motbevisning |
| 3. **Uppmärksamhet/prioritering** | När hamnar frågan på beslutsdagordningen? | Dagordningar, belastnings- och bemanningsserier, händelsekronologi | Trängsel; ojämn tillgång; beroende av kriser |
| 4. **Befogenhet/legitimitet** | Vem får fatta beslut, och vem har rättslig ställning? | Lagrum, mandat, konsultationsprotokoll, rättsmedel | Makt utan ansvar; konsultation som ersätter rättigheter; onödiga hinder |
| 5. **Beslut/genomförande** | Vad beslutades, finansierades och utfördes? | Datum, budget, faktisk leverans | Kapacitetsbrist; mandatluckor; uteblivet genomförande; överreaktion |
| 6. **Utfall/skada** | Hjälpte insatsen? Vem vann och förlorade? | Fördefinierade utfall, fördelningsmått, integritets- och underlåtenhetsskador | Verkningslöshet; ojämna bördor; otillåten delning; uteblivet skydd |
| 7. **Lärande/korrigering** | Förändrar motbevisning regler och prioriteringar? | Ändrade beslut, öppna utvärderingar, stoppvillkor | Ryktesskydd; irreversibilitet; selektiv rapportering; skadliga bestående åtgärder |

**Skillnaderna spelar roll.** En orosanmälan kan nå socialtjänsten, bedömas som allvarlig och handläggas i tid men följas av en ineffektiv insats. Att kalla allt detta ett ”återkopplingsunderskott” döljer vilka mekanismer som bör åtgärdas. På motsvarande sätt kan ett avstående från ingripande vara välgrundad återhållsamhet, inte underlåten respons.

Rättigheter, integritet, rättssäkerhet, lämplig demokratisk kontroll och rättsmedel gäller **genom hela processen**. De är legitimitetsvillkor, inte tecken på ett informationsfel.

## 3. Konkurrerande förklaringar och särskiljande förutsägelser

| Förklaring | Särskild förutsägelse | Evidens som skulle tala emot | Går den att pröva i en kommunal ärendekedja? |
|---|---|---|---|
| **Kompetensfällan** | Tidigare högpresterande enheter upptäcker, allt annat lika, oväntad förändring senare än andra | Lika snabb eller snabbare upptäckt hos högpresterande, med oberoende daterad förändring | **Nej**: kräver många enheter, historiska resultat och oberoende tidpunkt för förändringen |
| **Begränsad uppmärksamhet** | Likvärdiga ärenden fördröjs mer vid orelaterad belastning eller bemanningschock | Ingen koppling till belastning efter kontroll för allvar och informationskvalitet | **Delvis**: belastning över veckor inom enheten |
| **Selektiv respons** | Vid jämförbart allvar, rapportkvalitet och belastning varierar respons med avsändare eller vem som bär kostnaden | Likvärdig respons i tillräckligt stora och väl mätta material | **Delvis**: kvarvarande skillnad kan bero på okända behov |
| **Organisatorisk friktion** | Fördröjning följer personalomsättning, regelosäkerhet, överlämningar och rutinbyten | Snabba konsekventa överlämningar trots identifierad friktion | **Ja, för dokumenterade steg** |
| **Befogenhet/kapacitet** | Avsaknad av mandat eller resurser stoppar åtgärder trots känd information | Tillräckliga befogenheter och resurser men utebliven handling | **Delvis**: tidigare resursbeslut är politiska |
| **Bristande åtgärdseffekt** | Snabb respons ger ändå inte bättre förutbestämda utfall | Hållbar förbättring mot en trovärdig jämförelse | **Beskrivande**, inte automatiskt kausalt |
| **Legitim oenighet/återhållsamhet** | Signal erkänns men åtgärd avböjs av dokumenterade skäl | Skäl saknas eller liknande ärenden behandlas inkonsekvent | **Processuellt**; saklig legitimitet kan fortfarande vara omstridd |

Uppmärksamhet och inflytande kan samverka **utan att hypoteserna får bli oåtkomliga för prövning**. Belastning påverkar tillgänglig handlingskapacitet; tillträde till agendan kan påverka vilka ärenden som får denna kapacitet. Det senare kräver jämförelser givet allvar, informationskvalitet och belastning. Enkel samvariation räcker inte. Institutionell framgång kan i sin tur påverka uppmärksamhetsrutiner, men för att pröva det behövs en separat jämförande design.

## 4. Vad svenska källor motiverar att vi säger i dag

### Informationsutbyte: begränsade rättsliga vägar, inte ett generellt förbud

**Lag (2025:170)**, i kraft den 1 april 2025, inför specificerad uppgiftsskyldighet gentemot brottsbekämpande myndigheter. **10 kap. 15 a § offentlighets- och sekretesslagen (2009:400)**, i kraft den 1 december 2025, tillåter visst utlämnande för fem kontrolländamål rörande brott, förmåner, skatter och regelöverträdelser med avvägning och särskilda undantag. Bestämmelserna ger inte ett allmänt tillstånd att länka individdata från bostäder, skola, vård och socialtjänst för kommunal analys eller forskning. Förändringarna för fristående skolhuvudmän är planerade till den 1 januari 2027 och utvidgar tillämpningen av relevanta sekretessbrytande regler inom deras angivna ändamål. Ikraftträdande och varje konkret användning måste ändå kontrolleras juridiskt. [K01–K04.]

Riksrevisionen konstaterade 2024 variation i kvalitet, innehåll och frekvens i informationsutbytet vid insatser för barn som misstänks för grova brott. Det belägger faktiska organisatoriska problem, men inte en generell rättslig blockering eller kompetensfällan. [K05.]

### Samiska rättigheter: beslutstypen är avgörande

**Lag (2022:66) om konsultation i frågor som rör det samiska folket**, i ändrad lydelse, föreskriver konsultation i vissa ärenden av särskild betydelse för samerna. Omfattning och undantag varierar med beslutstypen; enligt 6 § kan frågan bli särskilt betydelsefull efter begäran av en samisk företrädare, medan skyldigheten vid planering omfattar vissa beslut om antagande och ändring. Konsultation innebär inte automatiskt vetorätt eller någon allmän lagstadgad rätt till fritt och informerat förhandssamtycke. **Girjasdomen** (T 853-18) fastställde Girjas samebys i förhållande till staten ensamrätt att upplåta småviltsjakt och fiske inom det aktuella området med stöd av urminnes hävd; domen ger inte en generell regel om gruvsamtycke. CERD:s uttalanden och bedömningar samt Sanningskommissionens förslag från 2026 aktualiserar ytterligare frågor men måste hållas isär från gällande inhemsk lag och civilrättsliga avgöranden. [K06–K10.]

En nordlig kommunal pilot får samordna service och använda sina lagliga planeringsbefogenheter. Den kan **inte** påstås avgöra undersökningstillstånd, bearbetningskoncessioner eller miljötillstånd som ligger utanför dess mandat, göra undantag från tillämplig konsultationsskyldighet eller låta ett medborgarråd ersätta kollektiva rättighetsbärare. Det är en rättslig och designmässig gräns, inte en bedömning av ett namngivet projekts lagenlighet. Svensk sakkunnig granskning inom offentlig rätt och samerätt behövs inför rättslig tillämpning.

### Ojämlikhet och valet av statistik

SCB redovisar Gini för ekonomisk standard på **0,314 år 2024** mot **0,310 år 2023**. Utan kapitalinkomster var värdet **0,246 under 2022–2024**. Detta gäller inkomstfördelning, inte hushållens samlade förmögenhet eller myndigheters lyhördhet för vissa avsändare. Regeringen meddelade i september 2025 att statistiken om hushållens skulder skulle utvecklas samtidigt som man uttryckligen avstod från mer tillgångsdata och hänvisade till att sådana uppgifter skulle kunna ligga till grund för en förmögenhetsskatt. Det **dokumenterade valet** lämpar sig för jämförelser mellan förklaringar av statistikprioriteringar; det visar inte i sig otillbörlig maktutövning eller att integritet angavs som regeringens skäl. [K11–K12.]

## 5. En styrningsarkitektur att pröva – inte införa som färdig sanning

De sju funktionerna leder till designfrågor, inte ett på förhand givet reformpaket:

1. **Definiera problemet före infrastrukturen.** Identifiera ett dokumenterat misslyckande, ansvarig beslutsfattare och om hindret gäller information, uppmärksamhet, kapacitet, mandat, åtgärdseffekt eller rättigheter. Jämför med enklare åtgärder.
2. **Använd minsta tillräckliga information.** Redovisa ändamål, nödvändighet, lagstöd, statistiska alternativ, säkerhet, behörighet, gallring, tillsyn och rättsmedel. Bedöm skador både av utlämnande och av att nödvändig information inte når fram.
3. **Gör prioriteringsregler synliga.** Förklara triage, tidsgränser, motiverade avståenden och vägar för motbevisning, omprövning och överklagande. Undvik att mediehändelser ensamma styr prioritering utan att missa akuta risker.
4. **Tydliggör mandat och deltagande.** Folkvalda organ behåller sina rättsliga befogenheter. Medborgarråd behöver begripligt uppdrag, balanserat urval och offentlig respons. Konsultation med rättighetsbärare är inte utbytbar mot representativt slumpurval.
5. **Följ beslut och verkligt genomförande.** Använd ett litet, genomförbart kärnset av mått: rättssäker och skyndsam bedömning, faktisk hjälp, kostnader, rättighetskränkningar, underlåtenhetsskador och rättelser. Mer data, fler möten eller högre hastighet är inte automatiskt bättre.
6. **Möjliggör rättelse och avveckling.** Förregistrera prospektiva frågor när det är möjligt, redovisa negativa resultat och ange vem som stoppar olagliga eller osäkra metoder och vem som beslutar om fortsättning.

Skyddsåtgärder kan förbättra ansvar och lärande men också öka kostnader och dröjsmål. Mer granskning är inte alltid bättre. Varje extra spärr ska ha ett tydligt skyddsändamål, rimliga tidsgränser och bedömda alternativkostnader. **Minimal tillräcklig samordning** används här som designprincip, inte som ett empiriskt uppmätt optimum.

## 6. Framtidskommuner: ett snävare pilotlöfte

En första grupp om **3–5 frivilliga kommuner** skulle kunna undersöka praktisk genomförbarhet, implementeringshinder, deltagarnas erfarenheter, integritet och oavsedda effekter. Gruppen kan **inte** ensam identifiera nationella kausala effekter, en allmän kompetensfälla eller finfördelade intersektionella skillnader. En centralt finansierad kärnutvärdering är rimligare än en omfattande ofinansierad instrumentpanel som främst högkapacitetskommuner klarar av. Dokumentera vilka som avstår och vad självselektionen betyder.

För nordliga kommuner ska försök begränsas till den egna lagliga service- och planeringskompetensen, med tydlig karta över tillståndsprövning utanför pilotprojektet. Skola och socialtjänst behöver särskilt lagstöd för varje dataflöde; inget allmänt ”myndighetsnervsystem” utlovas. Medborgarråd bör utvärderas för **designens integritet, deltagarnas deliberativa erfarenhet och vägen till faktiskt genomslag**, i linje med OECD:s riktlinjer. [K13.]

Dölj inte en omvälvande ”last” i en administrativ ”trojansk häst”. Redovisa också de långsiktiga ambitionerna öppet. Transparens är ett villkor för legitim styrning, inte något som ska kringgås tekniskt.

## 7. De kritiska och utvecklingspsykologiska perspektivens gränser

Kritisk teori kan synliggöra frågor om ojämn tillgång till dagordningen, val av statistik och koncentrerade intressen. Intersektionalitet kan föreslå interaktionseffekter och erfarenheter som inte får plats i ärendesystemens kategorier. Dekolonial och urfolksrättslig analys kan lyfta historiska villkor, kollektiva rättighetsbärare och kumulativa konsekvenser som individbaserad eller ärendevis analys missar. Värdet ska visa sig i **specificerade hypoteser, val av mätning eller öppet deklarerade normativa gränser**, inte i antagandet att makt bevisats vara orsak till en viss fördröjning.

Systemtänkande och kritisk realism hjälper till att formulera samverkande och alternativa mekanismer. Ekologisk ekonomi bidrar med materiella begränsningar och kumulativa effekter där de är relevanta. Reflexiv analys kräver att det redovisas vem som formulerat frågor och valt belägg. Spiral Dynamics får i förekommande fall vara ett valfritt tolkningsspråk – inte en vetenskaplig rangordning av personer eller länder. Varken ”högre stadier” eller juridiska termer ersätter observerade beslutsförlopp.

## 8. Slutsatser och uttryckliga begränsningar

Rapporterna kan syntetiseras på nivån **frågor och designprinciper** utan att någon nationell orsaksdiagnos låtsas vara bekräftad. Den mest hållbara slutsatsen är måttfull: fungerande styrning beror på mer än att upptäcka information. Tolkning, begränsad uppmärksamhet, legitim befogenhet, genomförande, utfall, korrigering och rättigheter spelar också roll. Det är en begreppslig utsaga, inte ett fynd att Sverige har misslyckats i ett visst led.

Nästa empiriska insats bör vara avgränsad: ett protokoll för en retrospektiv kohort av **orosanmälningar** till kommunal socialtjänst, under förutsättning att rättslig åtkomst och etikprövning kan ordnas, samt en separat dokumentgranskning av samisk konsultation efter beslutstyp. De kan pröva vissa mekanismer och beskriva andra men kan inte avgöra kompetensfällan på landsnivå. Nationella kausalpåståenden kräver en annan forskningsdesign och oberoende granskning.

**En mogen syntes lämnar möjligheten öppen att den ursprungliga hypotesen är felaktig.** Dess värde ligger i ärliga jämförelser och i institutioner som kan lära utan att offra dem de ska tjäna.

## Källregister (institutionella och primära källor)

- **K01** — [Lag (2025:170), Sveriges riksdag](https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/lag-2025170-om-skyldighet-att-lamna-uppgifter_sfs-2025-170/), uppgiftsskyldighet till brottsbekämpande myndigheter.
- **K02** — [SFS 2025:934](https://svenskforfattningssamling.se/sites/default/files/sfs/2025-10/SFS2025-934.pdf), 10 kap. 15 a § OSL, ikraftträdande 1 december 2025; rättslig detaljkontroll krävs före praktisk tillämpning.
- **K03** — [Skolverket, offentlighetsprincipen hos enskilda huvudmän](https://www.skolverket.se/styrning-och-ansvar/en-skola-i-forandring/offentlighetsprincipen-infors-hos-enskilda-huvudman), planerad start 1 januari 2027.
- **K04** — [Regeringen, uppdrag till Skolverket 21 maj 2026](https://www.regeringen.se/regeringsuppdrag/2026/05/uppdrag-till-statens-skolverk-om-stod-i-tillampningen-av-nya-regler-om-informationsutbyte/).
- **K05** — [Riksrevisionen, RiR 2024:9](https://www.riksrevisionen.se/granskningar/granskningsrapporter/2024/otillrackliga-insatser-nar-barn-misstanks-for-grova-brott.html).
- **K06** — [Lag (2022:66) om konsultation](https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/lag-202266-om-konsultation-i-fragor-som-ror_sfs-2022-66/), i ändrad lydelse.
- **K07** — [Boverket, konsultation i planärenden](https://www.boverket.se/sv/PBL-kunskapsbanken/detaljplan/detaljplaneprocessen/samiska-fragor/).
- **K08** — [Högsta domstolen, Girjas T 853-18](https://www.domstol.se/hogsta-domstolen/avgoranden2/2020/47294/).
- **K09** — [CERD, slutsatser om Sverige (2025)](https://regeringen.se/contentassets/ddc2b527534e42d59218ba632d0df760/cerd-concluding-observations-on-the-combined-twenty-fourth-and-twenty-fifth-periodic-reports-of-sweden.pdf), traktatorgans rekommendationer – inte svenska domstolsavgöranden.
- **K10** — [SOU 2026:58, *Markerna berättar och minns*](https://www.riksdagen.se/sv/dokument-och-lagar/dokument/statens-offentliga-utredningar/markerna-berattar-och-minns_heb358/html/), utredningsförslag, inte gällande lag.
- **K11** — [SCB, inkomster och skatter 2024](https://www.scb.se/hitta-statistik/statistik-efter-amne/hushallens-ekonomi/hushallens-inkomster-tillgangar-och-skulder/inkomster-och-skatter/pong/statistiknyhet/inkomster-och-skatter-2024/).
- **K12** — [Regeringen, skuldsstatistik 26 september 2025](https://www.regeringen.se/pressmeddelanden/2025/09/scb-ska-oka-tillgangen-till-statistik-om-hushallens-skulder/).
- **K13** — [OECD, *Evaluation Guidelines for Representative Deliberative Processes* (2021)](https://www.oecd.org/en/publications/evaluation-guidelines-for-representative-deliberative-processes_10ccbfcb-en.html).

## Tillkomst och granskningsbehov

Texten har utarbetats med AI-stöd och riktad källkontroll utifrån etapp 1:s reviderade tvåspråkiga rapporter, etapp 2:s v0.1.1 och två adversariella AI-granskningar. Källkontrollen är selektiv och garanterar inte juridisk riktighet. För ett publiceringsfärdigt rättsligt resonemang behövs mänsklig kompetens inom svensk offentlig rätt, samerätt, forskningsetik för socialtjänstdata, kausal analys och juridisk tvåspråkighet. Ingen enskild akt, intervju eller administrativ datamängd har granskats för denna syntes. Senare substantiella ändringar bör dokumenteras så att äldre versioner finns kvar.
