# Sweden — Whose Signals Count?

## Research agenda: information, attention, influence, capacity, and rights

**Companion to:** *Sweden — The Competence Trap* (Stage 1 revised working draft, 12 November 2026)  
**Status:** Stage 2 v0.1.1 — **pre-publication research-agenda draft; legal specialist review outstanding**. No original responsiveness study, causal identification or case-specific legal opinion has been completed.  
**Cut-off:** 12 November 2026  
**Scope:** Sweden; selected governance mechanisms and institutional-design tests. This is not a comprehensive country assessment.

## Executive summary

The companion does not reject the original report's *Competence Trap* and *Swedish Drift Loop*. It examines why information can reach an institution without necessarily producing action, and the reasons may include legal limits, capacity, limited attention, incentives, intervention effectiveness or differences in whose claims receive priority. **This paper has not measured differential responsiveness by source or social group.**

Four questions follow. **Who can make a signal visible? Who interprets it? Who can compel or block action? Who bears the gains and costs?** Critical theory directs attention to institutional and economic power; intersectionality probes unequal exposure and differential responsiveness; decolonial analysis asks whether collective Indigenous rights and historically situated impacts are properly recognized, without assuming a particular allocation of legal authority. Critical realism, systems thinking, ecological constraints, and reflexive evaluation help distinguish these lenses' hypotheses from established facts.

The evidence reviewed here supports a narrower, more useful conclusion than a claim that Swedish institutions are deliberately ignoring disadvantaged groups. A 2024 National Audit Office review found deficiencies in interventions and information exchange concerning children suspected of serious crime. Swedish law then expanded specific disclosure channels in 2025. This makes it untenable to assert a universal legal information blockade, but it leaves open whether information is used well, for proportionate purposes, and with equitable consequences [S01–S04].

Swedish distributional indicators warrant differentiated analysis: Statistics Sweden reported a 2024 equivalised-disposable-income Gini of **0.314**, compared with **0.310** in 2023; the 2024 figure excluding capital income was **0.246**, unchanged over 2022–2024. The share with low economic standard was **13.1%**, down slightly and its lowest since 2007. The Gini is an **income** measure, not a wealth-ownership measure. The Equality Ombudsman received **5,697 discrimination complaints in 2025**, up from **4,452** in 2024; the change cannot by itself establish a proportional change in underlying discrimination [S05–S07].

The Sámi case is a proposed test of the difference between *consultation*, *coordination*, and *decision authority*. Sweden has a Sámi consultation statute, extended to municipal and regional matters in 2024, while the UN Committee on the Elimination of Racial Discrimination has raised concerns about the scope of that framework, especially regarding land, resources and free, prior and informed consent. They concern legal scope, rights, and normative requirements. They do not establish that every proposed project is unlawful [S08–S11].

**Provisional research direction (not a finding about Sweden):** do not replace a feedback diagnosis with a domination diagnosis. Distinguish **information/operations, attention, authority/capacity, selective influence, intervention efficacy, and rights compliance**; test separately where the available unit of analysis permits. *Framtidskommuner* should test whether better sensing improves real outcomes **without** increasing surveillance, bypassing legal rights, or concentrating voice in already powerful groups.

## 1. Relationship to the original report

The Stage 1 report develops three major constructs: **Data Archipelago** (fragmented cross-domain learning), **Jantelagen / consensus filtering** (a hypothesis about dissenting signals), and **Municipal Trap** (a possible mismatch between local responsibilities and usable authority). It proposes *Framtidskommuner*—voluntary municipal pilots combining lawful learning, deliberation, flexibility, and independent evaluation. These are the propositions under test, not assumptions this companion is entitled to certify.

The original report already recognizes privacy safeguards, targeted disclosure, protected rights, independent evaluation, municipal equalization, and the risk of poorly designed pilots. Accordingly, this companion does **not** claim that power analysis or Sámi consultation is wholly absent from Stage 1. Some Stage 1 passages nevertheless remain unrevised or overstated; see Appendix C. The parent is preserved as a separate artifact, not silently corrected here. This companion asks whether these considerations might change the causal explanation, the choice of intervention, or what counts as success.

The DeepSeek critique supplied for this project is treated as a **source of hypotheses**. Claims such as “information silos serve wealth holders,” “segregation is primarily produced by suppressed minority signals,” and “an institutional arrangement is green colonialism” require separate evidence about decision records, incentives, causation, and rights. Rhetorical force is not evidentiary weight.

## 2. Analytical discipline

### 2.1 Six complementary lenses, without stage-ranking

- **Institutional and systems analysis:** map decisions, legal mandates, data paths, resources, feedback, implementation and learning.
- **Critical theory / political economy:** identify agenda-setting, ownership, bargaining power, resource control and the capacity to externalize costs. Distinguish positional advantage from unlawful or intentional domination.
- **Intersectionality:** ask whether combinations of socioeconomic position, disability, gender, age, geography, origin and other relevant factors change the likelihood of being heard or receiving effective services. Never infer an individual characteristic from a group average.
- **Decolonial and Indigenous-rights analysis:** inspect historical land and governance relations, current jurisdiction, participation and substantive rights. Sámi institutions and rights-holders are not interchangeable with generic stakeholder samples.
- **Critical realism and ecological economics:** test alternative generative mechanisms, including budgets, law, administrative capability, ecological limits and cumulative land-use effects; do not reduce every observed disparity to power.
- **Second-order/reflexive analysis:** disclose who framed the question, selected evidence, funded evaluation, decided success criteria and could influence publication.

Spiral Dynamics may be used as a tentative lens for discussing values; it is not a validated device for classifying whole populations, institutions or critics into stages. No stage label is evidence of a causal mechanism.

### 2.2 Five non-equivalent claims

This paper separates **(1) descriptive observations**, **(2) institutional mechanisms**, **(3) causal attributions**, **(4) rights and legal findings**, and **(5) normative recommendations**. For example, a complaint trend is an observation; selective institutional response is a hypothesis; a violation of a particular statutory duty requires the relevant legal test and case evidence; the desirability of a veto or redistribution is a policy judgment. One must not be smuggled into another.

### 2.3 Operationalizing power

“Power” is not one variable. Code, for each affected decision, **agenda power** (who selects issues), **epistemic power** (whose data and expertise are recognized), **legal power** (jurisdiction, rights, appeal and remedy), **fiscal power** (who funds and can withhold), **organizational power** (staff, access, implementation), **bargaining and exit options**, and **procedural voice** (who can contest a decision). Identify beneficiaries and burden-bearers only after measuring the actual distribution of options and outcomes.

### 2.4 What the lenses add—and what they cannot decide

Each interpretive lens should supply an **explicit research hypothesis or declared normative/legal boundary**. Intersectionality motivates a pre-specified interaction test or an audit of needs that administrative coding cannot represent; it does not make group differences causal. Critical theory motivates examining *unsent warnings*, decisions about which statistics to produce, and unequal influence **symmetrically across sources**. Decolonial analysis directs attention to cumulative landscape effects and standing of *collective* rights-holders, rather than solely individual survey responses. Institutional theory and critical realism demand workload, resource, attention and effectiveness alternatives. Ecological economics adds cumulative material effects only where a concrete case makes them relevant. Reflexive analysis requires the research team's provenance, funders and agenda setters to be scrutinized.

A **documented measurement decision** on 26 September 2025 expanded household-debt statistics while the responsible minister expressly rejected additional asset statistics, citing the possibility of a wealth tax [S28]. This is an identifiable decision for inquiry into agenda-setting, not evidence by itself of improper influence. The public statement **did not cite privacy** as its reason; privacy is a separately labeled hypothesis to investigate.

## 3. Proposed test case A — Information-sharing, operational barriers, and response

The *Data Archipelago* may describe fractured learning, but it should not be equated with an absolute prohibition on sharing. Riksrevisionen's 2024 review of interventions for children suspected of serious crime found differences in the quality, content and frequency of exchanges, highlighting organizational routines, uncertainty and staff turnover in the pathways examined [S01]. It does not demonstrate nationwide data fragmentation or delayed adaptation.

Two distinct 2025 reforms must not be conflated:

1. **Act (2025:170), effective 1 April 2025**, establishes specified duties to give information to seven law-enforcement authorities. Its §§5–7 cover named state agencies, municipalities and regions, and head teachers within the school system; §8 excludes multiple protected categories, including specified statistics, health-care and social-services secrecy [S20]. Its general route is *toward law enforcement*, not a blanket school-to-social-services learning channel.
2. **Chapter 10 §15a of the Public Access to Information and Secrecy Act, effective 1 December 2025**, permits authority-to-authority disclosures when needed for five control purposes: prevention/detection of criminal activity; investigation of crime; preventing improper benefits, support, tax or fee decisions; detecting or investigating such errors; and preventing/detecting/investigating cheating and rule violations. It requires an interest balancing and lists exceptions, including statistics secrecy and specified health-care secrecy [S21]. It is **not a general authorization to link records for learning, service optimization or research**, and permission to disclose does not automatically confer a lawful basis on the receiving controller.

A law enacted in May 2026 is scheduled to apply public-access and secrecy rules to eligible independent education providers from **1 January 2027**. Government guidance states that this also extends the applicability of §15a *by and toward* those providers, for §15a's purposes only, not unrestricted research linkage [S22]. The September 2026 inquiry directive (Dir. 2026:104) considers further changes; it is not itself a change of law [S23]. Dates and scope should be rechecked before publication.

**Candidate mechanisms (unproven here):** legal prohibition or ambiguity for a *specified purpose* (H-A1a, case-level control; H-A1b, learning/research); organizational and interoperability delays (H-A2); adequate information but inadequate authorized response (H-A3); a response delivered but ineffective (H-A5); and restrictions that avert disproportionate disclosure, mapping of individuals or lost trust (H-A4). IMY objected in November 2025 to a **separate proposed** rule on proactive disclosures; that objection did not repeal §15a [S12]. Both disclosure harms and harms of unjustified non-disclosure belong in the assessment.

**Investigation:** trace dated reports, lawful exchange channels, decision and implementation separately. A recorded decision not to intervene may reflect appropriate restraint; delay alone is not proof of failure. A before/after comparison around 2025 is currently vulnerable to simultaneous reforms and implementation lags. No causal impact is claimed.

## 4. Proposed test case B — Whose needs become legible?

The argument from a “Swedish consensus filter” to systematic exclusion must be tested, not assumed from a national cultural stereotype. There is nevertheless a serious measurement problem: national averages can conceal distinct experiences, and public institutions may register some needs more readily than others.

Statistics Sweden reports a **2024 income Gini of 0.314**, slightly above 2023 (**0.310**); excluding capital income, **0.246** remained unchanged from 2022–2024. The **13.1%** share with low economic standard was **slightly lower than in 2023 and the lowest since 2007** [S05, S06]. These are not measures of wealth or responsiveness. SCB also reports *sammanräknad förvärvsinkomst* (taxable earned income **including pensions and taxable transfers**) by sex and region of birth. Group differences require analysis of age, years in Sweden, education, employment and other factors [S13].

The Equality Ombudsman received **5,697 complaints about discrimination** in 2025, about 28% more than in 2024; **6,831 complaints of all categories** were received. The agency cautions that complaint statistics do not reveal the full extent of discrimination. Reporting and changes in institutional practice are possible explanations to investigate, not a verified agency attribution to this particular year [S07]. Boverket treats residential segregation as a relational phenomenon involving structural conditions (including direct and indirect discrimination) and individual choices; it emphasizes that separating neighbourhood effects from other determinants is empirically difficult [S14].

An intersectional test should therefore focus on **disparities in a specific service pathway**, not a catalogue of identity categories. For example: among families with comparable needs after repeated school absence, including those who did not seek assistance, are referrals, response times, service quality and outcomes distributed differently by intersecting geography, disability, household resources, age and relevant migration-related circumstances? Are there mechanisms—language access, digital barriers, staff turnover, administrative discretion—that plausibly explain the differences?

**Measurement safeguards:** register the categories and rationale before examining outcomes; protect evaluator independence while obtaining input from affected residents; use voluntary and lawful collection when sensitive characteristics are necessary; minimize identification risk in small cells; report denominator and missingness; estimate intersections only with sufficient sample and statistical power; avoid framing foreign-born residents as homogeneous. A model that demonstrates disparity does not automatically identify its cause.

**Potential disconfirmation:** if comparable cases show equitable access and similar justified decisions once need and context are controlled, a discriminatory-filter explanation for that particular process would be weakened, though not every other mechanism ruled out.

## 5. Proposed test case C — Sámi consultation, land rights, and decision authority

Northern industrial development requires cross-institutional coordination, but **better coordination cannot itself decide the content of rights or the allocation of legal authority**. This case must distinguish municipal planning, state concession decisions, environmental permitting, collective rights, and political judgments.

**Statutory consultation.** Under Sweden's Act (2022:66), §1 preserves other consultation duties; §2 requires specified public bodies, including municipalities and regions from March 2024, to consult Sámi representatives before decisions of particular significance. §3 excludes judicial-like decision bodies. §§4–5 impose subject- and decision-type exclusions; under planning legislation the duty applies to adoption or amendment of designated plans, not every land-use decision. Under §6, a Sámi representative's request can trigger consultation in a matter of significance; §11 allows the procedure to end when agreement/consent cannot be reached, so the Act alone is **not a general veto rule**. The Act itself does not settle every possible remedy under other laws [S08, S09]. Step one in any file audit is to identify the actual deciding body and determine whether the Act applied.

**Distinct rights and legal sources.** In *Girjas* (Supreme Court, T 853-18, 2020), the Court recognized Girjas sameby's exclusive right **against the state to grant small-game hunting and fishing in its defined area above the cultivation boundary**, grounded in immemorial prescription. This is not a universal holding on mining consent or all Sámi communities [S24]. The UN Committee on the Elimination of Racial Discrimination adopted a **non-binding treaty-body opinion** in *Ågren et al. v. Sweden* (2020) finding violations concerning the Rönnbäcken concession dispute; its 2025 concluding observations criticized gaps in the consultation regime and urged stronger protections for FPIC [S25, S11]. Their domestic legal weight and Sweden's follow-up need specialist review. Sweden has not ratified ILO Convention 169; non-ratification must not be equated with the absence of other domestic or international relevance.

**Inquiry, not enacted law.** The Sámi Truth Commission's *Markerna berättar och minns* (SOU 2026:58) calls, inter alia, for cumulative/landscape impact assessment (call 35) and FPIC in legislation (call 38). These are recommendations, not provisions already enacted [S26]. A 2025 Amnesty/Sámi Council report uses the contested concept *green colonialism* as an advocacy interpretation, not a judicial determination about a specific permit [S15]. The availability and standing of affected samebyar, Sámi organizations and Sámi individuals must be examined according to each decision; none is a generic substitute for all the others.

**Audit design:** select a set of decision files spanning **different decision types**, including matters inside and outside the Act's scope. Record who decided, consultation requests and dates, evidence of cumulative impact, whose objections were registered, decision changes, reasons and remedies. Include favorable and unfavorable outcomes; do not infer procedural unlawfulness or project-specific consent rights without specialist case review. Neither representation in a citizens' assembly nor an efficient municipal pilot replaces statutory consultation or judicial protection.

## 6. Proposed test case D — Local authority, funding and the possibility of local capture

The *Municipal Trap* is worth testing, but Swedish municipalities do not operate without redistributive support. The municipal equalization system is designed to moderate differences in tax base and structural costs; its actual effects must be modeled before attributing municipal service capacity directly to the local tax base. The previously cited SKR web pages [S16–S17] have **not been independently confirmed**, so they are not relied upon here for a numerical claim.

**Centralization is not always domination; decentralization is not always emancipation.** National standards can protect legal equality against local discrimination, while excessive earmarking or rigid national rules can constrain valid local experimentation. Conversely, local autonomy can empower neglected communities or amplify established local interests. Every proposed transfer of authority must answer: who gains discretion, who can appeal, who bears the cost, which national floors are non-waivable, and what fiscal equalization remains necessary?

The empirical question is whether particular mandates, funding rules or implementation capacities cause documented delays or poor outcomes. Compare municipalities with similar needs but different organizational arrangements or fiscal capacity. Examine central constraints and local political choices separately; do not treat municipality size or tax base as a sufficient causal explanation.

## 7. Proposed test case E — Citizen deliberation and policy response

The first report proposes standing municipal *medborgarråd*. Sweden already has relevant experimental experience: the **research-led** 2024 climate citizens' assembly selected **60 members** (after invitations and voluntary responses), of whom **49 participated throughout**, and generated **22 proposals** [S18]. It was not a state-commissioned national assembly. Those facts show deliberative activity, not by themselves durable policy impact [S18].

OECD guidance distinguishes **design integrity**, **deliberative experience**, and **pathways to impact**, including independent evaluation, accessible participation, balanced evidence and a public response to recommendations [S19]. This points toward a more rigorous standard than mere attendance or the number of recommendations.

A pilot should disclose its agenda setters, funders, recruitment procedure, nonresponse, compensation, facilitation, expert briefings, political response and actual implementation. Deliberation must not become a substitute for an elected assembly's accountability, a court's remedies, or affected Indigenous rights-holders' distinct legal standing. Nor should the companion assume that advice without binding power is always decorative: advisory institutions can matter when their recommendations receive reasoned, traceable treatment. Binding authority requires a further legitimacy and legal argument.

## 8. Candidate explanations and a bounded research design

The conceptual claim that information requires an authorized actor to produce action is close to a truism. The empirical question is whether **timing, decision, and outcomes differ in predicted ways**, after separating information quality, workload, resources, influence and legitimate restraint. The accounts below are hypotheses, not established explanations of Sweden; they are not yet jointly identified by the available data.

| Account | Candidate observable | Main ambiguity / needed comparison |
|---|---|---|
| **Information / operations** | Dated reports arrive late or are incomplete | Are missing facts relevant, lawful to share, and necessary for the decision? |
| **Agenda attention** | Within a unit, higher open-case load or vacancies delay decisions across sources | Load may reflect earlier political resource choices; use exogenous load changes if possible |
| **Authority / capacity** | A documented mandate or staffing constraint restricts available responses | Capacity is partly politically determined; file-level patterns do not identify that origin |
| **Selective influence** | At similar severity, quality and workload, response varies by pre-coded source category or cost-bearer | Source quality and attention may confound; residual association is not proof of favoritism |
| **Intervention efficacy** | An action is taken and implemented, but desired outcomes do not follow | Allocation to interventions is not random; failure is not always poor governance |
| **Competence Trap (parent)** | Prior high performance independently predicts longer recognition lag, controlling for problem mix and workload | **Not testable in a small municipal pilot**; requires independent anomaly onset dates and many units |

**Rights compliance is not another causal account.** It is assessed separately against applicable law and documented decision rights. Likewise, the meaning of an ethically acceptable trade-off is a declared normative position, not an estimated coefficient. The attention hypothesis is a serious, parsimonious rival—not an empirically demonstrated winner. Attention and influence may interact: powerful actors can shape what reaches the agenda.

### 8.1 Retrospective policy cases versus registered cohort research

The northern land-use, municipal finance and national-agenda examples are **purposefully chosen exploratory cases**, not pre-registered samples selected blind to outcomes. Use explicit negative/success comparators and treat process tracing as descriptive; do not claim causal identification from these cases. A genuinely **prospective protocol registration** would occur *before* extracting identifiable case data for a separately specified study.

The most feasible candidate is a **retrospective cohort of reports of concern about children to municipal social services**, registered *before extraction*. The outline below is a feasibility proposal, not an approved or executed study:

- Two to four municipalities, a fixed 24-month window, and sample size determined by a power calculation (not by an assumed number of reports).
- Unit: one dated report, nested within child and municipality; outcome: recorded investigation decision and time to decision. A new report on the same child within 12 months is a **proxy for renewed concern**, not proof that an earlier decision harmed the child.
- Predictors: pre-defined reporting-source category; blinded independent ratings of the original report's severity and completeness; weekly open-case load and vacancies; prior reports, age and relevant context. Coders must be shielded from decisions/outcomes for severity and quality coding, and agreement assessed against a pre-set threshold.
- Investigate missing reports through a suitably designed staff survey; note that signals never recorded are absent from an administrative cohort. Separate no response, reasoned non-intervention, implemented intervention, and ineffective intervention.
- Prerequisites: each municipality's secrecy and access assessment, ethics approval where required, secure handling, possibly a university research partner, and review of the deadlines under the **Social Services Act (2025:400)**. None has yet been secured.
- Stop as infeasible if access cannot lawfully be obtained, weekly load data are unavailable, or blinded coding cannot reach the pre-specified reliability threshold. Analyses of small demographic intersections must **not** be advertised as causal tests in a few volunteer municipalities.

The study could partially test operations, workload/attention, and observed source associations. It **cannot** establish country-wide selective responsiveness or test whether earlier Swedish institutional success itself created blindness.

### 8.2 Provisional evaluation safeguards for Framtidskommuner

A small pilot should use a **minimal core scorecard**, with additional indicators only when feasible: (i) decision timeliness and documented decision quality; (ii) implementation and a pathway-appropriate substantive outcome; (iii) wrongful disclosure *and* potentially harmful unjustified non-disclosure; (iv) legal compliance and participant safety; (v) transparent recruitment and agenda-setting. A repeat report within 12 months is one *imperfect* omission-risk proxy, not itself evidence of harm.

Record who defines problems and evaluates them, including public officials, contractors, funders, rights-holders, professional staff, majority and minority residents, and advocacy groups. Representation and subgroup comparisons at pilot scale are **descriptive monitoring**, not adequately powered intersectional causal estimates. Collect sensitive attributes only under a separate necessity and legality assessment; avoid disclosive small cells.

Review and appeal measures may introduce costs and delay; specify who may trigger each review, the grounds, the review deadline, and existing legal remedies before adding new veto points. Publish reasons for selection and refusal, and use stopping/repair rules if unlawful disclosure or rights violations occur. No experimental flexibility can override statutory consultation, data protection or other rights obligations. The principle of *Minimal Sufficient Coordination* is a design consideration, not evidence that a given level of authority or data sharing is sufficient.

## 9. What could change in the original proposal?

| Potential finding | Effect on *The Competence Trap* | Effect on *Framtidskommuner* |
|---|---|---|
| Information and organizational gaps dominate | Strengthens central diagnosis | Focus on lawful interoperability, staffing and process learning |
| Information was already available, but political priorities blocked action | Feedback deficit becomes a partly downstream symptom | Add contestability, transparent decision reasons, credible review and incentive changes |
| Disparities arise from unequal access or voice | Expands “sensing” to include who can define problems | Add co-design, accessibility, representation audits and distributional endpoints |
| Substantive Indigenous rights constrain a proposed coordination solution | Rights become a non-substitutable constraint, not a stakeholder preference | Exclude rights-diluting exemptions; run separate lawful consultation and rights assessment |
| Privacy or national standards prevent harm | Some barriers are protective, not failures | Preserve limits; test narrower, less intrusive alternatives |
| Local authority risks elite capture | Polycentricity is insufficient on its own | Add anti-capture safeguards, appeals, independent evaluation and national rights floors |

## 10. Research status and publication gate

The original report's strongest contribution remains its proposal to make governance more adaptive. This companion adds the possibility that adaptation itself may be selective, constrained by legitimate protections, or captured by interests. The serious question is not **“Is the Swedish system an engineering problem or a power settlement?”** Both may be true in different degrees and settings. The research task is to determine which mechanism is binding in which decision.

The cited material supports the **relevance** of these tests; it does **not** measure whose reports receive a response, establish the parent’s causal hypothesis, or provide project-specific legal conclusions. There has been no primary-file review of specific municipal cases, no matched municipal dataset, no independent interview program, and no comprehensive legal review of an actual mining permit or pilot exemption. The examples are **evidence-backed research leads** rather than completed empirical case studies.

**Provisional decision:** this v0.1.1 is a **pre-publication candidate, not a legal-review-cleared report**. Retain the original report as a separately labeled diagnostic working paper; develop this companion through case-level verification; revise the parent report only when evidence materially warrants it. A final synthesized report should distinguish legal non-negotiables, established mechanisms, contestable hypotheses and political value choices.

### Unresolved matters (declared, not silently closed)

No Swedish public-law/Sámi-law specialist has reviewed the legal account; no municipal files have been accessed; the retrospective cases were selected with known controversies; the hypotheses are not yet fully discriminating; small pilot samples cannot measure national subgroup effects; the status of some source links remains unconfirmed. The parent report also contains passages not yet corrected (Appendix C). Further legal confirmation is required before publication, including the judgment-level discussion of ILO 169 in *Girjas*, interpretation and remedies under the consultation statute, and each proposed data flow.

## Appendix A — Evidence and attribution rules

- **Verified source statement:** repeat a bounded proposition directly supported by an official document, primary law, reported statistic or identifiable research output.
- **Attributed assessment:** e.g. Amnesty's characterization of certain extractive practices; do not present the attribution as a court's finding.
- **Hypothesis:** a proposed mechanism that could explain observed patterns; specify alternative explanations and falsifiers.
- **Normative design choice:** specify whose values, rights, and trade-offs justify the recommendation. Efficiency and emancipation are not logically opposite; a well-defined systemic optimization may include participation, equity and non-domination as objectives or constraints.
- **Unknown:** if records, comparable data, or direct affected-party input are absent, keep the conclusion open.

## Appendix B — Source register

**Reference verification note (12 November 2026):** Official statute, court-summary, SCB and parliamentary pages were cross-checked for specified claims. This does not replace specialist legal review. S10, S15's announcement date, S16 and S17 remain unconfirmed at their cited locations. A source link is not itself proof of the article's interpretation.

[S01] Riksrevisionen (2024), *Otillräckliga insatser när barn misstänks för grova brott* (RiR 2024:9). https://www.riksrevisionen.se/granskningar/granskningsrapporter/2024/otillrackliga-insatser-nar-barn-misstanks-for-grova-brott.html  
[S02] Government of Sweden (2025), *Ökat informationsutbyte mellan myndigheter*, Prop. 2024/25:180. https://www.regeringen.se/rattsliga-dokument/proposition/2025/05/prop.-202425180  
[S03] Government of Sweden (1 December 2025), communication on the new secrecy-breaking provision. https://www.regeringen.se/pressmeddelanden/2025/12/nu-rivs-sekretessen-mellan-alla-myndigheter-i-sverige/  
[S04] Government of Sweden (2026), guidance assignment on school information exchange. https://www.regeringen.se/pressmeddelanden/2026/05/skolverket-far-uppdrag-att-stodja-skolors-tillampning-av-nya-sekretessbrytande-regler/  
[S05] Statistics Sweden (2026), *Högre ekonomisk standard – men inkomstskillnaderna ökar* (2024 reference year). https://www.scb.se/pressmeddelande/hogre-ekonomisk-standard--men-inkomstskillnaderna-okar/  
[S06] Statistics Sweden, *Inkomster och skatter* (2024 reference year). https://www.scb.se/he0110/  
[S07] Equality Ombudsman (DO, 2026), *Statistik över anmälningar till DO 2016–2025*. https://www.do.se/rattsfall-beslut-lagar-stodmaterial/publikationer/2026/statistik-over-anmalningar-till-do-2016-2025  
[S08] Swedish Parliament, Act (2022:66), *Lag om konsultation i frågor som rör det samiska folket*. https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/lag-202266-om-konsultation-i-fragor-som-ror-det_sfs-2022-66/  
[S09] Boverket, *Konsultation i ärenden som rör samiska frågor* (municipal planning implementation). https://www.boverket.se/sv/PBL-kunskapsbanken/detaljplan/detaljplaneprocessen/samiska-fragor/  
[S10] Sametinget (page update date unconfirmed), *Konsultation med Sametinget*. https://sametinget.se/konsultationsordning  
[S11] UN CERD (18 December 2025), *Concluding observations on Sweden*, CERD/C/SWE/CO/24-25, paragraphs 38–39. https://docstore.ohchr.org/SelfServices/FilesHandler.ashx?enc=VZ8yj3OGKOf0RJCS3WoPnE7T2oUZ8StMZIJo0NpHO49VPKwtbwJcz8EBobrL%2FfcdXzbf1oWhXrZc9iDxavCOUIOSGx%2FsD2bxL2jqc%2B2b%2BA8%3D  
[S12] Integritetsskyddsmyndigheten (3 November 2025), opinion on SOU 2025:45 (proposed **additional** rule). https://www.imy.se/globalassets/dokument/remissvar/2025/slutbetankandet-okat-informationsutbyte-mellan-myndigheter--nagra-anslutande-fragor.pdf  
[S13] Statistics Sweden (2026), *Inkomster för personer i Sverige* (2024 data by origin and sex). https://www.scb.se/hitta-statistik/sverige-i-siffror/utbildning-jobb-och-pengar/inkomster-for-personer/  
[S14] Boverket (2026), *Om boendesegregation*. https://www.boverket.se/sv/samhallsplanering/livsvillkor-och-utanforskap/kunskapsstod/om-boendesegregation/  
[S15] Amnesty Sápmi / Amnesty International and Sámi Council (announcement date unconfirmed), *Just Transition or Green Colonialism?* announcement and report description. https://amnestysapmi.se/ny_amnestysapport/  
[S16] SKR (2026), *Utjämningssystem samt frågor och svar*. https://skr.se/ekonomiochbudgetplanering/utjamningssystem.8275.html  
[S17] SKR (2026), municipal finances and uneven conditions. https://skr.se/pressrum/aktuellt/nyhetsarkiv/ljusareiekonominmenbehovenattstallaomarstora.10818.html  
[S18] Stockholm University (26 November 2024), first national climate citizens' assembly and lessons. https://www.su.se/nyheter/nyhetsartiklar/2024-11-26-rapport-om-lardomar-fran-medborgarrad-om-klimatet  
[S19] OECD (2021), *Evaluation Guidelines for Representative Deliberative Processes*. https://www.oecd.org/en/publications/evaluation-guidelines-for-representative-deliberative-processes_10ccbfcb-en.html

**Source limitations:** government communications describe their own policy rationale; advocacy organizations document allegations and normative claims; aggregate statistics are not causal identification; legal interpretation may differ across specific cases. This is a curated starting register, not a comprehensive systematic literature review.

[S20] Sveriges riksdag, Act (2025:170), §§1–8. https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/lag-2025170-om-skyldighet-att-lamna-uppgifter_sfs-2025-170/  
[S21] Sveriges riksdag, Public Access to Information and Secrecy Act (2009:400), ch. 10 §15a, wording after SFS 2025:934. https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/offentlighets-och-sekretesslag-2009400_sfs-2009-400/  
[S22] Swedish Parliament, 2025/26:UbU20, adopted May 2026 (school public-access rules effective 1 Jan 2027); Government Skolverket assignment U2026/00991 explaining consequences for §15a. https://www.riksdagen.se/sv/dokument-och-lagar/dokument/betankande/offentlighetsprincipen-med-lattnadsregler-for_hd01ubu20/ ; https://www.regeringen.se/regeringsuppdrag/2026/05/uppdrag-till-statens-skolverk-om-stod-i-tillampningen-av-nya-regler-om-informationsutbyte/  
[S23] Swedish Government, Dir. 2026:104 (9 Sep 2026), *Avskaffad sekretess mellan myndigheter...* https://www.regeringen.se/rattsliga-dokument/kommittedirektiv/2026/09/dir.-2026104  
[S24] Swedish Supreme Court, *Girjas* T 853-18, 23 Jan 2020, judgment summary. https://www.domstol.se/hogsta-domstolen/avgoranden2/2020/47294/  
[S25] UN CERD, *Ågren et al. v. Sweden*, CERD/C/102/D/54/2013, opinion adopted 18 Nov 2020 (UN record). https://juris.ohchr.org/casedetails/3021/en-US  
[S26] Swedish Sámi Truth Commission, *Markerna berättar och minns*, SOU 2026:58, summary calls 35, 38. https://www.riksdagen.se/sv/dokument-och-lagar/dokument/statens-offentliga-utredningar/markerna-berattar-och-minns_heb358/html/  
[S27] Statistics Sweden, *Inkomster och skatter 2024*, low-economic-standard series. https://www.scb.se/hitta-statistik/statistik-efter-amne/hushallens-ekonomi/hushallens-inkomster-tillgangar-och-skulder/inkomster-och-skatter/pong/statistiknyhet/inkomster-och-skatter-2024/  
[S28] Government of Sweden, 26 Sep 2025, decision and public rationale on debt but not new asset statistics. https://www.regeringen.se/pressmeddelanden/2025/09/scb-ska-oka-tillgangen-till-statistik-om-hushallens-skulder/  

## Appendix C — Editorial crosswalk

**This is a crosswalk, not an amendment to the frozen Stage 1 report.** In addition to the entries below, Stage 1 §2.3 ("demographic replacement"), §4.2 (documented suppression), Appendix A.2 (stage interpretations), Appendix C.3 (claimed mathematical proof), Appendix D.2 (privacy trade-off), and §§5.2/5.4 ("Trojan Horse", "political cover") remain **unrevised claims or rhetorical choices**. Pilot counts also differ across Stage 1 sections. A subsequent parent revision must review these independently.


| Original Stage 1 topic | Companion section | Status |
|---|---|---|
| §2.2 Data Archipelago | §§3, 8 | Test current law, implementation, necessity and privacy |
| §2.3 Consensus filtering | §4 | Hypothesis; avoid national-culture essentialism |
| §2.4 Municipal Trap | §6 | Include equalization and local-capture countercase |
| §3.2 Structured disagreement | §7 | Evaluate agenda, representativeness and effects |
| §3.4 Living testbeds (northern transition) | §5 | Sámi consultation and rights independent of coordination |
| §4 Political immune system | §§2, 8 | Treat beneficiaries and suppression as claims requiring evidence |
| §§5–6 Framtidskommuner | §§7–9 | Rights-preserving distributional, privacy and evaluation gates |

## Appendix D — Provenance and language concordance

The user initiated the research questions and supplied the original Swedish governance-report materials and a DeepSeek critique. The v0.1 companion was drafted with ChatGPT assistance; Claude Fable conducted independent Round 1 and Round 2 adversarial reviews, and ChatGPT prepared the reconciliation and this editorial draft. The author has **not** claimed a personally conducted case-file study or human legal review. AI-assisted source checking may contain errors; the cited original records take precedence. The English and Swedish versions are paired versions **without a privileged master language**: claims about Swedish legal terminology must be adjudicated against Swedish law, other claims against their respective sources. The six highest-impact Round 1 divergences (FPIC, authority vs influence, DO caveat, scope of file review, falsifiability, attribution) were resolved together in this version.

**Open legal release gate:** review by a Swedish legal specialist of consultation §§1–7, 11–12; *Girjas* judgment including ILO 169 discussion; CERD opinion and domestic weight; 2025 disclosure instruments; and 2027 school scope. The present text must not be presented as a signed-off legal analysis.

*This is a companion research-agenda draft, not a completed empirical country diagnosis. It has not been peer reviewed, legally certified, or validated against municipal primary records.*
