# Sverige — Vems signaler räknas?

## Forskningsagenda: information, uppmärksamhet, inflytande, kapacitet och rättigheter

**Följer upp:** *Sverige — Kompetensfällan* (reviderat arbetsutkast, etapp 1, 12 november 2026)  
**Status:** Etapp 2 v0.1.1 — **förpubliceringsutkast till forskningsagenda; juridisk sakkunniggranskning återstår**. Ingen egen studie av institutionell respons, kausal identifiering eller rättslig prövning av enskilda beslut har genomförts.  
**Kunskapsläge:** 12 november 2026  
**Avgränsning:** Utvalda svenska styrningsmekanismer och möjliga institutionella tester; inte en fullständig landanalys.

## Sammanfattning

Detta komplement avvisar inte huvudrapportens **kompetensfälla** eller **svenska eftersläpningsloop**. Det undersöker varför information kan nå en institution utan att nödvändigtvis leda till åtgärd, exempelvis på grund av rättsliga gränser, kapacitet, begränsad uppmärksamhet, incitament, åtgärders effektivitet eller skillnader i vilka anspråk som prioriteras. **Rapporten har inte mätt hur responsen skiljer sig åt beroende på avsändare eller grupp.**

Fyra frågor står i centrum: **Vem kan synliggöra en signal? Vem får tolka den? Vem kan genomdriva eller hindra beslut? Vem får nyttan och bär kostnaderna?** Kritisk teori riktar blicken mot institutionell och ekonomisk makt. Intersektionalitet undersöker hur olika livsvillkor samverkar och påverkar möjligheten att bli hörd. Dekolonial analys undersöker om kollektiva urfolksrättigheter och historiska konsekvenser erkänns, utan att på förhand fastslå en viss fördelning av rättslig beslutanderätt. Kritisk realism, systemtänkande, ekologiska begränsningar och reflexiv utvärdering hjälper oss att skilja hypoteser från belagda förhållanden.

Materialet ger en mer avgränsad slutsats än påståendet att svenska institutioner medvetet ignorerar missgynnade grupper. Riksrevisionen fann 2024 brister i de samlade insatserna och informationsutbytet kring barn som misstänks för grova brott. Lagstiftningen om informationsdelning utvidgades därefter 2025. Det gör ett generellt påstående om absoluta sekretesshinder ohållbart, samtidigt som frågan kvarstår om uppgifter används ändamålsenligt, proportionerligt och med jämlika konsekvenser [S01–S04].

SCB redovisade för 2024 en Gini-koefficient för ekonomisk standard på **0,314**, jämfört med **0,310** år 2023. Utan kapitalinkomster var den **0,246**, oförändrad 2022–2024. Andelen med låg ekonomisk standard var **13,1 procent**, något lägre än 2023 och den lägsta sedan 2007. Gini är ett mått på **inkomstfördelning**, inte ett direkt mått på förmögenhetsägande. Diskrimineringsombudsmannen (DO) tog emot **5 697 diskrimineringsanmälningar under 2025**, jämfört med **4 452 under 2024**. Skillnaden kan inte ensam tolkas som samma procentuella förändring i diskrimineringens faktiska omfattning [S05–S07].

Det samiska fallet är ett viktigt föreslaget test av skillnaden mellan **konsultation, samordning och beslutanderätt**. Sverige har en konsultationslag som från 2024 även omfattar kommuner och regioner i relevanta ärenden. FN:s kommitté mot rasdiskriminering har samtidigt påtalat begränsningar i lagens tillämpningsområde och kraven på fritt och informerat förhandssamtycke [S08–S11].

**Preliminär forskningsinriktning (inte ett fynd om Sverige):** ersätt inte diagnosen *återkopplingsbrist* med en lika svepande diagnos *dominans*. Håll isär **information/organisation, uppmärksamhet, befogenhet/kapacitet, selektivt inflytande, åtgärdseffekt och rättslig efterlevnad**, och pröva dem separat där studiedesignen medger det. Framtidskommuner bör pröva om ökad förmåga att se och agera förbättrar faktiska utfall utan mer övervakning, försvagade rättigheter eller ökad koncentration av inflytande.

## 1. Förhållandet till huvudrapporten

Huvudrapporten utvecklar tre centrala begrepp: **Dataarkipelagen** (brister i lärande mellan verksamheter), **Jantelagen/konsensusfiltret** (en hypotes om hur avvikande signaler behandlas) och **Kommunfällan** (en möjlig diskrepans mellan lokalt ansvar och användbart handlingsutrymme). Den föreslår **Framtidskommuner**: frivilliga kommunala försök med laglig kunskapsdelning, medborgarråd, anpassat handlingsutrymme och oberoende utvärdering. Dessa idéer är utgångspunkter för prövning, inte bevisade samband.

Den reviderade huvudrapporten beaktar redan integritet, riktad informationsdelning, rättigheter, oberoende utvärdering, kommunal utjämning och risker med felkonstruerade försök. Komplementet ska därför inte hävda att maktfrågor eller samisk konsultation är helt frånvarande. Flera passager i den reviderade huvudrapporten innehåller dock ännu oprövade eller starkt formulerade påståenden (bilaga C); huvudrapporten ändras inte tyst här. Frågan är i vilka fall dessa perspektiv **förändrar orsaksförklaringen, reformvalet eller framgångskriterierna**.

DeepSeeks tidigare analys behandlas som en **hypoteskälla**. Påståenden som att informationssilor gynnar förmögna grupper, att segregationsproblem främst beror på undertryckta minoritetssignaler eller att ett visst projekt utgör grön kolonialism kräver särskilt underlag om beslut, incitament, kausalitet och rättigheter. Retorisk skärpa är inte bevisstyrka.

## 2. Analytiska principer

### 2.1 Sex kompletterande perspektiv

- **Institutionell analys och systemtänkande:** kartlägg beslutsvägar, mandat, dataflöden, resurser, återkoppling, genomförande och lärande.
- **Kritisk teori och politisk ekonomi:** analysera dagordningsmakt, ägande, förhandlingsstyrka, resurskontroll och möjligheten att överföra kostnader på andra. Likställ inte strukturella fördelar med avsiktligt eller olagligt förtryck.
- **Intersektionalitet:** undersök hur exempelvis ekonomi, funktionsnedsättning, kön, ålder, geografi och migrationsrelaterade förhållanden samverkar. Dra aldrig slutsatser om individer från gruppmedelvärden.
- **Dekolonial analys och urfolksrätt:** undersök historiska och nuvarande markrelationer, jurisdiktion, deltagande och materiella rättigheter. Samiska rättighetsbärare kan inte ersättas av ett allmänt kommunalt medborgarurval.
- **Kritisk realism och ekologisk ekonomi:** testa andra generativa mekanismer, exempelvis lag, budget, förvaltningskapacitet, biogeofysiska gränser och kumulativ markpåverkan. Alla skillnader bör inte på förhand tolkas som maktutövning.
- **Andra ordningens/reflexiv analys:** redovisa vem som formulerat frågan, valt belägg, finansierat utvärdering, definierat framgång och kunnat påverka publiceringen.

Spiral Dynamics kan användas försiktigt som en tolkningsram för värderingskonflikter, men inte som en validerad metod för att nivåbestämma hela folkgrupper, partier, myndigheter eller kritiker. En stadieetikett förklarar inte en kausal mekanism.

### 2.2 Fem typer av utsagor

Skilj **(1) observation**, **(2) institutionell mekanism**, **(3) orsakspåstående**, **(4) rättslig bedömning** och **(5) normativ rekommendation**. En anmälningsökning är en observation; selektiv behandling kan vara en hypotes; ett rättighetsbrott kräver tillämplig norm och fallunderlag; förslag om omfördelning eller vetorätt är politiska och normativa ställningstaganden. En typ får inte tyst förvandlas till en annan.

### 2.3 Att operationalisera makt

Koda för varje beslutsprocess: **dagordningsmakt**, **kunskapsmakt** (vilka belägg som tillmäts vikt), **rättslig makt** (behörighet, talerätt, överklagande), **finansiell makt**, **organisatorisk makt**, **förhandlings- och utträdesmöjligheter** och **processuellt inflytande**. Identifiera vinnare och förlorare utifrån dokumenterade handlingsalternativ och utfall, inte utifrån antagna motiv.

### 2.4 Vad perspektiven tillför – och vad de inte kan avgöra

Varje perspektiv bör ge **en uttrycklig hypotes eller en redovisad normativ/rättslig gräns**. Intersektionalitet motiverar förhandsbestämda interaktionstester eller prövning av behov som administrativa kategorier saknar utrymme för; gruppskillnader blir inte därmed kausala. Kritisk teori motiverar granskning av *oro som aldrig anmäls*, av beslut om vilken statistik som produceras och av selektivt inflytande **symmetriskt för olika avsändare**. Dekolonial analys uppmärksammar kumulativa effekter på landskapsnivå och *kollektiva* rättighetsbärares ställning snarare än enbart individers enkätsvar. Institutionell teori och kritisk realism kräver alternativ via arbetsbelastning, resurser, uppmärksamhet och åtgärdseffekter. Ekologisk ekonomi tillför kumulativa materiella aspekter där ett konkret fall motiverar det. Reflexiv analys innebär att forskningens tillkomst, finansiärer och dagordningsmakt också granskas.

Regeringens **dokumenterade beslut om statistik** den 26 september 2025 utökade underlaget om hushållens skulder medan ansvarig minister avvisade ytterligare tillgångsstatistik och hänvisade till möjligheten till förmögenhetsskatt [S28]. Det är ett identifierbart beslut att granska avseende dagordningsmakt, men inte i sig bevis för otillbörligt inflytande. Uttalandet **anförde inte integritet** som skäl; integritet är en separat alternativ hypotes att undersöka.

## 3. Föreslaget prövningsfall A — Informationsutbyte, organisatoriska hinder och respons

*Dataarkipelagen* kan beskriva fragmenterat lärande, men får inte likställas med ett allmänt förbud mot uppgiftsdelning. Riksrevisionen fann 2024 variationer i informationsutbytets kvalitet, innehåll och frekvens i vissa insatser för barn som misstänks för grova brott. Granskningen beskriver bland annat rutiner, osäkerhet om regler och personalomsättning [S01]. Den belägger inte en rikstäckande mekanism för försenad anpassning.

Två reformer från 2025 måste hållas isär:

1. **Lag (2025:170), från 1 april 2025**, inför specificerade uppgiftsskyldigheter gentemot sju brottsbekämpande myndigheter. §§5–7 omfattar namngivna statliga myndigheter, kommuner och regioner samt rektorer inom skolväsendet; §8 undantar flera skyddade uppgiftskategorier, däribland viss statistik-, hälso- och sjukvårds- och socialtjänstsekretess [S20]. Det är inte ett allmänt stöd för delning från skolan till socialtjänsten för gemensamt lärande.
2. **10 kap. 15 a § offentlighets- och sekretesslagen, från 1 december 2025**, medger under angivna förutsättningar utlämnande mellan myndigheter för fem kontrolländamål: förebygga/upptäcka brottslig verksamhet; utreda brott; förebygga felaktiga beslut om förmåner, stöd, skatt eller avgifter; upptäcka eller utreda sådana fel; samt förebygga, upptäcka eller utreda fusk och regelöverträdelser. Intresseavvägning krävs och undantag finns, bland annat för statistiksekretess och viss hälso- och sjukvårdssekretess [S21]. Bestämmelsen är **inte en generell rätt att samköra register för lärande, tjänsteutveckling eller forskning**. Ett tillåtet utlämnande ger inte automatiskt den mottagande aktören rättslig grund för fortsatt behandling.

Den lagändring som riksdagen antog i maj 2026 ska från **1 januari 2027** jämställa berörda enskilda utbildningshuvudmän med myndigheter vid tillämpning av offentlighets- och sekretesslagen. Enligt regeringens Skolverksuppdrag medför detta också att 15 a § kan tillämpas *av och i förhållande till* dessa huvudmän, men bara för paragrafens ändamål, inte för obegränsad forskningssamkörning [S22]. Dir. 2026:104 är ett pågående utredningsuppdrag, inte gällande ny lag [S23]. Kontrollera datum och räckvidd före publicering.

**Möjliga mekanismer (ännu oprövade här):** rättsligt hinder för ett preciserat ändamål (H-A1a kontroll på ärendenivå, H-A1b forskning/lärande); organisatoriska eller tekniska dröjsmål (H-A2); information i tid men bristande beslutsbefogenhet eller respons (H-A3); åtgärd som genomförs men inte fungerar (H-A5); samt skyddsgränser mot otillbörligt utlämnande, kartläggning av enskilda eller skadat förtroende (H-A4). IMY avstyrkte i november 2025 ett **annat föreslaget** stöd för utlämnande på eget initiativ. Det upphävde inte 15 a § [S12]. Både skador av felaktigt utlämnande och skador av omotiverad underlåtenhet att dela information behöver följas.

**Prövning:** följ tidsatta anmälningar, tillämplig rättslig delningsväg, beslut och genomförande var för sig. Ett beslut att inte ingripa kan vara välmotiverat; dröjsmål är inte i sig belägg för fel. En före/efter-jämförelse kring 2025 påverkas av andra samtidiga reformer och införandefördröjningar. Ingen kausaleffekt påstås.

## 4. Föreslaget prövningsfall B — Vilkas behov blir synliga?

Påståendet att ett svenskt ”konsensusfilter” systematiskt missgynnar vissa grupper behöver belägg. Det kan inte härledas enbart ur en nationell kulturmetafor. Det finns däremot goda skäl att granska vad samlade genomsnitt döljer och vilka behov offentliga system har lättast att registrera och tillgodose.

SCB redovisar för 2024 **Gini 0,314**, något över 2023 (**0,310**), medan måttet utan kapitalinkomster var **0,246** och oförändrat 2022–2024. Andelen med låg ekonomisk standard var **13,1 procent**, något lägre än 2023 och lägst sedan 2007 [S05, S06]. Måtten beskriver inte förmögenhet eller institutionell respons. SCB redovisar också *sammanräknad förvärvsinkomst* (som **inkluderar pensioner och skattepliktiga transfereringar**) efter kön och födelseregion; gruppskillnader behöver analyseras med hänsyn till exempelvis ålder, vistelsetid, utbildning och sysselsättning [S13].

DO mottog **5 697 diskrimineringsanmälningar** 2025, cirka 28 procent fler än 2024, och totalt **6 831 anmälningar i alla kategorier**. DO betonar att anmälningsstatistik inte ger hela bilden av diskriminering. Anmälningsbenägenhet och myndighetspraxis är möjliga förklaringar att undersöka; vi tillskriver inte DO ett specifikt kausalt påstående om årets ökning [S07]. Boverket beskriver boendesegregation som ett relationellt mönster där strukturella villkor (inklusive direkt och indirekt diskriminering) och individuella val samverkar; det är svårt att särskilja bostadsområdets betydelse från andra orsaker [S14].

Intersektionell analys bör därför börja i **en konkret tjänste- eller beslutsprocess**, inte i en lång förteckning identitetskategorier. Ett tänkbart test är: får familjer med jämförbara behov efter upprepad skolfrånvaro likvärdig tillgång till uppföljning och stöd? Skiljer sig tider, kvalitet och utfall när ekonomi, funktionsnedsättning, geografi, ålder och relevanta migrationsrelaterade förhållanden samverkar? Kan eventuella mönster förklaras med språklig tillgänglighet, digitala hinder, personalomsättning eller diskretionära bedömningar?

**Mätdisciplin:** förregistrera kategoriernas syfte före granskning av utfall; beakta berördas kunskap samtidigt som utvärderingens oberoende bevaras; använd frivilligt och rättsligt förankrat datainsamlande för känsliga uppgifter; skydda små grupper mot identifiering; redovisa bortfall och nämnare; analysera interaktioner bara med tillräcklig statistisk styrka; behandla inte utrikes födda som en enhetlig grupp. En påvisad skillnad är inte automatiskt ett belägg för dess orsak.

**Motbevis:** likvärdig tillgång och välmotiverade beslut efter relevant justering för behov och förutsättningar försvagar hypotesen om ett diskriminerande filter i den avgränsade processen, utan att utesluta andra mekanismer.

## 5. Föreslaget prövningsfall C — Samisk konsultation, markrättigheter och beslutanderätt

Den nordliga industriomställningen kräver samordning, men **bättre samordning avgör inte i sig rättigheternas innehåll eller vem som har laglig beslutanderätt**. Här måste kommunal planering, statliga koncessionsbeslut, miljötillstånd, kollektiva rättigheter och politiska avvägningar hållas åtskilda.

**Konsultationslagen.** Enligt lag (2022:66) bevarar 1 § andra samrådsskyldigheter. 2 § ålägger angivna offentliga aktörer, däribland kommuner och regioner från mars 2024, konsultation före beslut av särskild betydelse för samerna. 3 § undantar domstolsliknande organ; 4–5 §§ innehåller ämnes- och ärendebegränsningar. För plan- och byggärenden gäller konsultationsskyldigheten antagande eller ändring av angivna planer, inte alla beslut om markanvändning. En begäran från samisk företrädare kan enligt 6 § utlösa konsultation i ett ärende av särskild betydelse; enligt 11 § kan processen avslutas när enighet eller samtycke bedöms ouppnåeligt. Lagen ger därmed **inte en allmän vetorätt** och avgör inte alla eventuella rättsmedel enligt annan lag [S08, S09]. Första steget i en ärendegranskning är att identifiera beslutsorganet och om lagen alls var tillämplig.

**Skilda rättigheter och rättskällor.** I **Girjasdomen** (HD T 853-18, 2020) slog Högsta domstolen fast att Girjas sameby gentemot staten har ensamrätt **att upplåta småviltsjakt och fiske inom ett bestämt område ovanför odlingsgränsen**, på grund av urminnes hävd. Domen fastställer inte allmän vetorätt vid gruvprojekt eller motsvarande rätt för varje sameby [S24]. FN:s rasdiskrimineringskommitté antog 2020 ett **icke bindande yttrande** i *Ågren m.fl. mot Sverige* med konstaterade konventionskränkningar avseende Rönnbäckenärendet. Kommitténs slutsatser 2025 kritiserade luckor i konsultationsordningen och efterlyste starkare skydd för fritt och informerat förhandssamtycke (FPIC) [S25, S11]. Betydelsen i svensk rätt och Sveriges uppföljning kräver sakkunniggranskning. Sverige har inte ratificerat ILO 169, vilket inte betyder att konventionens innehåll saknar möjlig indirekt rättslig relevans.

**Utredning, inte beslutad lag.** Sanningskommissionens *Markerna berättar och minns* (SOU 2026:58) uppmanar bland annat till kumulativa konsekvensbedömningar på landskapsnivå (punkt 35) och lagreglering av FPIC (punkt 38). Det är rekommendationer, inte redan gällande rätt [S26]. En rapport från Amnesty och Samerådet använder uttrycket *grön kolonialism* som en argumenterande människorättstolkning, inte som domstolsavgörande för ett visst tillstånd [S15]. Sametinget, samebyar, samiska organisationer och individer har inte samma roll eller samma rättigheter i varje fråga.

**Dokumentgranskning:** välj flera ärenden av **olika beslutstyper**, både inom och utanför konsultationslagens tillämpningsområde. Registrera vem som beslutat, begäran om konsultation, tidpunkter, kumulativa konsekvenser, invändningar, ändrade villkor, motiveringar och rättsmedel. Inkludera såväl lyckade som omtvistade ärenden. Dra inga slutsatser om enskilda projekts laglighet eller samtyckeskrav utan sakkunnig rättslig prövning. Ett medborgarråd eller kommunalt försök ersätter inte laglig konsultation eller rättsligt skydd.

## 6. Föreslaget prövningsfall D — Lokal makt, finansiering och risken för lokal maktkoncentration

Kommunfällan är värd att testa. Samtidigt saknar svenska kommuner inte omfördelande stöd. Det **kommunalekonomiska utjämningssystemet** syftar till att mildra skillnader i skattekraft och strukturella kostnader. De faktiska effekterna måste analyseras innan lokal skattekraft används som direkt mått på handlingsförmåga. De två tidigare hänvisade SKR-sidorna [S16–S17] har **inte kunnat bekräftas vid angiven källa** och används därför inte för något nytt sifferpåstående.

**Centralisering är inte alltid dominans, och decentralisering är inte alltid frigörelse.** Nationella normer kan skydda invånares rättigheter mot lokal diskriminering, medan alltför detaljerade villkor kan förhindra lokalt lärande. Utökad lokal makt kan ge eftersatta grupper inflytande eller befästa lokala eliter. Varje befogenhetsförskjutning måste därför precisera vem som får ökat handlingsutrymme, vem som kan överklaga, vilka nationella minimikrav som kvarstår och hur kostnaderna fördelas.

Jämför kommuner med liknande behov men olika organisatoriska villkor eller ekonomiska förutsättningar. Skilj nationella restriktioner från lokala prioriteringar. Varken kommunstorlek eller skattekraft räcker som generell orsaksförklaring.

## 7. Föreslaget prövningsfall E — Medborgarråd och politisk respons

Huvudrapporten föreslår återkommande **medborgarråd**. Sverige har redan försök att lära av: det **forskningsledda** klimatmedborgarrådet 2024 valde **60 deltagare** efter inbjudningar och frivilliga svar; **49 deltog hela vägen** och rådet tog fram **22 förslag** [S18]. Det var inte ett statligt beställt nationellt råd. Detta visar genomförd deliberation, men inte i sig långvarig politisk påverkan [S18].

OECD:s utvärderingsram skiljer på **processdesign**, **upplevelsen och kvaliteten i samtalet** samt **vägarna från rekommendation till faktisk påverkan**. Oberoende utvärdering, tillgänglighet, mångsidig evidens och en offentlig motiverad respons är centrala [S19]. Antalet möten eller rekommendationer räcker inte som framgångsmått.

Framtidskommunerna bör publicera vem som sätter dagordningen, finansierar rådet, utformar urvalet, uteblir från deltagande, leder samtalen, väljer sakkunniga och svarar på rekommendationerna. Medborgarråd får inte ersätta fullmäktiges ansvar, domstolsprövning eller urfolks särskilda rättsliga ställning. Råd med rådgivande funktion är inte alltid dekorativa: också icke bindande rekommendationer kan få verklig betydelse om myndigheterna svarar öppet och följer upp genomförandet. Bindande beslutanderätt kräver ytterligare demokratiska och juridiska skäl.

## 8. Möjliga förklaringar och ett avgränsat forskningsupplägg

Att information kräver någon som har befogenhet att handla är nära nog en truism. Den empiriska frågan är om **tidsförlopp, beslut och utfall skiljer sig åt på förutsagda sätt** när informationskvalitet, arbetsbelastning, resurser, inflytande och välmotiverat avstående hålls isär. Nedanstående är hypoteser, inte belagda allmänna förklaringar av Sverige, och det befintliga materialet kan ännu inte särskilja dem fullt ut.

| Förklaring | Möjligt observationsmönster | Central oklarhet / jämförelse |
|---|---|---|
| **Information/organisation** | Tidsatta rapporter kommer sent eller saknar väsentliga uppgifter | Är uppgifterna relevanta, möjliga att dela och nödvändiga? |
| **Dagordningsuppmärksamhet** | Hög ärendemängd eller vakanser inom en enhet förlänger handläggningstid för alla avsändare | Arbetsbelastningen kan spegla tidigare politiska resursval; pröva om möjligt externa belastningsförändringar |
| **Befogenhet/kapacitet** | Dokumenterade mandat- eller personalbegränsningar inskränker möjliga åtgärder | Kapaciteten är delvis politiskt bestämd uppströms |
| **Selektivt inflytande** | Vid liknande allvar, rapportkvalitet och belastning skiljer sig responsen efter förhandskodad avsändare eller kostnadsbärare | Informationskvalitet och uppmärksamhet kan snedvrida sambandet; restskillnad är inte bevis för partiskhet |
| **Åtgärdseffekt** | Åtgärden beslutas och genomförs, men avsett utfall uteblir | Insatser fördelas inte slumpmässigt och svagt utfall är inte automatiskt styrningsfel |
| **Kompetensfällan (huvudrapporten)** | Tidigare hög prestation förutsäger längre upptäcktsfördröjning, kontrollerat för problemtyp och belastning | **Kan inte testas i ett litet kommunförsök**; kräver många enheter och oberoende tidpunkt för problemets uppkomst |

**Rättslig efterlevnad är inte en ytterligare kausalförklaring** utan prövas separat mot tillämpliga normer och beslutanderätt. Normativa avvägningar är inte skattade effekter. Begränsad uppmärksamhet är en viktig och enklare konkurrent men har inte visats vinna empiriskt i Sverige. Uppmärksamhet och inflytande kan samverka, eftersom inflytelserika aktörer kan påverka dagordningen.

### 8.1 Retrospektiva policyfall och registrerad kohortstudie

Markanvändningsfallen, kommunfinansieringen och rikspolitiska exempel är **avsiktligt valda efter kända frågor och konflikter**. De är inte resultatblint förregistrerade urval. Lägg till jämförelsefall där processerna fungerat och använd processpårning beskrivande. En verklig **förregistrering** sker *före* uttag av identifierbara ärendedata för en särskilt definierad studie.

Ett genomförbart kandidatupplägg är en **retrospektiv kohort av orosanmälningar om barn till kommunal socialtjänst**, där protokollet registreras *före datauttaget*. Det följande är en genomförbarhetsskiss, inte ett godkänt eller utfört forskningsprojekt:

- Två till fyra kommuner, en fixerad 24-månadersperiod och stickprovsstorlek vald genom styrkeberäkning (inte ett på förhand antaget antal ärenden).
- Enhet: en daterad orosanmälan, grupperad per barn och kommun. Utfall: dokumenterat beslut om utredning och tid till beslut. Ny orosanmälan för samma barn inom tolv månader är en **ofullkomlig indikator på förnyad oro**, inte bevis för skada av tidigare beslut.
- Förklaringsvariabler: i förväg bestämd avsändarkategori; oberoende kodare bedömer allvar och fullständighet från enbart originalanmälan utan att se beslut/utfall; veckovis ärendemängd och vakanser; tidigare anmälningar, ålder och relevant kontext. Överensstämmelse mellan kodare bedöms mot förutbestämd gräns.
- Komplettera med enkät till personal om oro som inte anmälts. En registerstudie saknar per definition helt osända signaler. Skilj utebliven respons från motiverat avstående, genomförd insats och verkningslös insats.
- Förutsättningar: sekretess- och åtkomstbedömning av varje kommun, etikprövning där det krävs, säker informationshantering, sannolikt en universitetsanknuten forskningspartner, samt kontroll av relevanta tidsfrister enligt **socialtjänstlagen (2025:400)**. Inget av detta är ännu klart.
- Avsluta som ogenomförbart om laglig åtkomst saknas, veckodata för belastning inte finns eller oberoende kodning inte når registrerad kvalitetsgräns. Små undergrupper i ett par frivilliga kommuner kan **inte** ge kausala nationella tester av intersektionella effekter.

Upplägget kan delvis pröva organisation, belastning och observerade avsändarskillnader. Det **kan inte** fastställa generell svensk selektiv respons eller testa om tidigare framgång i sig skapat blindhet.

### 8.2 Preliminära skydd och utvärderingsmått för Framtidskommuner

Ett litet försök behöver en **begränsad kärnuppsättning mått**: (i) beslutstid och dokumenterad beslutskvalitet, (ii) genomförande och ett relevant sakutfall, (iii) otillåtet utlämnande *och* möjlig skada av obefogad underlåtenhet att dela, (iv) rättslig efterlevnad och deltagarsäkerhet, (v) öppet urval och dagordningsmakt. Ny orosanmälan inom tolv månader är en *bristfällig* indikator på risk efter utebliven insats, inte ett uppmätt skadeutfall.

Redovisa vem som formulerar problemen och styr utvärderingen, även tjänstemän, utförare, finansiärer, rättighetsbärare, yrkesgrupper, majoritets- och minoritetsinvånare och organiserade intressegrupper. Jämförelser mellan undergrupper i små försök är **beskrivande övervakning**, inte statistiskt säkra kausala intersektionstester. Känsliga personuppgifter ska samlas in enbart efter särskild nödvändighets- och laglighetsbedömning; skydda små grupper mot identifiering.

Nya gransknings- och överklagandeinstanser kan fördröja beslut. Specificera vem som får påkalla prövning, på vilka grunder, inom vilken tidsfrist och vilka rättsmedel som redan finns, innan nya vetopunkter införs. Publicera kriterier för urval och avslag samt stopp- och reparationsregler vid otillåtet utlämnande eller rättighetskränkning. Försöksregler får inte sätta konsultationsplikter eller dataskydd ur spel. Principen om *minsta tillräckliga samordning* är en designidé, inte bevis för att en viss fördelning av befogenhet eller information är tillräcklig.

## 9. Möjliga konsekvenser för huvudrapporten

| Möjligt fynd | Konsekvens för Kompetensfällan | Konsekvens för Framtidskommuner |
|---|---|---|
| Informations- och organisationsbrister dominerar | Stärker den ursprungliga diagnosen | Fokus på laglig samverkan, bemanning och fungerande lärprocesser |
| Informationen fanns redan men prioriteringar blockerade åtgärden | Återkopplingsbrist är delvis ett symtom | Öka möjligheterna till invändning, motiveringar och oberoende prövning |
| Ojämlik tillgång och röst | Sensing måste omfatta vem som definierar problemet | Tillgänglighet, samdesign, representationskontroll och fördelningsmått |
| Urfolks rättigheter begränsar föreslagen samordning | Rättigheterna blir en icke-utbytbar restriktion | Inga undantag som urholkar rättigheter; särskild konsultation och prövning |
| Integritetsskydd eller nationella normer förebygger skada | Vissa gränser är skydd, inte systemfel | Behåll gränser; pröva mindre ingripande alternativ |
| Lokal autonomi riskerar lokal elitdominans | Polycentricitet är inte tillräckligt i sig | Skydd mot maktkoncentration, överklagande, extern utvärdering och nationella rättighetsgolv |

## 10. Forskningsstatus och publiceringsgräns

Huvudrapportens centrala bidrag är ett förslag till **anpassningsbar styrning**. Komplementet undersöker om anpassningen kan bli selektiv, hindras av legitima skydd eller fångas av vissa intressen. Den centrala frågan är inte *”är detta ett ingenjörsproblem eller en maktordning?”* Båda kan förekomma. Forskningsuppgiften är att avgöra vilken mekanism som är begränsande i vilket beslut.

De granskade källorna visar att frågorna är **värda att undersöka**. De mäter **inte** vilka avsändares signaler som får respons, belägger inte huvudrapportens kausala kompetensfälla och ger inga rättsliga slutsatser om ej undersökta tillstånd. Ingen fullständig genomgång av enskilda kommunärenden har gjorts, inget matchat kommundataset har analyserats, inga oberoende intervjuer har genomförts och ingen uttömmande juridisk prövning av ett visst gruvtillstånd eller undantag har gjorts. Fallavsnitten är **forskningsspår med belagda utgångsfakta**, inte avslutade fallstudier.

**Preliminärt beslut:** v0.1.1 är ett **förpubliceringsutkast utan avslutad juridisk sakkunniggranskning**. Bevara huvudrapporten som ett separat diagnostiskt arbetsdokument, fördjupa detta komplement med fallbaserad verifiering och revidera huvudrapportens slutsatser när det finns nytt underlag som faktiskt motiverar det. En senare syntes bör tydligt skilja rättsligt bindande gränser, belagda mekanismer, prövbara hypoteser och politiska värderingsval.

### Kvarstående frågor (redovisade, inte avslutade)

Ingen svensk förvaltningsrättslig eller samerättslig expert har granskat rättsläget; inga kommunala primärakter har hämtats in; de retrospektiva fallspåren valdes med kända konflikter; hypoteserna skiljs ännu inte fullt ut åt; små försök ger inga nationella undergruppseffekter; vissa källhänvisningar är obekräftade. Även huvudrapporten innehåller avsnitt som behöver prövas på nytt (bilaga C). Innan publicering behövs juridisk granskning av bland annat Girjasdomens diskussion om ILO 169, konsultationslagens räckvidd och rättsmedel, samt varje konkret planerat dataflöde.

## Bilaga A — Regler för evidens och attribuering

- **Verifierad källuppgift:** ett avgränsat påstående direkt belagt i offentlig rapport, lagtext, statistik eller identifierbar forskning.
- **Attribuerad bedömning:** exempelvis Amnestys beteckning på exploateringsmönster; inte samma sak som en domstols dom.
- **Hypotes:** möjlig förklaringsmekanism som redovisar motförklaringar och tänkbara motbevis.
- **Normativt designval:** tydliggör värden, rättigheter och avvägningar. Effektivisering och frigörelse är inte logiska motsatser; systemisk optimering kan omfatta deltagande, jämlikhet och icke-dominans som mål och restriktioner.
- **Okänt:** när handlingar, jämförbara data eller berördas egna uppgifter saknas hålls slutsatsen öppen.

## Bilaga B — Källregister

**Källstatus per 12 november 2026:** Officiella lag-, domstolsöversikts-, SCB- och riksdagssidor har kontrollerats för vissa avgränsade uppgifter. Sakkunnig juridisk granskning återstår. S10, kungörelsedatumet för S15 samt S16 och S17 har inte verifierats på angiven sida. En länk är inte i sig stöd för rapportens tolkning.

[S01] Riksrevisionen (2024), *Otillräckliga insatser när barn misstänks för grova brott* (RiR 2024:9). https://www.riksrevisionen.se/granskningar/granskningsrapporter/2024/otillrackliga-insatser-nar-barn-misstanks-for-grova-brott.html  
[S02] Regeringen (2025), *Ökat informationsutbyte mellan myndigheter*, prop. 2024/25:180. https://www.regeringen.se/rattsliga-dokument/proposition/2025/05/prop.-202425180  
[S03] Regeringen (1 december 2025), information om ny sekretessbrytande bestämmelse. https://www.regeringen.se/pressmeddelanden/2025/12/nu-rivs-sekretessen-mellan-alla-myndigheter-i-sverige/  
[S04] Regeringen (2026), Skolverkets uppdrag om informationsutbyte. https://www.regeringen.se/pressmeddelanden/2026/05/skolverket-far-uppdrag-att-stodja-skolors-tillampning-av-nya-sekretessbrytande-regler/  
[S05] SCB (2026), *Högre ekonomisk standard – men inkomstskillnaderna ökar* (referensår 2024). https://www.scb.se/pressmeddelande/hogre-ekonomisk-standard--men-inkomstskillnaderna-okar/  
[S06] SCB, *Inkomster och skatter* (referensår 2024). https://www.scb.se/he0110/  
[S07] DO (2026), *Statistik över anmälningar till DO 2016–2025*. https://www.do.se/rattsfall-beslut-lagar-stodmaterial/publikationer/2026/statistik-over-anmalningar-till-do-2016-2025  
[S08] Sveriges riksdag, lag (2022:66), *Lag om konsultation i frågor som rör det samiska folket*. https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/lag-202266-om-konsultation-i-fragor-som-ror-det_sfs-2022-66/  
[S09] Boverket, *Konsultation i ärenden som rör samiska frågor*. https://www.boverket.se/sv/PBL-kunskapsbanken/detaljplan/detaljplaneprocessen/samiska-fragor/  
[S10] Sametinget (uppdateringsdatum obekräftat), *Konsultation med Sametinget*. https://sametinget.se/konsultationsordning  
[S11] FN:s kommitté mot rasdiskriminering (18 december 2025), *Concluding observations on Sweden*, CERD/C/SWE/CO/24-25, punkterna 38–39. https://docstore.ohchr.org/SelfServices/FilesHandler.ashx?enc=VZ8yj3OGKOf0RJCS3WoPnE7T2oUZ8StMZIJo0NpHO49VPKwtbwJcz8EBobrL%2FfcdXzbf1oWhXrZc9iDxavCOUIOSGx%2FsD2bxL2jqc%2B2b%2BA8%3D  
[S12] IMY (3 november 2025), remissyttrande över SOU 2025:45, avseende **ytterligare föreslagna** regler. https://www.imy.se/globalassets/dokument/remissvar/2025/slutbetankandet-okat-informationsutbyte-mellan-myndigheter--nagra-anslutande-fragor.pdf  
[S13] SCB (2026), *Inkomster för personer i Sverige* (2024 års uppgifter efter födelseregion och kön). https://www.scb.se/hitta-statistik/sverige-i-siffror/utbildning-jobb-och-pengar/inkomster-for-personer/  
[S14] Boverket (2026), *Om boendesegregation*. https://www.boverket.se/sv/samhallsplanering/livsvillkor-och-utanforskap/kunskapsstod/om-boendesegregation/  
[S15] Amnesty Sápmi / Amnesty och Samerådet (kungörelsedatum obekräftat), information om *Just Transition or Green Colonialism?*. https://amnestysapmi.se/ny_amnestysapport/  
[S16] SKR (2026), *Utjämningssystem samt frågor och svar*. https://skr.se/ekonomiochbudgetplanering/utjamningssystem.8275.html  
[S17] SKR (2026), kommunernas ekonomi och skilda förutsättningar. https://skr.se/pressrum/aktuellt/nyhetsarkiv/ljusareiekonominmenbehovenattstallaomarstora.10818.html  
[S18] Stockholms universitet (26 november 2024), erfarenheter från nationellt klimatmedborgarråd. https://www.su.se/nyheter/nyhetsartiklar/2024-11-26-rapport-om-lardomar-fran-medborgarrad-om-klimatet  
[S19] OECD (2021), *Evaluation Guidelines for Representative Deliberative Processes*. https://www.oecd.org/en/publications/evaluation-guidelines-for-representative-deliberative-processes_10ccbfcb-en.html

**Källbegränsningar:** regeringens kommunikation återger också regeringens motiv; intresseorganisationer kan föra fram både dokumentation och normativa bedömningar; sammanfattande statistik ger inte kausal identifiering; juridiska slutsatser måste knytas till faktiska ärenden. Detta är ett kuraterat startregister, inte en systematisk kunskapsöversikt.

[S20] Sveriges riksdag, lag (2025:170), 1–8 §§. https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/lag-2025170-om-skyldighet-att-lamna-uppgifter_sfs-2025-170/  
[S21] Sveriges riksdag, offentlighets- och sekretesslag (2009:400), 10 kap. 15 a § enligt SFS 2025:934. https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/offentlighets-och-sekretesslag-2009400_sfs-2009-400/  
[S22] Riksdagen, 2025/26:UbU20 antaget i maj 2026 (regler från 1 januari 2027); regeringens Skolverksuppdrag U2026/00991 om följden för 15 a §. https://www.riksdagen.se/sv/dokument-och-lagar/dokument/betankande/offentlighetsprincipen-med-lattnadsregler-for_hd01ubu20/ ; https://www.regeringen.se/regeringsuppdrag/2026/05/uppdrag-till-statens-skolverk-om-stod-i-tillampningen-av-nya-regler-om-informationsutbyte/  
[S23] Regeringen, Dir. 2026:104, 9 september 2026, *Avskaffad sekretess mellan myndigheter...* https://www.regeringen.se/rattsliga-dokument/kommittedirektiv/2026/09/dir.-2026104  
[S24] Högsta domstolen, Girjas, T 853-18, 23 januari 2020, domstolens referat. https://www.domstol.se/hogsta-domstolen/avgoranden2/2020/47294/  
[S25] FN:s CERD, *Ågren m.fl. mot Sverige*, CERD/C/102/D/54/2013, yttrande antaget 18 november 2020 (FN:s register). https://juris.ohchr.org/casedetails/3021/en-US  
[S26] Sanningskommissionen för det samiska folket, *Markerna berättar och minns*, SOU 2026:58, sammanfattningens punkter 35 och 38. https://www.riksdagen.se/sv/dokument-och-lagar/dokument/statens-offentliga-utredningar/markerna-berattar-och-minns_heb358/html/  
[S27] SCB, *Inkomster och skatter 2024*, tidsserie för låg ekonomisk standard. https://www.scb.se/hitta-statistik/statistik-efter-amne/hushallens-ekonomi/hushallens-inkomster-tillgangar-och-skulder/inkomster-och-skatter/pong/statistiknyhet/inkomster-och-skatter-2024/  
[S28] Regeringen, 26 september 2025, beslut och uttalat skäl om skuld- men inte ytterligare tillgångsstatistik. https://www.regeringen.se/pressmeddelanden/2025/09/scb-ska-oka-tillgangen-till-statistik-om-hushallens-skulder/  

## Bilaga C — Koppling till etapp 1

**Detta är en hänvisningsmatris, inte en ändring av den bevarade huvudrapporten.** Utöver tabellen behöver huvudrapportens §2.3 ("demografisk ersättning" eller motsvarande), §4.2 (påstått dokumenterat åsidosatta varningar), bilaga A.2 (utvecklingsstadier), bilaga C.3 (påstått matematiskt bevis), bilaga D.2 (integritetsavvägning) och §§5.2/5.4 ("trojansk häst", "politiskt skydd") granskas separat. Antalet framtidskommuner varierar dessutom mellan avsnitt. Ingen av dessa passager ändras tyst här.


| Ämne i huvudrapporten | Avsnitt här | Status |
|---|---|---|
| §2.2 Dataarkipelagen | §§3, 8 | Test av rättsläge, tillämpning, behov och integritet |
| §2.3 Konsensusfiltret | §4 | Hypotes; undvik att göra nationell kultur till en universalförklaring |
| §2.4 Kommunfällan | §6 | Beakta utjämning och lokal maktkoncentration |
| §3.2 Strukturerad oenighet | §7 | Pröva dagordning, representativitet och genomslag |
| §3.4 Levande försöksmiljöer (nordlig industriomställning) | §5 | Samisk konsultation och rättigheter oberoende av samordningen |
| §4 Det politiska immunsystemet | §§2, 8 | Vinnare och undertryckta signaler kräver belägg |
| §§5–6 Framtidskommuner | §§7–9 | Rättighets-, fördelnings-, integritets- och utvärderingsvillkor |

## Bilaga D — Tillkomst och språklig överensstämmelse

Användaren formulerade forskningsfrågorna och tillhandahöll underlaget till den ursprungliga svenska styrningsrapporten samt DeepSeeks kritik. ChatGPT medverkade i författandet av v0.1; Claude Fable genomförde oberoende adversarial granskning i två omgångar; ChatGPT sammanställde en avstämning och föreliggande redaktionella utkast. Författaren har **inte** uppgett att en egen aktstudie eller mänsklig juridisk granskning har genomförts. Källkontroller med AI kan innehålla fel; ursprungliga rättskällor och statistikpublikationer har företräde. Ingen av språkversionerna ges generell tolkningsföreträde: svenska rättstermer kontrolleras mot svensk rätt och övriga påståenden mot sina respektive källor. De sex viktigaste betydelseskillnaderna från Round 1 (FPIC, befogenhet/inflytande, DO-förbehåll, aktgranskningens omfattning, falsifierbarhet och källtillskrivning) har hanterats parallellt.

**Öppen juridisk publiceringsspärr:** svensk sakkunnig bör kontrollera konsultationslagen 1–7 och 11–12 §§, Girjasdomen inklusive ILO 169, CERD:s yttrande och rättsliga vikt, informationsutbytesreglerna från 2025 samt skolreglerna från 2027. Texten får inte beskrivas som juridiskt slutgranskad.

*Detta är en forskningsagenda, inte en färdig kausal landdiagnos. Den har inte vetenskapligt sakkunniggranskats, juridiskt kvalitetssäkrats eller validerats genom kommunala primärakter.*
