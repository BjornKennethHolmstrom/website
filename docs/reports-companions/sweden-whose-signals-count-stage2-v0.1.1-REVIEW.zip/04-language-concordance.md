# English–Swedish semantic concordance (Round 1 six priority issues)

| Material distinction | English v0.1.1 | Swedish v0.1.1 | Governing source / rule |
|---|---|---|---|
| FPIC | Do not imply a universal project-specific statutory veto | Påstå inte en allmän lagstadgad vetorätt; håll isär konsultation, FPIC och materiell rätt | Consultation Act §§1–7, 11; CERD and specialist review |
| Sámi authority | Specific decision authority and legally recognized rights, not a blanket coequal sovereignty | Konkret beslutanderätt och materiella rättigheter, inte automatiskt generell jämbördig suveränitet | Swedish law, Girjas, CERD |
| Ombudsman caveat | Complaint figures do not give complete prevalence; alternative explanations are hypotheses | Anmälningsstatistik visar inte hela omfattningen; alternativ förblir hypoteser | DO 2026 publication |
| Primary-file review | No municipal primary-file review was completed | Ingen kommunal primäraktgranskning har genomförts | Research provenance |
| Parent thesis disconfirmation | Parent country-level claim remains untested and individual cases may weaken it | Kompetensfällan kan försvagas i enskilda fall och prövas inte som landstes här | Candidate hypothesis table |
| Attributed assessments | Amnesty's framing is not a binding finding; government asset-data rationale is quoted as a statement | Amnesty som attribuerad bedömning; regeringens motiv återges men integritet är en egen hypotes | Advocacy publication and official release |

No language has blanket interpretive priority; original Swedish legal terms and each primary source control the factual meaning. This is an editorial concordance, not a certified bilingual legal review.
