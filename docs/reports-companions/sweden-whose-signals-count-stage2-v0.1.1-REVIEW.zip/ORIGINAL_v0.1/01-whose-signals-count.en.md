# Sweden — Whose Signals Count?

## Power, Exclusion, and the Limits of Feedback Reform

**Companion to:** *Sweden — The Competence Trap* (Stage 1 revised working draft, 12 November 2026)  
**Status:** Stage 2 research working draft v0.1 — evidence-informed hypotheses, not a validated causal study  
**Cut-off:** 12 November 2026  
**Scope:** Sweden; selected governance mechanisms and institutional-design tests. This is not a comprehensive country assessment.

## Executive summary

The companion does not reject the original report's *Competence Trap* and *Swedish Drift Loop*. It investigates a condition that the first report cannot resolve through feedback engineering alone: information becomes politically consequential only when someone has the authority, resources, incentives, and legitimacy to act on it. A system can improve its ability to sense problems while preserving asymmetries in whose evidence, interests, and rights shape the response.

Four questions follow. **Who can make a signal visible? Who interprets it? Who can compel or block action? Who bears the gains and costs?** Critical theory directs attention to institutional and economic power; intersectionality probes unequal exposure and differential responsiveness; decolonial analysis tests whether governance treats Indigenous rights as coequal authority or merely as another interest to coordinate. Critical realism, systems thinking, ecological constraints, and reflexive evaluation help distinguish these lenses' hypotheses from established facts.

The evidence reviewed here supports a narrower, more useful conclusion than a claim that Swedish institutions are deliberately ignoring disadvantaged groups. A 2024 National Audit Office review found deficiencies in interventions and information exchange concerning children suspected of serious crime. Swedish law then expanded specific disclosure channels in 2025. This makes it untenable to assert a universal legal information blockade, but it leaves open whether information is used well, for proportionate purposes, and with equitable consequences [S01–S04].

Swedish distributional indicators warrant differentiated analysis: Statistics Sweden reported a 2024 equivalised-disposable-income Gini of **0.314**, compared with **0.310** in 2023; the 2024 figure excluding capital income was **0.246**, unchanged over 2022–2024. The Gini is an **income** measure, not a wealth-ownership measure. The Equality Ombudsman received **5,697 discrimination complaints in 2025**, up from **4,452** in 2024; the change cannot by itself establish a proportional change in underlying discrimination [S05–S07].

The Sámi case is a particularly strong test of the difference between *consultation*, *coordination*, and *substantive authority*. Sweden has a Sámi consultation statute, extended to municipal and regional matters in 2024, while the UN Committee on the Elimination of Racial Discrimination has raised concerns about the scope of that framework, especially regarding land, resources and free, prior and informed consent. These are legal and normative tensions, not proof that every particular project violates the law [S08–S11].

**Provisional conclusion:** the most promising extension is not to replace a feedback diagnosis with a domination diagnosis. It is to test **feedback failure, authority/incentive failure, representational failure and rights conflict as separate, interacting explanations**. *Framtidskommuner* should test whether better sensing improves real outcomes **without** increasing surveillance, bypassing legal rights, or concentrating voice in already powerful groups.

## 1. Relationship to the original report

The Stage 1 report develops three major constructs: **Data Archipelago** (fragmented cross-domain learning), **Jantelagen / consensus filtering** (a hypothesis about dissenting signals), and **Municipal Trap** (a possible mismatch between local responsibilities and usable authority). It proposes *Framtidskommuner*—voluntary municipal pilots combining lawful learning, deliberation, flexibility, and independent evaluation. These are the propositions under test, not assumptions this companion is entitled to certify.

The original report already recognizes privacy safeguards, targeted disclosure, protected rights, independent evaluation, municipal equalization, and the risk of poorly designed pilots. Accordingly, this companion does **not** claim that power analysis or Sámi consultation is wholly absent from Stage 1. It asks whether these considerations might change the causal explanation, the choice of intervention, or what counts as success.

The DeepSeek critique supplied for this project is treated as a **source of hypotheses**. Claims such as “information silos serve wealth holders,” “segregation is primarily produced by suppressed minority signals,” and “an institutional arrangement is green colonialism” require separate evidence about decision records, incentives, causation, and rights. Rhetorical force is not evidentiary weight.

## 2. Analytical discipline

### 2.1 Six complementary lenses, without stage-ranking

- **Institutional and systems analysis:** map decisions, legal mandates, data paths, resources, feedback, implementation and learning.
- **Critical theory / political economy:** identify agenda-setting, ownership, bargaining power, resource control and the capacity to externalize costs. Distinguish positional advantage from unlawful or intentional domination.
- **Intersectionality:** ask whether combinations of socioeconomic position, disability, gender, age, geography, origin and other relevant factors change the likelihood of being heard or receiving effective services. Never infer an individual characteristic from a group average.
- **Decolonial and Indigenous-rights analysis:** inspect historical land and governance relations, current jurisdiction, participation and substantive rights. Sámi institutions and rights-holders are not interchangeable with generic stakeholder samples.
- **Critical realism and ecological economics:** test alternative generative mechanisms, including budgets, law, administrative capability, ecological limits and cumulative land-use effects; do not reduce every observed disparity to power.
- **Second-order/reflexive analysis:** disclose who framed the question, selected evidence, funded evaluation, decided success criteria and could influence publication.

Spiral Dynamics may be used as a tentative lens for discussing values; it is not a validated device for classifying whole populations, institutions or critics into stages. No stage label is evidence of a causal mechanism.

### 2.2 Five non-equivalent claims

This paper separates **(1) descriptive observations**, **(2) institutional mechanisms**, **(3) causal attributions**, **(4) rights and legal findings**, and **(5) normative recommendations**. For example, a complaint trend is an observation; selective institutional response is a hypothesis; a violation of a particular statutory duty requires the relevant legal test and case evidence; the desirability of a veto or redistribution is a policy judgment. One must not be smuggled into another.

### 2.3 Operationalizing power

“Power” is not one variable. Code, for each affected decision, **agenda power** (who selects issues), **epistemic power** (whose data and expertise are recognized), **legal power** (jurisdiction, rights, appeal and remedy), **fiscal power** (who funds and can withhold), **organizational power** (staff, access, implementation), **bargaining and exit options**, and **procedural voice** (who can contest a decision). Identify beneficiaries and burden-bearers only after measuring the actual distribution of options and outcomes.

## 3. Case study A — When information improves, does response improve?

The original *Data Archipelago* is plausible as a hypothesis about coordination and collective learning, but it should not be simplified to “agencies cannot share.” In 2024 the Swedish National Audit Office found that information exchange among agencies intervening in serious criminality involving children varied in quality, content and frequency. Its findings concern particular processes and a pre-reform period; they do not establish a general condition of the entire public sector [S01].

In April 2025, specified disclosure duties to law-enforcement bodies took effect; on **1 December 2025**, a broader secrecy-breaking provision entered into force for defined purposes such as preventing and investigating crime and erroneous payments, with balancing tests and exceptions [S02, S03]. A 2026 government assignment concerning guidance for schools indicates that practical interpretation and implementation remain live issues [S04].

This creates at least four hypotheses:

- **H-A1, legal bottleneck:** a demonstrably necessary exchange remains legally prohibited or uncertain.
- **H-A2, operational bottleneck:** exchange is lawful but blocked by procedures, interoperability, staffing or organizational incentives.
- **H-A3, response bottleneck:** relevant information reaches decision-makers, but action is delayed or ineffective because capacity or authority is missing.
- **H-A4, protective boundary:** withholding information is necessary to prevent disproportionate surveillance or misuse; removing the boundary would worsen rights or trust.

The fourth is crucial. The Swedish Authority for Privacy Protection (IMY) argued against a **further proposed** broad rule in a November 2025 consultation response, highlighting data minimization and profiling risks. This was a critique of an additional proposal, **not evidence that the already enacted December 2025 exception had been repealed** [S12].

**Evidence required:** trace a sample of decisions from first documented warning to transmission, interpretation, authorization, response and consequences. Code withheld information separately as *prohibited*, *unnecessary*, *not requested*, *not technically accessible*, *misinterpreted* or *deliberately rejected*. Compare cases before and after 2025 while accounting for concurrent policy change. Evaluate adverse events and the frequency of unjustified disclosures alongside useful responses.

**Potential disconfirmation:** if lawful information already reached the responsible actors in a timely fashion, but outcomes did not improve after sharing procedures changed, the information-bottleneck account would be weakened for that case.

## 4. Case study B — Whose hardship becomes legible?

The argument from a “Swedish consensus filter” to systematic exclusion must be tested, not assumed from a national cultural stereotype. There is nevertheless a serious measurement problem: national averages can conceal distinct experiences, and public institutions may register some needs more readily than others.

Statistics Sweden reports a **2024 income Gini of 0.314** and **13.1%** with low economic standard; these describe income distribution, not who holds decision-making power or wealth [S05, S06]. SCB also publishes 2024 median earned income by sex and region of birth, with sizable aggregate differences; those comparisons are not causal estimates of discrimination and depend on age, years in Sweden, education, employment and other covariates [S13].

The Equality Ombudsman's 2025 complaints increased by approximately 28% to **5,697**. The Ombudsman explicitly cautions that complaints do not capture the full incidence of discrimination; reporting propensity and institutional practices also affect counts [S07]. Boverket treats residential segregation as a relational phenomenon involving both structural conditions and individual choices; it emphasizes that separating neighbourhood effects from other determinants is empirically difficult [S14].

An intersectional test should therefore focus on **disparities in a specific service pathway**, not a catalogue of identity categories. For example: among otherwise comparable families seeking an intervention after school absence, are referrals, response times, service quality and outcomes distributed differently by intersecting geography, disability, household resources, age and relevant migration-related circumstances? Are there mechanisms—language access, digital barriers, staff turnover, administrative discretion—that plausibly explain the differences?

**Measurement safeguards:** pre-register the categories and rationale; co-design with affected residents; use voluntary and lawful collection when sensitive characteristics are necessary; minimize identification risk in small cells; report denominator and missingness; estimate intersections only with sufficient sample and statistical power; avoid framing foreign-born residents as homogeneous. A model that demonstrates disparity does not automatically identify its cause.

**Potential disconfirmation:** if comparable cases show equitable access and similar justified decisions once need and context are controlled, a discriminatory-filter explanation for that particular process would be weakened, though not every other mechanism ruled out.

## 5. Case study C — Sámi rights are not a coordination variable

This is the clearest place where the companion may change institutional design rather than simply offer another interpretation. In the first report, northern industrial transition is partly a problem of coordinating jobs, infrastructure, housing, environment and land use. That remains necessary. But effective coordination among national agencies, municipalities and industrial firms is not equivalent to legitimate decisions affecting Sámi rights-holders.

Sweden's **Act (2022:66) on Consultation in Matters of Special Importance to the Sámi People** provides for consultations with Sámi representatives in relevant decisions. Its municipal/regional application began in March 2024 in relevant cases; its scope, exceptions and procedure must be checked for each kind of decision [S08, S09]. Sametinget identifies the Sámi Parliament, affected *samebyar* and relevant Sámi organizations as distinct consultation actors depending on the matter [S10].

The UN Committee on the Elimination of Racial Discrimination, in observations adopted in December 2025, welcomed the consultation regime yet expressed concern about limits relating to natural resources, environmental processes and free, prior and informed consent (FPIC); it recommended review and more effective consultation aimed at obtaining consent [S11]. Amnesty International and the Sámi Council's 2025 report documents and argues against practices it describes as **green colonialism**; this is the authors' human-rights assessment and policy framing, not a judicial ruling that all green-transition projects are unlawful [S15].

Three propositions must be kept distinct: **a duty to consult**, **a substantive rights constraint**, and **a requirement for consent in the relevant context**. Under Sweden's consultation statute, consultations may conclude without agreement; it is inaccurate to assume that every consultation supplies a general legal veto. Conversely, the absence of a general statutory veto does not render substantive rights, international commitments or remedies irrelevant. The precise domestic and international legal effects require case-specific review.

The key design test is therefore not “are Sámi voices represented in the municipal citizen assembly?” It is **“which rights, jurisdictions and consultation procedures must be respected independently of the assembly and of a coordination pilot?”** Nor does any one institution represent all affected Sámi interests in all matters.

**Proposed case protocol:** choose one documented land-use decision; map the initiating authority, statutory framework, affected Sámi representatives, ecological and cumulative-impact studies, dates and content of consultations, reasoned responses, alternative sites, remedies and final decision. Obtain accounts from both rights-holders and decision-makers. Publish contested interpretations separately. Include consideration of climate-transition benefits and alternative ways of achieving them.

**Potential disconfirmation:** a comprehensive, timely, rights-respecting process that substantively influenced the decision would weaken the claim of systematic exclusion in that individual case, while leaving broader structural questions open.

## 6. Case study D — Local authority, funding and the possibility of local capture

The *Municipal Trap* is worth testing, but Swedish municipalities do not operate without redistributive support. The municipal equalization system explicitly seeks to moderate differences in tax base and structural costs, and its effects must be modeled before claiming that a declining local tax base mechanically deprives a municipality of its ability to respond [S16]. The Swedish Association of Local Authorities and Regions reports meaningful differences in municipalities' financial and demographic conditions even within that system [S17].

**Centralization is not always domination; decentralization is not always emancipation.** National standards can protect legal equality against local discrimination, while excessive earmarking or rigid national rules can constrain valid local experimentation. Conversely, local autonomy can empower neglected communities or amplify established local interests. Every proposed transfer of authority must answer: who gains discretion, who can appeal, who bears the cost, which national floors are non-waivable, and what fiscal equalization remains necessary?

The empirical question is whether particular mandates, funding rules or implementation capacities cause documented delays or poor outcomes. Compare municipalities with similar needs but different organizational arrangements or fiscal capacity. Examine central constraints and local political choices separately; do not treat municipality size or tax base as a sufficient causal explanation.

## 7. Citizen deliberation — a channel for influence or a legitimacy device?

The first report proposes standing municipal *medborgarråd*. Sweden already has relevant experimental experience: the 2024 national climate citizens' assembly convened **60 selected members, with 49 participating throughout**, and produced **22 proposals**, according to Stockholm University. Those facts show deliberative activity, not by themselves durable policy impact [S18].

OECD guidance distinguishes **design integrity**, **deliberative experience**, and **pathways to impact**, including independent evaluation, accessible participation, balanced evidence and a public response to recommendations [S19]. This points toward a more rigorous standard than mere attendance or the number of recommendations.

A pilot should disclose its agenda setters, funders, recruitment procedure, nonresponse, compensation, facilitation, expert briefings, political response and actual implementation. Deliberation must not become a substitute for an elected assembly's accountability, a court's remedies, or affected Indigenous rights-holders' distinct legal standing. Nor should the companion assume that advice without binding power is always decorative: advisory institutions can matter when their recommendations receive reasoned, traceable treatment. Binding authority requires a further legitimacy and legal argument.

## 8. Four competing explanations and a research design

| Account | Predicted observable pattern | Plausible alternative | Evidence that would weaken it |
|---|---|---|---|
| **F1 Information deficit** | Key warning is absent, delayed or unusable at decision point | Information was present; resources or objectives limited response | Documented timely information and unchanged action after sharing improves |
| **F2 Authority/capacity deficit** | Relevant actor recognizes need but lacks legally usable decision rights, people or funds | Deliberate inaction or an ineffective intervention | Actor had adequate authority and capacity; implementation still fails |
| **F3 Political-incentive/agenda deficit** | Well-documented problem repeatedly loses priority where influential actors face costs | Legitimate rights limits, budget trade-offs or low expected benefit | Transparent reasoned choices track evidence and consistently applied objectives |
| **F4 Representational/rights deficit** | Underrepresented groups encounter different access, agenda control or unremedied rights claims | Differences in underlying needs or justified decisions | Equitable case-adjusted access; rights-respecting procedures with substantive influence |

These accounts can overlap. Their value is that they yield distinct process evidence and different potential remedies. A blanket claim that “power causes the information deficit” would be less informative than identifying **when** the causal sequence involves law, organization, resources, political bargaining or unequal representation.

### 8.1 First research phase: case selection and protocol

1. Select **three bounded decisions or service pathways** before viewing outcome patterns: one inter-agency child-support pathway, one municipality-level service-access pathway, and one Sámi land-use decision. A fourth deliberative case can be added if documents permit.
2. Form a source register: legal text, audit reports, agency and municipal decisions, consultation minutes, budgets, policy evaluations, affected-person testimony and relevant administrative data. Separate first-hand evidence from advocacy, interpretation and press reports.
3. Record dated **decision chains**: trigger → recognition → information flow → option set → authority → decision → implementation → observed outcomes → complaints and remedies. Code missing links as missing rather than as deliberate suppression.
4. Evaluate **rival mechanisms** using process tracing and, where feasible, matched comparisons, before/after changes with concurrent-reform controls, negative cases and sensitivity analysis. Do not infer causal effects from a simple cross-sectional disparity.
5. Publish a **rights and distributional impact table** and a **red-team review** before final conclusions. Allow the original Competence Trap thesis to be supported, qualified, restricted to some domains, or rejected for individual cases.

### 8.2 Proposed Framtidskommuner experimental measures

**Process:** time from first verifiable signal to appropriate decision, cross-institution coordination quality, clarity of responsibility, completeness of follow-up.  
**Substantive:** service outcomes, educational and wellbeing indicators relevant to the chosen pathway, cost and time burden, durability of beneficial changes.  
**Distributional:** gaps in access, waiting times, treatment and outcomes across pre-specified relevant intersections; representation and speaking opportunity in deliberative bodies.  
**Rights and harm:** unauthorized disclosures, profiling and chilling effects, complaints, appeal outcomes, compliance with Sámi consultation and other rights obligations.  
**Capture risks:** agenda dominance, concentration of contracts or evaluation influence, dependence on a single funder, publication suppression and retaliation concerns.  
**Ecological impacts:** only where materially relevant; use cumulative land-use and biodiversity or resource-flow indicators, with expert and affected-community validation.

Pre-register metrics, collect baseline and comparison data, publish selection criteria and reasons for non-participation, and establish clear stopping/repair rules for rights violations. A pilot should fail the evaluation if it speeds decisions through unlawful shortcuts, even if its process score improves. Use the *minimal sufficient coordination* principle: collect/share no more data and centralize no more authority than is needed to achieve a justified public purpose while respecting rights.

## 9. What could change in the original proposal?

| Potential finding | Effect on *The Competence Trap* | Effect on *Framtidskommuner* |
|---|---|---|
| Information and organizational gaps dominate | Strengthens central diagnosis | Focus on lawful interoperability, staffing and process learning |
| Information was already available, but political priorities blocked action | Feedback deficit becomes a partly downstream symptom | Add contestability, transparent decision reasons, credible review and incentive changes |
| Disparities arise from unequal access or voice | Expands “sensing” to include who can define problems | Add co-design, accessibility, representation audits and distributional endpoints |
| Substantive Indigenous rights constrain a proposed coordination solution | Rights become a non-substitutable constraint, not a stakeholder preference | Exclude rights-diluting exemptions; run separate lawful consultation and rights assessment |
| Privacy or national standards prevent harm | Some barriers are protective, not failures | Preserve limits; test narrower, less intrusive alternatives |
| Local authority risks elite capture | Polycentricity is insufficient on its own | Add anti-capture safeguards, appeals, independent evaluation and national rights floors |

## 10. Provisional assessment and publication threshold

The original report's strongest contribution remains its proposal to make governance more adaptive. This companion adds the possibility that adaptation itself may be selective, constrained by legitimate protections, or captured by interests. The serious question is not **“Is the Swedish system an engineering problem or a power settlement?”** Both may be true in different degrees and settings. The research task is to determine which mechanism is binding in which decision.

The current evidence supports the **relevance** of these tests; it does **not** establish their full causal conclusions. There has been no primary-file review of specific municipal cases, no matched municipal dataset, no independent interview program, and no comprehensive legal review of an actual mining permit or pilot exemption. The examples are **evidence-backed research leads** rather than completed empirical case studies.

**Provisional decision:** retain the original report as a separately labeled diagnostic working paper; develop this companion through case-level verification; revise the parent report only when evidence materially warrants it. A final synthesized report should distinguish legal non-negotiables, established mechanisms, contestable hypotheses and political value choices.

## Appendix A — Evidence and attribution rules

- **Verified source statement:** repeat a bounded proposition directly supported by an official document, primary law, reported statistic or identifiable research output.
- **Attributed assessment:** e.g. Amnesty's characterization of certain extractive practices; do not present the attribution as a court's finding.
- **Hypothesis:** a proposed mechanism that could explain observed patterns; specify alternative explanations and falsifiers.
- **Normative design choice:** specify whose values, rights, and trade-offs justify the recommendation. Efficiency and emancipation are not logically opposite; a well-defined systemic optimization may include participation, equity and non-domination as objectives or constraints.
- **Unknown:** if records, comparable data, or direct affected-party input are absent, keep the conclusion open.

## Appendix B — Source register

[S01] Riksrevisionen (2024), *Otillräckliga insatser när barn misstänks för grova brott* (RiR 2024:9). https://www.riksrevisionen.se/granskningar/granskningsrapporter/2024/otillrackliga-insatser-nar-barn-misstanks-for-grova-brott.html  
[S02] Government of Sweden (2025), *Ökat informationsutbyte mellan myndigheter*, Prop. 2024/25:180. https://www.regeringen.se/rattsliga-dokument/proposition/2025/05/prop.-202425180  
[S03] Government of Sweden (1 December 2025), communication on the new secrecy-breaking provision. https://www.regeringen.se/pressmeddelanden/2025/12/nu-rivs-sekretessen-mellan-alla-myndigheter-i-sverige/  
[S04] Government of Sweden (2026), guidance assignment on school information exchange. https://www.regeringen.se/pressmeddelanden/2026/05/skolverket-far-uppdrag-att-stodja-skolors-tillampning-av-nya-sekretessbrytande-regler/  
[S05] Statistics Sweden (2026), *Högre ekonomisk standard – men inkomstskillnaderna ökar* (2024 reference year). https://www.scb.se/pressmeddelande/hogre-ekonomisk-standard--men-inkomstskillnaderna-okar/  
[S06] Statistics Sweden, *Inkomster och skatter* (2024 reference year). https://www.scb.se/he0110/  
[S07] Equality Ombudsman (DO, 2026), *Statistik över anmälningar till DO 2016–2025*. https://www.do.se/rattsfall-beslut-lagar-stodmaterial/publikationer/2026/statistik-over-anmalningar-till-do-2016-2025  
[S08] Swedish Parliament, Act (2022:66), *Lag om konsultation i frågor som rör det samiska folket*. https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/lag-202266-om-konsultation-i-fragor-som-ror-det_sfs-2022-66/  
[S09] Boverket, *Konsultation i ärenden som rör samiska frågor* (municipal planning implementation). https://www.boverket.se/sv/PBL-kunskapsbanken/detaljplan/detaljplaneprocessen/samiska-fragor/  
[S10] Sametinget (updated June 2026), *Konsultation med Sametinget*. https://sametinget.se/konsultationsordning  
[S11] UN CERD (18 December 2025), *Concluding observations on Sweden*, CERD/C/SWE/CO/24-25, paragraphs 38–39. https://docstore.ohchr.org/SelfServices/FilesHandler.ashx?enc=VZ8yj3OGKOf0RJCS3WoPnE7T2oUZ8StMZIJo0NpHO49VPKwtbwJcz8EBobrL%2FfcdXzbf1oWhXrZc9iDxavCOUIOSGx%2FsD2bxL2jqc%2B2b%2BA8%3D  
[S12] Integritetsskyddsmyndigheten (3 November 2025), opinion on SOU 2025:45 (proposed **additional** rule). https://www.imy.se/globalassets/dokument/remissvar/2025/slutbetankandet-okat-informationsutbyte-mellan-myndigheter--nagra-anslutande-fragor.pdf  
[S13] Statistics Sweden (2026), *Inkomster för personer i Sverige* (2024 data by origin and sex). https://www.scb.se/hitta-statistik/sverige-i-siffror/utbildning-jobb-och-pengar/inkomster-for-personer/  
[S14] Boverket (2026), *Om boendesegregation*. https://www.boverket.se/sv/samhallsplanering/livsvillkor-och-utanforskap/kunskapsstod/om-boendesegregation/  
[S15] Amnesty Sápmi / Amnesty International and Sámi Council (29 January 2025), *Just Transition or Green Colonialism?* announcement and report description. https://amnestysapmi.se/ny_amnestysapport/  
[S16] SKR (2026), *Utjämningssystem samt frågor och svar*. https://skr.se/ekonomiochbudgetplanering/utjamningssystem.8275.html  
[S17] SKR (2026), municipal finances and uneven conditions. https://skr.se/pressrum/aktuellt/nyhetsarkiv/ljusareiekonominmenbehovenattstallaomarstora.10818.html  
[S18] Stockholm University (26 November 2024), first national climate citizens' assembly and lessons. https://www.su.se/nyheter/nyhetsartiklar/2024-11-26-rapport-om-lardomar-fran-medborgarrad-om-klimatet  
[S19] OECD (2021), *Evaluation Guidelines for Representative Deliberative Processes*. https://www.oecd.org/en/publications/evaluation-guidelines-for-representative-deliberative-processes_10ccbfcb-en.html

**Source limitations:** government communications describe their own policy rationale; advocacy organizations document allegations and normative claims; aggregate statistics are not causal identification; legal interpretation may differ across specific cases. This is a curated starting register, not a comprehensive systematic literature review.

## Appendix C — Editorial crosswalk

| Original Stage 1 topic | Companion section | Status |
|---|---|---|
| §2.2 Data Archipelago | §§3, 8 | Test current law, implementation, necessity and privacy |
| §2.3 Consensus filtering | §4 | Hypothesis; avoid national-culture essentialism |
| §2.4 Municipal Trap | §6 | Include equalization and local-capture countercase |
| §3.2 Structured disagreement | §7 | Evaluate agenda, representativeness and effects |
| §3.4 Living testbeds (northern transition) | §5 | Sámi consultation and rights independent of coordination |
| §4 Political immune system | §§2, 8 | Treat beneficiaries and suppression as claims requiring evidence |
| §§5–6 Framtidskommuner | §§7–9 | Rights-preserving distributional, privacy and evaluation gates |

*This document is a companion working paper. It has not been peer reviewed, legally certified, or validated against a full set of municipal primary records.*
