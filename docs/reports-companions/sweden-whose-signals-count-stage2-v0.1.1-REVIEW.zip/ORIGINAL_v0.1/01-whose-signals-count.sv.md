# Sverige — Vems signaler räknas?

## Makt, exkludering och återkopplingsreformens gränser

**Följer upp:** *Sverige — Kompetensfällan* (reviderat arbetsutkast, etapp 1, 12 november 2026)  
**Status:** Forskningsutkast etapp 2 v0.1 — källunderbyggda hypoteser, inte en validerad kausalstudie  
**Kunskapsläge:** 12 november 2026  
**Avgränsning:** Utvalda svenska styrningsmekanismer och möjliga institutionella tester; inte en fullständig landanalys.

## Sammanfattning

Detta komplement avvisar inte huvudrapportens **kompetensfälla** eller **svenska eftersläpningsloop**. Det undersöker en begränsning som inte kan lösas enbart genom bättre återkopplingsteknik: information får politisk betydelse först när det finns befogenheter, resurser, incitament och legitimitet att agera utifrån den. Ett system kan bli bättre på att upptäcka problem och ändå bevara ojämlikheter i vilka erfarenheter, intressen och rättigheter som styr åtgärderna.

Fyra frågor står i centrum: **Vem kan synliggöra en signal? Vem får tolka den? Vem kan genomdriva eller hindra beslut? Vem får nyttan och bär kostnaderna?** Kritisk teori riktar blicken mot institutionell och ekonomisk makt. Intersektionalitet undersöker hur olika livsvillkor samverkar och påverkar möjligheten att bli hörd. Dekolonial analys prövar om urfolks rättigheter behandlas som självständig rättslig och politisk ställning eller bara som ännu ett intresse att samordna. Kritisk realism, systemtänkande, ekologiska begränsningar och reflexiv utvärdering hjälper oss att skilja hypoteser från belagda förhållanden.

Materialet ger en mer avgränsad slutsats än påståendet att svenska institutioner medvetet ignorerar missgynnade grupper. Riksrevisionen fann 2024 brister i de samlade insatserna och informationsutbytet kring barn som misstänks för grova brott. Lagstiftningen om informationsdelning utvidgades därefter 2025. Det gör ett generellt påstående om absoluta sekretesshinder ohållbart, samtidigt som frågan kvarstår om uppgifter används ändamålsenligt, proportionerligt och med jämlika konsekvenser [S01–S04].

SCB redovisade för 2024 en Gini-koefficient för ekonomisk standard på **0,314**, jämfört med **0,310** år 2023. Utan kapitalinkomster var den **0,246**, oförändrad 2022–2024. Detta är ett mått på **inkomstfördelning**, inte ett direkt mått på förmögenhetsägande. Diskrimineringsombudsmannen (DO) tog emot **5 697 diskrimineringsanmälningar under 2025**, jämfört med **4 452 under 2024**. Skillnaden kan inte ensam tolkas som samma procentuella förändring i diskrimineringens faktiska omfattning [S05–S07].

Det samiska fallet är särskilt viktigt för skillnaden mellan **konsultation, samordning och reellt inflytande**. Sverige har en konsultationslag som från 2024 även omfattar kommuner och regioner i relevanta ärenden. FN:s kommitté mot rasdiskriminering har samtidigt påtalat begränsningar i lagens tillämpningsområde och kopplingen till urfolks rätt till fritt och informerat förhandssamtycke [S08–S11].

**Preliminär slutsats:** ersätt inte diagnosen *återkopplingsbrist* med en lika svepande diagnos *dominans*. Undersök i stället **informationsbrister, befogenhets- och incitamentsbrister, representationsbrister och rättighetskonflikter som skilda men samverkande förklaringar**. Framtidskommuner bör pröva om ökad förmåga att se och agera förbättrar faktiska utfall utan mer övervakning, försvagade rättigheter eller ökad koncentration av inflytande.

## 1. Förhållandet till huvudrapporten

Huvudrapporten utvecklar tre centrala begrepp: **Dataarkipelagen** (brister i lärande mellan verksamheter), **Jantelagen/konsensusfiltret** (en hypotes om hur avvikande signaler behandlas) och **Kommunfällan** (en möjlig diskrepans mellan lokalt ansvar och användbart handlingsutrymme). Den föreslår **Framtidskommuner**: frivilliga kommunala försök med laglig kunskapsdelning, medborgarråd, anpassat handlingsutrymme och oberoende utvärdering. Dessa idéer är utgångspunkter för prövning, inte bevisade samband.

Den reviderade huvudrapporten beaktar redan integritet, riktad informationsdelning, rättigheter, oberoende utvärdering, kommunal utjämning och risker med felkonstruerade försök. Komplementet ska därför inte hävda att maktfrågor eller samiskt samråd är helt frånvarande. Frågan är i vilka fall dessa perspektiv **förändrar orsaksförklaringen, reformvalet eller framgångskriterierna**.

DeepSeeks tidigare analys behandlas som en **hypoteskälla**. Påståenden som att informationssilor gynnar förmögna grupper, att segregationsproblem främst beror på undertryckta minoritetssignaler eller att ett visst projekt utgör grön kolonialism kräver särskilt underlag om beslut, incitament, kausalitet och rättigheter. Retorisk skärpa är inte bevisstyrka.

## 2. Analytiska principer

### 2.1 Sex kompletterande perspektiv

- **Institutionell analys och systemtänkande:** kartlägg beslutsvägar, mandat, dataflöden, resurser, återkoppling, genomförande och lärande.
- **Kritisk teori och politisk ekonomi:** analysera dagordningsmakt, ägande, förhandlingsstyrka, resurskontroll och möjligheten att överföra kostnader på andra. Likställ inte strukturella fördelar med avsiktligt eller olagligt förtryck.
- **Intersektionalitet:** undersök hur exempelvis ekonomi, funktionsnedsättning, kön, ålder, geografi och migrationsrelaterade förhållanden samverkar. Dra aldrig slutsatser om individer från gruppmedelvärden.
- **Dekolonial analys och urfolksrätt:** undersök historiska och nuvarande markrelationer, jurisdiktion, deltagande och materiella rättigheter. Samiska rättighetsbärare kan inte ersättas av ett allmänt kommunalt medborgarurval.
- **Kritisk realism och ekologisk ekonomi:** testa andra generativa mekanismer, exempelvis lag, budget, förvaltningskapacitet, biogeofysiska gränser och kumulativ markpåverkan. Alla skillnader bör inte på förhand tolkas som maktutövning.
- **Andra ordningens/reflexiv analys:** redovisa vem som formulerat frågan, valt belägg, finansierat utvärdering, definierat framgång och kunnat påverka publiceringen.

Spiral Dynamics kan användas försiktigt som en tolkningsram för värderingskonflikter, men inte som en validerad metod för att nivåbestämma hela folkgrupper, partier, myndigheter eller kritiker. En stadieetikett förklarar inte en kausal mekanism.

### 2.2 Fem typer av utsagor

Skilj **(1) observation**, **(2) institutionell mekanism**, **(3) orsakspåstående**, **(4) rättslig bedömning** och **(5) normativ rekommendation**. En anmälningsökning är en observation; selektiv behandling kan vara en hypotes; ett rättighetsbrott kräver tillämplig norm och fallunderlag; förslag om omfördelning eller vetorätt är politiska och normativa ställningstaganden. En typ får inte tyst förvandlas till en annan.

### 2.3 Att operationalisera makt

Koda för varje beslutsprocess: **dagordningsmakt**, **kunskapsmakt** (vilka belägg som tillmäts vikt), **rättslig makt** (behörighet, talerätt, överklagande), **finansiell makt**, **organisatorisk makt**, **förhandlings- och utträdesmöjligheter** och **processuellt inflytande**. Identifiera vinnare och förlorare utifrån dokumenterade handlingsalternativ och utfall, inte utifrån antagna motiv.

## 3. Fall A — När informationen blir bättre: blir även responsen bättre?

Dataarkipelagen är en rimlig hypotes om samverkan och gemensamt lärande, men inte synonym med att myndigheter ”inte får dela uppgifter”. Riksrevisionens granskning av statens insatser för barn som misstänks för grova brott fann 2024 varierande kvalitet, innehåll och frekvens i informationsutbytet. Det gäller undersökta verksamheter före senare lagändringar, inte alla svenska myndigheter [S01].

Från april 2025 gäller särskilda skyldigheter att lämna uppgifter till brottsbekämpande myndigheter. Den **1 december 2025** infördes dessutom en generell sekretessbrytande bestämmelse för specificerade syften, bland annat brottslighet och felaktiga utbetalningar, med intresseavvägning och undantag [S02, S03]. Att regeringen 2026 gav Skolverket i uppdrag att stödja tillämpningen visar att praktisk rättstillämpning och organisatoriska frågor fortfarande behöver hanteras [S04].

Vi bör skilja fyra hypoteser:

- **H-A1: Rättslig flaskhals.** Ett nödvändigt informationsutbyte är förbjudet eller rättsligt oklart.
- **H-A2: Operativ flaskhals.** Delningen är tillåten men blockeras av system, rutiner, kompetens eller organisationsincitament.
- **H-A3: Responsflaskhals.** Informationen når ansvariga, men åtgärden uteblir på grund av resurs- eller befogenhetsbrist.
- **H-A4: Nödvändig skyddsgräns.** Begränsningen hindrar oproportionerlig kartläggning eller missbruk; ett avskaffande skulle skada rättigheter eller förtroende.

H-A4 är en reell konkurrerande tolkning. Integritetsskyddsmyndigheten (IMY) avstyrkte i november 2025 utformningen av ett **ytterligare föreslaget** generellt stöd för uppgiftslämnande på eget initiativ, med hänvisning till dataminimering och integritetsrisker. Detta gällde ett annat förslag och innebär **inte** att den i december ikraftträdda bestämmelsen upphävdes [S12].

**Prövning:** följ ett urval ärenden från första dokumenterade varning till delning, tolkning, beslut och konsekvenser. Skilj mellan uppgifter som var *förbjudna*, *onödiga*, *inte begärda*, *tekniskt otillgängliga*, *missförstådda* eller *medvetet avvisade*. Jämför före/efter 2025 med hänsyn till samtidiga reformer. Följ samtidigt integritetsintrång och obefogade utlämnanden.

**Motbevis:** om relevant information redan nådde ansvariga i tid men åtgärderna ändå uteblev, och utfallet inte förbättras när delningen förbättras, försvagas informationsflaskhalsens förklaringskraft i det fallet.

## 4. Fall B — Vilkas svårigheter blir synliga?

Påståendet att ett svenskt ”konsensusfilter” systematiskt missgynnar vissa grupper behöver belägg. Det kan inte härledas enbart ur en nationell kulturmetafor. Det finns däremot goda skäl att granska vad samlade genomsnitt döljer och vilka behov offentliga system har lättast att registrera och tillgodose.

SCB anger för 2024 **Gini 0,314** för ekonomisk standard och **13,1 procent** med låg ekonomisk standard. Detta beskriver inkomster, inte fördelningen av faktisk förhandlings- eller beslutsmakt [S05, S06]. SCB publicerar även medianinkomster efter födelseregion och kön med betydande gruppskillnader; statistiken visar inte i sig diskrimineringens kausala omfattning och behöver analyseras med exempelvis utbildning, ålder, arbetsmarknadsanknytning och vistelsetid i åtanke [S13].

DO mottog **5 697** diskrimineringsanmälningar under 2025, omkring 28 procent fler än 2024. Myndigheten framhåller själv att anmälningar inte ger hela bilden av faktisk diskriminering och att mörkertalet är stort [S07]. Boverket beskriver boendesegregation som ett relationellt mönster där strukturella villkor och individuella val samverkar; det är svårt att särskilja bostadsområdets betydelse från andra orsaker [S14].

Intersektionell analys bör därför börja i **en konkret tjänste- eller beslutsprocess**, inte i en lång förteckning identitetskategorier. Ett tänkbart test är: får familjer med jämförbara behov efter upprepad skolfrånvaro likvärdig tillgång till uppföljning och stöd? Skiljer sig tider, kvalitet och utfall när ekonomi, funktionsnedsättning, geografi, ålder och relevanta migrationsrelaterade förhållanden samverkar? Kan eventuella mönster förklaras med språklig tillgänglighet, digitala hinder, personalomsättning eller diskretionära bedömningar?

**Mätdisciplin:** förregistrera kategoriernas syfte; samarbeta med berörda grupper; använd frivilligt och rättsligt förankrat datainsamlande för känsliga uppgifter; skydda små grupper mot identifiering; redovisa bortfall och nämnare; analysera interaktioner bara med tillräcklig statistisk styrka; behandla inte utrikes födda som en enhetlig grupp. En påvisad skillnad är inte automatiskt ett belägg för dess orsak.

**Motbevis:** likvärdig tillgång och välmotiverade beslut efter relevant justering för behov och förutsättningar försvagar hypotesen om ett diskriminerande filter i den avgränsade processen, utan att utesluta andra mekanismer.

## 5. Fall C — Samiska rättigheter är inte en samordningsvariabel

Här kan komplementet tydligast förändra en tänkt reform. Huvudrapporten ser den nordliga industriomställningen delvis som en fråga om att samordna arbetstillfällen, bostäder, infrastruktur, miljö och markanvändning. Det behövs. Men effektiv samordning mellan staten, kommuner och företag är inte detsamma som legitima beslut för samiska rättighetsbärare.

**Lag (2022:66) om konsultation i frågor som rör det samiska folket** ställer krav på konsultation i relevanta ärenden; tillämpningen utsträcktes till kommuner och regioner 2024. Lagens undantag, räckvidd och beslutsförfarande måste prövas i varje ärendetyp [S08, S09]. Sametinget skiljer mellan Sametinget, berörda samebyar och relevanta samiska organisationer som konsultationsparter utifrån frågans art [S10].

FN:s kommitté mot rasdiskriminering välkomnade i sina slutsatser från december 2025 konsultationslagen men kritiserade begränsningar i frågor om naturresurser, miljöprocesser och fritt och informerat förhandssamtycke (*free, prior and informed consent*, FPIC). Kommittén rekommenderade en översyn och mer ändamålsenliga processer med sikte på samtycke [S11]. Amnesty och Samerådet beskriver i sitt arbete från 2025 exploateringsmönster som **grön kolonialism**. Detta är deras dokumenterade människorättsbedömning och normativa inramning, inte en generell domstolsprövning av alla enskilda projekt [S15].

Tre frågor får inte blandas ihop: **konsultationsskyldighet**, **materiella rättighetsgränser** och **krav på samtycke i den aktuella situationen**. En konsultation enligt svensk lag kan avslutas utan enighet; det vore fel att anta att varje konsultation skapar ett allmänt juridiskt veto. Omvänt innebär avsaknaden av ett sådant generellt veto inte att andra rättigheter eller rättsmedel saknar betydelse. Rättsverkningarna enligt svensk och internationell rätt kräver konkret juridisk bedömning.

Den avgörande designfrågan är inte enbart om samer har platser i ett kommunalt medborgarråd. Den är **vilka rättigheter, behörigheter och särskilda konsultationsförfaranden som måste respekteras vid sidan av medborgarråd och försöksverksamhet**. Ingen enskild institution kan förutsättas företräda alla samiska intressen i alla ärenden.

**Fallprotokoll:** välj ett väl dokumenterat markärende och kartlägg initiativtagare, rättsliga beslutsgångar, berörda företrädare, kumulativa och ekologiska konsekvensbedömningar, konsultationernas tidpunkter och innehåll, bemötande av invändningar, alternativ lokalisering, överprövning och slutbeslut. Inhämta synpunkter både från rättighetsbärare och myndigheter, och redovisa oförenliga tolkningar öppet. Pröva även klimatnyttan och andra sätt att uppnå den.

**Motbevis:** en tidig, fullständig och rättighetsrespekterande process där berörda faktiskt påverkat beslutet skulle försvaga påståendet om systematisk exkludering i det enskilda ärendet, men inte avgöra hela den strukturella frågan.

## 6. Fall D — Lokal makt, finansiering och risken för lokal maktkoncentration

Kommunfällan är värd att testa. Samtidigt saknar svenska kommuner inte omfördelande stöd. Det **kommunalekonomiska utjämningssystemet** utjämnar skillnader i skattekraft och strukturella kostnader. Dess effekter behöver beaktas innan man påstår att ett krympande lokalt skatteunderlag automatiskt gör kommunen handlingsförlamad [S16]. SKR rapporterar likväl betydande skillnader i kommunernas ekonomiska och demografiska förutsättningar [S17].

**Centralisering är inte alltid dominans, och decentralisering är inte alltid frigörelse.** Nationella normer kan skydda invånares rättigheter mot lokal diskriminering, medan alltför detaljerade villkor kan förhindra lokalt lärande. Utökad lokal makt kan ge eftersatta grupper inflytande eller befästa lokala eliter. Varje befogenhetsförskjutning måste därför precisera vem som får ökat handlingsutrymme, vem som kan överklaga, vilka nationella minimikrav som kvarstår och hur kostnaderna fördelas.

Jämför kommuner med liknande behov men olika organisatoriska villkor eller ekonomiska förutsättningar. Skilj nationella restriktioner från lokala prioriteringar. Varken kommunstorlek eller skattekraft räcker som generell orsaksförklaring.

## 7. Medborgarråd — inflytande eller legitimitetsmarkör?

Huvudrapporten föreslår återkommande **medborgarråd**. Sverige har redan försök att lära av: 2024 års nationella klimatmedborgarråd samlade enligt Stockholms universitet **60 utvalda personer, varav 49 fullföljde processen**, och tog fram **22 förslag**. Detta visar genomförd deliberation, men inte i sig långvarig politisk påverkan [S18].

OECD:s utvärderingsram skiljer på **processdesign**, **upplevelsen och kvaliteten i samtalet** samt **vägarna från rekommendation till faktisk påverkan**. Oberoende utvärdering, tillgänglighet, mångsidig evidens och en offentlig motiverad respons är centrala [S19]. Antalet möten eller rekommendationer räcker inte som framgångsmått.

Framtidskommunerna bör publicera vem som sätter dagordningen, finansierar rådet, utformar urvalet, uteblir från deltagande, leder samtalen, väljer sakkunniga och svarar på rekommendationerna. Medborgarråd får inte ersätta fullmäktiges ansvar, domstolsprövning eller urfolks särskilda rättsliga ställning. Råd med rådgivande funktion är inte alltid dekorativa: också icke bindande rekommendationer kan få verklig betydelse om myndigheterna svarar öppet och följer upp genomförandet. Bindande beslutanderätt kräver ytterligare demokratiska och juridiska skäl.

## 8. Konkurrerande förklaringar och forskningsupplägg

| Förklaring | Förväntat observerbart mönster | Alternativ förklaring | Vad skulle försvaga hypotesen? |
|---|---|---|---|
| **F1 Informationsbrist** | Väsentlig varning saknas, försenas eller går inte att använda | Informationen fanns; åtgärden begränsades av andra faktorer | Dokumenterad information i tid och oförändrade beslut trots bättre delning |
| **F2 Befogenhets-/kapacitetsbrist** | Behovet är känt men ansvarig saknar mandat, pengar eller personal | Medveten prioritering eller ineffektiv åtgärd | Tillräckliga befogenheter och resurser fanns men genomförandet misslyckades |
| **F3 Incitaments-/dagordningsbrist** | Väl belagda problem nedprioriteras när inflytelserika aktörer möter kostnader | Legitima rättighetsgränser, prioriteringar eller svag förväntad nytta | Öppna, konsekventa och välmotiverade beslut som följer belägg |
| **F4 Representations-/rättighetsbrist** | Olika tillgång, begränsad dagordningsmakt eller rättighetsanspråk utan effektiv prövning | Skillnader i faktiska behov eller välmotiverade beslut | Likvärdig behovsjusterad behandling och reellt inflytande inom rättsenliga processer |

Förklaringarna kan samverka. Poängen är att de lämnar olika processpår och motiverar olika reformer. Påståendet ”makt orsakar informationsbristen” blir mindre upplysande än att visa **när** förloppet faktiskt går via lag, organisation, resurser, förhandling eller utestängning.

### 8.1 Forskningsfas 1: urval och protokoll

1. Förregistrera **tre avgränsade beslutsprocesser** innan utfallen granskas: ett tvärsektoriellt stödärende för barn, en kommunal tillgång-till-service-process samt ett samiskt markanvändningsärende. Ett fjärde deliberativt fall kan tillkomma.
2. Bygg ett källregister med lagtext, revisionsrapporter, kommunala och statliga beslut, konsultationsprotokoll, budgetar, berördas vittnesmål och lämpliga administrativa data. Håll primärkällor åtskilda från opinionsmaterial och tolkningar.
3. Dokumentera tidsatta **beslutskedjor**: signal → upptäckt → informationsväg → alternativ → befogenhet → beslut → genomförande → utfall → klagomål och rättsmedel. Koda saknade uppgifter som okända, inte som avsiktligt undertryckta.
4. Pröva **konkurrerande mekanismer** med processpårning, rimliga jämförelsefall, före/efter-jämförelser som kontrollerar samtidiga reformer, negativa fall och känslighetsanalyser. Tvärsnittsskillnader ger inte automatiskt kausalsvar.
5. Publicera en **rättighets- och fördelningsmatris** samt oberoende metodkritik innan slutsatserna fastställs. Kompetensfällan kan få stöd, behöva modifieras, avgränsas eller visa sig otillräcklig i ett enskilt fall.

### 8.2 Mått för framtida Framtidskommuner

**Process:** tid från första verifierbara signal till ändamålsenligt beslut; kvalitet i samverkan; ansvarsfördelning och uppföljning.  
**Sakutfall:** relevanta resultat inom service, skola och välbefinnande; resursanvändning och varaktighet i förbättringar.  
**Fördelning:** skillnader i tillgång, väntetider, bemötande och utfall för i förväg motiverade grupper/intersektioner; faktiskt talutrymme och representation i råd.  
**Rättigheter/skador:** obehörig uppgiftsdelning, otillbörlig profilering, negativa effekter på tillit, klagomål, överprövning, respekt för samiska och andra rättigheter.  
**Maktkoncentration:** kontroll över dagordning, upphandling, forskningsmedel och publicering; beroende av enskilda finansiärer; risk för repressalier.  
**Ekologi:** vid materiell relevans, kumulativ påverkan på mark, biologisk mångfald och resursflöden, med fackgranskning och berördas medverkan.

Förregistrera mått, samla baslinje och jämförelseunderlag, publicera urval och bortfall och fastställ stopp- och åtgärdsregler vid rättighetskränkningar. Ett försök ska inte räknas som lyckat för att det fattar snabbare beslut genom olagliga genvägar. Följ principen om **minsta tillräckliga samordning**: dela inte fler uppgifter och samla inte mer beslutsmakt än vad ett legitimt syfte kräver med bibehållet rättighetsskydd.

## 9. Möjliga konsekvenser för huvudrapporten

| Möjligt fynd | Konsekvens för Kompetensfällan | Konsekvens för Framtidskommuner |
|---|---|---|
| Informations- och organisationsbrister dominerar | Stärker den ursprungliga diagnosen | Fokus på laglig samverkan, bemanning och fungerande lärprocesser |
| Informationen fanns redan men prioriteringar blockerade åtgärden | Återkopplingsbrist är delvis ett symtom | Öka möjligheterna till invändning, motiveringar och oberoende prövning |
| Ojämlik tillgång och röst | Sensing måste omfatta vem som definierar problemet | Tillgänglighet, samdesign, representationskontroll och fördelningsmått |
| Urfolks rättigheter begränsar föreslagen samordning | Rättigheterna blir en icke-utbytbar restriktion | Inga undantag som urholkar rättigheter; särskild konsultation och prövning |
| Integritetsskydd eller nationella normer förebygger skada | Vissa gränser är skydd, inte systemfel | Behåll gränser; pröva mindre ingripande alternativ |
| Lokal autonomi riskerar lokal elitdominans | Polycentricitet är inte tillräckligt i sig | Skydd mot maktkoncentration, överklagande, extern utvärdering och nationella rättighetsgolv |

## 10. Preliminär bedömning och publiceringsgräns

Huvudrapportens centrala bidrag är ett förslag till **anpassningsbar styrning**. Komplementet undersöker om anpassningen kan bli selektiv, hindras av legitima skydd eller fångas av vissa intressen. Den centrala frågan är inte *”är detta ett ingenjörsproblem eller en maktordning?”* Båda kan förekomma. Forskningsuppgiften är att avgöra vilken mekanism som är begränsande i vilket beslut.

De hittills genomgångna källorna visar att frågorna är **värda att undersöka**. De bevisar inte en komplett orsakskedja. Ingen fullständig genomgång av enskilda kommunärenden har gjorts, inget matchat kommundataset har analyserats, inga oberoende intervjuer har genomförts och ingen uttömmande juridisk prövning av ett visst gruvtillstånd eller undantag har gjorts. Fallavsnitten är **forskningsspår med belagda utgångsfakta**, inte avslutade fallstudier.

**Preliminärt beslut:** bevara huvudrapporten som ett separat diagnostiskt arbetsdokument, fördjupa detta komplement med fallbaserad verifiering och revidera huvudrapportens slutsatser när det finns nytt underlag som faktiskt motiverar det. En senare syntes bör tydligt skilja rättsligt bindande gränser, belagda mekanismer, prövbara hypoteser och politiska värderingsval.

## Bilaga A — Regler för evidens och attribuering

- **Verifierad källuppgift:** ett avgränsat påstående direkt belagt i offentlig rapport, lagtext, statistik eller identifierbar forskning.
- **Attribuerad bedömning:** exempelvis Amnestys beteckning på exploateringsmönster; inte samma sak som en domstols dom.
- **Hypotes:** möjlig förklaringsmekanism som redovisar motförklaringar och tänkbara motbevis.
- **Normativt designval:** tydliggör värden, rättigheter och avvägningar. Effektivisering och frigörelse är inte logiska motsatser; systemisk optimering kan omfatta deltagande, jämlikhet och icke-dominans som mål och restriktioner.
- **Okänt:** när handlingar, jämförbara data eller berördas egna uppgifter saknas hålls slutsatsen öppen.

## Bilaga B — Källregister

[S01] Riksrevisionen (2024), *Otillräckliga insatser när barn misstänks för grova brott* (RiR 2024:9). https://www.riksrevisionen.se/granskningar/granskningsrapporter/2024/otillrackliga-insatser-nar-barn-misstanks-for-grova-brott.html  
[S02] Regeringen (2025), *Ökat informationsutbyte mellan myndigheter*, prop. 2024/25:180. https://www.regeringen.se/rattsliga-dokument/proposition/2025/05/prop.-202425180  
[S03] Regeringen (1 december 2025), information om ny sekretessbrytande bestämmelse. https://www.regeringen.se/pressmeddelanden/2025/12/nu-rivs-sekretessen-mellan-alla-myndigheter-i-sverige/  
[S04] Regeringen (2026), Skolverkets uppdrag om informationsutbyte. https://www.regeringen.se/pressmeddelanden/2026/05/skolverket-far-uppdrag-att-stodja-skolors-tillampning-av-nya-sekretessbrytande-regler/  
[S05] SCB (2026), *Högre ekonomisk standard – men inkomstskillnaderna ökar* (referensår 2024). https://www.scb.se/pressmeddelande/hogre-ekonomisk-standard--men-inkomstskillnaderna-okar/  
[S06] SCB, *Inkomster och skatter* (referensår 2024). https://www.scb.se/he0110/  
[S07] DO (2026), *Statistik över anmälningar till DO 2016–2025*. https://www.do.se/rattsfall-beslut-lagar-stodmaterial/publikationer/2026/statistik-over-anmalningar-till-do-2016-2025  
[S08] Sveriges riksdag, lag (2022:66), *Lag om konsultation i frågor som rör det samiska folket*. https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/lag-202266-om-konsultation-i-fragor-som-ror-det_sfs-2022-66/  
[S09] Boverket, *Konsultation i ärenden som rör samiska frågor*. https://www.boverket.se/sv/PBL-kunskapsbanken/detaljplan/detaljplaneprocessen/samiska-fragor/  
[S10] Sametinget (uppdaterad juni 2026), *Konsultation med Sametinget*. https://sametinget.se/konsultationsordning  
[S11] FN:s kommitté mot rasdiskriminering (18 december 2025), *Concluding observations on Sweden*, CERD/C/SWE/CO/24-25, punkterna 38–39. https://docstore.ohchr.org/SelfServices/FilesHandler.ashx?enc=VZ8yj3OGKOf0RJCS3WoPnE7T2oUZ8StMZIJo0NpHO49VPKwtbwJcz8EBobrL%2FfcdXzbf1oWhXrZc9iDxavCOUIOSGx%2FsD2bxL2jqc%2B2b%2BA8%3D  
[S12] IMY (3 november 2025), remissyttrande över SOU 2025:45, avseende **ytterligare föreslagna** regler. https://www.imy.se/globalassets/dokument/remissvar/2025/slutbetankandet-okat-informationsutbyte-mellan-myndigheter--nagra-anslutande-fragor.pdf  
[S13] SCB (2026), *Inkomster för personer i Sverige* (2024 års uppgifter efter födelseregion och kön). https://www.scb.se/hitta-statistik/sverige-i-siffror/utbildning-jobb-och-pengar/inkomster-for-personer/  
[S14] Boverket (2026), *Om boendesegregation*. https://www.boverket.se/sv/samhallsplanering/livsvillkor-och-utanforskap/kunskapsstod/om-boendesegregation/  
[S15] Amnesty Sápmi / Amnesty och Samerådet (29 januari 2025), information om *Just Transition or Green Colonialism?*. https://amnestysapmi.se/ny_amnestysapport/  
[S16] SKR (2026), *Utjämningssystem samt frågor och svar*. https://skr.se/ekonomiochbudgetplanering/utjamningssystem.8275.html  
[S17] SKR (2026), kommunernas ekonomi och skilda förutsättningar. https://skr.se/pressrum/aktuellt/nyhetsarkiv/ljusareiekonominmenbehovenattstallaomarstora.10818.html  
[S18] Stockholms universitet (26 november 2024), erfarenheter från nationellt klimatmedborgarråd. https://www.su.se/nyheter/nyhetsartiklar/2024-11-26-rapport-om-lardomar-fran-medborgarrad-om-klimatet  
[S19] OECD (2021), *Evaluation Guidelines for Representative Deliberative Processes*. https://www.oecd.org/en/publications/evaluation-guidelines-for-representative-deliberative-processes_10ccbfcb-en.html

**Källbegränsningar:** regeringens kommunikation återger också regeringens motiv; intresseorganisationer kan föra fram både dokumentation och normativa bedömningar; sammanfattande statistik ger inte kausal identifiering; juridiska slutsatser måste knytas till faktiska ärenden. Detta är ett kuraterat startregister, inte en systematisk kunskapsöversikt.

## Bilaga C — Koppling till etapp 1

| Ämne i huvudrapporten | Avsnitt här | Status |
|---|---|---|
| §2.2 Dataarkipelagen | §§3, 8 | Test av rättsläge, tillämpning, behov och integritet |
| §2.3 Konsensusfiltret | §4 | Hypotes; undvik att göra nationell kultur till en universalförklaring |
| §2.4 Kommunfällan | §6 | Beakta utjämning och lokal maktkoncentration |
| §3.2 Strukturerad oenighet | §7 | Pröva dagordning, representativitet och genomslag |
| §3.4 Levande försöksmiljöer (nordlig industriomställning) | §5 | Samisk konsultation och rättigheter oberoende av samordningen |
| §4 Det politiska immunsystemet | §§2, 8 | Vinnare och undertryckta signaler kräver belägg |
| §§5–6 Framtidskommuner | §§7–9 | Rättighets-, fördelnings-, integritets- och utvärderingsvillkor |

*Detta är en komplementerande forskningspromemoria. Den har inte genomgått sakkunniggranskning, rättslig certifiering eller validering mot fullständiga primärhandlingar från kommunala ärenden.*
