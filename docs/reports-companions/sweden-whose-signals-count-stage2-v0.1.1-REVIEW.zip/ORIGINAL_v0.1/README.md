# Sweden — Whose Signals Count? | Sverige — Vems signaler räknas?

**Stage:** 2 — companion to *The Competence Trap / Kompetensfällan*  
**Version:** v0.1 research working draft  
**Date:** 12 November 2026

## Contents

- `01-whose-signals-count.en.md` — English companion report, complete research working draft.
- `01-whose-signals-count.sv.md` — corresponding Swedish report, with the same scope, cases, research design and limitations.
- `02-adversarial-review-brief.md` — brief for independent critical review.
- `03-source-evidence-ledger.csv` — source IDs, specific claims, limitations and pending verification.
- `SHA256_MANIFEST.txt` — package content checksums.

## Editorial principles

This package does not amend the Stage 1 report or claim that DeepSeek's critique has been validated. It treats critical theory, decoloniality, intersectionality and other perspectives as hypothesis-generating analytical lenses. It separates documented source facts, attributed assessments, causal hypotheses and normative recommendations. It distinguishes current law from proposals and does not confuse income Gini with wealth concentration.

## Suggested workflow

1. Review this v0.1 independently, preferably with a legal subject-matter reviewer and a methodological adversary.
2. Correct evidentiary and translation issues in v0.1.1 without changing the parent report.
3. Select and preregister bounded cases; obtain primary records and affected-party input through appropriate processes.
4. Only after case-level findings, write a formal synthesis identifying what survives and what changes in the original Competence Trap diagnosis and Framtidskommuner design.

**Do not describe this document as a validated comprehensive study of Sweden.**
