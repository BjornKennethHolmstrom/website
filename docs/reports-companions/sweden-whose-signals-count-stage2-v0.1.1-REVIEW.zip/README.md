# Sweden — Whose Signals Count? Stage 2 v0.1.1

**Prepared:** 12 November 2026  
**Status:** pre-publication bilingual research agenda; **legal review NOT completed**. Not an empirical national diagnosis.

**Contents**

- `01-whose-signals-count.en.md` — full English revised companion.
- `01-whose-signals-count.sv.md` — full Swedish revised companion.
- `02-source-evidence-ledger.csv` — S01–S28 verification/status register.
- `03-round2-dispositions-and-release-gate.md` — accepted/corrected claims and blockers.
- `04-language-concordance.md` — six material EN/SV alignment questions.
- `05-v0.1-to-v0.1.1.diff` — bilingual unified editorial patch.
- `ORIGINAL_v0.1/` — verbatim original EN, SV, ledger and README, retained for comparison.
- `SHA256_MANIFEST.txt` — hashes for all other files.

**Principal decisions**

1. Keep evocative main title, but identify the work as a research agenda, not completed case analysis.
2. Treat information, attention, influence, capacity, efficacy and legal rights separately.
3. Put the 2025 and 2027 Swedish legal changes in their specific scope; no blanket research linkage.
4. State bounded *Girjas* ruling, Sámi consultation law, CERD opinions and Truth Commission calls without equating them.
5. Define a feasible *proposed* municipal child-protection pathway study with no claims of obtained access or ethical clearance.
6. Preserve the parent report, original v0.1 and external audits untouched.

**Before public release:** Swedish specialist legal review (Sámi law and secrecy/information-sharing), author verification of claims and bilingual passages, and a decision on how explicitly to disclose remaining unverified source links. The current package does **not** certify any of those steps.
