# Stage 2 adversarial review brief / Instruktion för oberoende granskning

**Object:** `01-whose-signals-count.en.md` and `01-whose-signals-count.sv.md` (v0.1, 12 November 2026).  
**Purpose:** pressure-test the claims *before* treating the companion as a settled country analysis. Keep the Stage 1 parent report unchanged during this review.

## Required review output

1. **Claim audit:** For each empirical/legal claim carrying [Sxx], verify it against the exact underlying document (not merely the source title), assess whether the language overstates the evidence, and flag any link or year errors. Cite precise statute clauses and report pages where relevant.
2. **Rival-explanation challenge:** For every proposed information, incentive, representation or rights mechanism, state a plausible alternative that could explain the same observation. Note any hypothesis not currently falsifiable with realistically available records.
3. **Normative audit:** Identify places where a preferred normative conclusion is hidden inside a descriptive statement. Distinguish consultation, substantive rights and FPIC; avoid conflating human-rights advocacy with a court determination.
4. **Methods and safeguards audit:** Assess whether proposed municipal comparison, intersectional breakdown, data access, privacy, and citizen deliberation are realistically feasible and legally supportable. Identify possible design-induced harms.
5. **Parent/companion traceability:** Identify whether the draft improperly claims omissions already corrected in the Stage 1 parent; propose only evidence-justified subsequent modifications to the parent.
6. **Bilingual equivalence:** Flag material differences between English and Swedish claims, qualifications, references, status, recommendations, and the direction of causal hypotheses.

## Format for returned findings

| ID | Severity (critical/major/minor) | File and section | Claim or omission | Evidence/source | Proposed remedy | Would change parent report? |
|---|---|---|---|---|---|---|

Then give a **two-column verdict**: (a) *safe to publish as an exploratory working paper?* and (b) *safe to make causal or legal conclusions?* Use Yes / No / Conditional, with reasons. Explicitly identify what additional research would resolve each major uncertainty.

## High-priority red-team prompts

- Is “power” operationalized sufficiently to avoid self-sealing explanations? Where might a legitimate privacy boundary or rights constraint be falsely coded as domination?
- Could unequal social outcomes arise without exclusion from political agenda-setting? What data would separate these explanations?
- Does the account of the 2025 information-sharing changes mistakenly treat a legislative proposal as enacted (or vice versa)?
- Are the relevant Sámi consultation rights, land rights, and actual domestic enforceability properly distinguished? Is FPIC's legal status represented with appropriate nuance?
- Does the pilot design genuinely prevent local elite capture and epistemic capture of research teams?
- Are income inequality, wealth inequality and discrimination complaints kept analytically distinct?

**Instruction to reviewers:** Do not assume the Stage 1 diagnosis is true or false. Reward well-supported narrowing or disconfirmation of the Stage 2 hypotheses. Identify external evidence needed rather than inventing it.
