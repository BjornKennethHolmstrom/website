# Downstream handoff (pending source acceptance)

- Replace corresponding route +page.svelte and sections only after approval. Copy each revised PDF generator to scripts/; keep original simulation and registration files as historical artifacts. Do not run old training scripts as reproduction.
- Preserve public routes, cover images, output PDF filenames and July 2026 publication date. Verify Swedish URLs and revision date display, provenance module, math rendering, fonts, tables and complete SvelteKit/PDF builds. The supplied generators already use KaTeX, and their rendering code is unchanged; `throwOnError: false` is a known integration risk. No builds were run.
- XIX and XXIII METADATA.json provide proposed subtitle/description values for working-papers.ts and core.ts, adapt to existing keys and shorter carousel descriptions. No listing files modified yet.
- Reconcile papers.yaml, atlas §10, both briefs, syntheses.ts, project paper-19/23 copies and dependencies XVI→XIX, XVII, XXIII→XIX, Paper 0/XIV as appropriate. XIX tier must not present noncausal or unverified historical counts as verified online results; XXIII must distinguish squared measure, RMS re-score, directed cost proxy and selected routes from a staging mechanism. Correct garbled stress-rescaling null wording. Retain GA-F01/02 accepted scientific content. Consolidated integration after GA-F04.
- New experiments are optional and separate: causal warning evaluation, bridge ablation, held-out cost reference or redesigned staging cube. No new training required to close the source correction.

## Review outcome

XIX v0.1 accepted, XXIII v0.2 pending focused confirmation. Publish corrected VI and XX first or together. Make this full evidence archive accessible alongside both papers, including checks/asymmetry_floor_check.py. Do not mistake standalone source packages for the full correction archive.
