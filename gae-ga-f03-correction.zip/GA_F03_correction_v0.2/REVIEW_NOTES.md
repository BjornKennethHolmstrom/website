# Correction dispositions and independent review brief

## XIX

| Finding | Draft disposition |
|---|---|
| XIX-01 | §3 + A: forecast maturity through t+19, next-origin conservative clock, offline contrast only; persistence and incumbent caveat |
| XIX-02 | §4 + A: centered-window through t+28; all three effective lead ranges; no online claim |
| XIX-03 | §4: episode/timestep mismatch, earliest spike, nominal score, chance baseline and tie sensitivity |
| XIX-04 | §6 + A: flag write line 532, full-stream not regime graph; 19/20 remains unverified |
| XIX-05 | §6: RMS loss distance, cut-vertex proof, mean-loss bound, level-only witness, threshold sensitivity, withdraw mediation/dissociation claim |
| XIX-06 | §§2–5, A: P1 FAIL despite subcontrast; P3 FAIL; P2 nominal pass only; preserve P4 reports without certifying criterion |
| XIX-07 | §§2–3,9,A: build-before-seed, same-length seeds, hash/cache risks and validation task mismatch; no recovered outputs |

§7 explicitly withdraws automatic mechanism for XVI, certification mandate and demonstrated fragmentation/translation; retains candidate functions and research questions. Metadata/context/citation updated to reflect that status.

## XXIII

| Finding | Draft disposition |
|---|---|
| XXIII-01 | §2,3: actual squared prediction dissimilarity, RMS root pseudometric, distinction from XIX; observed triangle violations and exploratory RMS re-score |
| XXIII-02 | §3.2 + A.1: cut proof, scale/arrangement distinction; unsupported overshoot withdrawn |
| XXIII-03 | §3.3 + §8.1: gate 20/20; H_bridge 2/20; threshold 13/20; no general invariance or functional inference |
| XXIII-04 | §3.4: 1/20, full panel change .242, fixed edge count 9/21 and dependent invariants; bounded failure |
| XXIII-05 | §4.1–2, B.4: separate report n/a vs v4 .656/.763; repeats/unit sensitivity .544; symmetric squared-error identity not rank ceiling |
| XXIII-06 | §2.3,4.2,B: actual discrete cost proxy; mixed samples; cap 90.3%; censoring; no convergence or positive transfer certification |
| XXIII-07 | §4.3,7,B: five tests, matched step control, selection, candidate duplicates, destination-inclusion artifact, mechanism inconclusive; .313 explicitly review-reported and not relied upon |
| XXIII-08 | §4.4,5,A: actual additive leg costs, model-pair induced map well typed, possible directed path geometry; unsupported triangle-rate and universal noncomposition removed |
| XXIII-09 | six duplicate Swedish bodies replaced by single revised sections; metadata/page/PDF headings corrected |
| XXIII-10 | §3.1,3.4: all full-panel figures, first-three comparison, no asserted drafting history |

New required sensitivity: §4.2 includes v4 seed median .763 and mean-draw pooled medians .761 (150), .694 (121 at cap), 1.000 (29 any early stop), .677 (125 positive), 1.000 (25 zero). The supplied script computes medians, not every early-stop pair being exactly 1; do not infer that all 29 pairs have clipped zeros from the median (only 25 zero-cost pairs overall). Script and actual output preserved. No new training. This is a qualification of the review's prose, not a new empirical claim.

## Independent review requested

Review each paper independently against original archives and accepted audit, then their shared consistency. Verify all findings remain resolved, historical vs table replay vs exploratory tiers, every quoted statistic and denominator, time indexing, graph proof and typed cost construction. Check the new asymmetry output and distinction between pooled and seed medians. Check Swedish meaning (not just headings), references, metadata, and whether condensation removed useful defensible arguments. Check all 22 section pairs, render math and build only if feasible. Do not modify files or initiate training. Return ACCEPT_CORRECTION, REVISE_CORRECTION or BLOCK separately for XIX and XXIII. Acceptance of source does not authorize publication or downstream integration. Report limitations explicitly.

## v0.2 follow-up

See SOURCE_ACCEPTANCE_RECORD.md. XIX accepted unchanged. XXIII factual correction and exploratory wording softening only; four files changed. Focused independent confirmation pending.
