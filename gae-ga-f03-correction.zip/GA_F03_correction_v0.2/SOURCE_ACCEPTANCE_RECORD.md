# GA-F03 source correction status — 25 November 2026

- GA-F03-A audit v0.2: ACCEPT_AUDIT (previous independent review; frozen).
- XIX v0.1: ACCEPT_CORRECTION (Claude's verdict supplied by author in chat). Reviewed archive SHA-256: `21e2b8e0ac8465073d3c8fa2c6663a8958e840e3ae5fb8e47de5c0be432a69c4`. No modifications; source acceptance only.
- XXIII v0.1: REVISE_CORRECTION (one factual correction required). Reviewed archive SHA-256: `935a3cc189c4e8a7f93e33fe1a9354256429543a632d7ac46fcb0f0f4dedb6b5`.
- XXIII v0.2: patched candidate, awaiting focused confirmation. SHA-256: `0098a888b0c20fbaa024f590cf9e63ab5eb9082713bd8835d32cff096703d1bf`. Not independently accepted yet.

## XXIII v0.2 disposition

1. Appendix B.1, both languages: original v1 median directed asymmetry 0.79; smoke-run median relative asymmetry 1.000, not symmetric correlation. Checked against the original EN/SV Appendix B in the archived original. Historical status and missing outputs unchanged.
2. Section 4.1, both languages: the exploratory result cautions against dismissing the association as decorative; it does not rule out that interpretation. Registered failure and exploratory classification unchanged.

Only these four Markdown files differ from the reviewed XXIII v0.1 tree. No mathematical expressions, headings, code, data, metadata, Svelte page, PDF generator or historical registration changed. XIX's tree is byte-identical. Optional reviewer additions deferred; they do not block source acceptance. New reviewer check ZIP is preserved under evidence/ and the existing asymmetry script is byte-identical to its copy inside that ZIP. The stored asymmetry output reproduced exactly in this turn. No new training or full website/PDF build; reviewer checks requiring Marked and TypeScript were not rerun in this environment. No claim of authenticated historical run provenance, bibliography verification, or human specialist review.

The full combined archive is the reproducibility companion referenced in XIX and XXIII. It contains the original sources, accepted audit, recovered tables and supporting scripts, including checks/asymmetry_floor_check.py. Publish or link it when integrating the papers; the individual source archives are not complete evidence packages. Corrected VI and XX must precede or accompany publication. Consolidated downstream reconciliation remains pending. Neither paper is certified for publication here.
