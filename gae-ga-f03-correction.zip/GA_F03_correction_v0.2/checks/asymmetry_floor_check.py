#!/usr/bin/env python3
"""Reviewer check for GA-F03-A v0.2: sensitivity of XXIII's paired cost asymmetry to reference-floor status.
Usage: python3 -I asymmetry_floor_check.py path/to/xxiii_out
Pairs are (A,B) with different homes; costs are mean draws per (source, target regime); asymmetry = |c_AB-c_BA|/max."""
import sys, glob, itertools, numpy as np, pandas as pd
c = pd.concat([pd.read_csv(f) for f in sorted(glob.glob(f'{sys.argv[1]}/transition_costs_v4_seed*.csv'))])
HOME = {'normal_h8': 'normal', 'normal_h16': 'normal', 'compressed_h2': 'normal', 'wind_h8': 'wind',
        'damped_h8': 'damped', 'blur_h8': 'blur', 'velocity_aux_h8': 'normal'}
CAP = 1400; res = {'all': [], 'both_refs_at_cap': [], 'any_ref_early_stopped': [], 'both_costs_positive': [], 'one_cost_zero': []}
for s, g in c.groupby('seed'):
    m = g.groupby(['src', 'target_regime']).agg(cost=('d_cost', 'mean'), steps=('ref_train_steps', 'first')).to_dict('index')
    for a, b in itertools.combinations(HOME, 2):
        if HOME[a] == HOME[b]: continue
        x, y = m[(a, HOME[b])], m[(b, HOME[a])]; v = abs(x['cost'] - y['cost']) / max(x['cost'], y['cost'], 1e-9)
        res['all'].append(v)
        res['both_refs_at_cap' if x['steps'] == CAP and y['steps'] == CAP else 'any_ref_early_stopped'].append(v)
        res['one_cost_zero' if min(x['cost'], y['cost']) == 0 else 'both_costs_positive'].append(v)
for k, v in res.items(): print(f"{k:22s} n={len(v):3d}  median asymmetry {np.median(v):.3f}")
