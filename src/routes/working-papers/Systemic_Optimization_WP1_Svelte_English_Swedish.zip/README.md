# Systemic Optimization — Working Paper 1 · SvelteKit route

This package matches the established Working Paper 0 page architecture (Svelte 5 runes, `language` store, `SEO`, `Provenance`, `ShareButtons`, `marked`, `katex`, Tailwind `prose`).

## Install

Copy **`src/`** and **`static/`** from this ZIP into the root of the existing SvelteKit website. The page route becomes `/working-papers/what-if-the-model-is-incomplete`.

The page switches between **complete English and Swedish Markdown** when `$language` changes. The one PDF supplied is in English; the Swedish page links to it with a label that says so. The page includes five English and five Swedish-localized figure images, with identical underlying data.

## Content and assets

- `src/routes/working-papers/what-if-the-model-is-incomplete/+page.svelte`
- 28 Markdown sections under the route's `sections/` folder: 14 English, 14 Swedish (frontmatter, abstract, sections 1–8, appendices A–C, references).
- `static/working-papers/what-if-the-model-is-incomplete/` contains the 30-page English PDF and ten figures (five per language).
- `documents/` contains one **complete Markdown** file in each language, with corrected literal `|` escapes in Appendix B policy labels. All numeric results and the manuscript's scientific statements are retained.

The Svelte page imports your existing `$lib` components and language store, just like Working Paper 0. Ensure that `marked` and `katex` are installed (already used by Working Paper 0). Add the link to this new route wherever your working-paper index is maintained. No existing route is overwritten by this package.

## QA notes

The English PDF uses Working Paper 0's DOCX reference styles for A4 typography, running heads and footers, and a more readable print-only paragraph layout for Appendix A's seven-column evidence matrix. In web Markdown the original structured tables are retained with corrected escaping; the scientific data are unchanged. Swedish versions of all five figures use the frozen figure data with translated presentation labels.
