---
title: "What If the Model Is Incomplete?"
subtitle: "Computational Experiments on Causal Representation, Ecological Objectives, and the Limits of Learning"
author: "Björn Kenneth Holmström"
date: "6 November 2026"
series: "Systemic Optimization — Working Paper 1"
version: "Draft v0.2 — integrated series revision (A2-S2), for text audit"
---

# What If the Model Is Incomplete?

*Computational Experiments on Causal Representation, Ecological Objectives, and the Limits of Learning*

**Systemic Optimization — Working Paper 1**  
**Björn Kenneth Holmström**  
**6 November 2026 · Draft v0.2 — integrated series revision, for text audit**

> **Revision note (v0.2).** Rewrites the internal draft A2-S1 v0.1 as the second paper in the series, following an editorial and scientific audit. It corrects the attribution of E0's full-start clairvoyant comparison (O\*), which v0.1 had attributed to the fixed-probe oracle X\*. The evidence appendices are now inlined and the references source-checked. No frozen experimental verdict, estimand or number has been altered, and no new simulation was run. The experiment and its records carry the programme identifier **A2**.

> **Evidence convention.** As in Working Paper 0:
>
> - **[R]** marks a result established within the specified computational model. Its status is stated alongside it:
>   - *confirmatory*: a prespecified test on the committed 40-world sample;
>   - *prespecified descriptive*;
>   - *exploratory*: declared in advance on development worlds, or post hoc;
>   - *structural*: an exact property of the model.
> - **[IP]** marks an interpretive proposition.
> - **[H]** marks a hypothesis for future investigation.
>
> The fine-grained status codes are given in Appendix A. A result inside a synthetic model is not, by itself, evidence about real catchments or institutions.

## Abstract

An optimizer can solve its formal problem correctly while choosing poorly for the world it acts in. The difficulty may lie in what the objective values, in which causal mechanisms the model represents, or in whether the planner's own decisions let it discover what it has omitted.

Following *Systemic Optimization — Working Paper 0*, we examine how these failures interact. The setting is an eleven-period synthetic flood-adaptation model of three municipalities. Three hydrological mechanisms can be switched on or off independently, both in the physical world and in the planning model: downstream wetland retention, peak synchronisation, and rainfall dependence between catchments.

We distinguish three responses:

- assuming a missing mechanism into the model ("re-model");
- changing the objective to reward ecological capital ("re-value");
- acting in order to learn which mechanisms operate.

Only the first two are compared in the confirmatory test. Learning is studied exploratorily in preselected development worlds.

**Confirmatory results.** The test used 40 independently drawn synthetic worlds and a declared hypothetical equal weighting of retention present and absent.

- Assuming retention while minimising the original cost criterion U1 had lower mean U1 cost than optimising an ecological objective on the retention-omitting model. The mean difference was −1.112 (95% CI −1.737 to −0.487). The interval missed its planned precision.
- The ecological objective achieved lower wetland deficit and a larger terminal wetland stock.

**Descriptive and exploratory results.**

- A prespecified descriptive comparison found a much smaller mean omission-related U1 contrast under the ecological objective (+0.014 versus +1.851). That came with a U1 price of +1.085 when the model was correct.
- Under planning-parameter error, the observed U1 advantage of the assumption-based strategy nearly vanished.
- A passive policy can leave a decision-relevant mechanism permanently unobservable.
- An exact Bayesian probe-then-commit learner, despite noise-free state observations, captured at most about a fifth of a fixed-probe oracle's margin.

These results concern one synthetic model family, not observed catchments. They suggest that causal representation, objective choice and opportunities to observe must be evaluated together, because changing one alters the costs and possibilities of the others.

**Keywords:** systemic optimization; model incompleteness; causal representation; surrogate objectives; ecological objectives; identifiability; value of information; adaptive management; computational preregistration.

## 1. A correct solution to an incomplete problem

Optimization starts only after someone has decided three things:

- what the planner should value;
- which consequences its model should include;
- what evidence it is allowed to collect.

A policy may be optimal for those choices and still be a poor response to the physical system. That is not a failure of calculation. It is a failure, or an untested assumption, in the *construction of the problem being calculated*.

Working Paper 0 (Holmström, 2026) separated four kinds of adequacy: the objective, the causal model, information about future goals, and learning. Its flood experiment, A1, found that an ecological term in the objective could partly substitute for hydrological structure omitted from the planner's model. The structural-substitution contrast was a difference-in-differences equal to 34.3% of the narrow model's regret.

A1's narrow model omitted three mechanisms *at once*: downstream retention, peak synchronisation and rainfall correlation. That design left the central question open. Which omission mattered? And would an objective change still be worth its price if the mechanisms were switched independently, or if the planner simply represented them?

This paper takes up that question. It uses a fork of the same flood model in which each mechanism can be switched on or off by itself, in the world and in the model. The two papers are deliberately not comparable in their numbers:

- A1's estimand was an objective-substitution difference-in-differences against a bundled omission, evaluated on 800 Latin-hypercube worlds.
- The present confirmatory estimand is a contrast between two policy packages on 40 independently drawn worlds.

No figure from one paper should be read as a replication of a figure from the other.

### 1.1 Three responses, not three repairs

A planner who suspects its model is incomplete has at least three responses.

- **Re-model.** It can write the mechanism into its model before having evidence for it.
- **Re-value.** It can change its objective, so that protecting a valued resource incidentally protects against the omitted consequence.
- **Learn.** It can act to find out which mechanisms operate.

These are not interchangeable repairs.

- **Re-modelling without evidence is an assumption.** We call the strategy REP, for "repair", but the label names the strategy, not a claim that its model is right. REP includes no inference and no cost of acquiring the model. When the mechanism is absent, REP plans on a wrong model.
- **Re-valuing may buy insensitivity to the omission.** That insensitivity carries a measurable price under the original criterion.
- **Learning requires the mechanism to be exposed.** The system must visit states in which the mechanism changes what can be observed, and there must be enough time left to use what is learned. Exposure may itself require actions that the current policy has no reason to take.

These responses have long histories under other names:

- adaptive management and dual control (Walters & Hilborn, 1978; Walters, 1986; Fel'dbaum, 1960);
- robustness to misspecification (Hansen & Sargent, 2008; Lempert, Popper & Bankes, 2003);
- the value of information (Raiffa & Schlaifer, 1961; Howard, 1966);
- multi-objective formulation (Marler & Arora, 2004).

This paper does not claim to introduce them. Its narrower aim is to place them in one exactly solvable decision problem. There, the consequences of each can be traced, and the interactions between them made visible.

### 1.2 What this paper establishes and what it does not

**One confirmatory comparison.** The paper reports one confirmatory comparison, sealed in advance: a re-modelled policy against a re-valued policy, on 40 synthetic test worlds. It found a criterion-dependent trade-off (§3).

**Prespecified descriptive contrasts.** These explain the trade-off as robustness bought at a price (§4).

**Exploratory studies.** Their status is stated in each place:

- how the trade-off changes with parameter error, rain shifts and other mechanisms (§4.3);
- why exposure does not guarantee learning, studied in preselected development worlds (§5).

The learning studies are not a third arm of the confirmatory test.

**Scope.**

- Every world is a synthetic parameter draw.
- The equal weighting of "retention present" and "retention absent" is a hypothetical prior, not an estimate.
- Nothing here is a recommendation for a real catchment.

## 2. What is represented, what is optimized, what is observed

### 2.1 The flood model

The model is the A1 three-municipality flood system, with A1's solver, accounting and evaluation criterion unchanged.

**Municipalities.** Two upstream municipalities and one downstream municipality. We call them Up1, Up2 and Dn, to avoid a clash with the criteria names U1 and U2.

**State.** 31,104 states in total, made up of:

- each municipality's budget level and flood-protection capacity;
- each upstream municipality's wetland level $w_i\in\{0,1,2\}$;
- a wet/dry regime.

**Actions.** In each of the eleven periods:

- each upstream municipality may hold, build protection, or restore wetland;
- the downstream municipality may hold, build, or co-fund upstream restoration;
- a pool option $o\in\{0,1\}$, chosen once, buys into a regional relief pool for a fee.

**Rain.** Rain falls at one of three levels in each upstream catchment.

**Evaluation criterion U1.** U1 charges spending and pool fees, residual flood damage after relief, a budget-shortfall penalty, and monetised harm, with a terminal salvage value. U2 adds a penalty on the largest single-municipality residual damage. U2 is a simple distribution-sensitive variant, not a complete account of fairness.

Policies are computed by exact finite-horizon dynamic programming (Puterman, 1994), up to floating-point and tie-breaking precision. They are evaluated exactly by propagating state occupancies. Independent Monte Carlo simulation checks the evaluations statistically (Appendix C).

### 2.2 Switching mechanisms on and off

A *mask* records which of three mechanisms are present, written in the order R, S, C. Mask 111 has all three; 011 lacks retention.

| Mechanism | Present | Absent |
|:---|:---|:---|
| **R** downstream retention | the downstream flood load starts from *post-retention* upstream runoff, so upstream wetlands protect downstream | the load starts from raw upstream runoff |
| **S** peak synchronisation | a signed term proportional to the smaller upstream retention fraction adjusts the downstream load | no such term |
| **C** rainfall dependence | Gaussian-copula correlation between the two catchments' rain | independent rain, same marginals |

The *physical* mask $m^*$ describes the world. The *represented* mask $m$ describes the planner's model. All 8 × 8 combinations are evaluated within each base world.

**Planning conditions.**

- **Parameters.** Planning parameters equal the true ones ($s=0$), or are drawn from a declared perturbation ($s=0.25$, two draws).
- **Rain shift.** At evaluation the probability of heavy rain may be shifted by $\psi\in\{-0.1,0,+0.1\}$.

**Consistency with A1.** Mask 111 reproduces A1's full model exactly, and mask 000 reproduces A1's bundled narrow model exactly, array for array. The A2 test suite checks this.

**[R, structural] Exposure.** Upstream retention is proportional to wetland level. With no upstream wetland, the models with and without R produce identical transitions. The synchronisation term vanishes whenever either wetland is empty. A policy that never builds wetland therefore never enters a state in which R or S makes any observable difference.

### 2.3 What is optimized and how it is judged

**Planning objectives.**

- **F0** minimises expected U1.
- **F1-eco** adds a penalty for missing upstream wetland:

$$
\min_\pi\ \mathbb{E}_\pi\Big[\sum_{t=0}^{10} c^{U1}_t + \text{salvage}\Big]+\lambda\,\mathbb{E}_\pi\Big[\sum_{t=0}^{10} g_t\Big],\qquad g_t=\tfrac{2-w_{1,t}}{2}+\tfrac{2-w_{2,t}}{2}.
$$

  Here $\lambda=0.1\cdot\mathrm{range}(\text{cost})/\mathrm{range}(g)$ is computed on each planning model, as in A1.
- **F1-eco-fixed** holds $\lambda$ at its value on the full model. It checks that conclusions do not depend on recomputing $\lambda$.

**Evaluation criteria.** Every policy is judged on four criteria, all minimised, under the true scenario and with the policy's own pool choice:

- $J_{U1}$ and $J_{U2}$: the costs defined in §2.1;
- $J_{def}=\mathbb{E}\sum_t g_t$: the cumulative upstream wetland deficit;
- $J_{stock}=-\mathbb{E}[w_1+w_2]$ at the end of the horizon: the negative terminal wetland stock.

Each criterion has its own exact oracle.

### 2.4 Two changes at once: the policy packages

For a mechanism $X$ and a baseline mask $m_0$ lacking it, four strategies form a 2 × 2.

|  | objective F0 | objective F1-eco |
|:---|:---|:---|
| model $m_0$ ($X$ omitted) | OMIT | **COMP** (re-value) |
| model $m_0\cup X$ ($X$ assumed) | **REP**($X$) (re-model) | BOTH($X$) |

The confirmatory contrast compares the two highlighted cells, for $X=R$ and $m_0=011$:

$$
\Delta_i=\tfrac12\sum_{m^*\in\{111,\,011\}}\Big[J_{U1}\big(\pi^{F0}_{111};m^*\big)-J_{U1}\big(\pi^{F1\text{-eco}}_{011};m^*\big)\Big].
$$

- **What it averages.** Each world $i$ contributes the average over retention present and absent, with equal hypothetical weight.
- **Sign.** $\Delta_i<0$ means REP had the lower U1.
- **A package contrast.** The comparison changes *both* the represented mechanism *and* the objective. It estimates the difference between two policy packages, not the isolated effect of either change. The other two cells of the 2 × 2, and a regret decomposition, are used below to interpret it.

**MIX.** A further benchmark plans with F0 on a per-period average of the two models, with weight $q$ on the model with $X$. It is a heuristic, not an optimal plan for a world whose mechanism is fixed but unknown.

### 2.5 Where regret comes from

For a strategy evaluated on criterion $J$ in a given scenario, regret against the $J$-oracle splits into three terms:

$$
J(\pi_a)-J(\pi_d)=\underbrace{[J(\pi_a)-J(\pi_b)]}_{\text{representation}}+\underbrace{[J(\pi_b)-J(\pi_c)]}_{\text{parameters and shift}}+\underbrace{[J(\pi_c)-J(\pi_d)]}_{\text{objective}}.
$$

The policies are:

- $\pi_a$: the deployed strategy;
- $\pi_b$: the same objective on the correct mechanisms;
- $\pi_c$: the same objective with correct mechanisms and parameters;
- $\pi_d$: the $J$-oracle.

The parameter term is exactly zero at $s=0,\psi=0$. These are order-dependent accounting components, not unique causal effects.

### 2.6 Evidence design

| Stage | Worlds | Role |
|:---|:---|:---|
| Gate C pilot | 8 development worlds | exploratory omission factorial |
| Exposure and learning studies | preselected development worlds | exploratory |
| Development run | 16 development worlds | sample-size planning |
| **Confirmatory test** | **40 worlds**, independently and uniformly drawn over the frozen parameter ranges from a reserved random stream, once code and configuration were frozen | **confirmatory** |

**Confirmatory test.**

- **Primary test:** a two-sided one-sample $t$-test of mean $\Delta$ (df 39).
- **Precision target:** a 95% CI half-width of 0.50 U1. The development standard deviation implied fewer than 40 worlds, so the declared floor of 40 applied.
- **Secondary family:** four tests, Holm-adjusted (Holm, 1979): $\Delta$ on $J_{U2}$, $J_{def}$ and $J_{stock}$, and BOTH(R) − REP(R) on $J_{U1}$.
- Everything else in the factorial was declared descriptive or is exploratory.

**Discipline.** As in Working Paper 0:

- declarations were timestamped before runs;
- failed verification gates were kept as failures and corrected only by newly declared gates;
- the reserved test stream could be derived only once, by an authorised stage.

Appendix C gives the provenance record, including its limits.

## 3. What the confirmatory comparison shows

### 3.1 Re-modelling had the lower mean cost [R, confirmatory]

Under the hypothetical equal weighting, REP(R) had a lower population-mean U1 than COMP. The mean difference was **−1.112** U1 (95% CI −1.737 to −0.487; $t(39)=-3.60$, $p=0.00089$).

The null hypothesis of zero mean difference is rejected at the declared level. The planned precision was not reached: the interval's half-width was 0.625, against a target of 0.50. The standard deviation of $\Delta_i$ in the test sample (1.954) was much larger than in development (1.138), and the sample was not enlarged.

**The worlds disagree** (Figure 1):

- 30 of the 40 worlds favour REP;
- in a quarter of them, compensation is as cheap or cheaper;
- the extremes are −6.10 (world t39) and +4.92 (world t18);
- the median is −0.382 and the skewness −0.22.

Two descriptive checks, declared as such, agree in direction with the $t$-interval: a percentile bootstrap interval of [−1.705, −0.518] and a Wilcoxon signed-rank $p=1.1\times10^{-4}$.

![Primary contrast per test world](figures/wp1_fig1_primary_delta.png)

*Figure 1.* $\Delta_i$ for the 40 test worlds, sorted, with the mean. The shaded band is the 95% confidence interval **for the mean**, not a range that individual worlds should fall in. Source: `f0c_confirmatory.json`. [R, confirmatory]

### 3.2 The ecological side of the ledger [R, confirmatory]

The secondary family shows the other side of the comparison.

| Contrast | Mean | 95% CI (unadjusted) | Holm-adjusted $p$ | Lower on this criterion |
|:---|---:|:---|---:|:---|
| $\Delta J_{U2}$ (cost units) | −1.061 | [−1.734, −0.388] | 0.0028 | REP |
| $\Delta J_{def}$ (deficit units over 11 periods) | +6.362 | [+4.235, +8.489] | 1.3 × 10⁻⁶ | COMP |
| $\Delta J_{stock}$ (negative terminal wetland level) | +1.543 | [+1.056, +2.030] | 5.6 × 10⁻⁷ | COMP |
| BOTH(R) − REP(R), $J_{U1}$ | +1.603 | [+0.992, +2.214] | 9.6 × 10⁻⁶ | REP |

The intervals are ordinary 95% intervals and are not adjusted for multiplicity. Only the $p$-values are Holm-adjusted.

- On the distribution-sensitive cost, REP's advantage is about the same as on U1.
- COMP leaves less cumulative wetland deficit and more wetland at the end of the horizon.
- Re-modelling *and* re-valuing (BOTH) cost more U1 than re-modelling alone. BOTH's ecological outcomes were not part of the test.

![Prespecified criterion contrasts](figures/wp1_fig2_criterion_contrasts.png)

*Figure 2.* Prespecified contrasts, each on its own scale. Source: `f0c_confirmatory.json`. [R, confirmatory]

### 3.3 A comparison of packages, not a verdict on model repair [IP]

Two features of the result protect it from a tempting misreading.

**REP is an assumption, not a discovery.** In the half of the weighting where retention is absent, REP plans on a wrong model, and its U1 is still lower than COMP's (branch mean −1.125, 95% CI −2.126 to −0.124, a descriptive subgroup). Being wrong about the world was cheaper on U1 than paying for the ecological objective.

The 40-world regret decomposition, an exploratory reading of the frozen tables (Appendix B, T4), gives the reason:

- REP's misspecification cost in that branch is +1.765 U1;
- COMP's objective price is +2.890;
- the development worlds gave the same ordering (1.06 against 2.42).

The result is therefore an objective-mismatch comparison. It is not evidence that the planner *found* the right model.

**The contrast changes two things.** Moving from COMP to REP adds a mechanism to the model *and* removes the ecological term from the objective. The confirmed difference belongs to that package. It cannot be attributed to "better modelling" alone, and it says nothing about whether *spending* on better models beats spending on objectives or information. No such spending was modelled.

### 3.4 What the trade-off does and does not establish

**[R, derived from the confirmatory tests]** For the prespecified REP(R)-versus-COMP comparison, under the hypothetical equal weighting, the mean differences point in opposite directions on the named criteria:

- REP has lower U1 and U2;
- COMP has lower cumulative deficit and higher terminal stock.

Neither of these two policies is uniformly preferable. This is a logical combination of the four results, not a further test.

It says nothing about all strategies. In the exploratory tables, the heuristic MIX(R, q) has a lower equal-weight mean U1 than either pure F0 plan: 6.465–6.638, against 6.967 when retention is omitted and 6.924 when it is assumed (Appendix B, T5). REP thus beats COMP on U1 but is not the U1-best policy that was evaluated.

That MIX result has limits. MIX is not a correct plan for a fixed but unknown world, and the comparison is exploratory, with world means only.

## 4. Why objective robustness has a price

### 4.1 An objective that hardly notices the omission [R, prespecified descriptive]

How much does omitting retention cost each objective when retention is present? The representation term answers this. It is the U1 lost by planning on 011 rather than 111, averaged over the 40 worlds at $s=0,\psi=0$.

| Objective | Mean representation term (U1) | 95% interval |
|:---|---:|:---|
| F0 | **+1.851** | [+0.802, +2.900] |
| F1-eco | **+0.014** | [−0.173, +0.201] |
| F1-eco-fixed | +0.094 | [−0.206, +0.395] |

The observed mean omission cost under the ecological objective was **much smaller in this sample** than under F0. This was a declared descriptive comparison, not an equivalence test:

- no equivalence margin was set;
- the F1-eco interval contains both meaningful positive and negative values;
- the fixed-$\lambda$ variant shows that the result does not hinge on recomputing $\lambda$, and nothing more;
- one mechanism and one baseline were examined.

**[IP]** A plausible reading is that the ecological objective already builds upstream wetland for its own reasons, so learning that wetland also protects the downstream municipality changes little in its plan. F0 builds wetland only when its model says that it pays.

### 4.2 The price [R, prespecified descriptive]

The ecological objective is paid for even when the model is right. Its objective term under the correct model is **+1.085** U1 (95% interval +0.612 to +1.558).

This explains the shape of the confirmatory result. In the exploratory 40-world decomposition (Appendix B, T4):

- COMP pays its objective price in both branches: +1.085 when retention is present, +2.890 when it is absent;
- REP pays for misspecification only when retention is absent: +1.765.

Under an equal weighting, the always-paid price outweighs the sometimes-paid misspecification.

![Robustness and price](figures/wp1_fig3_robustness_price.png)

*Figure 3.* **A:** omission terms and the ecological objective's price, means with 95% intervals over 40 worlds; prespecified descriptive. Source: `f0c_descriptive.json`. **B:** omission terms by rain shift, world means only; exploratory (Appendix B, T2).

**[IP — Robustness is a purchase.]** An objective that makes a plan insensitive to an omitted mechanism has, in effect, bought insurance against that omission. Whether the purchase is worth it depends on how likely the mechanism is, how costly it is to omit, and how much the insurance costs when it is not needed. Calling the surrogate objective "robust" without naming the price conceals half of the comparison.

### 4.3 When the picture changes [R, exploratory]

The confirmatory comparison was fixed at exact planning parameters, no rain shift, and one mechanism. The frozen factorial contains other conditions. Their tables were declared before computation and are reported in full in Appendix B, with all counterexamples. They are exploratory and cannot alter the confirmatory verdict.

**Parameter error.** With perturbed planning parameters ($s=0.25$), REP's mean U1 advantage nearly disappears: −0.010 and −0.301 for the two draws, with worlds splitting 24/15 and 26/12 (counts below 40 are exact ties). F0's parameter term (+2.37 to +2.65 U1) exceeds F1-eco's (+0.86 to +1.52). The ecological contrasts keep their direction.

- **The confirmed U1 result is a statement about exact parameters.** It should not be described as robust to parameter error.
- **The near-zero means are descriptive.** They are not evidence of zero effect.

**Rain shift.** F0's omission term grows from +0.518 to +1.851 to +3.567 as $\psi$ moves from −0.1 to +0.1, while F1-eco's stays below +0.08. The mean REP-minus-COMP contrast moves from −1.318 to −0.808 without reversing.

**Other mechanisms.** In all twelve (baseline, mechanism) pairs the mean U1 contrast favours REP and the mean deficit contrast favours COMP. For S and C, however, the omission term itself is small. Those contrasts mostly reflect the ecological objective's U1 price, not any value in representing S or C.

**Pareto fronts.** Each strategy is mostly undominated among the 33 evaluated policies when its own model is right, and often dominated when it is wrong. On the U1–deficit front:

- REP is undominated in 97.5% of worlds with retention present, but in 55% without;
- COMP is undominated in 100% without retention, but in 30% with.

**Which omission matters is itself conditional.** In the earlier eight-world pilot (development worlds; true mask 111; planner masks ablated), omitting R carried almost all of F0's U1 omission effect at exact parameters: R +0.796, S −0.003, C +0.027. With parameter error ($s=0.25$, $\psi=0$), omitting C (+0.434) mattered more than omitting R (+0.338). These are omission effects in the planner, not physical effect sizes, and the sample is small.

**[IP]** The relevance of a missing mechanism is not a fixed property of the mechanism. It depends on what else the planner gets wrong.

## 5. Why exposure does not guarantee learning

The third response, learning, was not part of the confirmatory test. It was studied in a sequence of exploratory gates on preselected development worlds, using exact computation wherever possible. The question is simple: if the planner suspects that retention might operate, can it find out in time for the knowledge to pay?

### 5.1 A null built into the model [R, structural]

Without upstream wetland, the transition laws with and without retention are identical (§2.2). This held for every unexposed state–action pair examined, in every world and variant.

For the particular observation likelihood evaluated in the inference gates, the log Bayes factor between "retention present" and "absent" is exactly zero on every such history. That is a statement about that likelihood. It does not show that complete histories are uninformative under every possible observation model.

### 5.2 A trap the policy maintains itself [R, exploratory]

An exposure trap occurs when an omitted mechanism matters for the decision, yet the planner's own policy never enters a state in which it could be detected. Under passive operation, the exposure study found **seven** such exact traps, across six development and stress-test worlds: six for retention and one for synchronisation.

In world d05, omitting retention raises the true U1 cost by 2.36 at $\psi=0$. Yet the omitting planner's policy has zero occupancy of states where retention acts. However long it operates, it will never see evidence that would correct it, because its own choices keep that evidence out of reach.

**[IP — Observability is policy-dependent.]** Whether a model error can be discovered is not only a property of the world and the sensors. It is also a property of the policy being run. A planner can maintain its own blind spot.

### 5.3 Exposure is not yet evidence [R, exploratory]

Suppose the planner deliberately restores wetland for $k$ years (a probe) and then commits to a plan. We built an exact Bayesian learner for this case. It knows the two hypotheses, observes the full state without noise, updates its posterior exactly and commits at year $k$. This is a deliberately optimistic setting, closely related to Bayes-adaptive planning (Guez, Silver & Dayan, 2012).

**[R, structural]** A one-year probe cannot inform this learner: its first transition starts from an unexposed state, so the posterior equals the prior on every history.

**[R, exploratory]** Longer probes create exposure long before they create evidence. In world d05:

- the probe exposes retention with probability 0.77, 0.95 and 0.99 at $k=1,2,3$;
- the posterior has moved at all with probability 0, 0 and 0.15.

In world d00 evidence arrives sooner (0.47 at $k=2$). In world d02 it does not arrive before $k=3$ (0.36). See Figure 4.

![Exposure and learning](figures/wp1_fig4_exposure_learning.png)

*Figure 4.* Probability that retention is exposed at the commitment year (A), and that the posterior has moved by then (B). Joint probe, retention present. Source: `e1lite_cells.csv`. [R, exploratory; panel B at $k=1$ structural]

### 5.4 What learning could be worth, and what a learner gets [R, exploratory]

Three comparisons in the value-of-learning gates must be kept apart.

**Full-start clairvoyance (O\*).** This planner knows from the start whether retention operates. Its advantage over passive operation, $C(P0)-C(O^*)$, is:

- 0.92 / 1.84 / 2.76 U1 in world d00;
- 0.59 / 1.18 / 1.77 U1 in world d05;

as the hypothetical prior weight on retention rises from 0.25 to 0.50 to 0.75. It is zero in the two control worlds, where retention does not matter. This is a passive-relative bound, not canonical EVPI (Howard, 1966) and not the gain from any probe.

**The fixed-probe oracle (X\*).** X\* must carry out a prescribed probe for $k$ periods, then learns the truth perfectly before continuing. Against a restricted menu of fixed policies, B_extended, that includes the probes themselves, X\* has a positive net margin in only **10 of 54** primary cells in the three worlds where retention matters (7 of 54 in a sensitivity variant).

- Counting the two control worlds, which have no winning cells, the figures are 10/90 and 7/90.
- The two denominators answer different questions.
- X\* is a ceiling within its probe, not a bound on every adaptive policy.

**The feasible learner.** The exact probe-then-commit learner recovers at most about a fifth of the X\* margin:

- its ratio $\kappa$ to the X\* margin over B_extended is at best 0.107 in the primary variant and 0.179 in the sensitivity variant;
- the declared screen ($\kappa\ge0.5$) was met in none of the nine cells where it is defined;
- it beats B_extended in 2 of the 54 cells, both one-year probes with no posterior update (Figure 5).

An attribution of its gains shows that almost all of them come from *state-contingent commitment*: choosing a continuation by prior and reached state. They do not come from updating beliefs. The posterior update is worth at most 0.069 U1 in any cell, and 2.1% of the substantial gains.

![Oracle and learner](figures/wp1_fig5_oracle_vs_learner.png)

*Figure 5.* The fixed-probe oracle X\*'s net margin over the restricted menu B_extended, against the feasible learner's, in 54 primary cells in the three worlds where retention matters. These are **net programme margins against a restricted menu**, not isolated information value. The learner's positive margins at $k=1$ contain no posterior update. Source: `e1lite_cells.csv`. [R, exploratory]

**[IP — Value of information is not value to a learner.]** The theoretical value of knowing a mechanism, even within one probe, can far exceed what a simple exact learner earns within the same horizon. The gap does not come from bad inference. It is time, exposure and commitment: the evidence arrives late, the probe is costly, and the remaining horizon is short.

This is consistent with WP0's finding that information may be valuable while acquiring it is not. Here the cost is not a lost period of production but the physical commitment needed to make the mechanism visible at all.

These are results for one learner, one comparator, noise-free observation and one-time commitment, in selected worlds. They do not show that learning is never worthwhile.

## 6. Three responses, one coupled decision problem

### 6.1 What each response actually changes

| Response | What it changes | What it costs here | What we found |
|:---|:---|:---|:---|
| **Re-model** (assume R) | the represented transition law | nothing up front; misspecification cost when R is absent | lower mean U1 and U2 than re-valuing at exact parameters [R, confirmatory]; advantage nearly gone under parameter error [R, exploratory] |
| **Re-value** (ecological objective) | the objective | a U1 price paid whether or not R operates [R, prespecified descriptive] | better wetland outcomes [R, confirmatory]; much smaller observed sensitivity to omitting R [R, prespecified descriptive] |
| **Learn** (probe, then commit) | what the planner can observe and when | physical probe cost and time | structural nulls and self-maintained traps; little realised value for a simple learner [R, structural / exploratory] |

**[IP — The responses are coupled.]** These responses are not independent dials:

- the objective decides whether wetland is built;
- wetland decides whether retention is observable;
- observability decides whether learning is possible;
- what is learned decides which model the planner uses.

Re-valuing can thus make learning possible as a by-product, by building the stock through which the omitted mechanism would act. Assuming a mechanism can make learning unnecessary for one criterion while leaving another criterion worse.

None of these couplings was the object of a confirmatory test. The table is an interpretation of separately established pieces.

### 6.2 Negative results that should survive publication

1. **The confirmed advantage of re-modelling is fragile.** Its precision target was missed, ten of forty worlds go the other way, and under parameter error it nearly vanishes.
2. **Robustness was not free.** The ecological objective's insensitivity to the omission came with a U1 price under the correct model, and no equivalence was established.
3. **The policy compared was not the best policy.** A simple hedging heuristic had lower mean U1 than either pure commitment.
4. **The simple learner learned little.** Its declared screen was not met, and its few gains came from commitment, not information.
5. **Validation can fail correct code.** Two verification gates rejected correct implementations: a normal approximation for a rare event, and an invalid declared inequality. Both failures were kept and corrected only through newly declared gates (Appendix C).

### 6.3 Extending WP0's diagnostic framework [IP]

WP0 proposed asking four questions before choosing a remedy: What matters? How does the world work? What might matter later? Can we learn in time? This paper suggests refining the second and fourth questions.

| Question | Refinement from this paper | Diagnostic object |
|:---|:---|:---|
| How does the world work? | *Which* omission matters depends on what else is wrong (parameters, shifts) | omission terms under several planning conditions |
| How does the world work? | Assuming a mechanism and representing it correctly are different claims | REP evaluated in both mechanism branches |
| Can we learn in time? | Is the mechanism observable *under the policy we run*? | exposure occupancy of the chosen policy |
| Can we learn in time? | Is learning's value measured against a feasible learner, not an oracle? | feasible-learner margin over a fixed-policy menu |

This remains a proposal for operationalisation, not a validated framework.

## 7. Unanswered questions and limits

### 7.1 Limits

- **Synthetic generator.** The confirmatory worlds are independent draws from one investigator-defined generator, so inference is conditional on it. The $t$-interval at $n=40$ is an approximation.
- **Hypothetical weighting.** The equal weighting of retention present and absent is a hypothetical prior. Other weights would change the estimand.
- **One confirmed mechanism.** Only retention was tested confirmatorily, from one baseline, at exact parameters and no rain shift.
- **Strategy set.** REP is an assumption, not discovery. MIX is a heuristic. The robust ambiguity-averse planner from A1, which WP0 proposed comparing (Iyengar, 2005; Nilim & El Ghaoui, 2005), was not evaluated here.
- **Learning studies.** These used selected development worlds, noise-free full-state observation, a known two-hypothesis problem and one-time commitment.
- **Criteria.** U2 is a simple distributive variant. Wetland deficit and stock are model quantities, not field indicators.

### 7.2 Hypotheses for future work

The hypotheses are numbered after WP0's H1–H4.

**[H5 — Reversal is predictable.]** The sign of the re-model versus re-value contrast in a world will be predicted by the ratio of the ecological objective's price to the re-modelled plan's misspecification cost. Worlds like t18 should be those where the price is small. This requires new worlds and a new declaration, not a post hoc search of the 40.

**[H6 — Cheaper insurance.]** Two alternatives may keep most of the ecological objective's insensitivity to omitted retention at a lower U1 price:

- an objective that values wetland conditionally on its downstream relevance;
- a correct belief-state plan over the two hypotheses.

The MIX result motivates this, but does not establish it.

**[H7 — Parameter error favours robustness.]** As planning-parameter error grows, the advantage of re-modelling over re-valuing shrinks. A robust ambiguity-averse planner may then dominate both on U1. This should be tested with the A1 robust planner included from the start.

**[H8 — Exposure-aware planning.]** Planners that account for the observability their own policy creates will avoid self-maintained traps where the omitted mechanism is decision-relevant. Their net value will depend on probe cost and remaining horizon.

**[H9 — Observation channels beat longer probes.]** In line with WP0's H4 (integrated learning), adding an observation channel that responds to retention directly, such as a downstream flow measurement, will raise realised learning value more than lengthening probes.

### 7.3 Relation to the programme and to Governance as Engineering

The Systemic Optimization series asks how an optimization problem should be *constructed* and *evaluated*, not only solved. *Governance as Engineering* (GaE) concerns the institutional architecture through which such problems are formulated: who observes, who decides, what is valued, and how feedback returns.

**[IP]** This paper adds one architectural observation. What an institution can learn about the world depends on what it does, and what it does depends on what it values and what it believes. Monitoring arrangements, objectives and model assumptions are therefore not separable design choices.

A planning body that never acts on a mechanism may never be in a position to observe it. An objective adopted for one reason may, as a side effect, create the conditions for learning something else.

These are interpretive bridges. No result here validates a governance arrangement, and no recommendation for a real catchment follows directly.

## 8. Conclusion

Working Paper 0 began from the observation that an optimizer can solve the wrong problem correctly. This paper asks what happens next, once the incompleteness is recognised.

The answer from one synthetic flood model is that the three available responses — changing what we believe, changing what we value, and trying to learn — lead to different outcomes, and constrain each other.

- **Assuming the missing mechanism** produced lower mean flood-and-finance costs than **re-weighting the objective toward ecology** at exact parameters [R, confirmatory]. On average it did so even in the branch where the assumption was false [R, descriptive subgroup].
- **The ecological objective** produced better wetland outcomes [R, confirmatory]. Its plans were much less sensitive to the omission [R, prespecified descriptive], but its price was paid whether or not the mechanism operated.
- **Learning** was limited less by inference than by exposure and time. A planner can maintain its own blind spot, and a simple exact learner earned little of what an oracle could [R, structural and exploratory].
- **None of these rankings is unconditional.** Under parameter error the cost advantage of the assumption nearly disappeared, and which omission matters most changed [R, exploratory].

**[IP]** What changes in the programme after this paper is the unit of evaluation. It is not enough to ask whether a model is more complete or an objective more inclusive. The relevant object is the *package*: what is represented, what is optimised, and what the resulting policy allows us to observe. That package should be evaluated across criteria and conditions, against feasible rather than clairvoyant alternatives.

The next studies in the series should therefore test these packages, including robust and belief-state planners, under declared conditions in which their trade-offs can reverse.

---

## Appendix A. Evidence-status matrix

This is the authoritative claim-by-claim record. In the main text, **[R]** results carry a status word (confirmatory, prespecified descriptive, exploratory, structural). Here, each is given its precise code. *C-derived* marks a logical synthesis of confirmatory results, not an additional test. Source paths refer to the A2 project archive.

| Inferential status | Meaning |
|---|---|
| **C** confirmatory | prespecified test on the independent, committed F0-C sample; holds *within the declared synthetic population and the hypothetical 50/50 R weighting* |
| **C-derived** | a logical synthesis of C results; **not** an additional tested hypothesis |
| **PD** prespecified descriptive | declared before the confirmatory data; reported without an inferential claim |
| **ED** exploratory, declared | declared before outcomes, on development or preselected worlds; hypothesis-generating |
| **EP** exploratory, post hoc | chosen after seeing outcomes; labelled as such |
| **ST** structural | exact property of the model as specified (identity, structural null), verified numerically |

| Role | Meaning |
|---|---|
| **DS** decision science | claims about the decision problem |
| **NM** numerical methods | claims about estimators or solvers. Each row states whether the intervention was prospective and whether it covers a single fixed history. |
| **ENG** engineering verification | validation and parity gates; trust in code, not findings |

Abbreviations: R = downstream retention, S = synchronisation, C = rain copula; F0 = U1 objective; F1-eco = U1 + λ·ecological deficit. Every quantitative entry gives its source file.

### Group A — Objective adequacy and causal representation

| # | Claim (criterion named) | Source | Worlds | Status / role | Key numbers | Caveats |
|---|---|---|---|---|---|---|
| A1 | Under the declared hypothetical 50/50 R weighting, **REP(R) (F0 on 111) has lower population-mean U1** than COMP (F1-eco on 011) | F0-C primary; `analysis/f0c_…/f0c_confirmatory.json` | 40 IID test worlds | C / DS | Δ = −1.112 U1 [−1.737, −0.487], t(39) = −3.60, p = 0.00089 | precision missed (half-width 0.625); 30/40 negative, range −6.10 to +4.92 (t18); approximate t-inference conditional on the frozen generator |
| A2 | Same contrast on **U2** (U1 + maximum-municipality residual-damage penalty): REP lower | F0-C secondary | 40 | C / DS | −1.061 [−1.734, −0.388]; Holm p 0.0028 | U2 is not a complete distributive measure. CIs are ordinary unadjusted 95%; p-values are Holm-adjusted. |
| A3 | On **cumulative upstream wetland deficit**, COMP lower (better) | F0-C secondary | 40 | C / DS | +6.362 [+4.235, +8.489]; Holm p 1.3e-6 | model quantity, not a field indicator; same CI/p note as A2 |
| A4 | On **negative terminal wetland stock**, COMP lower (better, i.e. more stock) | F0-C secondary | 40 | C / DS | +1.543 [+1.056, +2.030]; Holm p 5.6e-7 | as A3 |
| A5 | BOTH(R) (F1-eco on 111) has **higher U1** than REP(R) | F0-C secondary | 40 | C / DS | +1.603 [+0.992, +2.214]; Holm p 9.6e-6 | BOTH's ecological outcomes were not part of this test |
| A6 | For the prespecified REP(R)-vs-COMP comparison, under the hypothetical 50/50 R weighting, **the mean criterion differences point in opposite directions**: REP has lower U1 and U2, COMP lower cumulative deficit and higher terminal stock. **Neither of these two policies is uniformly superior across the named criteria** | A1–A4 jointly | 40 | **C-derived** / DS | — | not a sixth test; says nothing about all strategies, any third policy, or per-world Pareto non-dominance |
| A7 | In the prespecified descriptive comparison, the observed mean **omission-related U1 contrast under F1-eco was small (+0.014)**, compared with **+1.851 under F0** (m\* = 111, s = 0, ψ = 0) | F0-C descriptive; `f0c_descriptive.json` | 40 | PD / DS | F0 +1.851 [+0.80, +2.90]; F1-eco +0.014 [−0.17, +0.20]; F1-eco-fixed +0.094 [−0.21, +0.40] | **not an equivalence or non-inferiority test**; the F1-eco interval contains meaningful positive and negative values; F1-eco-fixed addresses λ normalisation only; one mechanism (R), one baseline (011) |
| A8 | F1-eco has a **U1 price under the correct model** (its objective term) | F0-C descriptive | 40 | PD / DS | +1.085 [+0.61, +1.56] | the objective-term price is not the whole deployed-policy cost |
| A9 | The R-absent branch is also negative (descriptive subgroup). **The development decomposition suggests** this is because F1-eco's U1 premium exceeds REP's misspecification cost, not because the representation is right. The same decomposition computed read-only from the frozen 40-world tables is exploratory | branch: `f0c_confirmatory.json`; dev: `F0DEV_RESULTS_v0.1.md` §5; 40-world: Appendix B, T4 | 40 / 16 | PD (branch) / ED (dev) / EP (40-world) | branch 011: −1.125 [−2.126, −0.124]; dev: misspecification 1.06 vs F1-eco premium 2.42; 40-world: misspecification 1.765 vs F1-eco premium 2.890 (Appendix B, T4) | an objective-mismatch comparison, not causal discovery; not confirmed mechanistically |
| A10 | Omission cost under F0 is asymmetric and rain-dependent | F0-dev decomposition (`f0_decomposition.csv`); 40-world in Appendix B, T2/T4 | d00–d15 | ED / DS | F0/011 representation term 0.28 / 1.45 / 2.91 at ψ = −0.1 / 0 / +0.1 | development prefix; partly examined worlds |
| A11 | F1-eco is **less sensitive to planning-parameter error** than F0 (U1) | F0-dev decomposition; 40-world in Appendix B, T1 | d00–d15 | ED / DS | parameter/shift term at s = 0.25: F0 1.3–1.9 vs F1-eco 0.5–0.7 | development; the test-pool view is exploratory (appendix) |
| A12 | Correctly represented strategies are almost never dominated on two-axis fronts; the objective mainly selects a point on the U1–ecology front | F0-dev Pareto (`f0_pareto.csv`); 40-world in Appendix B, T6 | d00–d15 | ED / DS | non-dominated shares 1.00 (one 0.94) | two-axis fronts only; no statement about all policies |
| A13 | **The importance of an omitted mechanism depends on parameter uncertainty and conditions.** At s = 0, omitting R carries most of the F0 U1 omission effect; at s = 0.25, ψ = 0, **omitting C exceeds omitting R** | Gate C pilot `runs/pilot-v0.2_n8_812591e9c161/analysis.json` (factorial main effects on F0 regret) | 8 dev worlds (s = 0); 8 × 2 draws (s = 0.25) | ED / DS | s = 0, ψ = 0: R +0.796, S −0.003, C +0.027. s = 0, ψ = +0.1: R +2.046, S −0.011, C +0.016. s = 0.25, ψ = 0: **R +0.338, S −0.013, C +0.434**. s = 0.25, ψ = −0.1: R −0.131, C +0.397 | the pilot's physical mask was 111 with planner masks ablated, so these are omission effects in the planner, not physical effect sizes; small, previously studied sample; large SDs |
| A14 | In the pilot, the ecological objective did not recover the U1 omission penalty | Gate C pilot `summary.txt` | 8 | ED / DS | recovery ratio about −0.31 to −0.37 (s = 0, ψ = 0) | consistent with A8 |

### Group B — Exposure and identifiability

| # | Claim | Source | Worlds | Status / role | Key numbers | Caveats |
|---|---|---|---|---|---|---|
| B1 | With no upstream wetland, **the specified mechanism-specific transition likelihoods are identical** under R present and absent | E1-lite feasibility (`analysis/e1lite_feasibility/inventory.json`); G1-R V3; G3 controls | all | ST / DS | 100% of unexposed (s, a) pairs are exact nulls in every case and variant. The G3 blind log BF is exactly 0 **for the particular conditional observation likelihood evaluated in G3** | does not show that complete policy-state histories are uninformative under every observation model |
| B2 | **Exposure traps:** under the chosen passive policy, R stays unexposed in some worlds where it matters (d05 type) | D1–D2 `runs/d12-v0.1_bae2b0e7345b/summary.txt`; `G3_SUPPLEMENT_v0.1.md` | d00–d07 + synthetic | ED / DS | 7 exact (world × mechanism) traps in 6 worlds (6 R, 1 S); d05 planner occupancy of R exposure 0.000 | selected development worlds; stationary passive operator from S0 |
| B3 | Exposure is necessary, not sufficient: in d05 a deliberate probe establishes wetlands but rarely yields distinguishable transitions within 3 years | E1-lite G2 (`analysis/e1lite_g2_…`) | d05 | ED / DS | P(posterior moved) 0.00 at k ≤ 2, 0.15 at k = 3 (joint), with wetland stock established on 77–99% of paths | noise-free full-state observation (optimistic) |
| B4 | **Timing:** a one-year probe cannot inform the transition-based learner, because its first transition starts unexposed | E1-lite G2 | all | ST / DS | posterior at k = 1 equals the prior on every history | specific to the transition-based learner |

### Group C — Value of learning

| # | Claim | Source | Worlds | Status / role | Key numbers | Caveats |
|---|---|---|---|---|---|---|
| C1 | **Full-start clairvoyance O\*** (knows R from period 0): the passive-relative bound C(P0) − C(O\*) is material in R-relevant worlds and zero in controls. This is not the fixed-probe oracle X\* | E0 (`E0_RESULTS_v0.1.md`, `E0_CORRIGENDUM_v0.1.md`) | d00, d05, d02; controls d03, d07 | ED / DS | d00 0.92 / 1.84 / 2.76; d05 0.59 / 1.18 / 1.77 at q = 0.25 / 0.5 / 0.75 | **not EVPI**; preselected worlds |
| C2 | **Fixed-probe oracle X\*** (prescribed probe for k periods, then perfect revelation): its net margin over a restricted fixed-policy menu is seldom positive | E0 / E0.2 (`E02_ANALYSIS_v0.1.md`) | as C1 | ED / DS (E0.2 comparators post hoc, reviewer-proposed) | X\* beats B_extended in **10/54 (primary) and 7/54 (sensitivity) R-relevant cells** (d00/d05/d02); **10/90 and 7/90** including the controls d03 and d07, which have no winning cells | B_extended is a restricted fixed-policy menu; X\* is a within-probe continuation ceiling, **not universal EVPI and not a bound on all adaptive policies**; X\*e is not a general ceiling |
| C3 | A simple exact Bayesian probe-then-commit learner recovers at most about 18% of **the X\* margin over B_extended** (κ); the declared screen was not met | E1-lite G2 (`E1LITE_G1R_G2_RESULTS_v0.1.md`) | as C1 | ED / DS | κ ≥ 0.5 in 0/9 (primary); best κ 0.107 (primary), 0.179 (sensitivity) | known two-hypothesis problem; noise-free state; one-time commitment |
| C4 | Almost all of that learner's gain over the same-path fixed continuation is state-contingent commitment, not posterior updating | E1-lite G2.1 (`E1LITE_G21_ATTRIBUTION_v0.1.md`) | as C1 | ED / DS (descriptive decomposition) | information value ≤ 0.069 U1; 2.1% of substantial gains (primary) | specific learner and comparator; not a statement about all learners |

### Group D — Numerical methods and engineering

| # | Claim | Source | Status / role | Key result | Scope |
|---|---|---|---|---|---|
| D1 | Random-walk SMC evidence estimates were unreliable in the blind 16-D diagnostic; G3.2 detection rates are not interpretable | `G32_FINDINGS_v0.1.md` | EP (status assigned after the run) / NM | replicate verdict disagreements up to 11/24 | blind 16-D, D3a packages |
| D2 | Validated quadrature references: **1-D** via G3.3a (FAIL kept) and G3.3a-R (breakpoint-split, PASS); **2-D** via G3.3b-1 (48/48 references validated) | `G33A_RESULTS`, `G33AR_RESULTS`, `G33B1_RESULTS` | ED / NM | 1-D references within 1e-3 nats (Simpson accurate to 1.8e-5 but slow to converge); 2-D: 48/48 validated, exact nulls exact | the specific benchmark units |
| D3 | An **evaluator-informed, prospectively compared targeted split** reduced evidence-estimation error **on one fixed synthetic 2-D history**. It used fewer likelihood evaluations, but **runtime was not uniformly lower** | G3.3b-1 FAIL → 1M INCONCLUSIVE → 1P SUPPORTED → P3.1 FAIL → P3.1-R PASS → P3.2 EFFECTIVE (`G33B1P3_P31R_P32_RESULTS_v0.1.md`; `runs/g33b1p32-…`) | ED (prospective P3.2) / NM | mean \|log BF error\| 1.625 → 0.404 (512 particles), 0.457 → 0.181 (2,048). Particle-year cost lower. Wall-clock: 136 s vs 118 s at 512 (slower), 274 s vs 339 s at 2,048 (faster) | uses evaluator-known geometry; one history; **not** a deployable blind high-dimensional estimator |
| D4 | F0 machinery verified: oracles, lexicographic ties, decomposition identities, occupancy evaluator, Monte Carlo cross-check | F0-V FAIL (rare-event statistic) → F0-V-R PASS; F0-C validate-c PASS; parity sandbox FAIL (cross-platform ties) / workstation PASS | ENG | identities exact; the failures were test-statistic or cross-platform tie issues, documented | — |
| D5 | Validation statistics can reject correct code (normal approximation for rare events; invalid declared inequalities) | E1-lite G1, F0-V (`E1LITE_G1_RESULTS`, `F0V_RESULTS`) | EP (lesson) / NM | kept as FAIL records, each followed by a declared correction | methodological lesson |

## Appendix B. Exploratory tables from the frozen confirmatory factorial

**Status: EP (exploratory, post hoc), descriptive only.** 

- Read-only, from the frozen F0-C analysis tables in `analysis/f0c_f0c-v0.1-conf_6c5c58ff6e22/`. No simulation, no new world, no p-value and no confidence interval.
- The table definitions and their complete coverage were declared at **2026-11-06T10:10:31Z** in `records/a2_f0c_exploratory_appendix_declaration.json`, before any table was computed. The script checks the input hashes against that declaration.
- **Why EP and not ED.** The F0-C summary log and the F0-dev analogues were already known when the tables were chosen, so the choice was not blind to outcomes. Nothing here is a confirmatory finding, and nothing here is used to select a new hypothesis.
- **Unit.** The unit is the base world (n = 40). The 120 jobs are three planning conditions per world and are not independent.
- **Code and output.** `diag/a2_f0c_exploratory_appendix.py` (sha256 `b9f68d4d7825…`) writes `analysis/f0c_exploratory_appendix/tables.json` and `tables.md`.

### B.1 Definitions

- **Contrast.** Δ_X(J) = ½ Σ_{m\* ∈ {m₀ ∪ X, m₀}} [J(F0 on m₀ ∪ X) − J(F1-eco on m₀)], own pool. It is REP(X) − COMP under the hypothetical 50/50 weighting on whether X is present. Every J is minimised, so **Δ < 0 favours REP on the named criterion**.
- **Per-world statistics.** T1–T3 report the mean, SD, sign counts, minimum and maximum over the 40 worlds. Sign counts can sum to less than 40 when a world has Δ exactly 0.
- **World means only.** T4–T6 come from the frozen world-mean tables:
  - decomposition terms are regret components against the J_U1 oracle (representation → parameter/shift → objective);
  - T5 averages the two m\* branches of the factorial means;
  - T6 counts, for each world, whether a policy is non-dominated among the **33 candidate policies** (24 S|f|m and 9 MIX) on the named two-axis front.
- **Inputs (sha256).**
  - `f0c_core.csv` `d201fc09a085…`
  - `f0c_decomposition.csv` `eefdb4f6ec44…`
  - `f0c_factorial_means.csv` `63e52948900a…`
  - `f0c_pareto.csv` `35f130ddc694…`

### B.2 Tables

#### T1. Parameter error (m₀ = 011, X = R, ψ = 0): Δ = REP(R) − COMP

| Condition | J | mean | SD | n < 0 | n > 0 | min | max |
|---|---|---|---|---|---|---|---|
| s=0.0,d=0 | J_U1 | -1.112 | 1.954 | 30 | 10 | -6.104 | +4.925 |
| s=0.0,d=0 | J_U2 | -1.061 | 2.103 | 29 | 11 | -6.324 | +6.216 |
| s=0.0,d=0 | J_def | +6.362 | 6.651 | 3 | 37 | -3.795 | +18.069 |
| s=0.0,d=0 | J_stock | +1.543 | 1.523 | 2 | 38 | -0.544 | +4.000 |
| s=0.25,d=0 | J_U1 | -0.010 | 2.579 | 24 | 15 | -7.263 | +6.970 |
| s=0.25,d=0 | J_U2 | +0.155 | 2.785 | 23 | 16 | -7.170 | +7.839 |
| s=0.25,d=0 | J_def | +5.258 | 6.231 | 4 | 35 | -4.103 | +18.340 |
| s=0.25,d=0 | J_stock | +1.269 | 1.448 | 3 | 36 | -0.948 | +4.000 |
| s=0.25,d=1 | J_U1 | -0.301 | 2.547 | 26 | 12 | -4.720 | +10.552 |
| s=0.25,d=1 | J_U2 | -0.182 | 2.842 | 24 | 14 | -5.144 | +11.621 |
| s=0.25,d=1 | J_def | +6.937 | 6.663 | 5 | 33 | -1.076 | +18.069 |
| s=0.25,d=1 | J_stock | +1.639 | 1.542 | 3 | 35 | -0.007 | +4.000 |

Parameter/shift term (J_U1, world means):

| Condition / policy / m\* | term |
|---|---|
| s=0.0,d=0\|F0/111\|m*=111 | +0.000 |
| s=0.0,d=0\|F0/111\|m*=011 | +0.000 |
| s=0.0,d=0\|F1-eco/011\|m*=111 | +0.000 |
| s=0.0,d=0\|F1-eco/011\|m*=011 | +0.000 |
| s=0.25,d=0\|F0/111\|m*=111 | +2.654 |
| s=0.25,d=0\|F0/111\|m*=011 | +2.370 |
| s=0.25,d=0\|F1-eco/011\|m*=111 | +1.329 |
| s=0.25,d=0\|F1-eco/011\|m*=011 | +1.516 |
| s=0.25,d=1\|F0/111\|m*=111 | +2.483 |
| s=0.25,d=1\|F0/111\|m*=011 | +2.361 |
| s=0.25,d=1\|F1-eco/011\|m*=111 | +0.857 |
| s=0.25,d=1\|F1-eco/011\|m*=011 | +1.378 |

#### T2. Rain shift (m₀ = 011, X = R, s = 0): Δ = REP(R) − COMP

| ψ | J | mean | SD | n < 0 | n > 0 | min | max |
|---|---|---|---|---|---|---|---|
| psi=-0.1 | J_U1 | -1.318 | 1.753 | 33 | 7 | -6.184 | +2.144 |
| psi=-0.1 | J_U2 | -1.300 | 1.815 | 32 | 8 | -6.198 | +2.793 |
| psi=-0.1 | J_def | +6.615 | 6.673 | 4 | 36 | -3.367 | +18.136 |
| psi=-0.1 | J_stock | +1.609 | 1.522 | 2 | 38 | -0.352 | +4.000 |
| psi=0.0 | J_U1 | -1.112 | 1.954 | 30 | 10 | -6.104 | +4.925 |
| psi=0.0 | J_U2 | -1.061 | 2.103 | 29 | 11 | -6.324 | +6.216 |
| psi=0.0 | J_def | +6.362 | 6.651 | 3 | 37 | -3.795 | +18.069 |
| psi=0.0 | J_stock | +1.543 | 1.523 | 2 | 38 | -0.544 | +4.000 |
| psi=0.1 | J_U1 | -0.808 | 2.110 | 27 | 13 | -6.310 | +7.343 |
| psi=0.1 | J_U2 | -0.710 | 2.365 | 25 | 15 | -6.533 | +9.275 |
| psi=0.1 | J_def | +6.101 | 6.632 | 4 | 36 | -4.196 | +18.069 |
| psi=0.1 | J_stock | +1.476 | 1.524 | 2 | 38 | -0.720 | +4.000 |

Representation term of omitting R in m\* = 111 (J_U1, world means):

| ψ / policy | term |
|---|---|
| psi=-0.1\|F0/011 | +0.518 |
| psi=-0.1\|F1-eco/011 | +0.002 |
| psi=-0.1\|F1-eco-fixed/011 | +0.038 |
| psi=0.0\|F0/011 | +1.851 |
| psi=0.0\|F1-eco/011 | +0.014 |
| psi=0.0\|F1-eco-fixed/011 | +0.094 |
| psi=0.1\|F0/011 | +3.567 |
| psi=0.1\|F1-eco/011 | +0.078 |
| psi=0.1\|F1-eco-fixed/011 | +0.229 |

#### T3. All 12 (m₀, X) pairs (s = 0, ψ = 0): Δ_X = REP(X) − COMP

| m₀ + X | J | mean | SD | n < 0 | n > 0 | min | max |
|---|---|---|---|---|---|---|---|
| 011+R | J_U1 | -1.112 | 1.954 | 30 | 10 | -6.104 | +4.925 |
| 011+R | J_def | +6.362 | 6.651 | 3 | 37 | -3.795 | +18.069 |
| 101+S | J_U1 | -1.011 | 1.443 | 34 | 6 | -5.684 | +0.123 |
| 101+S | J_def | +6.852 | 6.571 | 0 | 40 | +0.000 | +18.069 |
| 110+C | J_U1 | -1.066 | 1.443 | 38 | 2 | -5.196 | +0.003 |
| 110+C | J_def | +6.783 | 6.589 | 0 | 40 | +0.000 | +18.069 |
| 001+R | J_U1 | -1.106 | 1.691 | 30 | 10 | -6.199 | +0.713 |
| 001+R | J_def | +5.883 | 6.667 | 3 | 37 | -0.361 | +18.069 |
| 001+S | J_U1 | -2.631 | 2.406 | 38 | 2 | -10.423 | +0.009 |
| 001+S | J_def | +11.906 | 6.255 | 0 | 40 | +0.000 | +18.619 |
| 010+R | J_U1 | -1.210 | 1.866 | 30 | 10 | -6.060 | +4.227 |
| 010+R | J_def | +7.192 | 6.483 | 4 | 36 | -2.908 | +18.232 |
| 010+C | J_U1 | -2.889 | 2.614 | 40 | 0 | -10.651 | -0.000 |
| 010+C | J_def | +11.872 | 6.217 | 0 | 40 | +0.000 | +18.619 |
| 100+S | J_U1 | -1.079 | 1.461 | 39 | 1 | -5.566 | +0.175 |
| 100+S | J_def | +7.523 | 6.445 | 0 | 40 | +0.000 | +18.232 |
| 100+C | J_U1 | -1.003 | 1.458 | 34 | 6 | -5.527 | +0.011 |
| 100+C | J_def | +6.209 | 6.715 | 0 | 40 | +0.000 | +18.069 |
| 000+R | J_U1 | -1.199 | 1.631 | 31 | 9 | -6.475 | +0.500 |
| 000+R | J_def | +7.119 | 6.723 | 1 | 39 | -0.239 | +18.232 |
| 000+S | J_U1 | -2.568 | 2.290 | 37 | 3 | -9.443 | +0.028 |
| 000+S | J_def | +11.881 | 6.130 | 0 | 40 | +0.000 | +18.619 |
| 000+C | J_U1 | -2.353 | 1.983 | 40 | 0 | -7.380 | -0.011 |
| 000+C | J_def | +13.211 | 5.428 | 0 | 40 | +0.037 | +18.619 |

#### T4. 40-world decomposition (J_U1, s = 0, ψ = 0, own pool; world means)

| policy / m\* | total | representation | parameter/shift | objective |
|---|---|---|---|---|
| F0/111\|m*=111 | +0.000 | +0.000 | +0.000 | +0.000 |
| F0/111\|m*=011 | +1.765 | +1.765 | +0.000 | +0.000 |
| F1-eco/011\|m*=111 | +1.099 | +0.014 | +0.000 | +1.085 |
| F1-eco/011\|m*=011 | +2.890 | +0.000 | +0.000 | +2.890 |

#### T5. MIX vs pure commitments (50/50 mean over m₀ ∪ X and m₀; s = 0, ψ = 0; world means)

| pair \| policy | J_U1 | J_def |
|---|---|---|
| R\|S\|F0\|011 | 6.967 | 18.082 |
| R\|S\|F0\|111 | 6.924 | 12.624 |
| R\|MIX\|R\|0.25 | 6.557 | 16.446 |
| R\|MIX\|R\|0.5 | 6.465 | 14.980 |
| R\|MIX\|R\|0.75 | 6.638 | 13.877 |
| S\|S\|F0\|101 | 4.040 | 12.076 |
| S\|S\|F0\|111 | 4.033 | 12.645 |
| S\|MIX\|S\|0.25 | 4.017 | 12.146 |
| S\|MIX\|S\|0.5 | 4.012 | 12.371 |
| S\|MIX\|S\|0.75 | 4.016 | 12.448 |
| C\|S\|F0\|110 | 2.746 | 13.381 |
| C\|S\|F0\|111 | 2.738 | 12.653 |
| C\|MIX\|C\|0.25 | 2.725 | 13.327 |
| C\|MIX\|C\|0.5 | 2.722 | 13.073 |
| C\|MIX\|C\|0.75 | 2.728 | 12.783 |

#### T6. Pareto: share of the 40 worlds non-dominated (s = 0, ψ = 0, own pool)

| axis \| m\* \| policy | share |
|---|---|
| J_def\|m*=011\|S\|F0\|111 | 0.550 |
| J_def\|m*=011\|S\|F0\|011 | 1.000 |
| J_def\|m*=011\|S\|F1-eco\|111 | 0.650 |
| J_def\|m*=011\|S\|F1-eco\|011 | 1.000 |
| J_def\|m*=011\|S\|F1-eco-fixed\|011 | 1.000 |
| J_def\|m*=011\|MIX\|R\|0.5 | 0.825 |
| J_stock\|m*=011\|S\|F0\|111 | 0.575 |
| J_stock\|m*=011\|S\|F0\|011 | 1.000 |
| J_stock\|m*=011\|S\|F1-eco\|111 | 0.625 |
| J_stock\|m*=011\|S\|F1-eco\|011 | 0.950 |
| J_stock\|m*=011\|S\|F1-eco-fixed\|011 | 0.950 |
| J_stock\|m*=011\|MIX\|R\|0.5 | 0.825 |
| J_def\|m*=111\|S\|F0\|111 | 0.975 |
| J_def\|m*=111\|S\|F0\|011 | 0.250 |
| J_def\|m*=111\|S\|F1-eco\|111 | 1.000 |
| J_def\|m*=111\|S\|F1-eco\|011 | 0.300 |
| J_def\|m*=111\|S\|F1-eco-fixed\|011 | 0.275 |
| J_def\|m*=111\|MIX\|R\|0.5 | 0.225 |
| J_stock\|m*=111\|S\|F0\|111 | 0.975 |
| J_stock\|m*=111\|S\|F0\|011 | 0.250 |
| J_stock\|m*=111\|S\|F1-eco\|111 | 0.925 |
| J_stock\|m*=111\|S\|F1-eco\|011 | 0.250 |
| J_stock\|m*=111\|S\|F1-eco-fixed\|011 | 0.250 |
| J_stock\|m*=111\|MIX\|R\|0.5 | 0.225 |

### B.3 What the tables show, including counterexamples

1. **Parameter error removes most of the U1 advantage of REP(R) (T1).**
   - At s = 0.25, mean Δ_R(J_U1) is −0.010 (draw 0) and −0.301 (draw 1), against −1.112 at s = 0. The signs split 24/15 and 26/12, and the maxima reach +6.97 and +10.55.
   - The parameter/shift term is larger for F0 on 111 (+2.37 to +2.65) than for F1-eco on 011 (+0.86 to +1.52). This matches the F0-dev direction (A11), but these are larger values on a different sample.
   - The ecological contrasts keep their direction and size: J_def +5.3 to +6.9, J_stock +1.3 to +1.6.
   - **The confirmed U1 contrast (A1) is a statement about s = 0. It should not be described as robust to parameter error.**
2. **The rain shift moves the contrast monotonically, with no reversal (T2).**
   - Mean Δ_R(J_U1) is −1.318, −1.112 and −0.808 at ψ = −0.1, 0 and +0.1.
   - The F0 representation term grows (+0.518, +1.851, +3.567), while F1-eco stays near zero (+0.002, +0.014, +0.078). F1-eco-fixed is slightly larger (+0.038, +0.094, +0.229).
   - The ψ = 0 entries reproduce the frozen PD values (A7), which checks the read path.
3. **All 12 mask pairs have the same mean signs (T3), but this mainly reflects the objective, not representation.**
   - Δ_X(J_U1) < 0 and Δ_X(J_def) > 0 in every pair.
   - For S and C the representation contrast is small, so Δ_X there is mostly F1-eco's U1 price for its ecological gain, not evidence that representing S or C has value.
   - Pairs adding R have up to 10 worlds with Δ > 0 and maxima up to +4.9. Pairs adding S or C have at most 6 positive worlds, with maxima ≤ +0.18.
   - The largest mean U1 contrasts, about −2.4 to −2.9, are 001+S, 010+C, 000+S and 000+C. In those pairs the baseline already omits R.
4. **The development decomposition of the R-absent branch has the same shape on the 40 test worlds (T4).**
   - In m\* = 011, REP pays a representation cost of +1.765 U1, while COMP pays an objective price of +2.890. The difference is the branch mean, −1.125.
   - In m\* = 111, COMP's cost is almost entirely objective price (+1.085 of +1.099).
   - This addresses A9: "F1-eco's U1 premium exceeds REP's misspecification cost" holds descriptively in the test sample (dev: 1.06 vs 2.42). It remains an exploratory decomposition, not a mechanistic confirmation.
5. **A hedging heuristic beats both pure F0 commitments on mean U1 for R (T5).**
   - Under the 50/50 weighting, MIX(R, q) has a lower world-mean J_U1 (6.465–6.638) than F0 on 011 (6.967) or on 111 (6.924). Its J_def lies between them (13.9–16.4, against 18.1 and 12.6).
   - For S and C, MIX is within about 0.03 U1 of the pure commitments.
   - REP(R) is therefore not the U1-best policy among those evaluated. **A6 is correctly limited to the REP-versus-COMP pair.**
   - MIX was not part of any test, it is a per-step kernel average rather than a mixture-optimal plan, and only world means are reported here (see H6 in §7.2).
6. **Each strategy is mostly non-dominated when its representation is right, and often dominated when it is wrong (T6).**
   - In m\* = 111, REP (F0/111) is non-dominated in 97.5% of worlds on both fronts, but COMP (F1-eco/011) in only 30% (J_def) and 25% (J_stock).
   - In m\* = 011 the pattern reverses: COMP is non-dominated in 100% and 95%, REP in 55% and 57.5%.
   - BOTH (F1-eco/111) is non-dominated in 100% and 92.5% of worlds in m\* = 111.
   - These shares are per-branch statements. They do not combine into a 50/50 Pareto statement.

### B.4 Nulls and non-findings

- At s = 0 the parameter/shift term is exactly 0 (structural; T1).
- The F1-eco representation term never exceeds +0.08 U1 in world mean across the three ψ values. This is a descriptive observation, not an equivalence result.
- No mask pair reverses the sign of the mean U1 or J_def contrast. The per-world counterexamples are listed in T1–T3.

## Appendix C. Reproducibility, numerical methods and provenance

### C.1 Solver, evaluation and verification [ENG]

**Solver.** Exact finite-horizon dynamic programming on the factored model: 31,104 states, 27 joint actions, 9 rain outcomes, $H=11$.

- Policies are selected with A1's lowest-action-index convention.
- Ecological oracles are lexicographic, with tolerance $10^{-9}\max(1,|m|)$.
- Evaluation propagates exact state occupancies. Independent Monte Carlo simulation cross-checks it statistically, which is not a formal proof.

**Verification gates.**

| Gate | Outcome | Note |
|:---|:---|:---|
| F0-V | **FAIL** (kept) | The rare-event test used a normal approximation for a stock category with probability ≈ 2.6 × 10⁻⁶: one path observed, $z=4.01$. The code was correct; the statistic was not. |
| F0-V-R | PASS | Exact binomial tests per stock category, threshold 0.005/160, fresh seeds |
| F0-C validate-c | PASS | Sandbox and workstation |
| Strict parity, sandbox | **FAIL** (kept) | One oracle's per-municipality spending split differed by 1.2 × 10⁻⁴. The cause was cross-platform resolution of exact two-level lexicographic ties in 281 reached states. |
| Strict parity, workstation | PASS (exact) | The workstation that ran the confirmatory evaluation |

**Tie-dependence.** Oracle per-municipality diagnostics depend on how exact ties are resolved, and therefore on the platform. Criterion values do not.

**A second lesson.** Validation can also fail correct code through an invalid declared inequality. This happened in the E1-lite gate G1, check V7. The failure was kept and corrected by a newly declared gate, G1-R.

### C.2 Evidence estimation for the learning studies [NM]

These results concern the numerical estimation of evidence, not the decision problem.

- **D1 [exploratory; status assigned after the run].** Random-walk sequential Monte Carlo evidence estimates (Del Moral, Doucet & Jasra, 2006) were unreliable in a blind 16-dimensional diagnostic. Replicate verdicts disagreed in up to 11 of 24 cases. The detection rates of that gate are therefore not interpreted.
- **D2 [exploratory, declared].** Validated quadrature references were established in two steps.
  - One-dimensional: G3.3a, whose failure is kept, and the breakpoint-split G3.3a-R, accurate to within 10⁻³ nats.
  - Two-dimensional: G3.3b-1, with 48 of 48 references validated and exact nulls exact.
- **D3 [exploratory, prospectively compared].** An evaluator-informed targeted split reduced evidence-estimation error on **one fixed synthetic two-dimensional history**.
  - Mean absolute log Bayes-factor error fell from 1.625 to 0.404 at 512 particles, and from 0.457 to 0.181 at 2,048.
  - It used fewer likelihood evaluations, but wall-clock time was not uniformly lower: 136 s against 118 s at 512 particles, and 274 s against 339 s at 2,048.
  - It relies on geometry known to the evaluator and is not a deployable blind high-dimensional estimator.

A separate numerical-methods note may be more appropriate for this material than the main series.

### C.3 Confirmatory provenance

| Item | Record |
|:---|:---|
| Declaration | `a2_config.json` block `f0c`, 2026-11-06T04:10:33Z; configuration snapshot in `records/` |
| Code freeze | fingerprint F_c `6c5c58ff6e22e3341c46959d8edb1bc25eb99863644ea2a5151b29458a38961d` over 48 files; configuration SHA-256 `4ac1dcb244bbf2c68ee354805e99f1ac5476d419af087b576b4a64c57257a9c9` |
| Test pool | 40 × 19 uniform draws from the reserved stream (spawn key 9, pool version 1); pool SHA-256 `b14d9984b3399c2e51661a811d7321af2bbc4a59f576a5127fa489577b112119`; generated 2026-11-06T06:09:41Z |
| Evaluation | 120 jobs (40 worlds × 3 planning conditions), 06:12:34Z–09:08:42Z; 8 workers; Python 3.10.12, NumPy 2.2.6, SciPy 1.15.3 |
| Commitment | The pool commitment was sent to the reviewer as text (`records/f0c_pool_commitment_as_sent.txt`). The **user-reported** order is: acknowledgement at about 06:12Z, then evaluation. This order is not independently timestamp-verified. |
| Safeguards and their limits | Recomputing the pool from the declared stream reproduces the committed hash, and code and configuration were frozen before generation. Together these substantially constrain discretionary pool selection. They are not a historical proof of the ordering. |
| Replay | An independent replay of the summary is byte-identical except for JSON float rounding (≤ 1.8 × 10⁻¹⁵) |
| Incident | Empty files with error-text names appeared on the workstation and were deleted before inspection; their origin is unknown. There is no evidence of impact on frozen inputs or run payloads: every manifest source list equals the freeze manifest. |
| Development reference | 16 development worlds; Δ −1.195 [−1.801, −0.588], SD 1.138; 15 of 16 negative. Development and confirmatory numbers are never pooled. |

### C.4 Figures and companion files

- Figures 1–5 are drawn by `paper/make_figures.py` from frozen outputs only, with input hashes in `paper/figures/wp1_figure_sources.json`.
- Appendix B's tables are computed by `diag/a2_f0c_exploratory_appendix.py`, against the declaration `records/a2_f0c_exploratory_appendix_declaration.json`.
- `paper/check_numbers.py` checks every number in this paper against a sourced registry.
- The companion archive contains the frozen inputs needed to regenerate all five figures and both appendix tables.

### C.5 Methodological disclosure

The study programme was initiated and directed by **Björn Kenneth Holmström**. The A2 experiments were designed and specified with substantial AI assistance:

- Claude (Anthropic) implemented, verified and ran the studies, and drafted this manuscript;
- ChatGPT (OpenAI) reviewed each gate and audited the drafts.

This is a documented multi-agent review process, **not independent human peer review**. AI cross-checks are not an independent human code audit. An external human audit of the frozen solver and evaluator, together with public release of the executable code and pool manifests, remains an important next step.

Draft v0.2 is not a peer-reviewed publication.

## References

Del Moral, P., Doucet, A., & Jasra, A. (2006). Sequential Monte Carlo samplers. *Journal of the Royal Statistical Society: Series B, 68*(3), 411–436. https://doi.org/10.1111/j.1467-9868.2006.00553.x

Fel'dbaum, A. A. (1960). Teoriya dual'nogo upravleniya. I [Dual control theory. I]. *Avtomatika i Telemekhanika, 21*(9), 1240–1249. https://www.mathnet.ru/eng/at12624 (in Russian; parts II–IV followed in 1960–61)

Guez, A., Silver, D., & Dayan, P. (2012). Efficient Bayes-adaptive reinforcement learning using sample-based search. *Advances in Neural Information Processing Systems 25*. https://proceedings.neurips.cc/paper_files/paper/2012/file/35051070e572e47d2c26c241ab88307f-Paper.pdf

Hansen, L. P., & Sargent, T. J. (2008). *Robustness*. Princeton University Press. ISBN 978-0-691-11442-2. https://doi.org/10.1515/9781400829385

Holm, S. (1979). A simple sequentially rejective multiple test procedure. *Scandinavian Journal of Statistics, 6*(2), 65–70. https://www.jstor.org/stable/4615733

Holmström, B. K. (2026). *What Should We Optimize, and What Must We Know? Three Computational Experiments on Model Error, Future Goals, and the Cost of Learning*. Systemic Optimization — Working Paper 0, Draft v0.2.

Howard, R. A. (1966). Information value theory. *IEEE Transactions on Systems Science and Cybernetics, 2*(1), 22–26. https://doi.org/10.1109/TSSC.1966.300074

Iyengar, G. N. (2005). Robust dynamic programming. *Mathematics of Operations Research, 30*(2), 257–280. https://doi.org/10.1287/moor.1040.0129

Lempert, R. J., Popper, S. W., & Bankes, S. C. (2003). *Shaping the Next One Hundred Years: New Methods for Quantitative, Long-Term Policy Analysis* (MR-1626-RPC). RAND Corporation. https://doi.org/10.7249/MR1626

Marler, R. T., & Arora, J. S. (2004). Survey of multi-objective optimization methods for engineering. *Structural and Multidisciplinary Optimization, 26*, 369–395. https://doi.org/10.1007/s00158-003-0368-6

Nilim, A., & El Ghaoui, L. (2005). Robust control of Markov decision processes with uncertain transition matrices. *Operations Research, 53*(5), 780–798. https://doi.org/10.1287/opre.1050.0216

Puterman, M. L. (1994). *Markov Decision Processes: Discrete Stochastic Dynamic Programming*. Wiley. https://doi.org/10.1002/9780470316887

Raiffa, H., & Schlaifer, R. (1961). *Applied Statistical Decision Theory*. Division of Research, Graduate School of Business Administration, Harvard University.

Walters, C. J. (1986). *Adaptive Management of Renewable Resources*. Macmillan.

Walters, C. J., & Hilborn, R. (1978). Ecological optimization and adaptive management. *Annual Review of Ecology and Systematics, 9*, 157–188. https://doi.org/10.1146/annurev.es.09.110178.001105

**Original research artifacts** (Holmström, 2026; unpublished specifications and frozen computational results): the A2 gate designs, declarations and results notes listed in Appendix A. These are the primary sources for every experimental number. The external references establish conceptual and methodological precedent only.
