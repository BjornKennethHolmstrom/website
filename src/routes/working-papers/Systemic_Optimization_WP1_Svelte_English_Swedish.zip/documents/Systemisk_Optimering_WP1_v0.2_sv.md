---
title: "Vad händer om modellen är ofullständig?"
subtitle: "Beräkningsexperiment om kausal representation, ekologiska mål och lärandets begränsningar"
author: "Björn Kenneth Holmström"
date: "6 november 2026"
series: "Systemisk optimering — Arbetsrapport 1"
version: "Utkast v0.2 — svensk utgåva"
lang: sv
---

# Vad händer om modellen är ofullständig?

*Beräkningsexperiment om kausal representation, ekologiska mål och lärandets begränsningar*

**Systemisk optimering — Arbetsrapport 1**  
**Björn Kenneth Holmström**  
**6 november 2026 · Utkast v0.2 — svensk utgåva**

> **Revisionsanmärkning (v0.2).** Denna utgåva bygger på den integrerade revisionen av A2-S1 till seriens andra rapport. Den rättar sammanblandningen mellan fullständig förhandskunskap (O\*) och oraklet efter en fast sondering (X\*), införlivar evidensbilagorna och bevarar de frysta experimentresultaten. Inga experiment, estimand eller testutfall har ändrats. Forskningsprogrammets beteckning är **A2**.

> **Evidenskonvention.** Som i arbetsrapport 0 betecknar **[R]** ett resultat inom den angivna beräkningsmodellen, med status angiven som *konfirmatoriskt*, *förhandsdefinierat deskriptivt*, *explorativt* eller *strukturellt*. **[IP]** är en tolkande proposition och **[H]** en hypotes för framtida prövning. De finare statuskoderna finns i bilaga A. Resultat från syntetiska modeller är inte i sig belägg för effekter i verkliga avrinningsområden eller institutioner.

## Sammanfattning

En optimerare kan lösa sitt formella problem korrekt men ändå fatta dåliga beslut i den värld där den verkar. Svårigheten kan ligga i vad målfunktionen värderar, vilka orsaksmekanismer modellen representerar eller om beslutsfattarens egna handlingar gör det möjligt att upptäcka det som modellen har utelämnat.

Som en fortsättning på *Systemisk optimering — Arbetsrapport 0* undersöker vi hur dessa brister samverkar. Vi använder en syntetisk modell för översvämningsanpassning i tre kommuner över elva perioder. Tre hydrologiska mekanismer kan slås av och på oberoende av varandra, både i den fysiska världen och i planeringsmodellen: nedströms vattenretention från våtmarker, synkronisering av flödestoppar och regnberoende mellan avrinningsområden.

Vi skiljer mellan tre svar: att **anta** en utelämnad mekanism i modellen (*ommodellera*), att **ändra målet** så att ekologiskt kapital belönas (*omvärdera*) och att **agera för att lära** vilka mekanismer som faktiskt verkar. Bara de två första svaren jämförs i det konfirmatoriska testet. Lärandet studeras explorativt i i förväg utvalda utvecklingsvärldar.

**Konfirmatoriska resultat.** Testet omfattade 40 oberoende dragna syntetiska världar och en uttryckligen hypotetisk lika viktning av världar där retention finns respektive saknas. Att anta retention och minimera den ursprungliga kostnaden U1 gav lägre genomsnittlig U1-kostnad än att optimera ett ekologiskt mål med en modell som utelämnade retention: medelskillnad −1,112 (95-procentigt konfidensintervall −1,737 till −0,487). Det fördefinierade precisionsmålet uppnåddes inte. Det ekologiska målet gav däremot mindre ackumulerat våtmarksunderskott och större kvarvarande våtmarksbestånd.

**Deskriptiva och explorativa resultat.** En förhandsdefinierad deskriptiv jämförelse visade en mycket mindre genomsnittlig U1-kontrast av att utelämna retention med det ekologiska målet (+0,014 jämfört med +1,851). Det hade ett U1-pris på +1,085 när modellen var korrekt. Vid felaktiga planeringsparametrar försvann nästan den observerade U1-fördelen med att anta mekanismen. En passiv policy kan hålla en beslutsrelevant mekanism permanent oobserverbar. En exakt bayesiansk lärandealgoritm som sonderar och sedan väljer en fast fortsättning, trots brusfria observationer av hela tillståndet, fångade högst ungefär en femtedel av ett orakels marginal.

Resultaten gäller en enda familj av syntetiska modeller, inte observerade avrinningsområden. De antyder att kausal representation, målval och observationsmöjligheter måste utvärderas tillsammans: om man ändrar en av dem förändras de andras kostnader och möjligheter.

**Nyckelord:** systemisk optimering; ofullständiga modeller; kausal representation; surrogatmål; ekologiska mål; identifierbarhet; informationsvärde; adaptiv förvaltning; beräkningsbaserad förhandsregistrering.

## 1. En korrekt lösning på ett ofullständigt problem

Optimering börjar först efter att någon har bestämt tre saker: vad beslutsfattaren ska värdera, vilka konsekvenser modellen ska innehålla och vilka belägg som får samlas in. En policy kan vara optimal för dessa val och ändå vara ett dåligt svar på det fysiska systemet. Det är inte ett räknefel. Det är ett fel — eller ett oprövat antagande — i *hur problemet som beräknas har konstruerats*.

Arbetsrapport 0 (Holmström, 2026) skilde mellan fyra former av tillräcklighet: målfunktionen, den kausala modellen, information om framtida mål och lärandet. Översvämningsexperimentet A1 visade att ett ekologiskt inslag i målfunktionen delvis kunde kompensera för hydrologisk struktur som utelämnats ur planeringsmodellen. Skillnaden-i-skillnader-kontrasten för strukturell kompensation uppgick till 34,3 % av den förenklade modellens ånger (*regret*).

A1:s snäva modell utelämnade tre mekanismer *samtidigt*: nedströms retention, synkronisering av flödestoppar och regnkorrelation. Därför lämnades en viktig fråga öppen. Vilket utelämnande var avgörande? Och skulle ett ändrat mål fortfarande vara värt sitt pris om mekanismerna kunde slås av och på oberoende av varandra, eller om beslutsfattaren helt enkelt representerade dem i modellen?

Den här rapporten tar upp den frågan. Den utgår från en förgrening av samma översvämningsmodell där varje mekanism kan aktiveras eller avaktiveras separat, både i världen och i modellen. De numeriska resultaten från de två rapporterna är avsiktligt **inte direkt jämförbara**: A1:s estimand var en skillnad-i-skillnader för målkompensation mot ett samlat utelämnande på 800 latin-hyperkubdragna världar; här jämförs två policypaket på 40 oberoende dragna världar. Inget tal i den ena rapporten ska tolkas som en replikation av ett tal i den andra.

### 1.1 Tre svar, inte tre sorters reparation

En planerare som misstänker att modellen är ofullständig har åtminstone tre handlingsvägar:

- **Ommodellera.** Föra in mekanismen i modellen innan det finns belägg för den.
- **Omvärdera.** Ändra målfunktionen så att skyddet av en värdefull resurs också kan skydda mot en utelämnad konsekvens.
- **Lära.** Handla för att undersöka vilka mekanismer som faktiskt verkar.

Dessa är inte utbytbara åtgärder. **Ommodellering utan belägg är ett antagande.** Vi kallar strategin REP, för *repair*, men namnet betecknar strategin och påstår inte att modellen är korrekt. REP innebär ingen inferens och ingen kostnad för att inhämta modellen. Om mekanismen saknas planerar REP med en felaktig modell.

**Omvärdering kan köpa okänslighet för en utelämnad mekanism.** Den okänsligheten har ett mätbart pris enligt det ursprungliga kriteriet. **Lärande kräver exponering.** Systemet måste besöka tillstånd där mekanismen påverkar vad som kan observeras, och det måste finnas tid kvar att använda kunskapen. Exponering kan i sin tur kräva åtgärder som den befintliga policyn inte har något skäl att välja.

Dessa angreppssätt har långa idéhistorier under andra namn: adaptiv förvaltning och dubbel styrning (*dual control*; Walters & Hilborn, 1978; Walters, 1986; Fel'dbaum, 1960), robusthet mot modellosäkerhet (Hansen & Sargent, 2008; Lempert, Popper & Bankes, 2003), informationsvärde (Raiffa & Schlaifer, 1961; Howard, 1966) och flermålsoptimering (Marler & Arora, 2004). Rapporten gör inte anspråk på att introducera dessa idéer. Dess snävare syfte är att placera dem i ett och samma exakt lösbara beslutsproblem, där konsekvenserna kan spåras och samspelet synliggöras.

### 1.2 Vad rapporten fastställer och inte fastställer

**En konfirmatorisk jämförelse.** En på förhand låst jämförelse prövar en policy som antar en mekanism mot en policy som ändrar målet, på 40 syntetiska testvärldar. Resultatet är en kriterieberoende avvägning (§3).

**Förhandsdefinierade deskriptiva kontraster.** Dessa belyser avvägningen som robusthet till ett pris (§4).

**Explorativa studier.** Det gäller dels hur avvägningen påverkas av parameterfel, regnförskjutningar och andra mekanismer (§4.3), dels varför exponering inte garanterar lärande i utvalda utvecklingsvärldar (§5). Lärandestudierna är **inte** en tredje arm i det konfirmatoriska experimentet.

Alla världar är syntetiska parameterdragningar. Den lika viktningen mellan ”retention finns” och ”retention saknas” är en hypotetisk prior, inte en skattning. Rapporten innehåller inga direkta rekommendationer för ett verkligt avrinningsområde.

## 2. Vad som representeras, optimeras och observeras

### 2.1 Översvämningsmodellen

Modellen är A1:s system med tre kommuner, med oförändrad lösare, redovisning och utvärderingskriterium. Två kommuner ligger uppströms och en nedströms. Vi kallar dem Up1, Up2 och Dn för att undvika sammanblandning med kriterierna U1 och U2.

Det finns totalt **31 104 tillstånd**. De beskriver varje kommuns budgetnivå och skyddskapacitet mot översvämningar, de två uppströmskommunernas våtmarksnivåer $w_i\in\{0,1,2\}$ och ett vått eller torrt väderregimläge.

I var och en av elva perioder kan uppströmskommunerna avstå från åtgärder, bygga skydd eller återställa våtmark. Kommunen nedströms kan avstå, bygga eller samfinansiera återställning uppströms. En regional stödfond har alternativet $o\in\{0,1\}$, som väljs en gång mot en avgift. Regnet har tre nivåer i vartdera uppströms avrinningsområdet.

**Kriteriet U1** omfattar utgifter och avgifter till stödfonden, kvarvarande översvämningsskador efter stödinsatser, påföljd för budgetunderskott och monetariserad skada samt ett terminalt restvärde. **U2** lägger till en påföljd för den största enskilda kommunens kvarvarande skada. U2 tar viss hänsyn till fördelning men är inte ett fullständigt rättvisemått.

Policyerna beräknas med exakt dynamisk programmering för ändlig horisont (Puterman, 1994), med reservation för flyttalsprecision och regler för likvärdiga alternativ. De utvärderas exakt genom att tillståndens beläggningssannolikheter propageras framåt. Oberoende Monte Carlo-simulering kontrollerar resultaten statistiskt (bilaga C).

### 2.2 Slå av och på mekanismer

En *mask* anger vilka av tre mekanismer som finns, i ordningen R, S, C. Masken **111** har alla tre; **011** saknar retention.

| Mekanism | Finns | Saknas |
|:---|:---|:---|
| **R: retention nedströms** | Belastningen nedströms utgår från avrinning *efter* retention; uppströms våtmarker skyddar nedströms | Belastningen utgår från obehandlad avrinning |
| **S: synkronisering av toppflöden** | En tecknad term proportionell mot den mindre av de två retentionandelarna ändrar belastningen nedströms | Ingen sådan term |
| **C: regnberoende** | Gaussisk kopulakorrelation mellan avrinningsområdenas regn | Oberoende regn med samma marginaler |

Den **fysiska** masken $m^*$ beskriver världen; den **representerade** masken $m$ beskriver planerarens modell. Samtliga $8\times8$ kombinationer utvärderas inom varje basvärld.

**Planeringsvillkor.** Vid $s=0$ är planeringsparametrarna lika med de sanna; vid $s=0,25$ används två deklarerade störningsdragningar. Vid utvärdering kan sannolikheten för kraftigt regn ändras med $\psi\in\{-0.1,0,+0.1\}$.

**Kontinuitet med A1.** Mask 111 återger A1:s fullständiga modell exakt och mask 000 återger den tidigare samlat förenklade modellen, element för element. A2:s tester verifierar detta.

**[R, strukturellt] Exponering.** Retention uppströms är proportionell mot våtmarksnivån. Utan uppströms våtmark ger modellerna med och utan R identiska övergångar. Synkroniseringstermen försvinner när någon av våtmarkerna är tom. En policy som aldrig anlägger våtmark kommer alltså aldrig till tillstånd där R eller S kan påverka det som observeras.

### 2.3 Vad som optimeras och hur det bedöms

**Planeringsmål:**

- **F0** minimerar förväntad U1.
- **F1-eco** lägger till en kostnad för våtmarksunderskott:

$$
\min_\pi\ \mathbb{E}_\pi\Big[\sum_{t=0}^{10} c^{U1}_t + \text{salvage}\Big]+\lambda\,\mathbb{E}_\pi\Big[\sum_{t=0}^{10} g_t\Big],\qquad g_t=\tfrac{2-w_{1,t}}{2}+\tfrac{2-w_{2,t}}{2}.
$$

  Här beräknas $\lambda=0.1\cdot\mathrm{range}(\text{cost})/\mathrm{range}(g)$ för varje planeringsmodell, precis som i A1.
- **F1-eco-fixed** låser $\lambda$ till värdet i den fullständiga modellen och testar om resultaten beror på att vikten räknas om.

**Utvärderingskriterier.** Varje policy bedöms enligt fyra kriterier som alla minimeras, i det sanna scenariot och med policyns eget fondval:

- $J_{U1}$ och $J_{U2}$: de ovan definierade kostnaderna.
- $J_{def}=\mathbb{E}\sum_tg_t$: ackumulerat våtmarksunderskott uppströms.
- $J_{stock}=-\mathbb{E}[w_1+w_2]$ i slutet av horisonten: negativt terminalt våtmarksbestånd.

Varje kriterium har ett eget exakt orakel som väljer den policy som är optimal enligt just det kriteriet.

### 2.4 Två förändringar samtidigt: policypaketen

För en mekanism $X$ och en basmask $m_0$ som saknar den bildar fyra strategier en $2\times2$-design.

| | Målfunktion F0 | Målfunktion F1-eco |
|:---|:---|:---|
| Modell $m_0$ (X utelämnas) | OMIT | **COMP** (omvärdering) |
| Modell $m_0\cup X$ (X antas) | **REP**(X) (ommodellering) | BOTH(X) |

Den konfirmatoriska kontrasten jämför de två markerade cellerna för $X=R$ och $m_0=011$:

$$
\Delta_i=\tfrac12\sum_{m^*\in\{111,\,011\}}\Big[J_{U1}\big(\pi^{F0}_{111};m^*\big)-J_{U1}\big(\pi^{F1\text{-eco}}_{011};m^*\big)\Big].
$$

Varje värld $i$ bidrar med medelvärdet för retention närvarande och frånvarande, med lika **hypotetiska** vikter. $\Delta_i<0$ innebär att REP hade lägre U1. Eftersom jämförelsen samtidigt ändrar *den representerade mekanismen* och *målfunktionen* mäter den skillnaden mellan två policypaket, inte den isolerade effekten av respektive förändring. De två andra cellerna och en ångerdekomposition används för tolkningen.

**MIX** är ett extra riktmärke som optimerar F0 med ett per-period-viktat genomsnitt av två modeller, med vikten $q$ för den som innehåller $X$. Det är en heuristik, inte den optimala policyn för en värld där mekanismen är fast men okänd.

### 2.5 Var ånger uppstår

För en strategi som utvärderas enligt kriteriet $J$ i ett givet scenario kan ångern relativt $J$-oraklet delas upp i tre termer:

$$
J(\pi_a)-J(\pi_d)=\underbrace{[J(\pi_a)-J(\pi_b)]}_{\text{representation}}+\underbrace{[J(\pi_b)-J(\pi_c)]}_{\text{parametrar och skift}}+\underbrace{[J(\pi_c)-J(\pi_d)]}_{\text{mål}}.
$$

Här är $\pi_a$ den använda policyn; $\pi_b$ har samma mål men korrekta mekanismer; $\pi_c$ har samma mål samt korrekta mekanismer och parametrar; och $\pi_d$ är oraklet för $J$. Parametertermen är exakt noll vid $s=0,\psi=0$. Detta är en **ordningsberoende bokföringsuppdelning**, inte unika kausala effekter.

### 2.6 Evidensupplägg

| Etapp | Världar | Roll |
|:---|:---|:---|
| Pilot Gate C | 8 utvecklingsvärldar | Explorativ faktoriell studie av utelämnade mekanismer |
| Exponerings- och lärandestudier | Förhandsvalda utvecklingsvärldar | Explorativa |
| Utvecklingskörning | 16 utvecklingsvärldar | Planering av stickprovsstorlek |
| **Konfirmatoriskt test** | **40** oberoende och likformigt dragna världar från låsta parameterintervall, via en reserverad slumpström efter fryst kod och konfiguration | **Konfirmatoriskt** |

Det primära testet är ett tvåsidigt t-test av medelvärdet för $\Delta$ (39 frihetsgrader). Precisionsmålet var ett 95-procentigt intervall med halvbredd 0,50 U1; den deklarerade lägsta stickprovsstorleken 40 användes. Fyra sekundära tester Holm-justerades (Holm, 1979): $\Delta$ enligt $J_{U2}$, $J_{def}$, $J_{stock}$ samt BOTH(R) − REP(R) enligt $J_{U1}$. Allt annat i faktorialen är deskriptivt eller explorativt.

Som i arbetsrapport 0 tidsstämplades deklarationer före körningarna; misslyckade valideringsgrindar sparades som FAIL och rättades endast genom nya deklarerade grindar; och den reserverade testströmmen fick användas en enda gång av ett auktoriserat steg. Bilaga C redovisar proveniensen och dess begränsningar.

## 3. Vad den konfirmatoriska jämförelsen visar

### 3.1 Ommodellering gav lägre genomsnittlig kostnad [R, konfirmatoriskt]

Med den hypotetiska lika viktningen hade REP(R) lägre populationsgenomsnittlig U1 än COMP. Medelskillnaden var **−1,112 U1** (95-procentigt konfidensintervall −1,737 till −0,487; $t(39)=-3.60$, $p=0.00089$).

Nollhypotesen om ingen medelskillnad förkastas på den deklarerade nivån. Den planerade precisionen uppnåddes däremot inte: intervallets halvbredd var **0,625**, mot målet 0,50. Standardavvikelsen i testsamplet (1,954) var betydligt större än under utvecklingen (1,138), och stickprovet utökades inte.

**Världarna skiljer sig åt** (figur 1): 30 av 40 gynnar REP; i en fjärdedel är kompensation lika billig eller billigare. Ytterligheterna är −6,10 (t39) och +4,92 (t18). Medianen är −0,382 och skevheten −0,22.

Två i förväg deklarerade deskriptiva kontroller pekar åt samma håll som t-intervallet: ett bootstrap-percentilintervall [−1,705, −0,518] och ett Wilcoxon-test med $p=1.1\times10^{-4}$.

![Primär kontrast per testvärld](figures/wp1_fig1_primary_delta_sv.png)

*Figur 1.* $\Delta_i$ för 40 testvärldar, sorterade med medelvärdet markerat. Det skuggade bandet är ett 95-procentigt **konfidensintervall för medelvärdet**, inte ett intervall som ska innehålla alla enskilda världar. Källa: `f0c_confirmatory.json`. [R, konfirmatoriskt]

### 3.2 Den ekologiska sidan av avvägningen [R, konfirmatoriskt]

Den förhandsdefinierade sekundära testfamiljen visar den andra sidan av jämförelsen.

| Kontrast | Medelvärde | 95 % KI (ojusterat) | Holm-justerat $p$ | Lägre på detta kriterium |
|:---|---:|:---|---:|:---|
| $\Delta J_{U2}$ (kostnadsenheter) | −1,061 | [−1,734, −0,388] | 0,0028 | REP |
| $\Delta J_{def}$ (underskottsenheter över elva perioder) | +6,362 | [+4,235, +8,489] | $1.3\times10^{-6}$ | COMP |
| $\Delta J_{stock}$ (negativ terminal våtmarksnivå) | +1,543 | [+1,056, +2,030] | $5.6\times10^{-7}$ | COMP |
| BOTH(R) − REP(R), $J_{U1}$ | +1,603 | [+0,992, +2,214] | $9.6\times10^{-6}$ | REP |

Konfidensintervallen är vanliga 95-procentiga intervall och har **inte** justerats för multipla tester. Endast p-värdena är Holm-justerade.

För det fördelningskänsliga kostnadskriteriet är REP:s fördel ungefär densamma som för U1. COMP ger mindre ackumulerat våtmarksunderskott och större våtmarksbestånd vid horisontens slut. Att både anta mekanismen och omvärdera (BOTH) kostar mer U1 än att bara anta den. BOTH:s ekologiska utfall ingick inte i det testet.

![Förhandsdefinierade kriteriekontraster](figures/wp1_fig2_criterion_contrasts_sv.png)

*Figur 2.* Förhandsdefinierade kontraster, var och en på sin egen skala. Källa: `f0c_confirmatory.json`. [R, konfirmatoriskt]

### 3.3 Policypaket jämförs, inte modellreparation isolerat [IP]

Två förhållanden skyddar mot en frestande feltolkning.

**REP är ett antagande, inte en upptäckt.** I den halva av den hypotetiska viktningen där retention saknas planerar REP med fel modell och har ändå lägre U1 än COMP (medelskillnad för grenen −1,125, 95 % KI −2,126 till −0,124; deskriptiv undergrupp). Att ha fel om världen var enligt U1 billigare än att betala för det ekologiska målet.

En explorativ dekomposition av de 40 testvärldarna (bilaga B, T4) förklarar mönstret: REP:s kostnad för felaktig representation i den grenen är **+1,765 U1**; COMP:s målpris är **+2,890**. I utvecklingsvärldarna var ordningen densamma (1,06 respektive 2,42). Resultatet handlar därför i hög grad om målkonflikten, inte om att planeraren *hittade* rätt modell.

**Kontrasten ändrar två saker.** Steget från COMP till REP lägger till en mekanism i modellen *och* tar bort det ekologiska målet. Den konfirmerade medelskillnaden gäller detta paket. Den kan inte tillskrivas bättre modellering ensam och säger inget om huruvida *investeringar i* bättre modeller är mer lönsamma än investeringar i målutformning eller information. Sådana investeringar modellerades inte.

### 3.4 Vad avvägningen fastställer och inte fastställer

**[R, härlett ur konfirmatoriska tester]** För den förhandsdefinierade jämförelsen REP(R) mot COMP under den hypotetiska lika viktningen pekar medelskillnaderna i olika riktningar för namngivna kriterier: REP har lägre U1 och U2, medan COMP ger lägre ackumulerat underskott och högre terminalt våtmarksbestånd. Ingen av dessa två policyer är entydigt bättre. Det är en logisk sammansättning av fyra testresultat, inte ett ytterligare test.

Detta gäller **inte alla strategier**. I de explorativa tabellerna har den heuristiska MIX(R, q) lägre lika viktad genomsnittlig U1 än båda rena F0-valen: 6,465–6,638, jämfört med 6,967 när retention utelämnas och 6,924 när den antas (bilaga B, T5). REP slår alltså COMP enligt U1 men är inte den U1-bästa av de utvärderade policyerna. MIX är emellertid inte en korrekt trosbaserad policy för en fast men okänd värld, och jämförelsen är explorativ.

## 4. Varför robusthet genom målet har ett pris

### 4.1 Ett mål som knappt märker utelämnandet [R, förhandsdefinierat deskriptivt]

Hur mycket kostar det enligt U1 att utelämna retention ur respektive mål när retention faktiskt finns? Representationstermen svarar på detta: kostnadsskillnaden mellan planering på 011 och 111, i genomsnitt över 40 världar vid $s=0,\psi=0$.

| Målfunktion | Genomsnittlig representationsterm (U1) | 95 % intervall |
|:---|---:|:---|
| F0 | **+1,851** | [+0,802, +2,900] |
| F1-eco | **+0,014** | [−0,173, +0,201] |
| F1-eco-fixed | +0,094 | [−0,206, +0,395] |

Den observerade genomsnittliga kostnaden för utelämnandet var alltså **betydligt mindre i detta urval** med det ekologiska målet än med F0. Jämförelsen var förhandsdefinierad deskriptiv, inte ett ekvivalenstest. Ingen ekvivalensmarginal hade bestämts; F1-eco-intervallet rymmer både meningsfulla positiva och negativa värden; varianten med fast $\lambda$ visar bara att resultatet inte helt drivs av omräkning av vikten; och bara en mekanism och en basmodell prövades.

**[IP]** En tänkbar förklaring är att den ekologiska målfunktionen återställer våtmark redan av egna skäl. Att upptäcka att våtmark också skyddar kommunen nedströms skulle då förändra policyn väldigt lite. F0 återställer våtmark bara när dess modell säger att det lönar sig.

### 4.2 Priset [R, förhandsdefinierat deskriptivt]

Det ekologiska målet betalas för även när modellen är korrekt. Dess målterm under rätt modell är **+1,085 U1** (95 % intervall +0,612 till +1,558).

Det förklarar formen på det konfirmatoriska resultatet. I den explorativa fyrtiovärldsdekompositionen (bilaga B, T4) betalar COMP sitt målpris i båda grenarna: +1,085 när retention finns och +2,890 när den saknas. REP betalar för felaktig modell endast när retention saknas: +1,765. Med lika viktning överväger det ständigt betalda priset den ibland betalda felmodelleringskostnaden.

![Robusthet och pris](figures/wp1_fig3_robustness_price_sv.png)

*Figur 3.* **A:** kostnader för utelämnad retention och för det ekologiska målet, medelvärden och 95-procentiga intervall över 40 världar; förhandsdefinierat deskriptivt. **B:** kostnader för utelämnande vid regnförskjutning, enbart världsmedelvärden; explorativt (bilaga B, T2).

**[IP — Robusthet är något man köper.]** En målfunktion som gör en plan okänslig för en utelämnad mekanism har i en mening köpt försäkring mot detta utelämnande. Om köpet är värt det beror på hur sannolik mekanismen är, hur dyrt det är att missa den och hur mycket försäkringen kostar när den inte behövs. Att kalla ett surrogatmål ”robust” utan att ange priset döljer halva jämförelsen.

### 4.3 När bilden förändras [R, explorativt]

Den konfirmatoriska jämförelsen gällde exakta planeringsparametrar, ingen regnförskjutning och en enda mekanism. Den frysta faktorialen omfattar fler villkor. Tabellerna definierades före beräkningen och redovisas i sin helhet i bilaga B, även när de motsäger huvudmönstret. De är explorativa och ändrar inte den konfirmatoriska slutsatsen.

**Parameterfel.** När planeringsparametrarna störs ($s=0,25$) försvinner REP:s genomsnittliga U1-fördel nästan helt: −0,010 och −0,301 i de två dragningarna, med världar fördelade 24/15 och 26/12 (resterande är exakta lika resultat). F0:s parameterterm (+2,37 till +2,65 U1) överstiger F1-eco:s (+0,86 till +1,52). De ekologiska kontrasterna behåller sin riktning. Det konfirmerade U1-resultatet gäller alltså **exakta parametrar**; det får inte beskrivas som robust mot parameterfel. Medelvärden nära noll är deskriptiva och bevisar inte att en effekt saknas.

**Regnförskjutning.** F0:s utelämnandekostnad växer från +0,518 via +1,851 till +3,567 när $\psi$ går från −0,1 till +0,1; F1-eco:s term håller sig under +0,08. REP-minus-COMP-kontrasten flyttar sig från −1,318 till −0,808 utan att byta tecken.

**Andra mekanismer.** För samtliga tolv par av basmodell och mekanism gynnar den genomsnittliga U1-kontrasten REP och underskottskontrasten COMP. För S och C är dock själva utelämnandekostnaden liten. Dessa kontraster avspeglar framför allt ekologimålets U1-pris, inte något större värde av att representera S eller C.

**Paretofronter.** Varje strategi är oftast icke-dominerad bland 33 utvärderade policyer när dess egen modell är korrekt, men ofta dominerad när modellen är fel. På fronten U1–våtmarksunderskott är REP icke-dominerad i 97,5 % av världarna där retention finns, men 55 % där den saknas. COMP är icke-dominerad i 100 % utan retention, men 30 % med retention.

**Vilken utelämnad mekanism som spelar störst roll är villkorsberoende.** I den tidigare piloten med åtta utvecklingsvärldar (fysisk mask 111; mekanismer avlägsnade ur planeringsmodellen) står R för nästan hela F0:s U1-effekt vid exakta parametrar: R +0,796, S −0,003 och C +0,027. Vid parameterfel ($s=0,25$, $\psi=0$) är effekten av att utelämna C (+0,434) större än av att utelämna R (+0,338). Detta är effekter av *vad planeraren representerar*, inte rena fysiska effektstorlekar, och urvalet är litet.

**[IP]** En utelämnad mekanisms relevans är inte en fast egenskap hos mekanismen. Den beror också på vad planeraren har fel om i övrigt.

## 5. Varför exponering inte garanterar lärande

Det tredje svaret, lärandet, ingick inte i det konfirmatoriska testet. Det studerades i en rad explorativa grindar med förhandsvalda utvecklingsvärldar och exakta beräkningar där det var möjligt. Frågan är enkel: om planeraren misstänker att retention kan finnas, kan den få reda på det i tid för att kunskapen ska löna sig?

### 5.1 Ett nollfall inbyggt i modellen [R, strukturellt]

Utan våtmark uppströms är övergångslagarna identiska med och utan retention (§2.2). Detta gäller alla undersökta oexponerade tillstånd–handlingspar, i varje värld och variant.

För den specifika observationslikelihood som användes i inferensgrindarna är logaritmen av Bayesfaktorn mellan ”retention finns” och ”retention saknas” exakt noll på sådana historiker. Det är ett påstående om just den likelihooden. Det visar inte att fullständiga historiker saknar information under varje möjlig observationsmodell.

### 5.2 En fälla som policyn själv upprätthåller [R, explorativt]

En *exponeringsfälla* uppstår när en utelämnad mekanism spelar roll för beslutet, men planerarens egen policy aldrig leder till ett tillstånd där mekanismen kan upptäckas. Under passiv drift identifierade exponeringsstudien **sju** exakta sådana fällor i sex utvecklings- och stresstestvärldar: sex för retention och en för synkronisering.

I världen d05 ökar en modell som utelämnar retention den verkliga U1-kostnaden med **2,36** vid $\psi=0$. Samtidigt ger den planeraren noll beläggning av tillstånd där retention kan verka. Hur länge den än fortsätter ser den därför inga belägg som skulle kunna rätta modellen: de egna besluten håller beläggen utom räckhåll.

**[IP — Observerbarheten beror på policyn.]** Om ett modellfel går att upptäcka är inte enbart en egenskap hos världen och sensorerna. Det beror också på den policy som körs. En planerare kan upprätthålla sin egen blinda fläck.

### 5.3 Exponering är ännu inte evidens [R, explorativt]

Anta att planeraren medvetet återställer våtmark under $k$ år — en *sondering* — och sedan förbinder sig till en plan. Vi byggde en exakt bayesiansk lärandealgoritm för denna situation. Den känner till två hypoteser, observerar hela tillståndet utan brus, uppdaterar sin posterior exakt och väljer en fortsättning vid år $k$. Upplägget är medvetet gynnsamt och besläktat med bayesianskt adaptiv planering (Guez, Silver & Dayan, 2012).

**[R, strukturellt]** Ett enda sonderingsår kan inte ge denna lärandealgoritm information: den första övergången börjar i ett oexponerat tillstånd, så posteriorn är identisk med priorn på varje historia.

**[R, explorativt]** Längre sonderingar skapar exponering långt innan de skapar användbar evidens. I d05 exponerar sonderingen retention med sannolikheterna 0,77, 0,95 och 0,99 vid $k=1,2,3$, men sannolikheten att posteriorn alls har ändrats är 0, 0 och 0,15. I d00 kommer evidensen tidigare (0,47 vid $k=2$); i d02 kommer den först vid $k=3$ (0,36). Se figur 4.

![Exponering och lärande](figures/wp1_fig4_exposure_learning_sv.png)

*Figur 4.* Sannolikheten att retention är exponerad vid beslutstillfället (A), respektive att posteriorn då har ändrats (B). Gemensam sondering, retention närvarande. Källa: `e1lite_cells.csv`. [R, explorativt; del B vid $k=1$ är strukturellt]

### 5.4 Vad lärande skulle kunna vara värt och vad läraren faktiskt får [R, explorativt]

Tre jämförelser i studierna av lärandets värde måste hållas isär.

**Allvetande från början (O\*).** Denna planerare vet redan vid start om retention finns. Dess fördel jämfört med passiv drift, $C(P0)-C(O^*)$, är 0,92 / 1,84 / 2,76 U1 i d00 och 0,59 / 1,18 / 1,77 U1 i d05 när den hypotetiska sannolikhetsvikten för retention ökar från 0,25 via 0,50 till 0,75. Fördelen är noll i de två kontrollvärldarna där retention saknar betydelse. Det är en gräns relativt den passiva policyn, inte ett kanoniskt EVPI-värde (Howard, 1966) och inte vinsten av någon sondering.

**Oraklet efter en fast sondering (X\*).** X\* måste först genomföra en förutbestämd sondering under $k$ perioder och får sedan perfekt information innan det fortsätter. Jämfört med en begränsad meny av fasta policyer, B_extended, som även omfattar sonderingarna utan lärande, har X\* positiv nettomarginal i bara **10 av 54** primära celler i de tre världar där retention spelar roll (7 av 54 i en känslighetsvariant). Med de två kontrollvärldarna inräknade blir talen 10/90 och 7/90. Nämnarna svarar på olika frågor. X\* är ett tak *för sin fixerade sondering*, inte en övre gräns för alla adaptiva policyer.

**Den genomförbara läraren.** Den exakta algoritmen som sonderar och sedan väljer en fast fortsättning tar till vara högst omkring en femtedel av X\*:s marginal. Kvoten $\kappa$, relativt X\*:s marginal över B_extended, är som bäst 0,107 i huvudvarianten och 0,179 i känslighetsvarianten. Det deklarerade kriteriet ($\kappa\ge0,5$) klaras inte i någon av de nio celler där kvoten är definierad. Läraren slår B_extended i 2 av 54 celler, båda med ett enda sonderingsår och **utan någon posterioruppdatering** (figur 5).

En uppdelning av algoritmens vinster visar att nästan hela nyttan kommer från **tillståndsberoende val av fortsättning**, med priorn och det uppnådda tillståndet som underlag, och inte från att övertygelsen om retention ändras. Posterioruppdateringen är värd högst 0,069 U1 i någon cell och utgör 2,1 % av de större vinsterna.

![Orakel och genomförbar lärandealgoritm](figures/wp1_fig5_oracle_vs_learner_sv.png)

*Figur 5.* Nettomarginalen för oraklet X\* efter fast sondering över den begränsade menyn B_extended, jämfört med lärarens, i 54 primära celler där retention spelar roll. Detta är **programmens nettomarginaler mot en begränsad meny**, inte isolerat informationsvärde. Lärarens positiva marginaler vid $k=1$ innehåller ingen posterioruppdatering. Källa: `e1lite_cells.csv`. [R, explorativt]

**[IP — Informationsvärde är inte samma sak som värdet för en genomförbar lärandealgoritm.]** Det teoretiska värdet av att känna till en mekanism, även inom en given sondering, kan vida överstiga vad en enkel exakt algoritm tjänar under samma tidshorisont. Skillnaden beror inte på dålig inferens utan på tid, exponering och bindande beslut: evidensen kommer sent, sonderingen kostar och den återstående horisonten är kort.

Detta överensstämmer med arbetsrapport 0:s slutsats att information kan vara värdefull även när det inte lönar sig att hämta in den. Här är kostnaden inte ett produktionsuppehåll, utan den fysiska investering som krävs för att mekanismen alls ska bli synlig. Resultaten gäller en algoritm, en jämförelsemeny, brusfri observation, ett enda bindande fortsättningsbeslut och utvalda världar. De visar inte att lärande aldrig kan löna sig.

## 6. Tre svar, ett sammanflätat beslutsproblem

### 6.1 Vad varje svar faktiskt förändrar

| Svar | Vad förändras? | Vad kostar det här? | Resultat |
|:---|:---|:---|:---|
| **Ommodellera** (anta R) | Den representerade övergångslagen | Ingen direkt startkostnad; felmodelleringskostnad när R saknas | Lägre genomsnittlig U1 och U2 än omvärdering vid exakta parametrar [R, konfirmatoriskt]; fördelen försvinner nästan vid parameterfel [R, explorativt] |
| **Omvärdera** (ekologiskt mål) | Målfunktionen | Ett U1-pris oavsett om R verkar [R, förhandsdefinierat deskriptivt] | Bättre våtmarksutfall [R, konfirmatoriskt]; betydligt mindre observerad känslighet för utelämnad R [R, förhandsdefinierat deskriptivt] |
| **Lära** (sondering, sedan bindande val) | Vad och när planeraren kan observera | Fysisk sonderingskostnad och tid | Strukturella nollfall och självupprätthållna exponeringsfällor; låg realiserad nytta för den enkla läraren [R, strukturellt/explorativt] |

**[IP — Svaren är sammanflätade.]** De tre svaren är inte oberoende reglage: målfunktionen avgör om våtmarker anläggs; våtmarkerna avgör om retention kan observeras; observerbarheten avgör om lärande är möjligt; och lärandet påverkar vilken modell som används.

En ekologisk omvärdering kan alltså skapa möjligheter till lärande som bieffekt genom att bygga upp det bestånd som den utelämnade mekanismen verkar genom. Att anta en mekanism kan göra lärande överflödigt för ett kriterium, men ändå försämra ett annat. Ingen av dessa kopplingar var föremål för ett eget konfirmatoriskt test. Tabellen tolkar flera separat fastställda delar.

### 6.2 Negativa resultat som måste få finnas kvar

1. **Den konfirmerade fördelen med ommodellering är skör.** Precisionsmålet missades; tio av fyrtio världar gick åt andra hållet eller var likvärdiga; vid parameterfel försvann fördelen nästan.
2. **Robusthet var inte gratis.** Den ekologiska målfunktionens låga känslighet för utelämnandet hade ett U1-pris även när modellen var korrekt, och ingen ekvivalens visades.
3. **Den jämförda policyn var inte bäst av alla.** En enkel säkringsheuristik gav lägre genomsnittlig U1 än båda rena åtagandena.
4. **Den enkla läraren lärde sig lite.** Det deklarerade kriteriet uppnåddes inte, och de få vinsterna kom från val av fortsättning, inte från ny information.
5. **Validering kan underkänna korrekt kod.** Två kontrollgrindar förkastade fungerande implementationer: en normalapproximation för sällsynta händelser och en felaktig deklarerad olikhet. Båda misslyckandena sparades och rättades endast genom nya deklarerade grindar (bilaga C).

### 6.3 En fördjupning av arbetsrapport 0:s diagnostiska ram [IP]

Arbetsrapport 0 föreslog fyra frågor innan en åtgärd väljs: Vad spelar roll? Hur fungerar världen? Vad kan spela roll senare? Kan vi lära oss i tid? Den här rapporten föreslår en förfining av fråga två och fyra.

| Fråga | Förfining från denna rapport | Diagnostiskt objekt |
|:---|:---|:---|
| Hur fungerar världen? | *Vilket* utelämnande som spelar roll beror på vad som i övrigt är fel (parametrar, skift) | Kostnader för utelämnanden under olika planeringsvillkor |
| Hur fungerar världen? | Att anta en mekanism och att representera den korrekt är olika påståenden | REP utvärderad i båda mekanismgrenarna |
| Kan vi lära oss i tid? | Är mekanismen observerbar *under den policy som vi faktiskt kör*? | Exponeringsbeläggning under vald policy |
| Kan vi lära oss i tid? | Mäts nyttan av lärande mot en genomförbar lärandealgoritm, inte ett orakel? | Algoritmens marginal gentemot en meny av fasta policyer |

Ramen är fortfarande ett förslag för framtida operationalisering, inte ett validerat ramverk.

## 7. Obesvarade frågor och begränsningar

### 7.1 Begränsningar

- **Syntetisk generator.** Testvärldarna är oberoende dragningar från en enda forskardefinierad generator. Inferensen är därför villkorad av den. T-intervallet vid $n=40$ är approximativt.
- **Hypotetisk viktning.** Lika vikt mellan retention närvarande och frånvarande är en hypotetisk prior; andra vikter skulle förändra estimanden.
- **En konfirmerad mekanism.** Endast retention testades konfirmatoriskt, från en basmodell, med exakta parametrar och utan regnförskjutning.
- **Strategiuppsättning.** REP är ett antagande, inte en upptäckt. MIX är en heuristik. Den ambiguitetsrobusta planeraren från A1, som arbetsrapport 0 föreslog att jämföra (Iyengar, 2005; Nilim & El Ghaoui, 2005), utvärderades inte här.
- **Lärandestudier.** De bygger på utvalda utvecklingsvärldar, brusfria observationer av hela tillståndet, ett känt problem med två hypoteser och ett enda beslut om fast fortsättning.
- **Kriterier.** U2 är en enkel fördelningskänslig variant; våtmarksunderskott och bestånd är modellstorheter, inte fältindikatorer.

### 7.2 Hypoteser för framtida forskning

Numreringen fortsätter efter arbetsrapport 0:s H1–H4.

**[H5 — Vändpunkter kan förutses.]** Tecknet på kontrasten mellan ommodellering och omvärdering i en värld kan förutsägas av förhållandet mellan ekologimålets pris och kostnaden för att anta en mekanism som saknas. Världar som t18 bör vara sådana där priset är lågt. Det kräver nya världar och en ny förhandsdeklaration, inte en efterhandsundersökning av de fyrtio.

**[H6 — Billigare försäkring.]** Två alternativ kan behålla större delen av det ekologiska målets okänslighet för utelämnad retention till ett lägre U1-pris: ett mål som värderar våtmark villkorligt utifrån dess betydelse nedströms, och en korrekt trosbaserad plan över de två hypoteserna. MIX-resultatet motiverar hypotesen men fastställer den inte.

**[H7 — Parameterfel gynnar robusthet.]** När parameterfelet ökar minskar fördelen med ommodellering jämfört med omvärdering. En ambiguitetsrobust planerare kan då överträffa båda enligt U1. Det bör testas med A1:s robusta planerare inkluderad från början.

**[H8 — Exponeringsmedveten planering.]** Planerare som beaktar vilken observerbarhet deras policy skapar undviker självupprätthållna fällor där den utelämnade mekanismen är beslutsrelevant. Nettovärdet beror på sonderingskostnad och återstående tidshorisont.

**[H9 — Observationskanaler bättre än längre sonderingar.]** I linje med arbetsrapport 0:s H4 om integrerat lärande kommer en direkt observationskanal för retention, exempelvis mätning av flödet nedströms, att öka realiserat lärandevärde mer än längre sonderingar.

### 7.3 Relation till forskningsprogrammet och *Governance as Engineering*

Serien *Systemisk optimering* frågar hur ett optimeringsproblem ska **konstrueras och utvärderas**, inte enbart lösas. *Governance as Engineering* (GaE) handlar om den institutionella arkitektur genom vilken sådana problem formuleras: vem som observerar, vem som beslutar, vad som värderas och hur återkopplingen når tillbaka.

**[IP]** Rapporten tillför en arkitektonisk iakttagelse. Vad en institution kan lära sig om världen beror på vad den gör, och vad den gör beror på vad den värderar och tror. Övervakningsarrangemang, mål och modellantaganden är därför inte oberoende designval.

Ett planeringsorgan som aldrig agerar på en mekanism kanske heller aldrig får tillfälle att observera den. En målfunktion som antagits av ett skäl kan som bieffekt skapa förutsättningar för att lära sig något annat. Detta är tolkande bryggor, inte empirisk validering av någon styrningsordning. Ingen specifik rekommendation för ett verkligt avrinningsområde följer direkt.

## 8. Slutsats

Arbetsrapport 0 utgick från att en optimerare kan lösa fel problem korrekt. Den här rapporten frågar vad som händer därefter, när vi väl inser att problemet är ofullständigt.

Svaret från en syntetisk översvämningsmodell är att de tre tillgängliga reaktionerna — att ändra vad vi tror, ändra vad vi värderar och försöka lära oss — ger olika utfall och sätter gränser för varandra.

- **Att anta den saknade mekanismen** gav lägre genomsnittliga kostnader för översvämningsskador och finanser än att **vikta om målfunktionen mot ekologi** vid exakta parametrar [R, konfirmatoriskt]. I genomsnitt gällde detta även den gren där antagandet var falskt [R, deskriptiv undergrupp].
- **Det ekologiska målet** gav bättre våtmarksutfall [R, konfirmatoriskt]. Dess policyer var mycket mindre känsliga för utelämnad retention [R, förhandsdefinierat deskriptivt], men priset betalades oavsett om mekanismen verkade.
- **Lärandet** begränsades mer av exponering och tid än av själva inferensen. En planerare kan upprätthålla sin blinda fläck, och en enkel exakt lärandealgoritm tjänade lite jämfört med vad ett orakel skulle kunna ge [R, strukturellt och explorativt].
- **Inga rangordningar är ovillkorliga.** Vid parameterfel försvann fördelen med antagandet nästan, och vilken utelämnad mekanism som betydde mest förändrades [R, explorativt].

**[IP]** Det som förändras i forskningsprogrammet efter denna rapport är **utvärderingsenheten**. Det räcker inte att fråga om en modell är mer fullständig eller om en målfunktion omfattar fler värden. Det som måste prövas är hela *paketet*: vad som representeras, vad som optimeras och vad den resulterande policyn gör möjligt att observera. Paketet bör utvärderas över flera kriterier och villkor, mot genomförbara snarare än allvetande alternativ.

Nästa studier i serien bör därför pröva sådana paket, inklusive robusta och trosbaserade planerare, under förhandsdeklarerade villkor där avvägningarna kan slå om.

---

## Bilaga A. Evidensstatus för varje påstående

Detta är rapportens auktoritativa förteckning över påståenden. I huvudtexten anges **[R]** tillsammans med ett statusord; här används precisa koder. *C-derived* markerar en logisk slutsats ur konfirmatoriska resultat, inte ett ytterligare test. Källvägarna avser projektarkivet för A2.

| Inferensstatus | Betydelse |
|:---|:---|
| **C** konfirmatoriskt | Förhandsdefinierat test på det oberoende, förbundna F0-C-urvalet. Gäller *inom den deklarerade syntetiska populationen och den hypotetiska 50/50-viktningen av R*. |
| **C-derived** | Logisk sammanställning av C-resultat; **ingen** extra prövad hypotes. |
| **PD** förhandsdefinierat deskriptivt | Deklarerat innan de konfirmatoriska data sågs, utan inferentiellt anspråk. |
| **ED** deklarerat explorativt | Deklarerat före utfallen i utvecklingsvärldar eller förhandsvalda världar; hypotesgenererande. |
| **EP** post hoc-explorativt | Analys som valdes efter att utfall hade blivit kända och därför märks som sådan. |
| **ST** strukturellt | Exakt egenskap hos den specificerade modellen, numeriskt verifierad. |

| Roll | Betydelse |
|:---|:---|
| **DS** beslutsvetenskap | Påståenden om själva beslutsproblemet. |
| **NM** numeriska metoder | Påståenden om estimatorer eller lösare; varje rad anger om interventionen var prospektiv och om den gäller en enda fixerad historia. |
| **ENG** teknisk verifiering | Validering och paritet; bygger tillit till koden, inte forskningsresultat i sig. |

Förkortningar: R = retention nedströms, S = synkronisering, C = regnkopula; F0 = U1-målet; F1-eco = U1 + $\lambda$ gånger ekologiskt underskott. Varje kvantitativt påstående har en namngiven källfil.

### Grupp A — Målens tillräcklighet och kausal representation

| # | Påstående (med namngivet kriterium) | Källa | Världar | Status / roll | Viktiga tal | Begränsningar |
|:---|:---|:---|:---|:---|:---|:---|
| A1 | Med deklarerad hypotetisk 50/50-viktning av R har **REP(R) (F0 på 111) lägre genomsnittlig U1** än COMP (F1-eco på 011) | F0-C primär; `f0c_confirmatory.json` | 40 oberoende testvärldar | C / DS | $\Delta=-1.112$ U1 [−1.737, −0.487], $t(39)=-3.60$, $p=0.00089$ | Precisionsmål missat (halvbredd 0,625); 30/40 negativa, från −6,10 till +4,92 (t18); approximativ t-inferens villkorad av generatorn |
| A2 | Samma kontrast för **U2** (U1 + påföljd för största kommunskadan): REP har lägre värde | F0-C sekundär | 40 | C / DS | −1,061 [−1,734, −0,388]; Holm-$p$ 0,0028 | U2 är inte ett heltäckande fördelningsmått; KI är ojusterade 95 %, p-värden Holm-justerade |
| A3 | För **ackumulerat våtmarksunderskott uppströms** är COMP bättre | F0-C sekundär | 40 | C / DS | +6,362 [+4,235, +8,489]; Holm-$p$ $1.3\times10^{-6}$ | Modellstorhet, inte fältindikator; samma KI/p-reservation som A2 |
| A4 | För **negativt terminalt våtmarksbestånd** är COMP bättre (dvs. mer våtmark) | F0-C sekundär | 40 | C / DS | +1,543 [+1,056, +2,030]; Holm-$p$ $5.6\times10^{-7}$ | Som A3 |
| A5 | BOTH(R), F1-eco på 111, har **högre U1** än REP(R) | F0-C sekundär | 40 | C / DS | +1,603 [+0,992, +2,214]; Holm-$p$ $9.6\times10^{-6}$ | BOTH:s ekologiska utfall ingick inte i testet |
| A6 | För den förhandsdefinierade REP(R)-mot-COMP-jämförelsen med hypotetisk 50/50-viktning pekar medelskillnaderna i **motsatta riktningar**: REP har lägre U1 och U2, COMP mindre underskott och mer terminal våtmark. **Ingen av dessa två policyer är entydigt bäst på alla namngivna kriterier** | A1–A4 tillsammans | 40 | **C-derived** / DS | — | Inte ett sjätte test; säger inget om andra strategier eller icke-dominans för varje värld |
| A7 | Den deklarerade deskriptiva jämförelsen fann en liten observerad genomsnittlig **U1-kontrast för utelämnad R under F1-eco (+0,014)** mot **+1,851 under F0**, med $m^*=111$, $s=0$, $\psi=0$ | F0-C deskriptiv; `f0c_descriptive.json` | 40 | PD / DS | F0 +1,851 [+0,80, +2,90]; F1-eco +0,014 [−0,17, +0,20]; F1-eco-fixed +0,094 [−0,21, +0,40] | **Inget ekvivalens- eller non-inferiority-test**; intervallet rymmer meningsfulla positiva och negativa värden; fast $\lambda$ testar bara normalisering; en mekanism och basmodell |
| A8 | F1-eco har ett **U1-pris när modellen är korrekt** (måltermen) | F0-C deskriptiv | 40 | PD / DS | +1,085 [+0,61, +1,56] | Måltermen är inte hela kostnaden för den använda policyn |
| A9 | Grenen där R saknas är också negativ (deskriptiv undergrupp). Utvecklingsdekompositionen **tyder på** att F1-eco:s U1-premium överstiger REP:s kostnad för fel modell; detta beror inte på att REP:s modell är korrekt. Motsvarande läsning av 40-världstabellerna är explorativ. | `f0c_confirmatory.json`; `F0DEV_RESULTS_v0.1.md` §5; bilaga B, T4 | 40 / 16 | PD / ED / EP | 011-gren −1,125 [−2,126, −0,124]; utveckling: 1,06 mot 2,42; testvärldar: 1,765 mot 2,890 | Målkontrast, inte kausal upptäckt eller konfirmerad mekanism |
| A10 | Kostnaden för att utelämna R under F0 är asymmetrisk och regnberoende | F0-dev-dekomposition; bilaga B T2/T4 | d00–d15 | ED / DS | 0,28 / 1,45 / 2,91 vid $\psi=-0.1/0/+0.1$ | Delvis tidigare studerade utvecklingsvärldar |
| A11 | F1-eco är **mindre känslig för fel i planeringsparametrar** än F0 enligt U1 | F0-dev-dekomposition; bilaga B T1 | d00–d15 | ED / DS | Parameter/skift-termer vid $s=0,25$: F0 1,3–1,9 mot F1-eco 0,5–0,7 | Utvecklingsresultat; testvärldsanalysen är explorativ |
| A12 | Korrekt representerade strategier domineras nästan aldrig på tvådimensionella fronter; målet väljer främst en punkt på U1–ekologi-fronten | F0-dev Pareto; bilaga B T6 | d00–d15 | ED / DS | Icke-dominerad andel 1,00 (ett fall 0,94) | Bara tvådimensionella fronter; inte alla tänkbara policyer |
| A13 | **Vikten av en utelämnad mekanism beror på parameterosäkerheten och omständigheterna.** Vid $s=0$ står R för största delen av F0:s U1-effekt; vid $s=0,25$, $\psi=0$ är effekten av utelämnad C större än utelämnad R | Gate C-pilotens faktoriella huvudeffekter på F0-ånger | 8 utvecklingsvärldar ($s=0$); 8 × 2 dragningar ($s=0,25$) | ED / DS | $s=0,\psi=0$: R +0,796, S −0,003, C +0,027. $s=0,\psi=+0,1$: R +2,046, S −0,011, C +0,016. $s=0,25,\psi=0$: **R +0,338, S −0,013, C +0,434**. $s=0,25,\psi=-0,1$: R −0,131, C +0,397 | Fysisk mask 111, planeringsmasker ablaterade: effekter i planeringen, inte fysiska effektstorlekar; litet tidigare undersökt urval, stora SD |
| A14 | I piloten kompenserade det ekologiska målet inte för U1-kostnaden av utelämnad struktur | Gate C-pilot `summary.txt` | 8 | ED / DS | Återvinningskvot cirka −0,31 till −0,37 ($s=0,\psi=0$) | Förenligt med A8 |

### Grupp B — Exponering och identifierbarhet

| # | Påstående | Källa | Världar | Status / roll | Viktiga tal | Begränsningar |
|:---|:---|:---|:---|:---|:---|:---|
| B1 | Utan våtmarker uppströms är **de specificerade mekanismvillkorade övergångslikelihoodarna identiska** med och utan R | E1-lite-inventering; G1-R V3; G3-kontroller | Alla | ST / DS | 100 % av oexponerade tillstånd–handlingspar är exakta nollfall; G3:s blinda log-BF är exakt 0 *för just den villkorliga likelihood som utvärderats* | Visar inte att fullständiga policy-/tillståndshistoriker saknar information under varje möjlig observationsmodell |
| B2 | **Exponeringsfällor:** under den valda passiva policyn förblir R oexponerad i vissa världar där mekanismen spelar roll (d05) | D1–D2; G3-supplement | d00–d07 samt syntetiska | ED / DS | 7 exakta fällor (värld × mekanism) i 6 världar (6 R, 1 S); d05-beläggning av R-exponering 0,000 | Förhandsvalda utvecklingsvärldar; stationär passiv drift från S0 |
| B3 | Exponering är nödvändig men inte tillräcklig: i d05 etablerar sonderingen våtmark men ger sällan urskiljbara övergångar inom tre år | E1-lite G2 | d05 | ED / DS | $P(\text{posteriorn ändrad})=0$ vid $k\le2$ och 0,15 vid $k=3$ (gemensam), trots etablerad våtmark på 77–99 % av banorna | Optimistiska, brusfria tillståndsobservationer |
| B4 | **Tidsordning:** ett ettårigt experiment kan inte informera den övergångsbaserade läraren eftersom första övergången börjar oexponerad | E1-lite G2 | Alla | ST / DS | Posteriorn vid $k=1$ är lika med priorn på varje historia | Specifikt för denna övergångsbaserade algoritm |

### Grupp C — Lärandets värde

| # | Påstående | Källa | Världar | Status / roll | Viktiga tal | Begränsningar |
|:---|:---|:---|:---|:---|:---|:---|
| C1 | **Fullständig förhandskunskap O\*** (känner R från period 0): gränsen relativt P0, $C(P0)-C(O^*)$, är betydande när R spelar roll och noll i kontroller. Detta är **inte** X\* | E0 och E0-korrigendum | d00, d05, d02; kontroller d03, d07 | ED / DS | d00 0,92 / 1,84 / 2,76; d05 0,59 / 1,18 / 1,77 vid $q=0,25/0,5/0,75$ | **Inte EVPI**; förhandsvalda världar |
| C2 | **Oraklet efter fast sondering X\***: nettomarginalen mot en begränsad meny av fasta policyer är sällan positiv | E0/E0.2 | Samma | ED / DS; E0.2-jämförelsen post hoc | X\* slår B_extended i **10/54** primära och **7/54** känslighetsceller med relevant R; **10/90** och **7/90** inklusive kontroller | B_extended är begränsad; X\* ger ett tak inom den valda sonderingen, inte universell EVPI eller en gräns för alla adaptiva policyer |
| C3 | En exakt bayesiansk lärandealgoritm med sondering och fast fortsättning återvinner högst cirka 18 % av **X\*:s marginal över B_extended** ($\kappa$); deklarerat kriterium uppnås inte | E1-lite G2 | Samma | ED / DS | $\kappa\ge0,5$ i 0/9 primära celler; bästa $\kappa=0,107$ primärt och 0,179 i känslighet | Känt tvåhypotesproblem, brusfritt tillstånd, engångsåtagande |
| C4 | Nästan hela algoritmens vinst mot samma väg med fast fortsättning kommer från tillståndsberoende val, inte posterioruppdatering | E1-lite G2.1 | Samma | ED / DS, deskriptiv uppdelning | Informationsvärde högst 0,069 U1; 2,1 % av större primära vinster | Gäller denna algoritm och jämförelse, inte alla lärandeprocesser |

### Grupp D — Numeriska metoder och teknisk verifiering

| # | Påstående | Källa | Status / roll | Huvudresultat | Räckvidd |
|:---|:---|:---|:---|:---|
| D1 | Slumpvandrings-SMC gav opålitliga evidensskattningar i den blinda 16-dimensionella diagnostiken; G3.2:s detektionsandelar kan inte tolkas | `G32_FINDINGS_v0.1.md` | EP / NM | Skilda replikat gav olika slutsatser i upp till 11/24 fall | Blind 16-D, D3a-paket |
| D2 | Validerade kvadraturreferenser: **1-D** via G3.3a (FAIL) och G3.3a-R (PASS); **2-D** via G3.3b-1 (48/48 referenser validerade) | G3.3a/G3.3a-R/G3.3b-1 | ED / NM | 1-D inom $10^{-3}$ nats (Simpson upp till $1.8\times10^{-5}$ men långsam); 2-D 48/48 och exakta nollfall | Specifika referensfall |
| D3 | En **evaluatorinformerad, prospektivt jämförd riktad uppdelning** minskade felet i evidensskattningen **på en enda fixerad syntetisk 2-D-historia**. Färre likelihoodberäkningar men **inte konsekvent lägre körtid** | G3.3b-1 → 1M → 1P → P3.1 → P3.1-R → P3.2 | ED / NM | Medelvärde $\lvert\log BF\text{-fel}\rvert$: 1,625→0,404 (512 partiklar), 0,457→0,181 (2 048). Partikelårskostnaden minskade; klocktid 136 mot 118 s vid 512 (långsammare), 274 mot 339 s vid 2 048 (snabbare) | Kräver känd posteriorgeometri; en historia; **inte** en utplacerbar blind högdimensionell estimator |
| D4 | F0-maskineriet verifierades: orakel, lexikografiska likheter, dekompositionsidentiteter, beläggningsutvärderare och Monte Carlo-kontroll | F0-V FAIL → F0-V-R PASS; F0-C validate-c PASS; sandboxparitet FAIL / workstationparitet PASS | ENG | Identiteter exakta; dokumenterade problem i teststatistik och plattformsberoende likhetsval | — |
| D5 | Valideringsstatistik kan förkasta korrekt kod (normalapproximation för sällsynta händelser; felaktig deklarerad olikhet) | E1-lite G1, F0-V | EP / NM | FAIL-poster bevarades och följdes av nya deklarerade korrigeringar | Metodlärdom |

## Bilaga B. Explorativa tabeller ur den frysta konfirmatoriska faktorialen

**Status: EP (explorativt efterhandsval), enbart deskriptivt.** Tabellerna har tagits fram läsande ur de frysta F0-C-tabellerna i `analysis/f0c_f0c-v0.1-conf_6c5c58ff6e22/`. Ingen ny simulering, ingen ny värld, inget nytt p-värde och inget nytt konfidensintervall har beräknats. Tabellernas definitioner och fullständiga täckning deklarerades den **6 november 2026 kl. 10:10:31 UTC** i `records/a2_f0c_exploratory_appendix_declaration.json` innan dessa tabeller beräknades. Skriptet kontrollerar indatans hashvärden mot deklarationen.

**Varför EP och inte ED?** Loggen från F0-C-sammanfattningen och motsvarande utvecklingsanalyser var redan kända när tabellerna valdes. Urvalet av analyser var alltså inte blindat för resultaten. Inget här används för att ändra konfirmatoriska slutsatser eller för att välja en ny hypotes.

**Enhet.** Basvärlden ($n=40$). De 120 jobben omfattar tre planeringsvillkor för varje värld och är inte 120 oberoende observationer. **Kod och resultat:** `diag/a2_f0c_exploratory_appendix.py` (sha256 `b9f68d4d7825…`) skapar `analysis/f0c_exploratory_appendix/tables.json` och `tables.md`.

### B.1 Definitioner

- **Kontrast:** $\Delta_X(J)=\tfrac12\sum_{m^*\in\{m_0\cup X,m_0\}}[J(F0\text{ på }m_0\cup X)-J(F1\text{-eco på }m_0)]$ med varje policys eget fondval. Det är REP(X) − COMP under en hypotetisk 50/50-viktning för om X finns. Alla $J$ minimeras: **$\Delta<0$ gynnar REP enligt det namngivna kriteriet.**
- **Per-världsstatistik:** T1–T3 anger medelvärde, standardavvikelse, teckenfördelning, minimi- och maximivärde över 40 världar. Teckenantal kan summera till mindre än 40 vid exakta nollvärden.
- **Enbart medelvärden över världar:** T4–T6 kommer från de frysta medelvärdestabellerna. Dekompositionstermerna är ångerkomponenter gentemot U1-oraklet (representation → parametrar/skift → mål). T5 medelvärdesbildar de två fysiska maskgrenarna. T6 räknar i varje värld om en policy är icke-dominerad bland **33 kandidatpolicyer** (24 `S|f|m` och nio MIX) på respektive tvådimensionella front.
- **Indata (SHA-256-prefix):** `f0c_core.csv` `d201fc09a085…`; `f0c_decomposition.csv` `eefdb4f6ec44…`; `f0c_factorial_means.csv` `63e52948900a…`; `f0c_pareto.csv` `35f130ddc694…`.

### B.2 Tabeller

#### T1. Parameterfel (m₀ = 011, X = R, ψ = 0): Δ = REP(R) − COMP

| Villkor | J | Medel | SD | n < 0 | n > 0 | min | max |
|---|---|---|---|---|---|---|---|
| s=0.0,d=0 | J_U1 | -1.112 | 1.954 | 30 | 10 | -6.104 | +4.925 |
| s=0.0,d=0 | J_U2 | -1.061 | 2.103 | 29 | 11 | -6.324 | +6.216 |
| s=0.0,d=0 | J_def | +6.362 | 6.651 | 3 | 37 | -3.795 | +18.069 |
| s=0.0,d=0 | J_stock | +1.543 | 1.523 | 2 | 38 | -0.544 | +4.000 |
| s=0.25,d=0 | J_U1 | -0.010 | 2.579 | 24 | 15 | -7.263 | +6.970 |
| s=0.25,d=0 | J_U2 | +0.155 | 2.785 | 23 | 16 | -7.170 | +7.839 |
| s=0.25,d=0 | J_def | +5.258 | 6.231 | 4 | 35 | -4.103 | +18.340 |
| s=0.25,d=0 | J_stock | +1.269 | 1.448 | 3 | 36 | -0.948 | +4.000 |
| s=0.25,d=1 | J_U1 | -0.301 | 2.547 | 26 | 12 | -4.720 | +10.552 |
| s=0.25,d=1 | J_U2 | -0.182 | 2.842 | 24 | 14 | -5.144 | +11.621 |
| s=0.25,d=1 | J_def | +6.937 | 6.663 | 5 | 33 | -1.076 | +18.069 |
| s=0.25,d=1 | J_stock | +1.639 | 1.542 | 3 | 35 | -0.007 | +4.000 |

Parameter-/skiftterm (J_U1, världsmedelvärden):

| Villkor / policy / m\* | term |
|---|---|
| s=0.0,d=0\|F0/111\|m*=111 | +0.000 |
| s=0.0,d=0\|F0/111\|m*=011 | +0.000 |
| s=0.0,d=0\|F1-eco/011\|m*=111 | +0.000 |
| s=0.0,d=0\|F1-eco/011\|m*=011 | +0.000 |
| s=0.25,d=0\|F0/111\|m*=111 | +2.654 |
| s=0.25,d=0\|F0/111\|m*=011 | +2.370 |
| s=0.25,d=0\|F1-eco/011\|m*=111 | +1.329 |
| s=0.25,d=0\|F1-eco/011\|m*=011 | +1.516 |
| s=0.25,d=1\|F0/111\|m*=111 | +2.483 |
| s=0.25,d=1\|F0/111\|m*=011 | +2.361 |
| s=0.25,d=1\|F1-eco/011\|m*=111 | +0.857 |
| s=0.25,d=1\|F1-eco/011\|m*=011 | +1.378 |

#### T2. Regnförskjutning (m₀ = 011, X = R, s = 0): Δ = REP(R) − COMP

| ψ | J | Medel | SD | n < 0 | n > 0 | min | max |
|---|---|---|---|---|---|---|---|
| psi=-0.1 | J_U1 | -1.318 | 1.753 | 33 | 7 | -6.184 | +2.144 |
| psi=-0.1 | J_U2 | -1.300 | 1.815 | 32 | 8 | -6.198 | +2.793 |
| psi=-0.1 | J_def | +6.615 | 6.673 | 4 | 36 | -3.367 | +18.136 |
| psi=-0.1 | J_stock | +1.609 | 1.522 | 2 | 38 | -0.352 | +4.000 |
| psi=0.0 | J_U1 | -1.112 | 1.954 | 30 | 10 | -6.104 | +4.925 |
| psi=0.0 | J_U2 | -1.061 | 2.103 | 29 | 11 | -6.324 | +6.216 |
| psi=0.0 | J_def | +6.362 | 6.651 | 3 | 37 | -3.795 | +18.069 |
| psi=0.0 | J_stock | +1.543 | 1.523 | 2 | 38 | -0.544 | +4.000 |
| psi=0.1 | J_U1 | -0.808 | 2.110 | 27 | 13 | -6.310 | +7.343 |
| psi=0.1 | J_U2 | -0.710 | 2.365 | 25 | 15 | -6.533 | +9.275 |
| psi=0.1 | J_def | +6.101 | 6.632 | 4 | 36 | -4.196 | +18.069 |
| psi=0.1 | J_stock | +1.476 | 1.524 | 2 | 38 | -0.720 | +4.000 |

Representationsterm när R utelämnas in m\* = 111 (J_U1, världsmedelvärden):

| ψ / policy | term |
|---|---|
| psi=-0.1\|F0/011 | +0.518 |
| psi=-0.1\|F1-eco/011 | +0.002 |
| psi=-0.1\|F1-eco-fixed/011 | +0.038 |
| psi=0.0\|F0/011 | +1.851 |
| psi=0.0\|F1-eco/011 | +0.014 |
| psi=0.0\|F1-eco-fixed/011 | +0.094 |
| psi=0.1\|F0/011 | +3.567 |
| psi=0.1\|F1-eco/011 | +0.078 |
| psi=0.1\|F1-eco-fixed/011 | +0.229 |

#### T3. Samtliga 12 (m₀, X) pairs (s = 0, ψ = 0): Δ_X = REP(X) − COMP

| m₀ + X | J | Medel | SD | n < 0 | n > 0 | min | max |
|---|---|---|---|---|---|---|---|
| 011+R | J_U1 | -1.112 | 1.954 | 30 | 10 | -6.104 | +4.925 |
| 011+R | J_def | +6.362 | 6.651 | 3 | 37 | -3.795 | +18.069 |
| 101+S | J_U1 | -1.011 | 1.443 | 34 | 6 | -5.684 | +0.123 |
| 101+S | J_def | +6.852 | 6.571 | 0 | 40 | +0.000 | +18.069 |
| 110+C | J_U1 | -1.066 | 1.443 | 38 | 2 | -5.196 | +0.003 |
| 110+C | J_def | +6.783 | 6.589 | 0 | 40 | +0.000 | +18.069 |
| 001+R | J_U1 | -1.106 | 1.691 | 30 | 10 | -6.199 | +0.713 |
| 001+R | J_def | +5.883 | 6.667 | 3 | 37 | -0.361 | +18.069 |
| 001+S | J_U1 | -2.631 | 2.406 | 38 | 2 | -10.423 | +0.009 |
| 001+S | J_def | +11.906 | 6.255 | 0 | 40 | +0.000 | +18.619 |
| 010+R | J_U1 | -1.210 | 1.866 | 30 | 10 | -6.060 | +4.227 |
| 010+R | J_def | +7.192 | 6.483 | 4 | 36 | -2.908 | +18.232 |
| 010+C | J_U1 | -2.889 | 2.614 | 40 | 0 | -10.651 | -0.000 |
| 010+C | J_def | +11.872 | 6.217 | 0 | 40 | +0.000 | +18.619 |
| 100+S | J_U1 | -1.079 | 1.461 | 39 | 1 | -5.566 | +0.175 |
| 100+S | J_def | +7.523 | 6.445 | 0 | 40 | +0.000 | +18.232 |
| 100+C | J_U1 | -1.003 | 1.458 | 34 | 6 | -5.527 | +0.011 |
| 100+C | J_def | +6.209 | 6.715 | 0 | 40 | +0.000 | +18.069 |
| 000+R | J_U1 | -1.199 | 1.631 | 31 | 9 | -6.475 | +0.500 |
| 000+R | J_def | +7.119 | 6.723 | 1 | 39 | -0.239 | +18.232 |
| 000+S | J_U1 | -2.568 | 2.290 | 37 | 3 | -9.443 | +0.028 |
| 000+S | J_def | +11.881 | 6.130 | 0 | 40 | +0.000 | +18.619 |
| 000+C | J_U1 | -2.353 | 1.983 | 40 | 0 | -7.380 | -0.011 |
| 000+C | J_def | +13.211 | 5.428 | 0 | 40 | +0.037 | +18.619 |

#### T4. Dekomposition av 40 världar (J_U1, s = 0, ψ = 0, eget fondval; världsmedelvärden)

| policy / m\* | totalt | representation | parametrar/skift | mål |
|---|---|---|---|---|
| F0/111\|m*=111 | +0.000 | +0.000 | +0.000 | +0.000 |
| F0/111\|m*=011 | +1.765 | +1.765 | +0.000 | +0.000 |
| F1-eco/011\|m*=111 | +1.099 | +0.014 | +0.000 | +1.085 |
| F1-eco/011\|m*=011 | +2.890 | +0.000 | +0.000 | +2.890 |

#### T5. MIX jämfört med rena åtaganden (50/50 medel över m₀ ∪ X and m₀; s = 0, ψ = 0; världsmedelvärden)

| par \| policy | J_U1 | J_def |
|---|---|---|
| R\|S\|F0\|011 | 6.967 | 18.082 |
| R\|S\|F0\|111 | 6.924 | 12.624 |
| R\|MIX\|R\|0.25 | 6.557 | 16.446 |
| R\|MIX\|R\|0.5 | 6.465 | 14.980 |
| R\|MIX\|R\|0.75 | 6.638 | 13.877 |
| S\|S\|F0\|101 | 4.040 | 12.076 |
| S\|S\|F0\|111 | 4.033 | 12.645 |
| S\|MIX\|S\|0.25 | 4.017 | 12.146 |
| S\|MIX\|S\|0.5 | 4.012 | 12.371 |
| S\|MIX\|S\|0.75 | 4.016 | 12.448 |
| C\|S\|F0\|110 | 2.746 | 13.381 |
| C\|S\|F0\|111 | 2.738 | 12.653 |
| C\|MIX\|C\|0.25 | 2.725 | 13.327 |
| C\|MIX\|C\|0.5 | 2.722 | 13.073 |
| C\|MIX\|C\|0.75 | 2.728 | 12.783 |

#### T6. Pareto: andel av 40 världar som är icke-dominerade (s = 0, ψ = 0, eget fondval)

| axel \| m\* \| policy | andel |
|---|---|
| J_def\|m*=011\|S\|F0\|111 | 0.550 |
| J_def\|m*=011\|S\|F0\|011 | 1.000 |
| J_def\|m*=011\|S\|F1-eco\|111 | 0.650 |
| J_def\|m*=011\|S\|F1-eco\|011 | 1.000 |
| J_def\|m*=011\|S\|F1-eco-fixed\|011 | 1.000 |
| J_def\|m*=011\|MIX\|R\|0.5 | 0.825 |
| J_stock\|m*=011\|S\|F0\|111 | 0.575 |
| J_stock\|m*=011\|S\|F0\|011 | 1.000 |
| J_stock\|m*=011\|S\|F1-eco\|111 | 0.625 |
| J_stock\|m*=011\|S\|F1-eco\|011 | 0.950 |
| J_stock\|m*=011\|S\|F1-eco-fixed\|011 | 0.950 |
| J_stock\|m*=011\|MIX\|R\|0.5 | 0.825 |
| J_def\|m*=111\|S\|F0\|111 | 0.975 |
| J_def\|m*=111\|S\|F0\|011 | 0.250 |
| J_def\|m*=111\|S\|F1-eco\|111 | 1.000 |
| J_def\|m*=111\|S\|F1-eco\|011 | 0.300 |
| J_def\|m*=111\|S\|F1-eco-fixed\|011 | 0.275 |
| J_def\|m*=111\|MIX\|R\|0.5 | 0.225 |
| J_stock\|m*=111\|S\|F0\|111 | 0.975 |
| J_stock\|m*=111\|S\|F0\|011 | 0.250 |
| J_stock\|m*=111\|S\|F1-eco\|111 | 0.925 |
| J_stock\|m*=111\|S\|F1-eco\|011 | 0.250 |
| J_stock\|m*=111\|S\|F1-eco-fixed\|011 | 0.250 |
| J_stock\|m*=111\|MIX\|R\|0.5 | 0.225 |


### B.3 Vad tabellerna visar, inklusive motexempel

1. **Parameterfel tar bort större delen av REP(R):s U1-fördel (T1).** Vid $s=0,25$ är den genomsnittliga $\Delta_R(J_{U1})$ −0,010 (dragning 0) och −0,301 (dragning 1), jämfört med −1,112 vid $s=0$. Tecknen fördelar sig 24/15 och 26/12, och maxvärdena är +6,97 och +10,55. Parameter-/skifttermen är större för F0 på 111 (+2,37 till +2,65) än för F1-eco på 011 (+0,86 till +1,52). Riktningen stämmer med F0-dev (A11), men värdena är större i ett annat urval. De ekologiska kontrasterna behåller riktning och ungefärlig storlek: $J_{def}$ +5,3 till +6,9 och $J_{stock}$ +1,3 till +1,6. **Den konfirmerade U1-kontrasten (A1) gäller $s=0$ och får inte beskrivas som robust mot parameterfel.**
2. **Regnförskjutningen flyttar kontrasten monotont men vänder inte tecknet (T2).** Medelvärdet för $\Delta_R(J_{U1})$ är −1,318, −1,112 och −0,808 vid $\psi=-0,1,0,+0,1$. F0:s representationsterm växer (+0,518, +1,851, +3,567), medan F1-eco håller sig nära noll (+0,002, +0,014, +0,078). F1-eco-fixed ligger något högre (+0,038, +0,094, +0,229). Raden för $\psi=0$ återger de frysta förhandsdefinierade deskriptiva värdena (A7), vilket kontrollerar dataläsningen.
3. **Alla tolv maskpar har samma tecken för medelvärdena (T3), men detta avspeglar främst målfunktionen, inte representationen.** $\Delta_X(J_{U1})<0$ och $\Delta_X(J_{def})>0$ i samtliga par. För S och C är representationskontrasten liten, så talen återspeglar huvudsakligen F1-eco:s U1-pris för dess ekologiska vinst, inte värdet av att representera S eller C. Par som tillför R har upp till tio världar med positiv $\Delta$ och maxima kring +4,9. Par som tillför S eller C har högst sex positiva världar och maxima högst +0,18. De största genomsnittliga U1-kontrasterna (cirka −2,4 till −2,9) finns i 001+S, 010+C, 000+S och 000+C; deras basmodell utelämnar redan R.
4. **Dekompositionen för R-frånvarande grenen ser likadan ut i de 40 testvärldarna som i utvecklingen (T4).** Vid $m^*=011$ betalar REP en representationskostnad på +1,765 U1, medan COMP betalar ett målpris på +2,890. Skillnaden är grenmedelvärdet −1,125. Vid $m^*=111$ är nästan hela COMP:s kostnad ett målpris (+1,085 av +1,099). Detta belyser A9: det ekologiska målets U1-premium överstiger den felaktigt representerade modellens kostnad, precis som i utvecklingsvärldarna (1,06 mot 2,42). Det förblir en explorativ dekomposition, inte en konfirmerad mekanismförklaring.
5. **En säkringsheuristik slår båda rena F0-åtagandena i genomsnittlig U1 för R (T5).** Med 50/50-viktningen har MIX(R, q) genomsnittlig $J_{U1}$ på 6,465–6,638, lägre än F0 på 011 (6,967) och 111 (6,924). Dess våtmarksunderskott ligger mellan dem (13,9–16,4, mot 18,1 respektive 12,6). För S och C ligger MIX inom cirka 0,03 U1 från de rena valen. REP(R) är således inte U1-bäst av alla utvärderade policyer, vilket motiverar att A6 begränsas till REP mot COMP. **MIX ingick inte i något konfirmatoriskt test**, genomsnittsbildar övergångskärnor period för period och är inte optimalt för en fast men okänd värld. Här rapporteras enbart världsmedelvärden; se H6 i §7.2.
6. **En strategi är oftast icke-dominerad när dess representation är korrekt och oftare dominerad när den är fel (T6).** När $m^*=111$ är REP (F0/111) icke-dominerad i 97,5 % av världarna på båda fronterna, men COMP (F1-eco/011) i bara 30 % på underskottsfronten och 25 % på beståndsfronten. När $m^*=011$ är COMP icke-dominerad i 100 % respektive 95 %, och REP i 55 % respektive 57,5 %. BOTH (F1-eco/111) är icke-dominerad i 100 % respektive 92,5 % vid $m^*=111$. Detta är uttalanden per fysisk mask och kan inte summeras till ett enda 50/50-Paretopåstående.

### B.4 Nollfall och resultat som inte erhölls

- Vid $s=0$ är parameter-/skifttermen exakt noll (strukturellt, T1).
- F1-eco:s representationsterm överstiger aldrig +0,08 U1 som världsmedelvärde vid någon av de tre regnförskjutningarna. Det är en deskriptiv observation, **inte** ett ekvivalensresultat.
- Inget maskpar vänder tecknet på den genomsnittliga U1- eller $J_{def}$-kontrasten. Motexempel bland enskilda världar finns i T1–T3.

## Bilaga C. Reproducerbarhet, numeriska metoder och proveniens

### C.1 Lösare, utvärdering och verifiering [ENG]

**Lösare.** Exakt dynamisk programmering med ändlig horisont på den faktoriserade modellen: 31 104 tillstånd, 27 gemensamma handlingar, nio regnutfall och $H=11$. Policyer väljs enligt A1:s regel om lägsta handlingsindex vid likvärdiga alternativ. Ekologiska orakel är lexikografiska med tolerans $10^{-9}\max(1,|m|)$. Utvärderingen propagerar exakta tillståndsbeläggningar. En oberoende Monte Carlo-simulering kontrollerar detta statistiskt, vilket inte är ett formellt bevis.

**Verifieringsgrindar:**

| Grind | Utfall | Anmärkning |
|:---|:---|:---|
| F0-V | **FAIL** (bevarat) | Testet för sällsynta händelser använde en normalapproximation för en beståndskategori med sannolikhet omkring $2.6\times10^{-6}$; en bana observerades och $z=4,01$. Koden var korrekt, teststatistiken inte. |
| F0-V-R | PASS | Exakta binomialtest per beståndskategori, gräns 0,005/160, nya frön. |
| F0-C validate-c | PASS | Både sandbox och arbetsstation. |
| Strikt paritet, sandbox | **FAIL** (bevarat) | Ett orakels fördelning av utgifter mellan kommuner skiljde $1.2\times10^{-4}$. Skälet var plattformsberoende val mellan två exakt lika lexikografiska nivåer i 281 nådda tillstånd. |
| Strikt paritet, arbetsstation | PASS, exakt | Arbetsstationen som utförde den konfirmatoriska utvärderingen. |

**Beroende av likhetsval.** Kommunvisa orakeldiagnostiker beror på hur exakta likheter bryts och kan därför vara plattformsberoende. Kriterievärdena gör det inte.

**Ytterligare en lärdom.** Validering kan också förkasta korrekt kod på grund av en felaktig deklarerad olikhet. Det hände i E1-lite G1, kontroll V7. FAIL bevarades och rättades genom den nya deklarerade grinden G1-R.

### C.2 Evidensskattning i lärandestudierna [NM]

Dessa resultat gäller numerisk beräkning av evidens, inte själva beslutsproblemet.

- **D1 [explorativt, status tilldelad efter körningen].** Slumpvandringsbaserad sekventiell Monte Carlo (Del Moral, Doucet & Jasra, 2006) gav opålitliga evidensskattningar i en blind 16-dimensionell diagnostik. Replikatens utslag skilde sig i upp till 11 av 24 fall, så upptäcktsandelarna från den grinden tolkas inte.
- **D2 [explorativt, deklarerat].** Validerade kvadraturreferenser fastställdes i två steg: i en dimension genom G3.3a (vars FAIL sparades) och den brytpunktsuppdelade G3.3a-R, med noggrannhet inom $10^{-3}$ nats; i två dimensioner genom G3.3b-1, med 48 av 48 referenser validerade och exakta nollfall exakt återgivna.
- **D3 [explorativt, prospektivt jämfört].** En evaluatorinformerad riktad uppdelning reducerade felet i evidensskattningen på **en enda fixerad syntetisk tvådimensionell historia**. Genomsnittligt absolut fel i log-Bayesfaktor föll från 1,625 till 0,404 med 512 partiklar och från 0,457 till 0,181 med 2 048. Antalet likelihoodberäkningar minskade, men inte körtiden i alla fall: 136 s mot 118 s vid 512 partiklar och 274 s mot 339 s vid 2 048. Metoden bygger på geometri som evaluatorn känner till; den är ingen färdig blind högdimensionell estimator.

En separat teknisk metodnot kan vara lämpligare för denna del än seriens huvudtext.

### C.3 Konfirmatorisk proveniens

| Post | Registrerat värde |
|:---|:---|
| Deklaration | Blocket `f0c` i `a2_config.json`, 2026-11-06T04:10:33Z; konfigurationssnapshot i `records/`. |
| Kodfrysning | Fingeravtryck F_c `6c5c58ff6e22e3341c46959d8edb1bc25eb99863644ea2a5151b29458a38961d` över 48 filer; konfiguration SHA-256 `4ac1dcb244bbf2c68ee354805e99f1ac5476d419af087b576b4a64c57257a9c9`. |
| Testpool | 40 × 19 uniforma dragningar från reserverad ström (spawn key 9, poolversion 1); pool SHA-256 `b14d9984b3399c2e51661a811d7321af2bbc4a59f576a5127fa489577b112119`; genererad 2026-11-06T06:09:41Z. |
| Utvärdering | 120 jobb (40 världar × 3 planeringsvillkor), 06:12:34Z–09:08:42Z; 8 arbetare; Python 3.10.12, NumPy 2.2.6, SciPy 1.15.3. |
| Förhandsförbindelse | Poolens fullständiga hash skickades som text till granskaren (`records/f0c_pool_commitment_as_sent.txt`). **Enligt användarens uppgift** kom bekräftelsen omkring 06:12Z, och utvärderingen startade därefter. Exakt ordning är inte oberoende tidsstämplad. |
| Säkerhetsåtgärder och begränsningar | Den deklarerade slumpströmmen återskapar samma hash; kod och konfiguration var frysta före poolgenereringen. Det begränsar kraftigt möjligheten att välja pool selektivt men är inget historiskt bevis om den exakta tidsordningen. |
| Omkörning | En oberoende upprepning av sammanfattningen är byteidentisk utom avrundning av flyttal i JSON ($\le1.8\times10^{-15}$). |
| Incident | Tomma filer med feltext i filnamnen uppstod på arbetsstationen och raderades före inspektion. Ursprung okänt. Ingen indikation på påverkan av frysta indata eller körningar: källistorna i manifesten motsvarar frysningen. |
| Utvecklingsreferens | 16 utvecklingsvärldar; $\Delta=-1,195$ [−1,801, −0,588], SD 1,138; 15 av 16 negativa. Utvecklings- och konfirmationsdata blandas aldrig. |

### C.4 Figurer och följeslagsfiler

- Figurerna 1–5 skapas av `paper/make_figures.py` enbart från frysta resultat, med indatahashar i `paper/figures/wp1_figure_sources.json`.
- Tabellerna i bilaga B skapas av `diag/a2_f0c_exploratory_appendix.py` mot deklarationen i `records/a2_f0c_exploratory_appendix_declaration.json`.
- `paper/check_numbers.py` kontrollerar alla tal i rapporten mot ett källmärkt register.
- Följeslagsarkivet innehåller de frysta indata som behövs för att återskapa de fem figurerna och båda bilagornas tabeller.

### C.5 Metodologisk redovisning

Forskningsprogrammet initierades och leddes av **Björn Kenneth Holmström**. A2-experimenten utformades och specificerades med omfattande AI-stöd. **Claude (Anthropic)** implementerade, verifierade och körde studierna samt skrev manusutkastet. **ChatGPT (OpenAI)** granskade grindarna och utkasten. Detta är en dokumenterad granskning med flera AI-agenter, **inte oberoende mänsklig sakkunniggranskning**. AI-kontrollerna är inte en oberoende mänsklig kodrevision. En extern mänsklig granskning av den frysta lösaren och utvärderaren, tillsammans med offentlig kod och poolmanifest, är ett viktigt nästa steg.

Utkast v0.2 är inte sakkunniggranskat.

## Referenser

Del Moral, P., Doucet, A., & Jasra, A. (2006). Sequential Monte Carlo samplers. *Journal of the Royal Statistical Society: Series B, 68*(3), 411–436. https://doi.org/10.1111/j.1467-9868.2006.00553.x

Fel'dbaum, A. A. (1960). Teoriya dual'nogo upravleniya. I [Dual control theory. I]. *Avtomatika i Telemekhanika, 21*(9), 1240–1249. https://www.mathnet.ru/eng/at12624 (in Russian; parts II–IV followed in 1960–61)

Guez, A., Silver, D., & Dayan, P. (2012). Efficient Bayes-adaptive reinforcement learning using sample-based search. *Advances in Neural Information Processing Systems 25*. https://proceedings.neurips.cc/paper_files/paper/2012/file/35051070e572e47d2c26c241ab88307f-Paper.pdf

Hansen, L. P., & Sargent, T. J. (2008). *Robustness*. Princeton University Press. ISBN 978-0-691-11442-2. https://doi.org/10.1515/9781400829385

Holm, S. (1979). A simple sequentially rejective multiple test procedure. *Scandinavian Journal of Statistics, 6*(2), 65–70. https://www.jstor.org/stable/4615733

Holmström, B. K. (2026). *What Should We Optimize, and What Must We Know? Three Computational Experiments on Model Error, Future Goals, and the Cost of Learning*. Systemic Optimization — Working Paper 0, Draft v0.2.

Howard, R. A. (1966). Information value theory. *IEEE Transactions on Systems Science and Cybernetics, 2*(1), 22–26. https://doi.org/10.1109/TSSC.1966.300074

Iyengar, G. N. (2005). Robust dynamic programming. *Mathematics of Operations Research, 30*(2), 257–280. https://doi.org/10.1287/moor.1040.0129

Lempert, R. J., Popper, S. W., & Bankes, S. C. (2003). *Shaping the Next One Hundred Years: New Methods for Quantitative, Long-Term Policy Analysis* (MR-1626-RPC). RAND Corporation. https://doi.org/10.7249/MR1626

Marler, R. T., & Arora, J. S. (2004). Survey of multi-objective optimization methods for engineering. *Structural and Multidisciplinary Optimization, 26*, 369–395. https://doi.org/10.1007/s00158-003-0368-6

Nilim, A., & El Ghaoui, L. (2005). Robust control of Markov decision processes with uncertain transition matrices. *Operations Research, 53*(5), 780–798. https://doi.org/10.1287/opre.1050.0216

Puterman, M. L. (1994). *Markov Decision Processes: Discrete Stochastic Dynamic Programming*. Wiley. https://doi.org/10.1002/9780470316887

Raiffa, H., & Schlaifer, R. (1961). *Applied Statistical Decision Theory*. Division of Research, Graduate School of Business Administration, Harvard University.

Walters, C. J. (1986). *Adaptive Management of Renewable Resources*. Macmillan.

Walters, C. J., & Hilborn, R. (1978). Ecological optimization and adaptive management. *Annual Review of Ecology and Systematics, 9*, 157–188. https://doi.org/10.1146/annurev.es.09.110178.001105

**Ursprungliga forskningsartefakter** (Holmström, 2026; unpublished specifications and frozen computational results): the A2 gate designs, declarations and results notes listed in Appendix A. Dessa är primärkällorna för alla experimentella tal. De externa referenserna redovisar endast konceptuella och metodologiska föregångare.
